--
-- PostgreSQL database dump
--

\restrict 05YQk86kfEfZ7TqpRaQc0WmDpLyycOhhfKT87cg26ye6chz7n4qeTy2fxrxh6fu

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: BillStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BillStatus" AS ENUM (
    'UNPAID',
    'PENDING',
    'PAID',
    'OVERDUE',
    'PARTIAL',
    'WAIVED'
);


--
-- Name: BillType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BillType" AS ENUM (
    'MONTHLY',
    'CHECKIN',
    'CHECKOUT'
);


--
-- Name: CheckoutStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CheckoutStatus" AS ENUM (
    'DRAFT',
    'PENDING_REFUND',
    'COMPLETED'
);


--
-- Name: InvoiceItemType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvoiceItemType" AS ENUM (
    'PLATFORM_FEE',
    'SMS_ADDON',
    'DISCOUNT',
    'OTHER'
);


--
-- Name: MaintenanceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MaintenanceStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED'
);


--
-- Name: MeterType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MeterType" AS ENUM (
    'WATER',
    'ELECTRIC'
);


--
-- Name: ParcelStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ParcelStatus" AS ENUM (
    'PENDING',
    'PICKED_UP'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


--
-- Name: PlanTier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlanTier" AS ENUM (
    'FREE_TRIAL',
    'STARTER',
    'GROWTH',
    'ENTERPRISE',
    'PRO'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'OWNER',
    'TENANT',
    'STAFF'
);


--
-- Name: RoomStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RoomStatus" AS ENUM (
    'AVAILABLE',
    'OCCUPIED',
    'MAINTENANCE'
);


--
-- Name: SmsTier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SmsTier" AS ENUM (
    'SIZE_S',
    'SIZE_M',
    'SIZE_L'
);


--
-- Name: SubmissionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubmissionStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


--
-- Name: VehicleType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VehicleType" AS ENUM (
    'CAR',
    'MOTORCYCLE',
    'OTHER'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
    revoke trigger on cron.job_run_details from postgres;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
begin
    if not exists (
        select 1
        from pg_catalog.pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
        set search_path to ''
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8.0', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
            set search_path to ''
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_prefix_len INT;
    v_prefix_start INT;
    v_combined_levels INT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_prefix_len := length(coalesce(prefix, ''));
    v_prefix_start := coalesce(array_length(string_to_array(coalesce(prefix, ''), v_delimiter), 1), 1);
    v_combined_levels := coalesce(array_length(string_to_array(v_prefix, v_delimiter), 1), 1);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT array_to_string(path_tokens[$1:$2], '/') AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $3 || '%%'
                  AND bucket_id = $4
                  AND array_length(objects.path_tokens, 1) <> $2
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT array_to_string(path_tokens[$1:$2], '/') AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $3 || '%%'
               AND bucket_id = $4
               AND array_length(objects.path_tokens, 1) = $2
             ORDER BY %I %s)
            LIMIT $5 OFFSET $6
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING v_prefix_start, v_combined_levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := substring(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter) from v_prefix_len + 1);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := substring(v_current.name from v_prefix_len + 1);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
    v_sort_order text;
    v_sort_column text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    -- Defense-in-depth: this function is independently reachable and must
    -- not trust p_sort_order/p_sort_column to already be validated by a
    -- caller. Normalize to the same strict allow-list storage.search_v2
    -- uses before interpolating anything into dynamic SQL below.
    v_sort_order := lower(coalesce(p_sort_order, 'asc'));
    IF v_sort_order NOT IN ('asc', 'desc') THEN
        v_sort_order := 'asc';
    END IF;

    v_sort_column := lower(coalesce(p_sort_column, 'updated_at'));
    IF v_sort_column NOT IN ('updated_at', 'created_at') THEN
        v_sort_column := 'updated_at';
    END IF;

    IF v_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        v_sort_column,
        v_cursor_op,
        v_sort_column,
        v_sort_order,
        v_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: Bill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Bill" (
    id text NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    "roomId" text NOT NULL,
    "rentAmount" double precision NOT NULL,
    "waterAmount" double precision NOT NULL,
    "waterUnits" double precision,
    "electricAmount" double precision NOT NULL,
    "electricUnits" double precision,
    "commonFee" double precision DEFAULT 0 NOT NULL,
    "parkingFee" double precision DEFAULT 0 NOT NULL,
    "internetFee" double precision DEFAULT 0 NOT NULL,
    "otherFee" double precision DEFAULT 0 NOT NULL,
    "totalAmount" double precision NOT NULL,
    status public."BillStatus" DEFAULT 'UNPAID'::public."BillStatus" NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paymentDate" timestamp(3) without time zone,
    "slipUrl" text,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "balanceForward" double precision DEFAULT 0 NOT NULL,
    "paidAmount" double precision DEFAULT 0 NOT NULL,
    "electricReading" double precision,
    "waterReading" double precision,
    "advanceRent" double precision DEFAULT 0 NOT NULL,
    "keyDeposit" double precision DEFAULT 0 NOT NULL,
    "securityDeposit" double precision DEFAULT 0 NOT NULL,
    type public."BillType" DEFAULT 'MONTHLY'::public."BillType" NOT NULL,
    "vehicleFee" double precision DEFAULT 0 NOT NULL,
    "slipTransRef" text,
    "tenantId" text,
    "waivedAt" timestamp(3) without time zone,
    "waivedReason" text
);


--
-- Name: Checkout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Checkout" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "waterReadingFinal" double precision,
    "electricReadingFinal" double precision,
    "finalUtilityAmount" double precision DEFAULT 0 NOT NULL,
    "finalRentAmount" double precision DEFAULT 0 NOT NULL,
    "outstandingAmount" double precision DEFAULT 0 NOT NULL,
    "depositAmount" double precision DEFAULT 0 NOT NULL,
    "deductionAmount" double precision DEFAULT 0 NOT NULL,
    "deductionNote" text,
    "deductionPhotoUrl" text,
    "netAmount" double precision DEFAULT 0 NOT NULL,
    "refundSlipUrl" text,
    status public."CheckoutStatus" DEFAULT 'DRAFT'::public."CheckoutStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "ownerId" text NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    "totalAmount" double precision NOT NULL,
    status public."BillStatus" DEFAULT 'UNPAID'::public."BillStatus" NOT NULL,
    "slipUrl" text,
    "paidAt" timestamp(3) without time zone,
    "dueDate" timestamp(3) without time zone,
    note text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "slipAmount" double precision,
    "slipTransRef" text,
    "slipVerified" boolean DEFAULT false
);


--
-- Name: InvoiceItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InvoiceItem" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    type public."InvoiceItemType" NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "unitPrice" double precision NOT NULL,
    amount double precision NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: MaintenanceRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MaintenanceRequest" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "imageUrl" text,
    status public."MaintenanceStatus" DEFAULT 'PENDING'::public."MaintenanceStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "scheduledNote" text,
    "preferredAt" timestamp(3) without time zone,
    "aiCategory" text,
    "aiTechnician" text,
    "aiUrgency" text
);


--
-- Name: MeterSubmission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MeterSubmission" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "tenantId" text NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    type public."MeterType" NOT NULL,
    reading double precision NOT NULL,
    "photoUrl" text,
    status public."SubmissionStatus" DEFAULT 'PENDING'::public."SubmissionStatus" NOT NULL,
    note text,
    "approvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Parcel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Parcel" (
    id text NOT NULL,
    "trackingNumber" text,
    "recipientName" text,
    "roomId" text NOT NULL,
    status public."ParcelStatus" DEFAULT 'PENDING'::public."ParcelStatus" NOT NULL,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "pickedUpAt" timestamp(3) without time zone,
    "isDeleted" boolean DEFAULT false NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "billId" text NOT NULL,
    amount double precision NOT NULL,
    "slipUrl" text,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "verifiedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Property; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Property" (
    id text NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    "imageUrl" text,
    "leaseTemplate" text,
    "ownerId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "companyName" text,
    "promptPayName" text,
    "promptPayNo" text,
    "taxId" text,
    "defaultCommonFee" double precision,
    "defaultInternetFee" double precision,
    "defaultParkingFee" double precision,
    "electricRate" double precision,
    "waterRate" double precision,
    "signatureUrl" text,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "defaultAdvanceRent" double precision,
    "defaultCarFee" double precision,
    "defaultKeyDeposit" double precision,
    "defaultMotorcycleFee" double precision,
    "defaultSecurityDeposit" double precision,
    "enableTenantReport" boolean DEFAULT false NOT NULL,
    "reportEndDay" integer DEFAULT 24 NOT NULL,
    "reportStartDay" integer DEFAULT 20 NOT NULL
);


--
-- Name: PropertyStaff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PropertyStaff" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "propertyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RegistrationCode; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RegistrationCode" (
    id text NOT NULL,
    code text NOT NULL,
    months integer DEFAULT 1 NOT NULL,
    "isUsed" boolean DEFAULT false NOT NULL,
    "usedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Room; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Room" (
    id text NOT NULL,
    number text NOT NULL,
    floor text,
    "rentPrice" double precision NOT NULL,
    "inviteCode" text,
    "propertyId" text NOT NULL,
    status public."RoomStatus" DEFAULT 'AVAILABLE'::public."RoomStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "imageBalcony" text,
    "imageBathroom" text,
    "imageFacility" text,
    "imageMain" text,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "electricMeterStart" double precision DEFAULT 0,
    "hasAircon" boolean DEFAULT false NOT NULL,
    "hasFan" boolean DEFAULT false NOT NULL,
    "hasFurniture" boolean DEFAULT false NOT NULL,
    "waterMeterStart" double precision DEFAULT 0
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: SmsAddon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SmsAddon" (
    id text NOT NULL,
    "ownerId" text NOT NULL,
    tier public."SmsTier" DEFAULT 'SIZE_S'::public."SmsTier" NOT NULL,
    quota integer NOT NULL,
    used integer DEFAULT 0 NOT NULL,
    "resetMonth" integer NOT NULL,
    "resetYear" integer NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "thaibulkApiKey" text,
    "thaibulkApiSecret" text,
    "thaibulkSenderId" text DEFAULT 'JadHor'::text
);


--
-- Name: SystemSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SystemSettings" (
    id text NOT NULL,
    "heroHeadline" text,
    "heroSubheadline" text,
    "heroImageUrl" text,
    "contactEmail" text,
    "contactPhone" text,
    "pricingMonthly" double precision DEFAULT 500,
    "pricingYearly" double precision DEFAULT 5000,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "roomId" text,
    "leaseStart" timestamp(3) without time zone,
    "leaseEnd" timestamp(3) without time zone,
    "depositAmount" double precision,
    "idCardNumber" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "contractIpAddress" text,
    "contractPdfUrl" text,
    "contractSignedAt" timestamp(3) without time zone,
    "contractUserAgent" text,
    "signatureUrl" text,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "lineUserId" text,
    "phoneNumber" text,
    address text,
    "emergencyContact" text,
    "emergencyPhone" text,
    "firstName" text,
    "lastName" text,
    "moveInDate" timestamp(3) without time zone,
    "profileCompleted" boolean DEFAULT false NOT NULL,
    "eContractData" jsonb,
    "eContractStatus" text DEFAULT 'NONE'::text NOT NULL,
    "eContractToken" text,
    "dataAnonymizedAt" timestamp(3) without time zone,
    "moveOutDate" timestamp(3) without time zone
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text,
    name text,
    image text,
    role public."Role" DEFAULT 'TENANT'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    username text,
    "pdpaAcceptedAt" timestamp(3) without time zone,
    "planExpiresAt" timestamp(3) without time zone,
    "planTier" public."PlanTier" DEFAULT 'FREE_TRIAL'::public."PlanTier" NOT NULL,
    "lineChannelAccessToken" text,
    "lineUserId" text,
    "lineBindingCode" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    "resetTokenHash" text,
    "lineBindingCodeExpiresAt" timestamp(3) without time zone
);


--
-- Name: Vehicle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Vehicle" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "licensePlate" text NOT NULL,
    brand text,
    color text,
    type public."VehicleType" DEFAULT 'MOTORCYCLE'::public."VehicleType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: VerificationToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VerificationToken" (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL,
    versioning_status text DEFAULT 'DISABLED'::text NOT NULL,
    CONSTRAINT buckets_versioning_dark_check CHECK ((versioning_status = 'DISABLED'::text)),
    CONSTRAINT buckets_versioning_standard_only_check CHECK (((type = 'STANDARD'::storage.buckettype) OR (versioning_status = 'DISABLED'::text))),
    CONSTRAINT buckets_versioning_status_check CHECK ((versioning_status = ANY (ARRAY['DISABLED'::text, 'ENABLED'::text, 'SUSPENDED'::text])))
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    archived_at timestamp with time zone,
    is_delete_marker boolean DEFAULT false NOT NULL,
    is_versioned boolean DEFAULT false NOT NULL
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
cmpydz4o50001ju04t9ewtpcw	cmpy7gsse0001r2ag8ry4b9km	oauth	line	U88f912f73a60cd69b861c67e89c4d56e	qEDTx1ofZYeNzpmBZIl5	eyJhbGciOiJIUzI1NiJ9.puXHmiRgBDd6J3X16U9cpNyu7uHvxOmBKe2NNZM9Q_X-zCugMjWPq0GRGf_Cx2Gi9FHob-n8mHR0Dc56af1jlk5YklhqzIhpdkDU6eBo3-jrQ246apps-J1JbSwDxayod-9JjHraHz3BEhKW9Y9yamGLijYXiBIvhA_Ue85xzFo.7mCrnkyzfaZVdh4IxPIVC6XdnwyOdgAdRHfM6pABQ6c	1783102487	Bearer	openid profile	eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2FjY2Vzcy5saW5lLm1lIiwic3ViIjoiVTg4ZjkxMmY3M2E2MGNkNjliODYxYzY3ZTg5YzRkNTZlIiwiYXVkIjoiMjAxMDI4NjkwNiIsImV4cCI6MTc4MDUxNDA4NywiaWF0IjoxNzgwNTEwNDg3LCJhbXIiOlsibGluZXNzbyJdLCJuYW1lIjoi4Lit4Lij4Lij4LiW4LiT4LieIOC4qC4iLCJwaWN0dXJlIjoiaHR0cHM6Ly9wcm9maWxlLmxpbmUtc2Nkbi5uZXQvMGhTLXZRWFVvNERBSkxLQk9UbnVaelZUWnRBbTg4QmdwS014NFJZR3BfQURCbUcwaFdkRXRBYlR3aEJ6QXhFQmhSSnhvV1lUb2dWRE51QnpFcmQwMUhKQ2g3RzNBd1dVME1KVFUzUGdwd01Hc3ZlUUltS2d3QkRCNXpQR1FSYURjMk5EZ2JHUzkwRVd3dmZoTW1QRTBmWVRCREZ6VW5jQXBkSEFjIn0.errPhtxlzq3XN5Cj-lF_epBcIIIfeEzUBin2YioA27M	\N
cmqd5ou0u0002i804ltiomofg	cmqd5ou0a0000i804nfcl5gxv	oauth	line	Ueb0767f75c2a03c28cad3e483cbc5ebd	KrCHlomucZUNeqLX3E7b	eyJhbGciOiJIUzI1NiJ9.7mocV5M5sXTJ0teeuq8Dfw9l-DL__eCq1ioxLSweERkMP_rFgBhMBtcvsIkde6dccnNuJ6jdhXKLzw0rmLOZGmqqtfiknieAj7EVJevb3Y_h0isDxPLO_spJPyx1hx16jUwVls0KCb8s0vA8OywZLq4wsvw2sh2xnYyGzqzSL9s.J8-7ItTe-4jzK4dJbd7JpJA70QTp3IhIhaA5Z53dsP0	1783995567	Bearer	profile openid	eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2FjY2Vzcy5saW5lLm1lIiwic3ViIjoiVWViMDc2N2Y3NWMyYTAzYzI4Y2FkM2U0ODNjYmM1ZWJkIiwiYXVkIjoiMjAxMDI4NjkwNiIsImV4cCI6MTc4MTQwNzE2NywiaWF0IjoxNzgxNDAzNTY3LCJhbXIiOlsibGluZXFyIl0sIm5hbWUiOiJNRUdBTUFYIEJhbmduYSIsInBpY3R1cmUiOiJodHRwczovL3Byb2ZpbGUubGluZS1zY2RuLm5ldC8waF9pTEpXMC1KQUVaeE14RDhYdUJfRVUxMkRpc0dIUVlPQ1FkR2RRWm5XM1VQQ2tSRlNsRVlJd00wVm5kVVZFNURHRkljSndabVhDTUoifQ.APiwVQToVSz8beYfFV1UZMqXNBiE_SD2eSj4Hp1s1EY	\N
cmro2lkeu0002l104g6543tcb	cmro2lkde0000l10412mw52xf	oauth	line	Ua286a2402446549f5fd345492aed600f	aTTtmTgZuwViwVhJ8tyY	eyJhbGciOiJIUzI1NiJ9.w_O2EHoNKvsG0XZ2ZqT2lBHnUJDql1l7342FX1wsZSaxkqMHnIgrA58BQWQH3AFCmw7pVVa-cBnBMMZRTW-XHnXmPx9r30kN538oUweM6B_p9NgNEYBG7VlIov64ULds4FnYssqdPyZ57qGYYGAqIDodGvVZ_cldLyExYDjAl5I.8jY8_1ZuUL7SGFUe8iDEt4z4QbN9RCGbTcBsgE8gbW0	1786832286	Bearer	openid profile	eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2FjY2Vzcy5saW5lLm1lIiwic3ViIjoiVWEyODZhMjQwMjQ0NjU0OWY1ZmQzNDU0OTJhZWQ2MDBmIiwiYXVkIjoiMjAxMDI4NjkwNiIsImV4cCI6MTc4NDI0Mzg4NiwiaWF0IjoxNzg0MjQwMjg2LCJhbXIiOlsibGluZWF1dG9sb2dpbiJdLCJuYW1lIjoi5ZCs6LW35p2lIiwicGljdHVyZSI6Imh0dHBzOi8vcHJvZmlsZS5saW5lLXNjZG4ubmV0LzBoZE5VTnRDaUNPMkZvTnk3NnBUTkVObFJ5TlF3ZkdUMHBFQVI5VjAxbFpsQkJVbnRuVndFbkRrNWlaUVZBVUN3LVZWVW5BVTR6YlFZWCJ9.EtRXeq3F6metG1wnB78Mmsn33V6LZXMxm2U0JutxPS8	\N
cmt5yqpcf0002l104593fvrys	cmt5yqpaq0000l1045x2mwekg	oauth	line	U73bba04afe32a461a0967732a49c7768	rK1qOtcksPxSo4M2nR98	eyJhbGciOiJIUzI1NiJ9.BVcSrklDVj3sebsMJ3nzDMCjfj4g6zSiRquG_gLrH9odrRWN9EA6XlHTOoK_xxnSl-Ysg4uIoslS6rTqOWQOP6FISJ-cIFH5O7IrwLXt_c0dK57eWEtkTLpmeT9K7H6mu0obT7ZmuOUCILdPlDkiah2u2MIQOv8TJjiXdd_m9Eo.i1UFjpgejdozHUy43L8-07Lm1I0H1lNMOSuzQodlXg0	1790090981	Bearer	profile openid	eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2FjY2Vzcy5saW5lLm1lIiwic3ViIjoiVTczYmJhMDRhZmUzMmE0NjFhMDk2NzczMmE0OWM3NzY4IiwiYXVkIjoiMjAxMDI4NjkwNiIsImV4cCI6MTc4NzUwMjU4MSwiaWF0IjoxNzg3NDk4OTgxLCJhbXIiOlsicHdkIiwibWZhIl0sIm5hbWUiOiJGZXJuIEZlcm4iLCJwaWN0dXJlIjoiaHR0cHM6Ly9wcm9maWxlLmxpbmUtc2Nkbi5uZXQvMGhNdDlnY2k0Z0Vsc0VIZzNIZnFwdERIbGJIRFp6TUJRVGZIME9iU05NVG1vc0xWUmZPWGhhT1NOSkdEZ3VLZ1lFYkg4S2JTVWJUbTU5TVNKNE9DMDRZVlZfRTJoQ0t5Vm1aUXNJYW1aV09uZHlkU0ZaUlF0ZlhWNU1TaDVOS0F4ZmVDc29ZMXNkTzJwVGQxeFhUQTRDZEg5ZkVRdFFLejVLYmlZIn0.KAhFj7hXmV3khC_ivUGMbxF97n7N_KBlpeT99_1jGPc	\N
cmt8fo40m0002ih04bsiocjff	cmt8fo3ze0000ih04cql1wsfa	oauth	line	U85faa1690064b8538f273dcbb2095e0d	6lFaGdi0e9HTSsqWoiZQ	eyJhbGciOiJIUzI1NiJ9.NjMcLvT8uSQsjY_c6IpXne6bvqMJds3z2dGwujHOrk5Q_k-Q61Hac-m9NF0a8WOuhFUoFLz5Npc-mRgJAinQJXhhMsru189TiePD3uvoym3ub8zgMssf6O1EY6l1_ufPVEr9mSUt2NeUjU00TA-HvREN_gvT4K1_WWlHtsJI520.bI2s6JaN2hzz1wY8WwkWWzx_qohTbEZ26C_Z3Xc_2V0	1790240346	Bearer	profile openid	eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2FjY2Vzcy5saW5lLm1lIiwic3ViIjoiVTg1ZmFhMTY5MDA2NGI4NTM4ZjI3M2RjYmIyMDk1ZTBkIiwiYXVkIjoiMjAxMDI4NjkwNiIsImV4cCI6MTc4NzY1MTk0NiwiaWF0IjoxNzg3NjQ4MzQ2LCJhbXIiOlsibGluZXFyIl0sIm5hbWUiOiIhTXVr8J-QsCIsInBpY3R1cmUiOiJodHRwczovL3Byb2ZpbGUubGluZS1zY2RuLm5ldC8waExKbTc4WXN6RTJWUVRnM0pCUUZzTWkwTEhRZ25ZQlV0S0hoY1VYUWRTd2QxSzFReE9TNWNWbmNkU2dWNkxGeGpQQzVmVUNCTEhRQXBZU3N6R2xFcGMzY3VKaWg5R3pWTktGMEZmUWxTRXlVaEtSeEpIbm9GZkFnVFRDZ0hleE0yTlZ3RVhDd3RGeE1tQ3paSWFuMGxjekE3UFRVVExnMVNBaUUifQ.ZG7kGgKl3XXb-IoIhFd0qbGQyT0ZH1BG_FG2C4uQNzg	\N
\.


--
-- Data for Name: Bill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Bill" (id, month, year, "roomId", "rentAmount", "waterAmount", "waterUnits", "electricAmount", "electricUnits", "commonFee", "parkingFee", "internetFee", "otherFee", "totalAmount", status, "dueDate", "createdAt", "updatedAt", "paymentDate", "slipUrl", "isDeleted", "balanceForward", "paidAmount", "electricReading", "waterReading", "advanceRent", "keyDeposit", "securityDeposit", type, "vehicleFee", "slipTransRef", "tenantId", "waivedAt", "waivedReason") FROM stdin;
cmr3ei72f0001ic04wlahro4u	7	2026	cmpy7gt040006r2agan42aflc	4500	540	30	700	100	100	100	150	0	6090	UNPAID	2026-07-23 00:00:00	2026-07-02 11:08:15.303	2026-07-02 11:08:47.979	\N	\N	t	0	0	\N	\N	0	0	0	MONTHLY	0	\N	\N	\N	\N
\.


--
-- Data for Name: Checkout; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Checkout" (id, "tenantId", "waterReadingFinal", "electricReadingFinal", "finalUtilityAmount", "finalRentAmount", "outstandingAmount", "depositAmount", "deductionAmount", "deductionNote", "deductionPhotoUrl", "netAmount", "refundSlipUrl", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Invoice" (id, "invoiceNumber", "ownerId", month, year, "totalAmount", status, "slipUrl", "paidAt", "dueDate", note, "createdAt", "updatedAt", "slipAmount", "slipTransRef", "slipVerified") FROM stdin;
cmqb304iq0001jo04qzie7ntz	INV-202606-0001	cmpy7gsse0001r2ag8ry4b9km	6	2026	199	PAID	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4SNlRXhpZgAATU0AKgAAAAgABgESAAMAAAABAAEAAAEaAAUAAAABAAAAVgEbAAUAAAABAAAAXgEoAAMAAAABAAIAAAITAAMAAAABAAEAAIdpAAQAAAABAAAAZgAAAMAAAABIAAAAAQAAAEgAAAABAAeQAAAHAAAABDAyMjGRAQAHAAAABAECAwCgAAAHAAAABDAxMDCgAQADAAAAAQABAACgAgAEAAAAAQAABFagAwAEAAAAAQAABaikBgADAAAAAQAAAAAAAAAAAAYBAwADAAAAAQAGAAABGgAFAAAAAQAAAQ4BGwAFAAAAAQAAARYBKAADAAAAAQACAAACAQAEAAAAAQAAAR4CAgAEAAAAAQAAIj0AAAAAAAAASAAAAAEAAABIAAAAAf/Y/9sAhAABAQEBAQECAQECAwICAgMEAwMDAwQFBAQEBAQFBgUFBQUFBQYGBgYGBgYGBwcHBwcHCAgICAgJCQkJCQkJCQkJAQEBAQICAgQCAgQJBgUGCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQn/3QAEAAj/wAARCACgAHoDASIAAhEBAxEB/8QBogAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoLEAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+foBAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKCxEAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDzH/hW/wDsfpR/wrf/AGP0r79j+Gpc/cwB7VZX4bQr1jzQB+eVx8MlmhKMn6Vx7/CzaxXy+ntX6en4ZxyHCJj8K52b4WnzDmP9KAPzjHwu/wCmf6Uf8Ku/6Z/pX6L/APCrsDJTp7V9LaJ+wJ8Vb7SrjWtS06SGCLTl1GNIU8+aVZMCJUjTqWJGf7o6+lAH4pf8Ku4/1f6Un/Crf+mf6V+uuvfsdfE7wp4n0nwh4o0v+z77Wtv2ZZWXHzHADFN2PpVfWf2RPiRos08b6W1wtq5imkgG+NJU2h4iePnjLqrgdCaAPyS/4Vcenl/pT4/hi8LiSNMEe1frOv7IfxWaZbdvD90pZA+SgwFzjJP9OuOgrR8Q/sZ/FDw5PHb3Gmi4Ms0luptmV182NmXZngAttOz1x68UAfmFZ/DZLyATJH9RjpVr/hVf/TP9K/QHU/gvqngTXW0bWogsoVGkUKw2hxkZDqpBHfit+H4WLMVCIMHvjtQB+b1p8DkuLwao8X7qIgsMdT2/+vXoFv8ADJbpggj/AEr9FLf4YwwwC1WMbcY6Vkj4aHTpSNnB6HHagD4Qn+FOn2Vu09ynyqOeK4F/BpLkpbqB247V+gGu+EHvmFrGv7pP1P8AgK53/hXH+wPyoA//0P2jm+HoiAXy+tQf8ICv/PMV+mepfAKWOIT7tqIPmJA4H+Arw+1vfgxLrP8AYcPiK0kuQ2zqfLz0wJNvl/8Aj1eFnPFGWZc4LMMRClzaR55Rjd9ldq/ojlxOOoUbKtNRvtdpHyPF8Ojt3mPr04q0PhiJY1cx+3Sv0Wb4KS+X57Y2AZ3dsev0xV/QfhHp+taVHqOiXEV5byZ2ywMsiHHXDLkcV7HtocyhdXOjmV7H5tr8LwjBljGR04r6Zt/jV8SbHWrW4tvLhs4LL+z3g5CGNsDLbQG+QjKbcbfevp5/gn5TKkhCluFBwM/Sqt98CLFvLOpRxnLBI/MVfvN0C57n0FW5JblXPjfVvEHjT4n+JdD13WLk2zaYSlvNKfM2qrHy3bdg5C+4z35r1q08HazBqEepav4ns5USKSKFwkQMhuWTezq5IYAxIzN14617Nf8Awq0nSbq2sNTuobaa8by7eORlRpWH8KA4LEegrWPwOm4XHT2qYVoSbjF7fgJSWyPmi/1Hxj4NYXo1O017+0Fdtqqq+TKBsWVlXJ3KOVHH41wEPjb4kaJfNqNtdLHPKQxCRIoyGd88DjLOx49fSvtYfA6X+7+lc9q/wIvDdCYL8rAdvStBnwF4i8Oaj471mbxDrxD3koG9iAoIUYHTjpV/R/huIYdmFY9sY4FfYkHwW1K61ASbcRRngY4rpF+Dd6jB1GCP0oA+Ml8AY/gqpqnw+E9obYJhm6H0r770r4a22pweZBNFJJHgPsZTgscL06ZPA96dD8KbS8Z3t54pfLzu2sp27cg5x0xtI9se1AH5fSfDN4TteLH4VF/wrf8A6Zn8q/UK2+EdrqW59Pmjn2Y3eWyvjPTO3pnFWf8AhSVx/d/SgD//0f6+P+CiHibXvDH7MWqXfhJXQT3dva3cicFbaQnfyOgJCqfY4r8T9ItPCvhnQBrWranBqkt/Cv2C3s5OVZl+d7kEbovKPyhCAXIyPk5P9OniPwtovjXw9d+EvFdnHfaZfxGCe3kGUZGGPbBHYjBHWvz6sf8Agl1+z9ZeLv7Yhv8AUm0/fuGmmQeWB/d80DzMf8Cr+EPpOfRxz/ijPKea5RyTXIoWnJpU3r7yVmno9u6WjPyLjngzGY7ExxFCz0tZu1vOx7R+xhq2reJv2dtMuvE8RdszW9u7/wAVupwh569x9BXN6R8EPjvoYgTw/q9rBb2EUapAk0ixy+XdLNsZfLIQGMMm5ezY24FfZGk6JofhnQIfCugQrb2dpEIYY4htWNVGAF+lfPcfwi+M/wBsi1ZPHDG5AijcmHGYY95K7QdmZGK7225wuFxX9TZL4YU4ZLgsux1aTnQpxhzRbje0Un5200PtqOWWw9KjOV3BJXWnSxwV18BfjDrMmky6zrFnPcWFwJRPMvmPDwhLQl49wbKlcAgENnqBTNR+Afxr8V3GjDxfq9rLb2F7DcSxxTSFtsKxowViq8vtZ8gAqzcGuxn+C/xkg8LL4Xg8ZlFkt5llcpIx86YfeR9+9VU84zx2xgV1t38OfirJokekxeLFS4gvFmjkMLA+THAESJsMN37zMhPQ9CK1n4TZW4uDqTala653rba5pDJobO/3nlR+BPxde+0S41fV7e9l0q6WRJZmLssZhMT4Hl7t+cFSrr6nOMV9BfB/wp4r8I+Ehonjq6Go3yyyPuRmdY0ZsqgdwGIA9enTtXkOtfAT4mzw3Fv4U8Zz28NxAYmExlmcMEjVGBLjGGQtxjOas3fwU+LIvbdtF8Xvb28EsMvlOsrhmWQtIGBkyQ67Rg9CPQ4r3cm4FwGAxP1qhOV33ba2ivwUVY3w2B9lPngn9/p/kfVBWx6BMn2okitETcYsj/PFfKmo/BD4nXl7c3kni1g9y6OVIlwpEPlsF2uuAz4cD+HGOah1T4K/GBrqNLPxuUgitTAsRikOJC7HzWPm/MQrbQPx7AV9iqEe53/WJLofUEem6Y42pFhuw4A/CuP+IGgaJqngHXdLvZDYw3Gm3cMlx8v7lJIHVn5IHygk8kDjqBVP4ZeC9d8GaE2na7qrancM/mCR93HGCBuLce3Sus8W2Vvd+GNQsNUTzLSe1nSVQzJ8rRsGG5QWXI4BAJHYdqznFLQ1hOTsfwVQeIvDvwe0iz+IXh/SdU1Sfxnra6/pmm20L6VIsWkxM0kzeXdP5djaXMyiHzh9nE6Mz7FZGr1v4X+BPCmL+azEPh7Sdf0XWvE0WueHbv7V4fuZZUuTPp0s8txDcn7HBcXG62lt8z3W2UsAWlOxF8O9A8P3Os/B7wglvMPDWlK+keI5tK1S2tWsLO6e7msLqbUIYre6upbREWKCCyeKd4Nm1Ch8z568U+GtP8ZadB4i0LRYvBnh46kkgufDFlaJbzRl4YQ1lNdwQ63K73NlHaS/Z7OHAkEYtptjmsToP6Av+CBng/wyvgf4nfE7RGKPrWsQ2dxp8li9lNZvZvcybcSsWMDfaM2y7FAg2N/GVT+gfGnf3f0P+Ffz5f8ABvbrnxQ1j4G+Krz4larf3lxqt02svp95KMafd3ur6wL2I2g3mzuDLFm4haXeJB80UTAg/wBCey3/ALv6imrEO/Q//9L+6P4n/E/wt8IPAmp/Er4g3gsdJ0iEzTOfvHsqovdmOFUdyQK/IWT/AILFva6smr3nwx1KDwvNMyLfeaPtBjUBi4h8vacIVJHmY5+9X19/wUn+F/jL4s/sla74f8DwPcahaSwah9li+/PFbNukRV7/AC/MB328Cvw3P/BRf4l6h4Z1fwrqEFk8t5ALC109LVt6RvAIXhx1x8qjHJOB0AxX9EeF3h7QzLLXi4YZYifPyyjzuHJHSzVl13u9Ekfxd47+L2LyjPVl08a8HTVPnhL2amqktbxd7aJJLlWrbXkf1CeAPiJ4R+JvgXT/AIleEJ0utH1O3FzbzDjKHrkdQy4IK9iMV59pH7TXwf1nWLbRNLurlri9ZUiJtZQnzSLCvz7NoBkZUBJxk14R/wAE/vh34v8Agp+yDoWh/EGKSO7EVxqEttIMvbxyEuIiD0YKM7exOK8RvP8AgqN+xz4X0228TLomoPpsiRLbXdva2HlG5kktv9F5uVaKVDdxSOXCRLz8+5cV+S59gsDg8ficLTbnCEpKDTWybSe2ultj+h+FcxzXM8pwWOmlSnOnCU4uO0nFNpa6W+9H6vb1iUbm4PZuTUZkt7mPa68L0YdRX5XQ/wDBXP8AZV1PX4dFtk1Sf7Te6fYi4i+wNBG2pQSzwmZxeHyGxEY/IlCXLSMixwvuFZFp/wAFiv2ZLjS21CPRPEDQiyuLpgq6czCa2a5T7E4S+Pl3J+yTfK+1IyuyZ45PkHyvK2foTdj9ZYzEMyR5Ozjcf6Crm+dhhjtX3/lX5I63/wAFnP2N/Ces6V4b11tatrvVZEhRFtIpFhuPOjgkhmeKZkV4XkXzDuKAcqxBGfd7X9vPwZ4w+PPin9mb4V+Hb/XvGPhWJnuY5ZrSytDNEsDy2/mvK8ySLFcKwJtxG2CFc44fJYXN3Pu9pJmxLCE+uRS5cj94g46noK8mk8WfFKK+njg8HK9quqwWkc39owjzLB0BlvdmzKmJvl8j7z4yCBXqhkYHZEnye4zTipPYznyIkE9qrbl6jj2/Cuf8Y+H4fF3g7VfCtzO9vHq1ncWbSDBZRPG0e5R6jdkfSt6K1jDhnXbmluIi8m9+F6DHQUrM0SR+Efgn/gi3ceDp9a1Xwr8V9T8Natf6raa1bXmhwNE0d1aeYVhdbme4As23jdbReWg+YrtLZHq3jb/glHp3xN0eXwj458Xf2lodnHcx6Xpgtpbe2s7eYWpS28y2uIrlYUltzcYhmiYyyH5ggC1+v0W2D91jrxzVjYkeGi4U8HH9afs+4lX7Hwh+wb+wvp/7CXhnXvBXh7xXqHifTtauUvkfVEiW4hmLStMqtEFQxN5ilRt3bg8js8kjMfvX7ao4+WouAd03A9e9LthHQt+ZpKLKUkz/0/72Y4xI5kkO5/QdK8Rj8BfB2P4mtqS6Hoq6wsYm84Wtv9p87efm37d+/H417LqsU39lXMeluBcmFxDgY+fb8n64r8oI7K6GqrbRQXY17zgnl85E277+fvZ7Yx75xxXtZbCb5uWVtLf15HgZxSo+57SmpWd1dLT08z9YdTmWDTp9ROSsMbSOo5yFXJwPcDpX5b3Px7/ZGi8L33g1PhRDZtcYni0660Kw+zzz3sQuC7JCXRs7EMpGXLbVG6QbR+olsdWXTYvtJBnSIb9vPzhecAYzzXzFB42+OM+pxape+DoEuAqQvKIZC6xGT94A3mDIjjCzKP42byRhkZj5yps9aTsfPfwZ+L37LfxF8U+G/B0/wttdM1rxDEmoRyvotiLTz7GxSZJBKuXBSKVo7csquAGGFFfbNn8DvgZFb/Z7XwRoEMKo8e1NNtVURuXLrgR42sZHJHQ7m9TWVq3jL4nw/wBvz6T4dLPZQq2loyr++k2sWVyJcH5gF/d+uenTgdS+KHx5sLwxf8IoHtHE+HitZ5H3KI/KJVZAAuWcNkg4Tco5AqXBiuj063+BnwQgkkj0/wAFaBCJ5mnl2aZaDfI5UtI2IuWYopLHk7R6Cu7tfCPhO01qTW7TTbOC9laRzPFBGsrNLtEhaQLuy+xd3PzbVz0FeY6P41+Jt5BpMGpaKsZn1F4LqVIZI0FqN+JUDPvjIwufNXDZ+Uent6xQIAxb9MfpUaoaj3IJJJ428s8BelT4a4X5T8+M/WpGeVGxlQnvUcjTyHEZAXsBVKJLsioknOy4B9D6ipAvk52EnHG3/PapxudhHMmeOc9qYwgkCmI7CvAz3o1QopDFmjufk2Y9KbI5U7YAOe9WX80IZo0DdmA/pioYZ0ZSuz5T6cEVCnY19mCxb5f3zAsOgHTirGLvsuB/u0eXAmPm/SpsN224+p/wrQtU0f/U/vXyIgQi8nuf/rdq+JLH9u79iTUvjefhZZ/Ebw/J4p2iz+wLcr5/niTb5ecYzn5evXivtC4by4pUt+QqEE/hX+c14F+IXw+g+I+jSW+oXE3iC68VGOW3Vl+zwxJeAKXBUNucHjaxHHOK+syHJ6eJclUbVl0Pm+Ls9q4D2fs4J37n+jZIY7aIzE428nfwAorMtNesdQiguIbuIx3OPJYOuHz93b65wcAelWL2zt5YZra5ZgsodGOB0YEV8gP+zH8PVvFnTxdfD7JGZFRZ7ZfKiIRFYAINqqU+Vv8AaYZwcVw4HD4Waft6nL292/8AkdWf4vMaLj9QoKon/e5bf0j7NmuNmUTnHf8AwpIGnWPzByx4A/z2rkfCj+GfDnh608O2urR3IstlmXlmjLtI3Ko2MAO38K4HGMDFaK+IfD5+eLUbV1VHlJWaPiOM7XY88Kp4Y9AeK8ucIpuKeh6EJy5FKUbPt28jciZ5FLSt8/b0Aqb5YjlBux3/AMMVnf2xpDbZftluNyhh+8TDK33WHPQ8Y7GqN/4n8M6Temxu9RtILlUEjJLNGrKh/i2kg498VnyLoRe3Q2BGkvDoNw9zUwRVU4GCOgPSvNfFHxt+EngfUtO8P+K/E2n2Wo6tdrYWlu8ymWS5bGIVRcnefQivRZLdY/mkYn3xQlfRsc3bZDfPu3YQ4I7dO1TTzNBiIfM3f0FPidVwbcZ46f8A1qRXjkbcvyN6HpScSlPTUr2zTMTIe3QfyAp6PM7M1ycYHC+/0oe2kB3IM1K/3BvwhHc9x9KrkRHM9rDPljbgE+/+GKixJ/dP4Bv8aUtskxByfX0+lTfWRR7VryntRhZH/9X+9VAjI1uy/I4xx78cV/MF4b/4Nj/hn4d+P0Xxei+MOry6ZFq41JdHOmwhti3HniH7R5+N38Bk8np/DX9QnmTcuRtUfhUJaVW3wxAZ716uGxtWi37J2uLH5TQxVvbxvYr6lb2d/p9xpl6/yTxvGSnBUOCDg/jX4qeI/wDgmB8B59Ksvh34k+LF8uvz/vrG7LWcN29nDNZ+RBhdu+KNraIHBDOzsQwJGP2pnggubSW3uIvkZGRscHDDBA/Cvy20/wDZe/YkjsZNF8O6zrtvBqUIspEhuJT58V1cCGOJ2eNmZTNG8EKk4jff5YV8tXPyvZHbNqOh5/B/wSU+F1n4lt/El98TdblvLK90y9hleWJGji0y1mtmhHlsilJY52D+YrqqHAXPzjN8Mf8ABHn4Gaz4TRrHx1q+qWr2N1p0M6+XIBbTPefuY3l8yQwR/aigR3fIiTLHFe7eJ/2b/wBj59XJ8a6rrF7daJd3U7mSeZcS20MZuQwgjRXQW/lqyYKsnYndn6Y8E+Jfgp8CPB+hfCKw1K5WGygghsnul8ySVJY2eIsUVQcqhHCjp0rJ05dEck5x7n586r/wRV+Geu6zp/iTU/iH4mSTSLrzrJLRoII4olninhtzGibXjhMeF3dmPoMeg/F//gkv8Jfi58QvFfxSk8T61put+Krtbn7RBJ/x4eWIBCtnsZPL8nyMr1Usx3o4+Wv0j8D/ABH8J+Oxdv4VujMbAos4KmMxs67gpVsHOPwz9K9CDzSEcY45OB2rJp9TDmj0Pyb8Gf8ABJD4SfDz4p6P8XPDXi/W11fTfEEXiGWaeQNLPMttJbzRMRiMR3Ik3SqY3X5RsCHmv1iJSMFLgjn+Ef54pjM+4SxxhiO+RTfvfejx69sf0qkkYufYj8tkbdAd2OR2OKfKXUfvBtVu/cexp261Rt4bp0FSBzs3Fsj/AGh/LFKVuhUVZakUUDxyYcg4H5/h6UG3kmJkft1A5PHtRut518nGMcBh29qgTCybVfcw5yuQPzqOZmvKrE8Um1uFAVutTfZLfvTRJMxBHA9cYzSGWPPKj8x/hXVr0PTsf//W/vTI3/NJ8v1/lT1EaRZdvl7CvmL9sAftDy/AXW1/ZfRJPGc4WG0GI8osmULI0rpHGUJB8wh9gBby3ICn5W1v4m/8FQdN1a/0HTfB+hXSWVrcNY6gsH7q9uFvGitIpIzehrZJYNjzSAyeUMsquRsrt8kej5H6eySrOhgddyHj5vQjH4Vxtn8JPhvHMsv9iWaleR+5T0A449APpX5i+KfH3/BV3xfp0Y8PeErLw7PDeWZjaCW2/eiPzRdLcCf7SPssrrGFMWyVI38wElPLb7w/Zr8WfHXxv8PptW/aK0CHw1r32t44rW3IIMEcMQ3nEkg+ebztnzZ8sJnBpc+nu6EyaaskekX/AMMfAWqXtxd6jo9o8t0ZGlLwqS5lAWTPHO5QAfUACmXnwx+HGq3Ud1qmiWlxLHs2ySRKzKI1KKBnoFUkADtXfrJ5K4c7l9ug/wADUimKZshSuO9DnY4ay7HJeGfAng/wM0o8KabbacbkR+YbeMJ5giG1NxHXaOB6V1Z+cky8Ad+34U3zAX8qEcZ78/pUjR+dNhiAOir9KhtPc4tV8IsccaIWU/J/npVZrhdvlINy+hqV5WTEZAAHSp9zzJvibDeg/p/hWWiG+Z6Irw2iFw7ZUHtS3Ks02GO0DgccCvmL9sX4qfEH4Nfsz+Lvit8NPsY1rw9ZC9i/tCCSeEpFInmqY4nidmMW4JhhhsZ44r8A/E//AAV//bz8Ja54p0e/0rwn5fhnVNNt7j7NDDdYudQku0g0S326yv2u4lSCJ3mQJdQCX/kHSAAnOUkbU07H9SUREA2Y68en1qZYxAMocI/Gf6Gv59P2mf8Agqz8aPh18fvEvgv4XN4Z1DSdKtdtpphhlur54j4dbV5NdNxFdKH0+0vF+xSotvt3IwNwj/JX2x+yz+3ZceOvg/o+rfEm4sPEGs634k8QeHtH1TQohbaZrqaRqklhaXdmklxcBVvIlWdQk8y7A7KzIua5alblVzaNJn6ZN8zbpPlHY0uyDsSPb/Ir5r+Af7THhL9oq5n/AOEc06+09YrdbiI3iRr5qCRon2hGOCjrjnGeo4r6ULSg4EYwPrXrwatoehG2x//X/uW+KfxT+H3wR8DXvxG+JmqQaVpWnoWeWV1Tc2CVjj3FQ0jYwq5/IDNef2/7Wn7NV5vY+NtFzAF82M3MZljLTLbqjqCSrtKyoqnliflBHNTftH+CP2ePGnw6Fh+01a2Fz4ZtbyCfOqSGG2jufmhhdmVlAOZCFLHAYgjBAI+T/iZ+xf8A8E6NS+IEPhPx94Shn1/xnZ3EL2y6jehpLKAW00ztCt2uyPNlbgyImdyKufmOels7Gz65/wCGnPgHJGJofGmjCMzNbptuowGlR5Iiq5I3HfFIvy8EowHQ1xPgn9tT9mPx3bmZPFFlpkvntBHDqEsdtPJhSyyJGXJMciKzRtxvVWIGBXjvhn/gnx+wD4hhX4j+FfC0dzHrksuqpMmqamkU0t7IblrkRfalTzGeRirBAyBiq7VOKbN/wTC/YWurtLm88GSCeJZESQ61rCyRqyyL8r/bgV2JI6xkEeUp2x7VwKG9NCJSfQ+/9I1jR/EOnW/iDw3cxXdldoJIZYmDRyIejKRwQfar8uII+U/dt3Bx+dcx4X8PeG/Anhix8EeDrdbbTdHgjtLeIM0nlxxKFVdzlnY46liWJ5JzXSQyTlDIc56Y/wA9qyfkcrkPjeBl2AbP9oU8RxJ8zMMf57dqrxlmQs+AeigDgfgKn+SI5xu9Ow+tJq25jzN7EsjSFgjbdnq1MYy/8u4AX2xUAjimGJF+btzXn+m/FP4Uat9tGj+J9Juzptubq5WK+t38iAMyGWXa52RhkZdzYGVIzwRSlJdAUH1PQZIhc5hvIwwYfNuHb37VmNomgM6tDawBxIJBmNeZBwH6feHY9abp+uQa1ZwX+j3EdxbXKB4ZYGV45EboyMpKsp7EHFeej48/BN7iSwg8ZaDPc25xIi6jas0ZE4tsFfMyD55EPP8Ay0wn3uK8yvXVjvp0zyq8/ay/Zi03w1N8QZ9Rhj02Gd7Ce5FlMPLAt/tbs2Isi3+znzi+Nu0+vFd/4Y+NvwS1vwzB4g0y+t7WyDzxwrLH5EqPav5UoSF1DAqxAG1ecjGQRXkPhn9mj9kr4i+ErvTfDNpBrehveSGdLPVru5tzMsP2OSBzFdMuwQ/uWtz+7CgKU4FP8NeF/wBjiW60LTtE1fSLifR7281DTI01xp5muVInuy5N0z3CxHa7xyl0jCodqhVxwuunax0qlbQ+hfAvxN+FXxBuLi2+Hmu6fq0lokbzCzkSTYkmdhO3scGvVfn7D/P5V8yfArwp+zN4ZaeL9n6XSrh7S2jimGm34vDFDcMZ494Esu1ZDl0Jxkfd4r6DLuDjYfyP+FfULVIyep//0P7b/j78DvCf7Q/w9m+Ffi93Wwmura5d4o4nlDW0qyr5RlRxE+VwJVAdOqkGvgez/wCCOP7LyaXY6Zr+o6rrUtlJb7bi+NrJKba2t7e0SzYiAA27Q2sKyp0kKBmyen6ywkAFCm0GmG2CviNh9K6eZE8zSPy4uv8AgkZ+y02prc7r6CMaK2hyRR+SscsLWi2au6eX5ZdFRJFbZuEqIQQF21F4W/4JG/sueGdSk1u+k1HXHNzezqdQ+zzbFv3keeLmH7jGVgw/iGAc4r9UHEO3yZ25HAx29qgSOWI705U8cccUr6ambn0R8w/srfso/D39k3wvrHhP4cXl9d22tXsd/Mt9J5jCWKzt7PKHGcuturuc4MhYgKDivp4xTRuGwcetK6sXEBwjdeOh9M1JAsqqztyRwBUqdtEZ8jY0gZ3HCeoP9KY/7mTanLH8hS+Q4xcTdBzxzTo5MSFwnD9//rin7QlU2S7yqKWYb/5fhXx/d/sceBTe67errGow/wBt6a2mjy/L/cRyXZvWdNylWbzjkbhgDjBr66mtV/5ZsB7HipvkiTyrgj6DqPpWEzaHmfI/w+/ZI8G/Df4mad8VtA1fUJ9R07SxpOyXyyj24ZW5UKOeD7/MecAAeTat/wAE7vhZ4nuDqfiHXNQub95ZZ5bwx263FxLJerfBrhxHiTy3XES7QqfeA3Yx+gghkiYSQHcF6djiiZWHyv8AJu5Dd+Oxrx61SR6VKKPnr4Pfs0+DPgdoZ0bw5NqFyh1I6pma7uMiQRiJEIEnzxJGqqI3LJkZ2jjHlXgT9hb4c/D7xDaeKNK1bUZXtpreV4rr7O8UwsY0hs1YeUCPJRByuN7fMe2PtqC3nSb52zj0NMe3nnZpZOi/j+lcV5WvFfI6UlsfOXwA/Zg8Efs4y3EPgq+vbyGS3FvDHdMjCBGmkuZAu1FLGSaVny2dowq4Ar6cG8DBcD24psOEONuFap/skfv/AN819ZGorI8pn//ZAAD/wAARCAWoBFYDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9sAQwACAgICAgIDAgIDBQMDAwUGBQUFBQYIBgYGBgYICggICAgICAoKCgoKCgoKDAwMDAwMDg4ODg4PDw8PDw8PDw8P/9sAQwECAwMEBAQHBAQHEAsJCxAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQ/90ABABG/9oADAMBAAIRAxEAPwDyHyhR5dXvLFHligCl5XvR5XvV0RgUeWKAKPlCl8r3q75Yo8sUAUvK96PKHpV3yxS7BQBQ8oUeUKv7BRsFAFHyvejyvervligRgUAUfKFHlCr3lijyxQBR8ujyhV7yxS7BQBR8r3o8r3q75Yo8sUAUvK96TyhV7yxR5YoApeV70nlCr+wUnligCl5XvVeSDvjrWr5YpDECMUAc+0IqBoRW28PrVZoaAMgxVGYsGtUxHHNRmLigDO8r3o8r3q/5XvR5XvQBQ8r3o8r3q/5XvR5XvQBn+V70vle9X/K96TyqAKPle9Hle9XvKo8qgCh5Ro8rmtDyvejyvegCh5XvSeV71f8AKpfK96AM/wAo0vle9X/K96PK96AM/wAr2pfK96v+V70eV70AUPK96PK96veVS+V70AZ/le9L5XvV/wAr3pPLoAo+V70eV71e8ql8r3oAz/K96PKNX/KpfK96AM/yjR5XrWh5XvR5XvQBn+UaPLrQ8r3o8r3oAz/K96PKPpWh5XvSeVxQBQ8o0vle9X/K96PK96AM/wAo0vle9X/K96PK96AKHle9Hle9X/K96PK96AM/yu9L5XvV/wAr3o8r3oAoeV70nle9aHle9Hle9AFDyvejyver3lUvle9AGd5Rp3le9XvKpfK96AKHle9J5XvV/wAqjyqAKHle9L5XvV/yvejyvegDP8r2pfK96v8Ale9J5XpQBR8r3pPKNaHle9J5VAFDyvel8r3q/wCV70eV70AZ/le9Hl1oeV70nlUAUfK96TyvetDyvek8qgDP8o0vlGtDyvejyvegCiiFG3LW1EBKgYVT8r3qe2byX56HrQBZ8o0vle9XxGDyOc0vle9AGf5XvR5XvWh5XvSeVxQBQ8r3pPKNaPlUeVQBn+V70nk1o+V70eV70AZ3lGjya0fK96PK96AM7yaXyver/ldqPJoAz/JpfK960PK96Tys0AZ/le1Hk1o+VSeVzQBQ8r3pPJrR8r3o8r3oAzvJ4o8o+laPle9J5XegDOaAEYIzmsWe1ML7e3aus8r3qvcWnmp7jpQBy3le1HlGr5hI4Io8qgCh5XvR5XvV/wAql8r3oAoeV70ghJOAK0PK9639G0vewu5V4HQf1oAtabpq2kGG/wBY/J/wrR2Vf8ujyvegDOMWaPK960PLNN8s0AZ5hxSGKtHZTfLoAzzFR5XvV8xUeVQBm+V60eVWh5VIYqAM4xUeUfStPyTR5XpQBmeSKPJFafknvR5GKAMzyj1ApfKPpWn5OOtL5GeaAMnyaPJrWMHtR5FAGOYRR5XvWt5NIbcUAZHk0eTWt5FHkUAf/9Dzzy6TZWhso8sUAUPLo8ur+yjyxQBn+X7Uvl1f8sUeWKAKHl0eXV/yxR5YoAo+V703y/atDyxR5YoAoeXS+V71e8sUeWKAKHl0eXV/yxR5YoAoeXR5dX/LFHligCh5dHl1f8sUeWKAKHl0mytDyxR5YoAoeXR5dX/LFGygCh5dHl1f8sUbKAMt4aqvFW60QIqo8VAGK0NRGLtWu0VRGKgDJMVHl1pGLvSeV70AZvl+1L5daHlUvle9AGd5dHl1o+V70nlelAGf5dJ5ftWl5XvR5XvQBm7KXy60PLpfK96AM3ZRsrS8r3o8r3oAzvLo8utDyqXyvegDP8r3o8r3rQ8r3pPKoAz/AC6XyvetDyvekMVAGf5dJsrS8r3o8r3oAzvLo8utHyvejyvegDP8r3pPKNaPle9J5VAGf5VHlVo+V70eV70AZ3l0eXWj5XvR5XvQBneXR5daPle9Hle9AGd5dL5XvWh5XvSeVQBn+XS+V71oeV70eV70AZ3l0eXWj5XvR5XvQBm+X7UbK0vK96PK96AM7y6PLrQ8ql8r3oAzvLo8utHyvejyvegDN2Uvl1o+V70nl0AZ/l0eVWj5XvSeXQBnbKXy60fK96TyqAM/y6XyvetDyvek8qgDO8v2pfLq/wCX7U7yvegDO8qk8v2rR8ql8r3oAzvLo8utHyvejyvegDO8ujy60PKpfK96AM7y6PLrQ8ql8r3oAzvKo8utDyqPLoAWzfH7pvwrR8qs0RkHIratyJkyfvigCvsNGw1peVTfKoAz/Ko8utLyqPKoAzfKo8vPWtDyqd5VAGb5dHlVpeVR5VAGaY6PLrS8qk8v2oAzvLoEdaXlUeVQBm+XR5VaXlUeVQBm+XR5daXlU0xUAZ/l0eXWh5VL5XNAGd5Xegx1oeVTvKoA529tP+Wqj61m+XXZGEMNrCsSe1MMm0dD0oAyfK96Ty60fK96FhLEKoyTQBDY2Ju5xGPudT9K7lIVRQijAHFJp9gLSDBHzvya0NlAFMJ60vljvVvy+1L5dAFPy6PKq6I6Xy6AM/yhSeUK0fK96PLFAGd5XvTPKrT8r3o8nNAGZ5VP8r3rQ8rsKcIqAM3yeM0ohrSENPEPrQBmiCneSa0vJPepBBnqKAMoQUvkA1si29acLcDtQBieTR9nrc8hfSjy19KAMMwA01oBW55I9KjeNEUu/AFAHPTLHCA0hxmoPPt/79JeYupMk4UdBVX7KnrQB//R5jyjR5TetX/LFHligCh5Ro8o1f2UeWKAKHl45o8pvWr/AJYo8sUAUPKo8o1f8sUeWKAKHlGjyjV/yxR5YoAoeVR5RzV/yxR5YoAoeU3rS+V71e8sUeWKAKHlN60eUav+WKPLFAFDyjR5Rq/5Yo8sUAUfK96PK96veWKPLFAGf5WaXyjV/wAsUeWKAKHlGjym9av+WKPLFAFDym9aheLmtXyxTHiyKAMRouagaKth4sdqhMWTQBkmLim+XWp5VR+VQBQ8r3pPLrQ8ql8r3oAzvKo8utDyqXyvegDO8qjyq0PKpfK96AM7yqPLrR8r3pPKoAz/AC6PLrR8r3pPKoAz/Lo8qtDyqPKoAoeV703ZWj5VHlUAUPK96Tyq0PKo8qgDO2UbK0fKo8qgCh5XvSeUa0PKo8qgDP8ALpfK96v+V3pfK96AM/yvek8utDyqPKoAz/Lz0pfK960PK96TyqAM/wAvmjy60PKpfK96AM7ym9aPKrR8r3o8r3oAz/K96Tyq0PKo8ugDP8qjy60PKo8ugDP8ujy+9aHlUeVQBQ8r3pPKrR8r3o8r3oAzvLo8qtDyqPKoAz/Kb1o8utHyvek8qgDP8vijy60PKpfK96AM7y6PKrR8r3pPKoAz/KNHl1oeVR5VAGf5dHlVoeVR5VAGf5dHl1oeVR5VAGf5XFL5XvV/yqPKoAz/AC6Xyver/lUvle9AGd5dL5XvV/yqPKoAz/Lo8utDyqXyvegDO8upIt0TBhVzyqPKoA0EAkUOvQ1J5VV7RvLbY33DWx5XFAGdspfKrR8r3o8r3oAzdlGytHy6XyvegDN8v2pfKrQ8ril8r3oAzdlHl+1afle9J5XvQBm+X7UvlVo+V70eV70AZvl+1GytHyRS+V70AZuyjZWl5XvR5XvQBm7KNlaXle9Hle9AGd5VJsrS8r3o8o+lAGbsqGe1Ese3HI6VseV70eV70AcUYSpKkcit7SdP/wCXmQf7o/rWidKN1IHUcD730rYWEKMDgDtQBV8unbKt7DSeXQBW2U7YaseXTvLoAq7DS7KtBBS7DQBU2UbKthKesfagCiI80/y+fu1d8v2qQQ4FAGd5VSLDWgIalWHtigDNEPpUgh7YrTW39alEQFAGYIfWlEeOi1peX6UhioAz9h9KNh9K0PKpvlUAZ+w9dtGw1oeVSeV3oAzth9KwdSn3v5CdB1+tb1/MYE2ofnb9K5zyvegChsNGw1f8r3o8r3oA/9Kp5VN8qtDyhSeXQBQ8ujYa0PLpPLoAoeXR5daHlijyxQBQ8s/3aTy6v+XS+UKAM/y6XZV7y6PLoAoeXR5dX/Lo8ugChsNHl1oeWKPLFAGf5VHl1oeWKTy6AKHl0eXV/wAujy6AKHl0eXV/y6XyxQBn+XR5daHl0nl0AUPLo8qtDy6Ty6AKHlUGPitDyhR5YoAyHiqBoq2GjqFouM0AZBj55qMxVqmMZqMx80AZ/lU3yq0fL9qPL9qAM/yl9aTyq0PLo8ugDP8AKo8qtDy6PLoAz/Ko8utDy6XZQBneVR5VaHl0vl+1AGd5XpR5VaHl0eXQBn+VR5VaOyjy/agDO8rijyhWh5dHlCgDP8qjyq0fL9qTy6AM8xelHlCtDy6PLoAz/Ko8oVoeUKXZQBneVR5XpWjspPLoAz/L5o8qtDy6PLoAo+VTfK9a0fL9qTy6AM/yqPK5rQ8oUvl+1AGd5VHlVoeXS7KAM7yqPKFaHlCjYPSgCh5XNHlL61f8ul8v2oAzhEKPKzWj5ftSeXQBnmKjyq0PLo8selAGf5VHle9aHl0eXQBn+VR5VaHl0eXQBn+VR5VaHlj0o8ugDP8AK4o8qtDy6PLoAo+VTfKGa0fL9qTyhQBn+V6UeVWh5dL5ftQBneVR5VaHl9qPLoAzzFR5YzWh5dHl0AZ/lelHlVo7KTy6AM/yqPKzWh5dHl0AZ/lUeVWh5dL5ftQBneVWvZyb18p+oqDy6cqlGVl6igDT8v2pfLq1CVmQOOvepvLoAzvLzR5YrREdJ5YzxQBQ8s+lGztWh5dJ5XpQBn+X7Upj7YrQ8ul8r3oAzdlGytARUvlUAZ3l+1GytAxg07yvegDN8v2pfLrQ8ul8r3oAztlJ5ftWgIwTSmOgDO8v2o8vFaHlijy+woAz9lKsJc7QMk1oeVzWvp9mFHnsvLdKAEtbMQRbT1PWqE9sYXwOh6V0uymS24lQoaAOY2Gl2VbaIqxQ9RRsNAFQR0bKubKPL9aAK3lik8urmzJ+lO2UAUvL7CpVjx0q0sdPEfNAFURipliqyEyanWOgCoIqmEPrV1YqkEdAFLZSbDWh5YpPK96AM/ZzSGOr5jpDHQBQ2Z6Umw1oeXSeXQBQ2GoLh1giMj9v1rVMYHJrl7+X7TLhfuJwP8aAMeYyTO0jtURjIq/5QpPKFAFHyzR5Zq/5Qo8oUAf/09DZSeXV/wAujy6AKGw0bDV/y6PLoAobDRsNX/Lo8ugChsNGw1f8ujy6AKGw0bDV/wAujy6AKGw0bDV/y6PLoAoeXRsNX/Lo8ugChsNGw1f8ul8r3oAz9ho2Gr/lGl8r3oAz9ho2Gr/l0eXQBQ8ujYav+XR5dAFDYaNhq/5dHl0AUNho2Gr/AJdHl0AZzRVA0da5jqBo/vUAZTR1G0YzWkY6Y0fNAGb5dL5dX/Lo8ugDP8ul8sVoeVR5XvQBn+XR5eaveXS+XQBn+XR5daHl0eXQBn+XR5daHl0eXxQBQ8ujyver/l0eXQBn+XR5daHl0vle9AGf5fek8vFaHl0eXQBn+XzR5dX/AC6Xy6AM/wAujy60PLNL5XvQBneXS+XWh5XvSeXQBn+XSmMCr/l0vle9AGd5dHl1oeXR5dAFDy6Ty60PLpfK96AM/wAqk8ur/l0vl4oAz/LpfLFX/Lo8vIoAz/Lo8vitDy6PLoAoeVR5dX/Lo8ugDP8ALo8utDy6DFQBn+XR5Y6VoeXR5dAFDyqPLq95dL5fagDP8ul8rNX/AC6PLoAz/LpTFV/y+1Hl0AUPLFJ5daHl0eXQBn+XS+XV/wAujy6AM/y6PLq/5dL5dAGf5dHl1oeXR5dAGf5dL5Yq/wCXS+V70AZ/l0eUKv8Al80eXQBn+X3o8utDy6PL5oAz/Lo8utHyvek8ugCh5Xak8utDy6Ty6AIbZjC+ex6it1UDBWXoayfL7VpWL4PlP36UASiKl8r3q95fNL5VAFDyvemiLFaHlZNL5VAGf5WKTy/atHyjSbKAM/ZSiP0q/so8s0AUPLBpPKxxtrQ8s0bKAKBiHpS+V71f8qk2UAUPKo8vNX9lGygDP8rvR5XpWj5dCQl2CjvQBXtbTzpQCOB1roBEAOB0qeC1EEe1an2d6AKQSl8oVd2Uvl56UAYl5abh5qryOtZuyuu8v1rHuLUxPkLwaAMry6Ngq4EzzS+Xk0AVBHS7KthKcI6AKojx0qQR8VZEfNTLGOtAFdYx/dqwsVTrGKnVOOaAKvl0vl561b2mjbQBU8uneXmrW0U/aaAKRippjq/t9KXYaAM/y6Ty6v7Kp3swtoS38Z4FAGFqVxgG3j69zWF5XvV8qWO5utJsFAFDy6PLq/spNlAFHy6PLq9so2UAf//U6vYaNhq95Ro8o0AUdho2Gr3lGjyjQBR2GjYaveUaXyjQBQ2GjYaveUaPKNAFHYaNhq/5RpRCaAM/Yad5TetXxFineV70AZ3lHvS+XWj5VO8qgDN2GjYa0/KPpR5RoAzNho2GtPyjR5RoAzNho8utPyjR5R9KAMzyvem+U3rWn5JpvlGgDN8s0mw1peXSGKgDO2GjYavmE9qTyjQBRMXGTULRVqmM4qFozQBltFUTRCtRozUTRmgDP8r3pPLrQ8o0eUaAM/y6PLrQ8o0eXQBn+XS+XV/yjR5RoAz/AC6PLrQ8o0eUaAM/y6PLrQ8o0eUaAM/y6PLrQ8o0eUaAKHle9J5daHlGjyjQBQ8uk8utDyjR5RoAz/Lo8utDyjR5RoAoeXSeXWh5Ro8o0AZ/l0eXWh5dHlGgDP8ALpfLq/5Ro8o0AZ/l0eXWh5Ro8o0AZ/l0bBWh5dHlGgCh5dJ5daHlGjyjQBn+XS+XV/yjR5RoAoeXSeXWh5Ro8o0AZ+wUvl1f8o0eXQBn+XR5daHlGjyjQBn+XR5daHl0eUaAKHl0nl1oeUaPKNAGf5dHl1oeUaPKNAGf5dL5dX/KNHlGgDP8ujy60PKNHlGgCh5dJ5daHlGjyjQBn+XR5daHlGjyjQBn+XS+XV/yjR5RoAz/AC6PLrR8r3pPKNAGf5dHl1oeUaPKNAFAx0nl1oeUaPKNAGf5dHl1oeXR5RoAz/Lp3le9XvKNHl0AZ/l0ojIOav8AlGjyjQBdtX85MN98dat+VmsuLdE4da6CPbKgdO9AFTyvek8qr/l/7NGygCj5XvSeVzWh5RpPL9qAKPle9J5RrQ8ujy6AM/yuc0vle9X/AC8daPLoAz/L4o8qr+yjy/agCj5XvSeVxg1oeXR5dAFDyvetOztdo81hyelSW9qZWzjgVr+X2oAp7KUJVzZ2p2w0AUfLpRHVzy6UR8/doAp+XTZLdZUKtV4R07y6AOSaBkYo3UU3y66K7tS48xRyKyvLoAqbKesdWdlSLHxQBWWOpliqdY6nWPNAECxU7y6tbMClIxQBV8ul2Va20u0UAVfLz0o8ure32o2+1AFby6XZVkDNLtoApybYkZ36CuTuna5lMjdOwrZ1G481/Kj+4nX3NZmygCl5XvR5XvV3ZRsoApeV70nl1e2UbKAKXle9Hle9XdlGygD/1fR9hpClX/KNHlGgChsPSl2Gr3lGjyjQBR2Gl2Vd8o0eUaAKOw0CMmr4iNP8qgDP8vFOCE1fEPpThD6UAUBEe9OEZrREIPanCHtigDP8r3oEfOK0NgFG2gCj5RxSiI1d2mjaaAKfle9Hle9W9lGygCmYjSGMjrV7aaNpoAzjH2o8qtHbR5amgDMMZ70wxntWsYe2KZ5I9KAMzZTDHmtPyfWmGE0AZ5jwKiaPitdouMVXeI0AZTR0wx81pGLmozFzQBQ8r3pvl+1aPlUeVQBn7BR5daHlUvle9AGd5dL5dX/Ko8qgDP8ALo8utDyqPKoAz/Lo8utDyqPKoAz/AC6PLrQ8ql8r3oAz/K96Ty60PKo8qgDP8ujy60PKo8qgDP8ALo8utDyqPKoAz/Lo8utDyqPKoAz/AC6XyveugisIX0qe9YN5sUoUYxswRnnvnr37Vs23hG/1gWw8O25vDJGnmASRl/MI+YbOCoB4569c80AcL5dHl17HafB/xBPKba6u7G0uR1hkuN8o+scKysPxAqD/AIVvs1Q+Hpb+H+0znbGhbPTOTFJHHJjHUgHFFgPI/Lo8uu11/wAFeJPDMjrrFhJDGhx5oGYj6YkHHNc15VAGf5dHl1oeVR5VAGf5dHl1oeVR5VAFDyvek8utDyqPKoAz/Lo8utHyvek8qgCh5XvSeXWh5VHlUAZ/lj+7R5daHlUvle9AGd5dHl1o+V70nlUAZ5io8utDyqPKoAz/AC6PLrQ8qjyqAM/y6PLrQ8qk8v2oAoeXS+V71f8AKo8qgDP8ujy60PKpfK96AM7y6PLrQ8qjyqAM/wAujy60PKpfK96AM7y6PLrQ8qjyqAM/y6PLrQ8qjyqAM/y6PLrQ8qjyqAM/y6PLrQ8qjyqAM/y6PLrQ8qjyqAM/y6Xyver/AJVHlUAZ/l1cs5PKfY33HqXyvek8qgDX8vNHlmiyk3jyn6jp71o+VQBn+VR5VaHlUeVQBniPtR5VaHlUeVQBQ8r3pvlelaPlUhioAz/LNL5VaHlUeVQBQ8r3oWAuwUdTV/yqvW1sFG9hyaAIY4BGoVe1SbBV7yhR5VAFPYaPLParnl46U7y6AKWyjy8Vd8ujy++KAKfl07yhVzy6d5VAFHyhWRd2vlPlehrpPLOc02WASoUbvQByQjqUR1beFo3KMOlOCHpQBXWPJ4qZUqdY+anWPigCoU5oCetWyozQF9qAKojpfL71a2+1O2mgCp5dHl1b20baAKwQVn383kp5afff9K1Z5FgjLt+Fc3IWlcu/U0AZ3l0GKru0UbRQBS8ujyx/dq7tFG0UAUvLo8ur+yjZQBQ2CjYKu7RRtFAH/9b2PaP7tGwDtV7yqPKoAobRRtFX/Ko8qgCjtH92lWMf3auiGpPKoAo7Ae1PEY/u1dWKniLvigCiIx/dp4jzV4RAcmmMM9KAKuAvAphBNW/LFHligClsHpRsHpVzyhS+WKAKWwelGwelXfLFHligCn5ftSbB6Vd2UeWKAKWwelHlj0q75Yo8sUAU9lGyrnlijZQBVGR2p21Wqz5VJ5YoAqmP1Wm+X7VfCjoakWHJyKAMxoagaME1svFg5xVZohjigDHMVR+Xz92tYxDFQmKgCh5XvR5XvV/yqPKoAoeUfSjyver/AJVHlUAUPK96Tyq0PKo8qgDP8ul8r3q/5VHlUAZ/lUeVWh5VHlUAUPKPpR5XvV/yqPKoAoeUfSm+X7Vo+VR5VAFDyvel8r3q95VHlUAUPKPpR5XvV8QljtAyT6V9FeDvgDqt1YR634sRrSOQborTpIR2MvdQf7vX1x0oA+aorSWYkRRmTHoM0S2c0OPOjZM9MjGa+h/Enhyx0SVNPuLCGS2kbBEqZHPHToPwrlU8JwR6f4j0XSLc/ZbSCDU4F6mP59soHtjOfpVWFc8ns0vRcounyNHLL8mFPDgn7jjowzzg8V0Nl4Z8a6n4utPDmm3Edvd3BIaS0g8hxF3JfJIJH93bx1r1X4KeDl1rWZNTu03QWw+XPc9/8PoTX038OfCNvY3mveLZIwbmVniiOOkcfp9T/Ki47Dvh94G8P+CbcRQQKyRkRGU/fnl7geoHc18/ftReLdSvteg8N+HdVksZLKIeb9kxG6PJziWX/WZxjCIV4OS3OK991fWRpvxF8PaLKf3EWnXM0Y7POCM/jgZ/Gvz/AL28uNXvbjVrsl57yR5pCe7yHcf51IFPQNc8baCpQa9NfxPxJBd7p7eQHqHjdj19c5HrVacJNNJLHEIVckiMHeEB7AkAnFa+n6bPqV9BYWyFpJ2CgDrzXOt4X+MF7fSBPtenRxtgQwOYkQZ6HZjJ9zkmq3FsT+XS+V719BeAfh5Lrdn9i8axO8mMLOMJOh9dwHzf8CzVfxv8CvEvhiB9V0j/AInGlgZLxJiWMf8ATSPk49xkeuKkZ4L5XvR5R9Kv+VR5VAFDyj6UeV71f8qjyqAM/wAql8r3r6Y/Zl0zT9Q8eX8Oo20V1GNNlcLMiyAHzoRnDDrzXv8A8f8Aw7oNj8MdSurHTLa3nWW3xJFCiMMyrnkDNAH50eUfSjyvetrT9Lu9Vv7fTLGMy3N3IkUSjqXc4A/Ov068GfDPwz4V8M2GiT6dbXlxBH++mkhVmklblzkgnGeB6DAoA/Kvyvejyvevcvjd4m0nxF4vksfD1tBBpmk7oIzBGsYlkz+8kJUDIyML2wMjqa8c8qgCh5XvR5R9Kv8AlUeVQBQ8r3o8r3q/5VHlUAZ/lUeVWh5VHlUAUPK96PKPpV/yqPKoAoeV70eUfSr/AJVHlUAZ3l+1O8r3q/5VHlUAUPK96PK96v8AlVreH7dH17TUkAdHuoAQeQR5goA5ryvek8qv2B/4RPwr/wBAWy/8B4v8K/I7yqAKHlH0o8r3r6q/Zg0nTtR8S6xHqNrFdKlmpAmjEgB8wcgMK9K/aa0LRtO8B2Eum6fb2sjanCpaGJI2I8mY4yB04FAHwV5XFL5XvV/yqPKoAoeUfSjyver/AJVHlUAUPK96PKPpV/yqPKoAoeV70eV71+iX7Pfh7Q774aWdxfadb3MpnuAXliR3wJDjkjNeC/tNaZp+nePLGHTraK1jOmRMyxIIwT50wzgDGeKAPmfyj6UeV71f8qjyqAM/yqXyver/AJVHlUAUBGVIYda37dhNGG796z/Kqa3Jgk3du9AGh5VL5fNXlQMoYc5pfKoAo+VTfLrQ8qjyqAKGygR1o+VR5VAGb5dHl1peVQsJZsAUAVYLbe2T0rS8qrKQhF2rTxH3oApbKUR8/dq75dHl8UAUth64p3l1c8ulEXagCnso2Vc2Uvl0AUtlLsq75fFKIxQBT2GjYaueUKXZQBjXVp5g8xRyKyxHXW7KzLu08tvMQcGgDLWPmp1jqYR81MqYoAomMk80bfVatlOTRs70AVfLpdlW9hpNpoAq7KCmBk1b2is28mOPJT8aAMi6czyf7A6VV8pfWr200uw0AUfKpPL71e2mjaaAKXlUeVV3aaNpoApeVR5VXdpo2mgCl5VHlVd2mjaaAP/X9+2ijaKv+VR5VAFHaKAgNXvKpwhxQBT2j+7ThGOuKuCHNSCL1oApqg604qqjJq4Y9oyahKFjk0AUiCxzSbRV7yqPKoAo7RRtFXvKo8qgCjtFG0Ve8qjyqAKO0UbRV7yqPKoAo7RRtFXvKo8qgCjtFG0Ve8qjyqAKO0UbRV7yqPKoAo7RRtFXvKo8qgCjtFTRDGT2qx5VTLGAoFAFcx8ZFV3i5rQCkH2pTGDzQBjtHjmozFkVrNFURh5oAy/KNHlVotFxmmeUKAKPlGjyqveUKXyxQBQ8pvWjyqveUKPKFAFHyqPKb1q/5Yo8sUAUPKpfK96v+VTfKoAo+UaPKrQ8qk8sUAUPKo8qr3letHlUAUfKb1o8qr3lU5YWYhUXe54AHc+lAH05+zp8MoL+Y+PdaiEkNs5jso2GQZU+/N/wE8L75PUCvsi4hW4bBGRXgnws8ZWNl4G8N6Xt2GW0DfWTJ8wfUNXutpdebEJAM5oA8D+KXhFNSaARDlZUP5GuA0+2GjReMNfcbIbbTDApPqSx/rX1Jf6SdTmDMuAK8I/aHNp4V+F95Z2hCTapKkXuQPmP6CjyB9yn8BrDZo6QtyZIY5Pxk3E/rX0JoFmtvZ3Fmw43E4+teN/CqBdK/s9TwJ7VPzR2H8jX0MsKpJvXvQHQ+cvjN4SvtSisNX0qUWmoabL5trcEEojkAPHLjny5AME9jg9M18OX+ka9plzJDqej3Vvuc+W0UTTwOO3lyRBlYe4NfrTdW0U0ZjmAKPXCT+AfCssz3DWwjc/eK8Z+uKAPjT4OeD9Zm8Txavd6dLb29sCyNOhjOSMAhXAY+3GPftX1tLawu5JiHPU4rptP0zSNNX7JpkAjQ+lbUekRMM4oA4i30y36qgBq3HevZPhW2EV2a6TGgwtUb/w7Hdp8p2mgq58p/Fr4Z6XrcU/ibwpEtvqMQMl3aJwkqd5Ix2I7jvXyf5Rr7S+JketeErc6tan95aHcrDkH/YPqCOCK+c/HelW9pqcWoWsZt49TiFx5R6xlwCR+v55oJPOfKo8qr/lik8oUAfQf7LybfH+oH/qGS/8Ao6GvoT9oYbvhbqQ/6a2//o1a8E/ZjTb49vz/ANQ2X/0dDX0N8dII7n4dXdvPKIY5J7VXkYbggaZAWIHp1oA8P/Zq+H4ubyfx5qcWYrYtDZhh1k/jkH+6PlHuT3FeufHfx/8A8Ih4WbTNPk2aprCvFGR1ji6SSeo4OF9zntXrXh/R9N0DRbLR9IQLZ2sYSPHcdd2R1LHknuTmvzr+Kuqa3rXjvVZtejME9vKYI4m/5ZRIT5YHrkHOe+c96APLfKr6e079mDVdR0601FNdgjF1FHKFMLHb5gBx17Zr5v8AKFfqv4X/AORa0kf9Odv/AOixQB8BeEvgT4s8V3d2I3js9PtZpIftcwIEpjcofLQcnkew988VN45+Cc3gzWfDmjjVlvD4gnMAfyPLERDxJkjc2f8AWe3Svqrxh8ZfBfgK5bRI0e8vIeGgtgoWMnnDsSAD6gZPrXgniT4nWnxK8a+Cja2Mll/Zuox58xw+/wA2WHpgDps/WgA1H9mHVNO0671FtdgkW1iklKiFst5YJx19q+YvKb1r9ZfFH/ItasP+nO4/9Fmvyp8sUAe7+Dv2eNS8XeGrHxJBrENsl6pYRtESRhivUH2ry/xR4Gn8MeNpPBUtytxLHLBF5wBAPnqrg49t36V99/BUY+GGgj/plJ/6NevlH4rJn46XLf8AT1p//omGgDfvv2XdXs7O4vP7dhk+zxtJtEDZOwZx171i+Ef2bPFev2sd/rdzHosUoyqOhlnx2JjBUD6Fs+or74ZlRSzdBya+IvEH7SHiu41SRvDlvBa6ejfu1mj8yRwO7nOBn0HT1PWgCDxH+y/4g0yxe70DVItWkiBYwtEbeR8dl+aQE/UivmWS2khkeKVCkiEhlPBBHUEGv1N8A+KT4z8Jad4ieIQvdKwkQdBJGxRsZ7EjI9q+JfjD4bX/AIW5eaZp6BDqk1uygf8APS4C7j+Lkn8aAOa8AfB/xR8QQbqwC2unxnY1zNnYT3CgDLEe3A7mvYrv9lK/S3Z7DxFFLcdlltjGn/fYkkP/AI7X1ppGk6d4Y0O20myAhs9PiCDP91Byx9zySfXmvj/Wv2k/FL61JJoNtbRaZGxEUc0ZeSRB3chhgn0GMdOetAGfo/7MHia+tPO1PUIdOuAzqYihkwAcAhlOCCOR+vNeY614Ln8C/EW08N3Fwt09vPaN5qjYD5hVuh9M1+g3gHxQ/jLwlp/iSS3Fq94JN0YbeAY5GjODgcErn2zXyB8X0B+NwP8A01sf/QUoA+9K+KP+GU9X/wCg/B/35f8Axr7Xr4B/4aH+JX/Pe2/78D/GgDd/ZZTb4m1n/rzX/wBGCvZv2gfDur+KvCuk6Jodsbq6n1SLCjoAIZskk8ADuTXkX7L6bfE2sH/pzX/0YK+k/iZ44TwB4YbXDb/aZpJUghjJ2qZHBb5iOwCk+/TvQB836d+ynqU1qJNV1+O1uCOUitzOg/4EWj/lXlvxE+C/iT4fRDUZ5E1DTWYL58QI2k9BIp6Z7HJHvnivVfB37QPi+/8AFVhY65FbS2V/OsLrFGUMfmNsBU7j0J6HOR7819S+ONMg1jwfrWm3ABSe0l69mCkqfwIB/CgD8xPDXh+TxHr+n6DHKIH1CZIQ5GQhc4zivpH/AIZT1f8A6D8H/fl/8a+d9D1S60DWLPXLEK1xYypMgkBKb0ORkAjj8a90X9pL4hOdqWmnk+0Ev/x2gCa8/ZX8TxxlrDWLOdh0Egkjz+IDV4F4n8H6/wCD9TbSfEFq1rcY3LnDI6/3lccEfT6Hmvtz4Q/FzXfHerXeieILKG3ligM8ckIdAwRwpBDlufmBGD2NVP2l9Jgu/BtlqpQfaLK7VVbvslRgw/MKfwoA8J+HPwW1vxz4cGuWOuDT4vOki8oox5THPBA5zXD/ABN8B3/gHX7fRtQvhqMk1sk4kCkYBkddvJP93P419ifs5Lt+HIH/AE+T/wDsteI/tOJu8e2B/wCobF/6OmoA+ZfKo8qr+yk8oUAUvK96TyqveUKPKFAFHyjR5TetaHlU3yhQA6yfY3lP0PStfZWN5QratH81cN98UAN8oUbO1XvKo8qgClspPKFXvKpNlAFPZVqGEKMkcmrEUGTuI4q1soAq7RS+UKshDS+XQBV8vil2VaEZpdhoAqBPWgJ61b8r0o8qgCsEBo8urflN60eUaAKgjpfLq2I6XZzQBT2GnbKtiOgR0AVQlK8IkQo3erOyniPigDmnhMb7WHSnqmK3Li2EiZHUVnrH60AUHj+am7KvSRkHNRhPegCt5dL5eatbKa6hF3N0oAz7hxFHx1PSsUx5OTWjLulfcaj8o0AUtlGyrnlml8o0AUtlGyrvlGjyjQBS2UbKueWaPLNAFTyqTZV3yjR5RoApbKNlXfKNHlGgD//Q+mtopNgq/wCX7UvlUAUVjFP2irgjxT1ioAqCPHFP2ACrgi71HImTtFAGe3zGk2+1XfKpNlAFLaKNoq95VHlUAUtvtSbRV7yqPKoApbfak2ir3lUeVQBS2+1G32q75VHlUAUtvtSbRVzyqd5VAFLb7Um0Ve8qjyqAKe32pu0Ve8qjyqAKW32pNoq55VHlUAVVTLYxUxj71cihwM+tOMeTigDOKd6EGODVwpmmGPtQBCYs9ajMQIxWhGuRg04xc0AZPlUww+lahixTTHQBmeVR5VaXlUmygDO8qjyq0PKpfL9qAM7yqPKrS8qjyqAM3yqPKrS8qjyqAM3yqPKrS8qjyqAM3yqPKrR2UvlUAZvlV1fguyFxr8BK5MXzAe/QVjeVXpXwk07+0PFksI/5YWryEfXIH60Aen/DPRrm3D200Qk0/wA55Yo5BzE7nnyz1wfSvq6zSJLdEjGABXmS/YdFtYi7CNEAraXx94egtsicMVHTNBWx3hZUUk8AV8g/FCCf4qa1cW1nzpOhxSBW7STkckfyr0zVdf17xsx0nRAbayk4kmHBI9BXQWvhiy8O6H/Z9onY5Pck9SaLk2ucN4Uu4BeW9mx2ulvBcRH1jeNUk/75kXn617/azbl2Sda+FtT8UXGktLLaHGoeFL145Iz/AB2dyfMjJ/2eSvsRX1V4O8Zab4r0WLUtOcEhQJI8/Oh9D/j3oA9GnP7sg1xl3c+T5/mNwmH/AC6/pW2NRhlTaH/OuF1q6iSUrLzHLlW+h4NJlImi1eK3vNjEda9KtLiK4hEkRzmviDWfEWtWWo3vh5/n1XSMSGP+O4s3/wBVcx+oxxJjowrufAnxktgqW1+3Tgg8EU7E3PrCqd7cfZLZ5+PkHesbT/Feh6jCssNyoz2PFcl458W6baaXII7hXOOinP8AKgDznxT49uL37RHHaRXCW55yMgY74NfPnibRPEupNqfiDXmUpGsBtxHyPKfvnuck5ruPhvrdjqGvapFfEfvB8yH0q1rt5baf4W1zQriQE6W2ImJ621zny/8AvlgRQB85+VR5VaXlU3yqAPdv2ak2+Or4/wDUNl/9HQ1718exu+GmoD/prb/+jVrw/wDZwTb43vT/ANQ6b/0dDXunx1GfhvqA/wCmlv8A+jVoA5n4BeOjruhnwtqEmb3SlHlE9ZLboPxQ8fTHvWP+0H8Pf7Ssh410uLdc2ahbsD+KIdJPqvQ/7P0r5q8Ma5feFdds9e0//WWsmSvZ0PDqfYjiv0Z0zUNN8T6LDf22J7LUIs4YcFHGCrD8wRQB+WvlV+pPhn/kW9J/69IP/RYr4K+JfgSXwR4llsYwTY3GZbVj3jJ+4T6r0P4HvX3t4a48OaUP+nWD/wBFigD83PG0efGevn/qIXf/AKNajwTHjxnoB/6iFp/6NWr/AI0jz4w13/r+uf8A0a1UNAuk0vXNO1OQfJaXEUx+kbhv6UAfpF4n58N6sP8Ap0n/APRZr8tvKr9VrmG31TT5bctugvIiuVPVJBjIP0NfG7fs5+L/AO0jbpd2n2PdxOS2dn/XPGd2O2cZ796APoj4NcfDTQh/0yk/9GvXyz8U0z8b7lv+nmw/9FQ19q+GdBtvDGhWWgWbNJDZptDN1Y5ySfqSTXxr8T0z8a7o/wDTxY/+ioaAPuSf/US/7p/lX5QeVX6vz/6iX/dP8q/LLyqAPvP4Ejb8MdJH+1cf+jnrxXx4iH9obSGfp9q0788rivbvgcMfDTSx/tXH/o56+dvjTdTaf8VDqVv/AK21W1lT/ejAI/UUAfX/AIxDnwjrgi/1n2G5249fKbFfmB5VfqVo+q6f4l0eDVLMiW0vYs4PPB4Kn3ByCK+WtU/Zw1htYkOkahbppruShlMnnRqexAUhsdM7hn2oA9n+Box8LdFH/Xz/AOlMtfN3xcTPxpDf9NbL+UdfX3gzw1F4P8M2Xh2GY3Isw/7wjBZpHZzx2GWOPavkD40Sm2+KtxeAZ8gW0nH+xGpoA+66/Jryq/Vq1uoL21ivLZw8NwgkRh0KuMg/lXx1dfs3+LRcyCyv7F7fcdhkeVHKdsgRsAfxNADv2ZU2+JNY/wCvRf8A0YK9I/aWXd4FsB/1Eov/AETNXAfs2Jt8R6t/16D/ANGCvRf2j13eB7If9RGP/wBEzUAfHfhGPHizRD/0+23/AKNWv0u1/wD5AWo/9e03/oBr84fCcePFWjf9ftv/AOjBX6P67/yBNQ/695f/AEA0AfC/wT+H1j418Q3E+sL5thpapJJFyBJI5PlqT6cEn1xj1r7L1XXfB3gDT4jqEsGk2jHEccceM467Y4wScd8Divnz9mq+hhvNc0pziWdIJlHqIywb/wBDFd98Y/hrrHjr+zrzRZY/OsvMRo5W2Bg+CCpweRjnP9KAO78N/EfwZ4tv303w9qH2u5SMylPJlj+RSATmRFHUjvXC/tDru+HjD/p7h/8AZqZ8JvhNdeBbmfWdZuI5L+eLyUSHJSNCQWySBkkgdsD3zVn9oBQ3gAg/8/cP/s1AEP7PC7fh6o/6e5//AGWvFv2lE3+OrE/9Q2L/ANHTV7d+z+u3wAB/09zf+y143+0bHu8b2R/6h0f/AKOmoA+b/K70eVWl5Io8qgDN8qjyq0PKp3lUAZvlUeVWj5XbFL5VAGb5VPjDRvvWrvlU7yqALkeJU3rT/LNV7YmJ8HoetauwUAUvLxTli3Ntq55ef4asRwheq8mgCuIgowKdsq3sNJtFAFXZS7Dmrezil2UAVNppNlXdgzil2GgCkEpdnNXNho2GgCoU9KXZVoJ60uygCp5dN2Gr+00baAKQQ07aKt7OaXy80AVNvtTghqz5dATmgCEJzVG4ttjb1HBrXC4NPMYZdp6GgDm5I8rmoPLrZe3Kko1UfLPSgCr5dZty3mHYOgrSuDtXYvVqz/KzQBT8oUeXV7yqPKoAo+UKPLq55VO8qgCj5dHlCr3lUnld6AKXlCjyhir3lUeVQBR8vtR5VXvKpPL7UAUvKFHlCrnlgdqXYPSgD//R+t/K96BHzVvy6csdAFbyxUgiFWBHzUoi5oApsm1c1W8vPNX5l5CioNhoAreXS+V71Y2GjYaAK/lUnl1Z2GjYaAK/le9J5dWdho2GgCt5dHl1Z2GjYaAK3l0eXVnYaNhoAreXS+V71Y2GjYaAK3l0eXVnYaNhoAr+XR5XvVjYaNhoAreXSiLJxVjYasww8bjQBW2YHFMK+tXzHmozHzQBR2CmmPJq60fam+XQBVVMMDVry8jpR5dW4Uyu30oAoNFTPK961DF2qPy6AMvyvejyvetEx4pvl0AZ/l0eXWh5dHl0AZ/l0vle9X/Lo8ugDP8ALo8utHy6Ty6AM/y6Xyver/l0eUKAKHlUnl1oeXR5dAGf5dek/Ay4EHxRv7GQ/wDH7o7mMe8EuW/RhXDeXVWDxP8A8K+8T6N46aIywWDPBcAdfs8+0yH/AMhgD3NAH0348g1PXI5LDTXKeUMkj1JwP1Nc14G8ISy3B+1OZERsDd6CvT/Ct/oeu6Lc69pF4L22vLwKkmCmEAyAQe4J5rR8NNbW6eYSAKAOxSTSvDemmaZ47aCJcySMQAPqTXhvij4z6HM5tNOtp9QUf8tBIbaM/Qj5j+IFedePvF15401c21udmmWrEQrnAfH/AC1fPHPbPQe+a5N/D18sfm+VM4IyNtpdEH6EQ7f1osVc8++IGrXUHiCDxl4X0uYpIn2fUrdrh7nz7YnPAk5ypyQB6mvT/AGl6/pgg8QeDrtpdPuBvAByUB6o49veuam0PUtRhktIIpYw4IkkAIeNDwSmf+WnZRj72M8ZrP8Ag5feLPhd4iutIvzHqPhrjy2WQieCTALxx5BEsSsSq7iCQMg4xkM+p9t6Lqz30QXV7dref/npH0P1H+FbVxothdj/AI+1IP8AeyK5uy+I3w9vjHbtrdjbXci5WG6lS3lP0WQjP4ZrI8U+JksYcaWbW8nk/wBUgnHzn2wefzoKK3xG+G+jeJ9OtL9dQ/szX9Ey2n6hC+JEB+/E/qp9D/jXjsFvrtjOsfj7wkdVTP8AyEtIAEhHrLBwM/7uK6fw14O+JPjDVjqvjq/i0fRLchlsbIfvJe4M0xLMFHdYyM9+MivQn8S/YPEM/hDctvqu0z6dJJxHOI/vwt/I98EMKAMjwr/wr/XAYPDuveXKgyYLhGilQe6vg/j0ro7zwRp7yBrq4F0ByFjPX2r5m8WajpupeLH1TSYjZySjzzEfv29wCY7iM/RhyOhDele9eAtSs9RtI7559jxnDRk/ccdR/Ue2KAOJ8aeHtNTVotX0L/R9Rgi3kJx9ot/4sgcbl6+4z3Br5A1PxpqWpz6poF8WSe5EVqD0J2X0P8sH86+1/FD2d3DrGt2En+keF7v7QuOcwOBLIvuMFgP96vn/AMVeGdB1m707xVo8kbJFq+oxlR1Mcfl4b6CVf1qkJlXy6PLrQ8ul8o+lSM6XwH4yuvAesTaxaWyXLywGAq5IADMrZ4/3a7Hxj8YtU8Y6BPoFzp0NvHOyMXV2JXY4bv8ASvKPLo8ugCh5dereBPitrPgbTZdJgt47y3kk3xiUkeWT97GOx449frXnPl8Unl0AemeOvilP460pNO1DSYYngkEkU0bkuh7jnsR1H0Pauo0/4/6xp9hbWCaVAwtokiBLvyEAGf0rwvy6PLoANWu31bVbzVZEEb3k0kxUdAZGLY/Ws/y60PLqaGznuGKW8TTEDOFBJx+FAHqHg34z+IvCthHpN1CmpWkIxGHcpIo7IG54HYEHH04rotY/aE8QXlsYdH06HT5HGPNdzOR7qCFGfqDXi/8AZGpf8+c3/fs/4Uf2RqX/AD5zf9+z/hQB6r4e+OfiDQ9Ig0yazTUJIzI7TzSN5jmSQyHP54rzfxF4oufEPi2TxbNbrFLJJFJ5SklP3Cqg5687aw2hZWZWGCOCDSeXQB78/wC0TrboUOj2/Ix/rGr5x8utDy6PLoA9a8IfGTU/CHh+28P22nQ3EdsZCJHdgT5jl+31rgPGnia48Za9Jr1zAtvJIqLtUkj5BjvWJ5dHl0AdX4O+IXibwSzJpMwktZDlreYF4ifUcgg/QjPfNek3X7QviiSAx2thawSkY3ne+PcDI/XNdx8JPDPhDUvB0d1rNhaXFyZpQWmRC2AeOtepReEvh9ZuLiLTNPjdDkMY4+D680AJ8Op9YuvBum3uvyNLfXKyTOz/ACkiSRnTjsNpGB2FfJPxsZJviNqWw58tIEP18pT/AFr6u8SfEjwn4btXkmvo7m4UfLBAwkcnsDjIX6nFfD2talda7q11rF5jz7yUytjoM9h7AcD2oA7Lwh8XPFXhCyTS4PKvrOP/AFcc4JMYPZWBBA9jmu7/AOGi9c/6A9v/AN/Hr5/8o+lJ5dAHWeAvG954Cv7m/s7VLo3MSxEOxAAznPFb3jz4q6j470iLR7ywitUinE4aNySSqsmOf96vNfLqQQigCLTLh9N1G01JE3m0ljmAPQmMg4/Sverz9oDWby0ntG0iBRPG0ZId+NwxXhflClEVAD9F1XU/D2pwavpEpt7q3OVYDPXggg8EEdRXvlv+0Pra2wS50eCSfHLJI6J/3yQx/WvAhFnoKd5PrQB6nB8afFY8Qf25eIk0ccbxx2gykKbyPm4yS3GMnPWoPGvxY1Hxtov9i3enxW0fmpLuRyT8mfX615t5Q9KPJPpQB6T4J+LGo+CdF/sW00+K5TzXl3u5By+OOPpXK+O/F13461aLV7u3jtnigWALGSRgMzZ5/wB6sDyh6UzyaAMryqQxeorVMRHam+VQBleT6U3y61fK9aQxUAZfl0vlVoeURSeXzQBQ8qk8utDy6PLoAoeV71ftmyPLb8KPLpwjOeOtAF+OHJye1T+XVhEwgz1qTaaAKnlUeVVzApQtAFLyvejYau7fajZQBS8unbKt7KXYKAKewntT9lWtpo2mgCpsNGw1b207aKAKWw0eXV7YKTZQBTCetL5dW9lGygCr5dHl1a2cUbTjFAEPl5p4j7VMFAqQL3oApy2/mLx1FYl0gi+c966wKOtYWoRBpSOxoA5dhuO5qbsFXmhKkj0o8r3oAp7DSeXV3yvek8ugClsFLtFXPLpfK96AKPl07YatiIUvle9AFPYaPLFXPLFJ5dAFLy6Ngq75dHl0AUvLo8urvl+tL5YoA//S+0vKFPEXFWvLFO8ugCqI6lWOrCx8ZpXTEZNAGUybjmk8r3qzso2UAVvK96TyhVrb7UbKAK3le9Hle9WdvtRt9qAKvl0eXVrZRt9qAKvlA0vle9WfL9qNvtQBW8r3pPLq1t9qNlAFbyvejyverO32o2+1AFXy6XyverW32pNvtQBW8r3pPLq1spRGWOAKAK6Q7jzVgr6VdEOxdoppjoAolQaTYKu+XTDHzQBTMdHle9XDHSeXQBT8upYk2t9an8unBMHNACGLmozGAa1Cg4NRmLmgDMaOk8r3rRMfFN8r3oAoeV70eV71f8ujyvegCh5XvR5XvWh5R9KTyvegDP8ALo8utDyvajyvegCh5XvSeXWh5XvS+V70AZ3l0vle9aHle9J5XvQBn+XVe6sLa9tpLS7iEsEo2srDIIPrWz5XvSeV70AdR8M7p/D3hfX/AA/bFjb2DW97Ao5dIiGjlx3PlttJ9ARW017rGn+EpdSuywS/Jhtw3yF/NzlsdcBc4Pc15Hrr+JrCxfVPBt7Lp+r2oLxSQkAun/LSPkEEMOx7gHtXUD/hKX0HTLrXrj7fBqUMV3FdNI8sku9eRI7gYaMkrtAAHagDn2jlC/uX8t/UVROkwCZ7mMDzXOctkkH1yCrE/Uke1b/l0vle9AC6NZazaG4ae9M8d/EYxHd3EaDH9+ISEHg9wcdqhudOubNQ9ymyN+kmQYz9HBKn864u80jx1danPLDrstpZykyeXBJJbuZDJJ954yPMCxFFUMCABgYAxXR6VbeIdOXJ1WZ3H952lB4/jEjlSPYKBQBFfeHtG1VBNrllDeBFMUUM6A4D8vI4I4JOMDqAo9aytK8I+HtE04aTpdhFb2gYyCMD/lof4vr79q6/yIkdzCMI7E88nk96d5R9KAPV/hx421BNNvfDmszvePYxG5s5ZDvkeCMjzYpD/FtyNpPJDEHOMnzP42x3zeG7/VtHnP8Aavg+aK+s5x997cqZoST1IaIPAfVlj9K6jwLYNJq8t2w/dC2uIG+s8TY/9BP6V57pmsTav4b8HX0wE513w/qdlID0efSybm3J+hjP51SBmVqF/Z+J/EejePNI4tPEukGeeMdEvIpIlkP/AAJSPrjNdR4esL3UNcg062vTZR3AJ3E/JvT+E+nmLnn1Va8L+Da31kmseEZz5lt4Yu57SKQ9w8nGP+Aqp/Gva5b650eGTUrOTyp4FJjbAPPbggg5PGCKkDovGNkPhnHrmkvcNPc+JNNu5I43/wCer+VbwgfWQ15d4X8Np4e0qOzdzPcMXlmkJPMkh3NjPRcngVtjTNW1eWy8RePr/wDtXxSijzyiCK2tIwP3UEUQ4yu5mcnJ3Eela/l0AUPKFHl1o+V70nle9AFDyvejyvevZvg7pGm6p4nubfU7SK6iSzdgsqBwHEiDOD3wTXsetT/CXw/fnTtYsLOC4Cq5X7Hu4PTlUIoA+NfKFHl19deKPAHg3XvDM+teHbeKGRYWmhlg+RH2DOCvTnGOgIP41yXwk8BaJrGnza7rduLrEpiiifOwbQCWI75zjnjigD5y8ujy6+uJde+C1vK0ElpZ5jJU4siRke/l814t4tt9K8ReKvJ8D2yyQSxoEihi8vLoCWwpA9KAPMfK967jwB4tXwRrM+rNafbPNgeDaH8vGWV85wf7tbXhzRo/CviWxufHVgbfT5BLkTxb0fCkD5MHOCR2r3R/Bnw88b6NJdaBbxRA7lSaBDCUkA7rgZ6jII6dKAM7w18X7nxTrEOjafoREkuSWNxwiDksf3fb+fFbnj/4k2ngox2MEH2zUJV8xUJwiJnALH3I4A/TjPmHwQtmtvFGpRyjEkdsUPtiRc/yrm/jCpfx1eeyQ/8AosUAeU3sr3t5NeyqA9xI8hA6Zc5OKreXX25qfgPwVdaMj3dlbWMUYSWWaONIzsUZILY4B7+1ZGhf8Kk8QTPoelWNpJIoOA9vtdwOpV2AY/nnvQB8d+V70eV716v458DQ6D4vg0fTm2W2oeW0O7ny/MfZgk9cEfliveL/AMP/AA38D6PDJq2nwNHkRh5YvPlkcjOeQx7E9gKAPjDyhR5XvX0f4KsfCfiL4iaw9pYQTaWbVWhieEBVI8oEhSOOc1wvxU0uy03xjcWunW6W0KxREJEgRMleeBQB5T5dHl1oeV70vle9AGd5dL5XvWh5XvR5XvQBn+V70eV71d8v2p4i70AURFilEVaHle9SLFjigDOENP8AJ9a0hD6UMqxjL0AURD60GNF5ZgKV5mbhOBVUxknJNAExaEd80zzYvemeV70eV70ASiSE98U8LG3Rgar+V70nl0AWzCKjMNLHJInB5FXkKS8Dg+lAGaYfWmGLFbHkN6U0wetAGP5QIppixWuYcUhizQBk+VS+Sa0vKPajyjQBm+Sau29px5jD6VaitmduenetHy/agCiseOKl8r3qxsNSKuRigCn5XvR5dXvK9KTyiKAKXl0uyrfl0bDQBV8ul8urOzinBTQBU8ujy6ubTQEoAp+XR5dXdnpRsNAFPYaAlXNhpdlAFMJ60vl1a2GjYaAK3l0eWathaXbQBT8upNmasBaMbeTQBTl/dr7mqLRB1wavSKZG3GkCE8UAYE9sT25FUtvtXUSw5+YdqzprXPzrQBj+X7UbKveXR5dAFLb7Unl+1XvLpfLoAoeX7UeX7Ve8ul8ugCjt9qTy/ar3l5o8ugClt9qNvtV7y6QR0AUfL9qPL9qv+WKPLFAH/9P7v8r3qTyxU3l84qbyxQBVWPio54/3YHvWgI+KhuE4ANAGV5dHl1b2CjZQBV8r3o8r3qzspdgoAq+V70nl1b2CjYvrQBU8ujy6t7B/eo2UAVPLpfK96tbKTZQBW8r3pPLq1spdg/vUAVfK96PK96tbB/eo2DFAFXyvejyverWwUnl+lAFXys1bSER/WrcVvtG49alMYFAFHaKbsFXTEDTTHjpQBTMY6Unle9WdlL5eeaAKvle9Hle9XPK96b5dAFXyvek8urnle9L5XvQAqR5QGkaKrkEf7upGi5oAzTEMU3yvetExcU3yvegCh5XvR5XvV7yjS+V70AUPK96Ty60PK96TyjQBQ8ujy60fK96PK96AM7yhS+V71e8o0vle9AGf5QpfK96veXS+V70AUPK96Ty60PK96TyjQBQ8urXhfUmgnufh1qHNjqiy3mlN/wA8byIGSWEf7My7mA/vA+tS+XWPq5+wGw11F3SaPeW94PpFIC4/EZB9qALJjA5NRw+XPEk8Tb45AGB9QeRV3UlR/NeI7IhN19I0k5/8dFU9HtPs2lWdoc5t4Y4yD1GxAOfegB/l0jRsASo3HsM4z+PNaPle9Hle9AHDReJNB1dJLTTb0/bYiBLb4KXMTg5KuuG2njGeV7jIr07TtC0m7j+1T6j9ktkXfI1wI4pEQdSQJJF/X8K828QfDfwT4qu0vvEOkRXdwox5vKSY/wB9MH+Y9a6rwl4J8P6feW+keFvDstzcFtyy3d2JLS0Cc+c8QEYO3HGQecYoA9Fl13RNI0h73SY2g0+zt7mQvJ/rJCITNI7ZAwQsagccebjg8V89fD+4gX4ZfDu/nOP7I0nX9UlHpGbaROf+BSCuy+Id0fEXhq/0HQLopHrPmaPY3JG8zpv8zUL4gEZUlfLXkAkccMK8+1nw7D4Q+G0+gWU7XWoa5Fb+GbeST/nlcyCS52IOAFhjZj+GSaAOi8IaVBZaLFcJGEuL8JcXB7vK6gEn8AB+FdppFtBJqL313F9ot9IiN0Yj9ySfB8mM+xYc0y3tRDCkS9EAFT2SSW+jxTDOdXmvJJPeO3lWGL8jGx/GgDGtbV4YVEz+bK5Mksh6vI53O34sSas+V71e8o0eUaAKPlUeV71f8r3pfK96APUfgkm3xXdH/pyk/wDRsVZ3xgTd4zkP/TCL+VafwgmtrPxLdS3UqxIbNhl2CjPmR8c1S+Kctvd+LJJraRZl8mMZQgjp6igD13wEMfC6Ef8ATG6/9GSV5p8MfH2m+HLOXRtZ3xwvIZY5QC4BIAYEDnHGRgHvXoXgvUNPg+HMNtNdxRyiG5G1pADzJJjjOa818BeE/C+vWNzPr1ybeSOXaoEqx5GM9CKAPTf7A+Fni2Ym1FvJcy5bEMhikJ6k7QR+PFeXa74Zj+G/i/SNQtJXeyklDgt98BSBIpIxng9fevUdI8HeAdA1CLV7bUAZbfJXzLlNoyMZ4xXm/wAVfEmm+IL6ztdMkE0dkJMyj7heTHA9cbetAHefGnTftfhq3v0GTaTjP+5ICD+uKX4Irt8K3Y/6fX/9FRVt2d5ofirwXbWOr3ccf2mCNZR5io4aMjJ56cjPSoINU8G/D/Q5LTT7xJypaQRiQSSySEY529OgGcAYoA4P4TLt8a64f9iT/wBGiuO+LSbvHF4f+mcX/osVtfC7WbPTvEt1Nqkyw/bInAdzhd+4NyW6Z5rZ+LGl6FOieI7C7E15cSxxOiyK6bRG3OBzngDrigDvPiXn/hXd0B/dt/8A0YleEfCtNvjzSz/13/8ARMle2fELUdOufAtzBBdRSSEQfKsgJ4kXsDXjPw3eK18Z6dPPII0TzcsxAAzEw6mgDsPjFDdT+J9Giss/aHQCLHXeZOP1r0/xAmiDw3ap8RWhkAZd5UOFMuD9zZ8/TPT+VecfErVrW38WaJqtpItyLMLIRGwP3JM44rvNZfwV470iGO61NEQMJFIlWORGxjBDfrkUAcP8OU0JfiFq58Nf8g37J+5+96xbv9Z833s9a4n4vJu8bXB/6ZRf+gV7J4X8O+DfCd9LfWGsrLJLGYiJZ4iMEg9sc8V498T5ra98Wzz2kqzxmOIboyGHC+ooA8u8ul8r3q/5XvS+V70AZ/le9J5dX/KNO8r3oAz/ACuadsFXxFSiLmgCkIuM1IIqvCH0pXAiQuaAM6UrCPU1lOHkO5quvudtzdabsoApbDRsNXNoo2igCnsNGw1d2UbKAKWw0bDV3ZQIyaAKflmnCMjnvV7ZQI80AS20gceW/WrRgz1qkIwBxWxbfvl2t98UAUfI7GmeUBWwYKQwEdKAMYwntQICTgVrNFxzUsUUS/MzjP1oAqJbhFwKeY6vARf3x+dOEanoQaAM7yx/doEYBrR8k+lIYRQBT8sdqPLxVwRYp3l9qAKPlU0xVeMeKTy/agCj5dAjFXtlGygCj5dHl1d2D0pPL9aAKmw0uyrXl0eXQBW8sd6d5Yqx5dGw0AV/LFHle9WdlO2mgCn5dL5XvVvZml2GgCl5frVWbk7BWnINi5qiYyeTQBVCCnbBVnyzT1TtQBWCdqrSQbG9q1PLoMYYYagDAltd3zJ1qkUI4NdH5RU4pj2ySD5l2n1oA5/YaNhrUks3j56rUXle9AFDYaNhq95VL5XvQBQ2GjYavbBSeWKAKeyk2Gr3lelL5XvQBQ2GjYaveWOlHlj1oA//1P0L8r3p3l1a2HNP2mgCoIuKr3MfStVUPSq9zGeDQBkeXR5dXdpo2mgCl5dJ5ftV7yzRtNAFLy6PKNXdpo2mgCl5dJ5ftV7aaNpoApeXR5dXdpo2mgCn5XvSeXV3YQaNpoApeXR5dXdpp6Qs5xigDP8AKJ4xV2K2C/M3Wr6WwQe9KUoAqlMUzy81c8o0hT0oAp7Kb5dXNpo8s0AVPK96PK96t7TRtNAFTyvejyvere00eWaAKnle9Hle9W9po2mgAt4/k/GpTHVu3iPl5p5i5oAzzHxUfl1pmLimeUaAM/yjR5daPle9J5RoAz/Lo8utDyjR5RoAz/KNJ5ftWj5dHl0AZ/l0eXjrWh5Ro8o0AZ3l+1L5daHlGjyjQBn+XSeX7Vo+UaPKNAGd5ftVPUrOO7sZ7OZxHHcDyix6Jv4z+Gc1u+XTHtkkAEiB8HIzzz60AY9tC0lti4QfPwR1B7fr1rOjil0xik2TAM4l68df3memO7HrySSTius8o0eUaAMaO4tJI0l8+JEk+7ucR5+gfB/StGGynuCBbgSk9ApBz+RrgPGPgCXWHfWfDl5No+sgAGa1nktjLs6CRouuOmWDDHBH3SvJaV4k8X+GSbLxib+5jfgm4nae3yOM5kZio77VNwT/ALPQAHtGpwQaCQ/ii/tdDg4y11KhkPtHChLSH2Fc9f8Ai2fXbWTwt4TsrvStAn/4/LuceXqepp/dReDbwsONz7Tj7oyc1zcPjLwhZb57FLeKSTqYCkCH67xEfzWqX/Cc3ty5h0e2W4TPyxabHLeSP9ZWjht4ue5ZvXBqrAd/Y6RO8z3ZREkjhEUcany7e0to+kak8LGOrHqT9ABxGmf8Vl4pi8SREyaHoEUlvprMCPtNxP8A8fN3j0IAii/2QfWtuHT/ABX4ptVtPFccWl6R1OnQSebJL3/0mYYDe6qMe4xiu3itY4IkhhQRxxjCqnAAHYCpApeX7Uqs0kUcC7TFaAxrg8oZGaZgw6g+YzEdiuO+caHlGmG1jZxIyAuOAcc0AUvLo8utDyjR5RoAz/Lo8utDyjR5RoAz/Lo8o1oeUaPKNAGf5dHlGtDyjR5RoA9O8AeGvCGvWBg1QeZqG9yEEjo3lrjnAOOprjfG2gWmga/Lp9iSYdquobkjcOmaj0PV77w/e/2hp+3zdpT5hkYNJreq32v3x1C/2+aQF+UYGB7UAcx5dJ5ftWj5Ro8o0AZ/l0nl+1aPlGjyjQBn+UaPKNaHl0eXQBn+XR5daHlGjyjQBneX7UeX7Vo+UaPKNAGf5Ro8utDyjR5RoAoeUfSk8utDyjS+V70AU/K4pwiq95XvThFigCksXFZl4d0mwHhP510Ei+XGz+lYBjJJY96AKflj1o2L61d8r3o8r3oApbF9aNi+tXPKpfK96AKWxfWjYvrV3yvegQ5NAFMRCneWKveV70CHuaAKaxDqakEQq4IfWneUAMtwBQBTEXpUiMlu4kY4qCa5x8sQ/GqDKznLNk0AdFJdqR+5G73NUJJp3HzE/hSWvzR7fSrIi3HaBQBSjjLtk9Ks7BV1YQowKDFzQBS2Cl2e9W/KpfK96AKyPIn3XNWku2HDrmk8r3pPKoAvRvFL904PpVjy81kiL0q5DcSR/K3zigCwYqaYsVfTZIu5OaDEaAM/ZmkMferxipuygClspdlWynpRsoAqeXR5dW9vFLt4oAp+XR5dXQtLsNAFHy6PLq7tFLsNAFLaaNmKu7DUMo42igDNddxpPK96t+XS+WaAKXl0vle9XfLpdlAFIJil2Vd8qjy89KAM94eMjtUWytcR1DJb45A4oAobD2qJ7aOTkjBrQ8o0u3/ZoAxXsGH3OartbyL94V0hjBpRHQBzHlt6UeXXTGAN1Apv2aM/wigDmvKNHln0rpBax/3BThAnZB+VAHNiFiOlL5DeldN5XvR5XvQB/9X9JPKxUgj4q1t/2acqHFAFVY+ahuYjsB960tpps0e6I/nQBg7TRtNXNpo2mgCntNG01c2mjaaAKe00bTVzaaNpoAp7TRtNXNpo2mgCntNG01c2mjYT0WgCntNG01ppaO3J+UVaS3SPp1oAyo7Vm5fgVdEaqMCrezNJ5dAFQoTTdlXCmKbtNAFQp2pvlVd2mjaaAKPl+1J5VX9po2mgCj5XNL5VXdpo2mgCj5ftQI/RavbTRtNAFLyqPKb1q7tNKsZJA9aAJYYtsS0vlGtExYAFJ5VAGY0fam+X7VpGKk8o0AZ/lUeVWh5Ro8o0AZ/lUmytHyjR5RoAzvL9qd5R9Kv+UaXyvegDN8v2o8v2rR8o0eUaAM7y/ajy/atHyjR5RoAzjF2Io8v/AGa0fLo8ugDO8v2o8v2rR8o0eUaAM/yqTy/atHyjR5RoAz/KpPL9q0fKNHl0AZ3l+1Hl+1aPl0eUaAM7y/ajyx/drR8o0eUaAM7yvWgxdiK0fLo8ugDO8v2pfKrQ8ujyjQBneV2pfK4zitDyjR5RoAz/ACqTy/atHyjR5dAGcIjml8qtDyjR5RoAz/Ko8qtDy6PKNAGd5ftS+VWh5Ro8ugDP8qk8v2rR8o0eUaAM7y/ajy/atHyjR5dAGcYuxFHl+1aPlGjyjQBn+VSeX7Vo+UaPKNAFDyj6U3y/atHy6PKNAGd5ftSiLmtDyjQI+aAKnle9PEfFW9lSCLigDFv1Ih2+prG8o10epJhI/wAaydpoApeUaPKNXdpo2mgCl5Ro8o1d2mjaaAKXlGpPLq0E708JnigCmIjTxEc1dEfYUrARqWbgCgCk4WJd78AVkTzNMfQVZnkeZ9x6dhUO0/3aAKm0UbRVvaaNpoAdZD5yvrWxHFtGe5qnYREzgnpW4YwaAKJSmslXfLppjIoAp7DQEq3tNG00AVNoo2Gre00bTQBT2mjaaubTS7DQBBEzRnK9a27eRZxjo/cVlbTUqblIZeCKANcx4qNouat28onT/bXrUuwd6AM3yu1MMXatPy+1NMeaAM3y/wDZpfKq95Qo8sdKAKew0bB6Vd2UbKAKeyjZVzZRsoApFdozVUx1oMu40mygCh5dHl1oeVR5VAGf5dHl1oeVR5VAFHYaNhq95VL5XvQBR2UhjyMGr3lUvle9AGUYypwaQR1pNDkVF5RoAp+UaPKNXPKNLtNAFLyjS+Wau7PUUm0UAU/LNJ5Rq7tFLsHpQBR8o0eUau7f9mjb/s0Af//W/UHyvQUoiI7V17WiN1SoTp0R5AIoA5nyj/dpfJyCDXSHTj2amf2fKOmKAOJeEozKRSeX7V1N3psgbeB9ap/YJPSgDB8vtil8v2rd+wSelOGnP3xQBgeX7UeX7V0Q031NSDTox15/GgDmfL9qVbd3PyiupFmi9FFSfZ6AObWxY8vxVhbZE+6Oa3Ps9H2egDHMZpPKb1rX8jFJ5Q9KAMnym9aaYz2FbHkn0o8oelAGL5RPak8v2rb8k+lHlD0oAxvKPpR5R9K2PIpfKHpQBi+Uf7tHlH+7W15Q9KPKHpQBieX7UvlH+7W15Q9KTyaAMbyj/dpfKPpWz5Q9KPKHpQBjeUfSpraDdJnHArT8oelX7a1xHux1oAzjESc0nlYrc+zj0qMwdsUAYnlN60eUa2vsw9KPs4oAxfKPSjyjW19nFL5HtQBieUf7tHlH+7W19mHpR9nFAGL5Ro8o1tfZxR9mHpQBi+U1HlGtr7OKPs5oAxfKNHlGtr7OKX7OPSgDE8o0GI1tfZwO1H2cUAYvlN60eUa2vs5o+zigDF8o0eUa2vs/qKXyPagDE8o0eU3rWz9npfsw9KAMXyjR5R/u1teRR9nHegDF8pvWjyjW19mHpR9nFAGL5Ro8pq2vIo+z5oAxfKNHln+7W19nNJ9noAxvKNHlGtvyBR9nHpQBieUaPKb1ra+zD0pPs9AGN5TetHlGtn7Pz92l+zigDF8s/wB2k8v2rc+zj0pPsw9KAMTyj1pfKNbX2cUfZzQBi+Wf7tHlH+7W19mHpR9mHpQBi+UaPKNbX2cUfZxQBi+U1HlGtv7OPSk+zigDF8o0eUa2vs4o+zD0oAxfKNHlGtr7PntR9mHpQBi+U3rR5R64ra+zij7OaAMjyTT1iOK1xB7U4W/PSgDmNShPlI2OhrG8v2rubu0D27jFc/8AZhQBi7DS+X7Vs/Zl/uij7MKAMXYaNhra+ze1KtsPSgDIEfH3aeseOcVr/Zz6VJ9mA4oAyBH61jXknmPsT7grqLxBFFtHV+Kxfs4/u0AYew0bDW59nH92j7OP7tAGHsNOWMscVtfZx/dqdLUAZoAp2MP73PoK1vLNWbO2wC34Vc8kUAZGxvSmlOeRWz5IpvkD0oAxyg9KPLHpWz5Apv2cUAZPl+1Hl+1a/kUn2cUAZGwelGwela/2el+zigDH2D0pQmDWv9nNH2cUAZ8RaJw61vqokVXXoaoiEYxWlYDB8k9DyKAIzEe1J5Rra8jjFN8j2oAwzF2xR5Z/u1tG3HpSeQvpQBjeUc5xR5R/u1s+SPSjyR6UAY3lH+7UbxkcAVuGAAdKhMGTnFAGL5TetAiPpW39nHpR9nHpQBieUf7tL5ZrZNuPSl+zj0oAxhGaPLz1rZ+zj0o+zj0oAyBEaPJzWv5NHke1AGR5J60eUa1/I9qXyAaAMfyjUTwEHIroPIFNNuDQBz3ln+7R5RrbNtjgU37P/s0AY/le9J5Z/u1tfZh6Uv2celAGJ5Ro8o9a2vs464o+zigDF8o/3aPKP92tryKPIoA//9f9jfs4pfs9ankj0pfKoAyhb+gpwt81p+VSiKgDIktQ6FazPs56Gus8r2qncW+DvA60Ac/9no+ze1bHlr6UnlUAZH2ej7PWv5VHlUAZHkUnk4rY8qjyqAMbyaTyTW15VHlUAYf2c+lL9n/2a2/KpvlUAYv2c+lL9n/2a2fKp3lUAYn2ek+zn0rc8qjyqAMP7OfSj7OfStsRUvlUAYn2ej7P/s1t+VR5VAGH9nPpR9nFbnlUeVQBifZ/9mj7PW35VJ5XrQBjpa72C1qC2AGAOlaMFrgbj1NWPJFAGP8AZ8dqb5FbBhpPJFAGR9nNH2c1r+TR5NAGR9nNH2cmtfyRR5NAGR9nNHkmtfyaPJoAyPIo+z81r+SKd5JoAxvs5o+zmtfyR6UeTQBj/Z6X7Oa1/Jo8kelAGR9nNH2c1seUPSk8mgDI+zmj7Oa2PKHpSeTQBkfZ/Wj7Oa1/Jo8mgDI+zmj7Oa1/Jo8mgDI+zmj7Oa1/JHpR5IoAyPs5o+zmtjyh6Unk0AY/2el8k1r+TR5IoAyPs5o+zmtfyaPJoAyPs5o+zmtjyh6UnkigDH+z0vkmtfyRS+UPSgDH+zmj7Oa1/JFHk0AZHkUfZzWv5NHk0AZH2c0eRWv5NHkigDI+zmj7Oa1/Jo8mgDI+zmj7Oa1/JFHk0AZH2c0n2etnyR6UnkigDI+zmj7Oa1/JpfKHpQBj/ZzR9nNa/kijyR6UAY/2el+zmtfyaPJoAyVt+1L9nPpWr5NPEOaAMr7PkYNc9PZGKUrXbeVVS9s/MTzAOU/lQBx/2ej7N7VteSaTyKAMf7OaUW1a/kU/yKAMYW3NPFsM1riCkeLZG7+goA5G8i8yY+icVV+ze1bnkk9ab5BoAxfs3tR9m9q3PJPpQICTQBjpaAnJqX7MScBa2PIIHSrlpabm3sOBQBUitRHGE9Kd9nFbRhFL5CelAGJ9nFM+zmtowd6TyDQBjfZzR9nNbXkfSl8igDF+z57Un2c1teRnpSeQ3tQBj/Zx6Un2YelbPkGjyaAMb7OaDbA1teR60nk0AYwtqkSHYyuOorV8ml8ke1AFtEDoGH8VHk1asUyhQ9qtmHntQBk+RSeSK1vI4pnkigDO8gUeQK0/K96QxcUAZLQZPSm/Z/8AZrW8nil8kUAY/wBnPpS/Z/8AZrX8kUeSKAMj7N7Un2c+lbHkijyRQBj/AGc+lL9nzWv5Io8kUAZH2ek+zn0rY8kUeSKAMf7OfSj7OfStjyRR5IoAyPs9H2etfyRR5IoAxzb5/hpv2c1teSKaYBQBj/ZyaPIrX8mjyaAMj7OaPJNa/k0eTQBkeRR5Fa/kijyRQB//0P248k0eTWn5dHl0AZnk0eTWn5dJ5ZoAz/K9qRoAw2kVpbDShM0Ac69rsbbio/s9dK9uHXFUWh2nBoAyvI9qjkSOGN5ZiERBksTgAe5rN8W+LNF8G6cdQ1aXBPEUS/6yQ+gH8z0FfGvjH4k6/wCMZik0n2axzlbeM/J/wL+8fr+AFfm3E3GeByVezl79V7RX5t9EeLj8zpYX3XrLt/mfQPiL4veGNHZ7fTc6nOO8ZxFn/e7/AIAivINU+L3ivUCVtZI7KM9ok5x9XyfyxXkKtUytX8tZrx5nWObXteSPaGn47v7z8/xGb4mt9qy8tP8AgnTXfiTXdQJ+2ahPKD2aRyPyzWcJXzuyc+uaoK1TK1fnlWvVqvmqSbfm2zyJTlJ3k7nS2XiPXLDH2S/mjA7CRwPyzXcaX8VfE9iQt063kY7SjnH1GD+ea8oDVMrV7OCzvMcG08NXlH0bt92x00sVWpa05tfM+q9A+KPh3VikN+p0+c4++cx5/wB/t+IFenokUqCSMh0cZBByCK+C1au98J+Pta8LyCOKTz7Mn5oZDx+Hofp+tfuHD/ihWjJUc2jdfzxWq9Vs/lY+rwefST5cQrruj668gN2o8gelUfDfiPSfFNiL3TZOR/rEP34z6Ef1ro/KX1r+nsNiaOJpRrUJKUZaprY+5hOM4qcHdMyvIo8itTyhR5I9a6jQy/KHpS+R7Vp+UKPKoAzPI9qPI9q0/KFHlCgDL8gfexU0NoHOSOBVfXtX03wzo13r+ryGOzsl3SMAScZwAAO5JAr41139qbxO+oyf8Izp1rb6eOIxdI0kp92KyKBn0Gcepr43POKcuybljjJ+9LZJXdu/oeZi8fQwtlVerPt/yQO1IYq+Cv8AhqP4jf8APvp3/fiT/wCO16Z8Ivjl4x8d+N7bw5rMFmltLFK5MMbo+Y1JHJcj9K+ZwPiHk+MxFPC0nLmm0l7vV/M4qWdYapNU43u/I+qPJNHk1peUaPLr9YPoDN8mjya0vLNHl0AZvk0eTWn5dHl0AZnk0eTWn5dJ5ZoAzfJo8mtPYaPLoAzBD60eSa0vLpfLoAzPJ9aPJrS8s0eXQBm+TR5NaXl0eUaAM3yaPJrS8ujy6AM3yaXyRWl5XvRsNAGZ5NHk1peWaz9V1HTtE0+fVtXuFtLO2XdLLIcBB/8Ar4A7mpnOMIuc3ZITaSuxvk0eTXjC/tG/Ctrr7P8AbZwmceabeTy/r/e/SvbtPu7PVLKDUtNnW4trlBJFJGco6HoQa8nA5vgca5RwlaM2t7NO33GFLE0at1Skn6EHk0eTWn5dHl17B0GZ5NHk1peWaPLoAzfJpfJFaPl14N8cPivdfDaxs7LRoo5dU1HeVMoykUacFsAjJJPA6dc+h8jM8zw+XYSeMxTtGO/5JL1ZzYivToQdSo9Eez+TR5NfBGneOP2j/E9qNV0dr65tJCQskNnEIzg4OCIsHB4781f/ALX/AGov+eOp/wDgJH/8br8yh4iYeaU6eDqtPZ8q1/E8NZzBq8acren/AAT7o8mjya87+Dk3jm78JSS/EATDUxdSAefGI38rau3gADGc16t5Zr9UwGLWLw8MQouPMr2as16o9+jU9pBTStfuZvk0eSa0vLo8s16BsZvk0eTWl5dHlmgDN8mjyTWn5dHl0AZvkik8mtPy6Ty6AM3yaPJrS8s0uw0AZnk0eTWl5dHl0AZvkmjya0/LpPLNAGb5NHkmtLyzR5dAGb5NHk1peXR5dAGb5NKIa0fLoEdAFDyh6UeUPStDyz0qTyxQBzNzYbf3kY47iqPlD0rs/K96oTWGSzR/lQBzXk57VJ5NaZhIOCvNL5dAGYIarXcWI8epreEVUbuIEgUAc75NL5IrV+z0eRQBk+TUgt8CtRbcdasx2ZY5IwKAMmKzMh9BWiLcINqjgVpiELwBS7KAM3yaTyq0vLo8r3oAy/Kp3lVpeXSeXQBneVSeTWl5dHl80AZvk0nlVqeXSeWaAM3yaPJrS8ujy6AM3yaXyq39Pto57yOKUZQ5yPwNLres+APDMscHiTV7HSpJxujW7u0gLgcEgSOMj6UAc/5VJ5NT/wDCffBr/obNG/8ABlD/APHaP+E++DX/AENmjf8Agyh/+O0APs48TbfUVqeTWUvxC+DituXxZo2f+wnB/wDHal/4WR8Iv+hu0X/wYwf/AB2gC/5Ipnle1dFpU+g65YxapolxDf2c+7y57eUSxPtJU7XUkHBBBweorS/s60/55/qf8aAOL8r2pvk+tTat4w+HOg3z6brniDTdOvIwC8NzexQyKCMjKO4IyORxT9G8VfD3xFeHT/D+u6dql0FL+Ta3cU8m0dTtjYnAyOaAK/kil8r3rtP7OtP+ef6n/GvPj8R/hCpKt4t0YEdR/aMH/wAcoAueVQIqqf8ACx/hD/0Nujf+DK3/APjldPc3vhey0n/hIL2+t4NK2LL9rknVLfy5MbW80ttw2Rg5wcjFAGJ5XtR5XtVP/hY/wh/6G3Rf/Blb/wDxyuzs49I1G0hv9PdLm2uFWSKSKTfHIjjIZWUkEEcgjrQBzPlD0o8oelaWu654L8MCFvEuqWeki5z5RvLlLfzNmM7PMYZxkZx0zWhpsmg6zYxanpE8N9ZzDKTQSiWNgDg7WUkHkY4oA50xZ7Unle1dp/Z1p/zz/U/41xuqeMvhvod9Jpet+IdM068gx5kFzexQypvAYZR3BGQQRkdDQAnlD0o8oelUv+FkfCL/AKG7Rf8AwYwf/HaP+FkfCL/obtF/8GMH/wAdoAu+UP7tHlD0ql/wsj4Q/wDQ3aL/AODK3/8AjtH/AAsj4Rf9Ddov/gxg/wDjtAF3yh6Unle1dNJBZy2f2q0wyOAyOrZDA4wQc4IIrO8r3oAyPJo8mtUxUzy6AM3yaPJrS8s0vl0AZnk0eTWn5dHl0Af/0f3b8sUnl1e2UbKAKPl0eXV7ZSeXQBS8ujy6vbKNlAFIJiuO8deLdJ8E6DLrOqckfLDED88sh6KPb1PYV3MzxW8LzzuI44wWZjwABySfpX5tfFf4gTePPFEt1E5GnWhMVpGf7g6v9WPJ/Adq/NuM+JlkuB5qetWekV+bfkvzPDzTH/VaV4/E9v8AM5zxN4p1Xxbq0uratLvkkPyr/BGnZUHYCsRWqkrVMrV/CtevVrzlVrSbk3dt7tn5RKbm3KTu2XFap1aqStUytWRkXVaplaqStUytWYF0NUqtVMNUytWhoXFap1aqQaplagDqPDviLUfDeox6lp0mx06js47gjuDX2v4V8RWHizSY9TsOD0ljzzG/cH+h7ivgZWr0b4c+MZfCWvRzSEmyuCI51H9zsfqvX8x3r9c4H4rqZTiVQxEv3M3r/dfdfr5H0WVZi8NU5Jv3X+Hn/mfbHlUvle9Wo/LmjSWIh0cAgjoQehqTyxX9tp31R+pFDyqXyvervlCl8sUwKHlU5LfdWitvnk1OI8cCgDB1XRNL1zTJ9H1a2W5s7kYlifo4Bzzj3FfDX7QfwX0HwXp1v4s8JxtbWkkwgnty5dELglWjLZIHBBBJ5IxX6CbK+ff2nEA+E16T2uLb/wBGCvzbjbKsLispxFWtTTnCLalbVW133t5Hi5rh4VMPOUlqlo/Q8N/Zu1Dwv4qlufBvibw/pt5c2kPn29xJZwmR4wQrpIdvzEZBBPPXNfYem+CvCOjXQv8ASNDsbK5QECWC2ijkAPBwyqDz9a+CP2W8/wDC1IwO9ncf0r9G9QuV07T7nUJELpbRPKQOpCAnH6V894dThiMmjVxEU5QbV7K9lZrXfS5xZK1PDKU1qnuJ5dHl18aXn7YMQYrYeFiU7GW7wfyER/nVCL9sC/EmZ/C8Tp6LdkH8zEa9qXiJw6nb6x/5LL/I6nnOCX2/wf8AkfbXl0eXXhXw+/aJ8E+OL+LRbmOXRtSuDsiSch4pHPRVlHc9gwGegya+g9lfcZbmmEzCj7bBVFOPl+q3XzPUoYilWjz05XRR8ujy6+WvE37U1h4b8R6p4efw9LOdNupbcyC5ADmJymceWcZx0r6b8P6kuvaDpuuJF5I1G1iuBGTnZ5qB8Z4zjPWuTLs+y/MK1ShhKvNKG6s1bW3VLqZ0cZRrScKcrtblry6PLrgfir8RYfhd4dg8Qz2DagJ7pLXy1kEZBdJHzkg/3envXG/Cj452nxT1260ODR30821sbjzHnEmQGVMYCj+9mitn+X0cdHLqlW1WW0bPr52t+I5YyjGqqMpe8+h7h5dHl1yfxG8ZRfD3wld+KprQ3yWrRL5SuIyfMkCdcHpnPSvKPhr+0LZ/EbxVF4Xh0OSyeWOSTzWnEgHljOMbR1+tLFZ9l+FxkMvrVbVJ2srPW7stUrbruKpjKNOqqU5e89kfQfl1+XT/AB3+LYdgPEEvB/55Q/8AxFfqnso2V43EmQ4rNPZfVsXKjy3vy31vbezW1vPc5sdg54jl5Kjjbt1/FH5Vf8L4+Ln/AEMEv/fqH/43R/wvj4uf9DBL/wB+of8A43X2p8VvjvafC3xFb+H7jR5NQNxaJdb0nEeA8kkeMFT/AM8859657w1+1R4E1i9istZtLjRvN486TEsAP+0U+YfXbj1xX4bWy2nRxUsHVz6cZp2aaktfVyt+J8pKgozdOWMafz/zPRfg1rWreJvhro2ua5cG6vbkT+bKQATsmkQcIAOAAOlen+XVtNkiCSMh1cZBHIIPpXzT8RP2jbL4f+L73wnNoT3r2QiJlFwEB8yNZOnlnpux1r+hK+Y4bJcBSeY1tEox5mm+Z230u9bNn2Mq0MNRj7aXZX7u3zPovy6PLrnPAPiuPx34R0/xZFbGzS/EhERfeU8uRo+uBnO3PSm/EDxZH4C8Iah4tmtjeJYeXmIPsL+ZKsfXBxjdnpXtfX8P9U+u837vl5r6/Da97b7a7XOv21P2Xtb+7a/yOl8ujy6+dfh3+0ZZfEHxdZ+FIdCeye8EpEr3AkA8uNpOnljrjHWvo69nWxsri9cF0t43kIHUhBmuTLc4wWY0HicHU5oJ2bs1qlfql0ZlQxNKvF1KbuiPy68C/aU0vU7/AOF9wdNjaQW1xFNOFGT5SZBP0BIJ9AM15he/tgIHK6d4XJTs0t3g/kIj/Os+H9r/AFAN/pPhiGRPRbkocfUxn+VfmWb8a8OY7B1cDLEtKaauoy0v8tTw8TmmCq0pUnU3Vtn/AJHitx4n+G7/AAlg8Nw6MU8VpLlr3y16eaWz5udxBj+XbjAP5n7d/Z80vUtN+FWkQ6pG0TyGWWNG4IikkLL+YO4exrwLU/2h/hzFCl/oHgK1/tg8mSeK3QRv1BDxqWb/AMdrV+G/x88X6vceKPEfibbc2ej6d9ojsoAIk3+aq8OQzdD3Jr4LhzMMqwGaQqTxKqS9nyLki4xUVrdt7uy6Js8bA1sPRrqTqXdraKystbvzPtHy6PLr4nuf2wL1n/0TwvHGn/TS7Ln9IlruvA/7U3hzxDqcGk+JNObRJLhhHHOJBLBvPA3HapUH1wQO5A5r9ew3HuQ4isqNPEava6aX3tJfefSwzbBznyqf4M+nvLo8ur2yvnj4pfHyz+GPiSPw7Po0moNJbpceYs4jHzlhjG0/3fWvsMyzXC5dQ+sYyfLG9r2b1fomejXxEKEeeq7I958uvkn9p74da/4gTTPFOgWkl79gjeG4iiBeQITuWQIOSByDjkcds4+gfhj48i+JXhgeJYLJrBDNJD5TOJD+7xznA659K6zXNZ0rw3pV1ret3K2llaLuklboB+HJJPAA5J4FeJm2FwOe5TKM6lqU0pKW1rap6/jfocuIp0sXh2m/detz81fDHi74w+I9Hs/hf4SEscdrkH7OnlSiMnP72bI2qCevy56HNbrfF342fDE/8Iv4gG+WD7hvozK+zp8soYeYvoct9a9Y139rrS4Ll4vDfh+S7iBwJriURZx/0zRW4+rD6VhW/wC2BqCv/pXhiKRO/l3JQ/rGa/nZVsrw1owzqoqkfd5lFuKito2XbunY+M5sPDSOKd1peztbt/TPrnwfqFzrnhLRNavQBcahZW1xLtGBvliVzgdhk10Xl1yfw58awfETwpbeKba0ayS4aRfKZg5BjYoeQB6eleQfE/8AaKg+Hfii48LR6E2oT2yxsZTcCJP3ihhgeWx4zX9IVs9wGCy+ljcTW/dyStKz1urp2Sb1tc+2li6NKjGrUlo7a9z6L8ujy6+IH/a/1UvmPw1AE9DcsT+ewfyrq/D37XGgXdwkHiXQ5tPjc4M0EguAPcoVjOPpk+1fPUfEHh6rUVNYi3rFpfe1ZfM4o5xg5O3P+DPrTy6PLqPSdT03XdNt9X0e4W7s7tRJFLGchwf88g8g8GtLZX6XCcZxU4O6Z7iaauij5dHl1e2UbKoZR8ujy6vbKNlAFHy6PLq9so2UAUfLo8ur2yjZQBR8ujy6vbKNlAFHy6PLq9so2UAUfLo8ur2yjZQBR8ujy6vbKNlAFHy6NmKvbKNlAFTb7UbfareyjZQBQeFJBhhuqubBT91sVr7KNlAGJ9ikXpzWfdWsm9RjtXWbBVS5jywNAHLCzk9KlWxyfmNbfl0vl0AZi2qJ0FSeVV7y6PLzQBR8qk8oGr/lGl8r3oAzvJFHkitDyjS+V70AZ3kijyRWj5XvSeUaAM/yRR5IrQ8o0vle9AGd5Io8kVoeUaPKNAGf5Io8kVo+V70nlGgBumxhb2M/X+Rr+ev/AILd/wDJVPhr/wBga7/9KRX9EFmmLlD9f5V/O/8A8Fu/+SqfDX/sDXf/AKUigDxnwB/wSK/aK+IvgTw38QdF8T+FYNO8UabZ6pbpcXN8syQ3sKzRrIEsmUOFcBgGIz0J611v/DlT9p3/AKGzwf8A+Beof/IFfrxN8RvE3wj/AOCbfh34leDnij1rw/8AD3Qrm1eaMSxiQWNuPmQ9Rz0r8Qf+HvH7ZP8A0EdG/wDBWn/xVAHo3/DlT9p3/obPB/8A4F6h/wDIFfJX7Vf7D3xT/ZC0/wAOah8R9X0bU4/E0tzFbjSpriUo1ssbP5nn28GAfMGMZ79K+yvgB/wVD/at+Ifx0+HngHxJf6VJpPiPxBpem3ixackbm3u7qOKUK4bg7WOD2r6D/wCC4v8AyK3wk/6/NY/9F2tAH3N/wTB/5MZ+GX+5q3/p2vK9f/ah/ah8BfsmeA9O+IXxC07UtS0/UtSj0uOLS44ZJxPJDNOGYTzQrs2wsCQxOSOOpHy7+w74i1Twf/wTF0TxdoZUajomheJ721LLvTz7a9v5Y8p3G5Rkd6/Ar9of9uD9oD9pnwZYeCPivcWM2laffx6jELayW2b7RHFLCMsDyNsrcf4UAffvxU/ZG+I3/BSXxnd/ta/BPU9K0Dwj4oWK1t7TxDLPb6ij6bGLOUyR2kF3CA0kRK4mJK4yAeK+lf2Cf+CdPxn/AGWPjjP8TPH2u6BqOmy6RdaeItMnupJ/NnkhZTia1hXYBGc/NnpxX5E/BL/goZ+0f+z98PLD4X/Dm+02HQ9OeeWFLiwSaTdcSGWTLkgn5mOK/U3/AIJ4ft3/ALRH7R/x8uPh98Urixk0aPRbu+AtrEW8nnRSwqnzgnjEh4oA/cev5Lf2jf8Agmf8cf2evhtr3xl8Ya/4dvtF0qWDzYbC4vJLlvtlykCbVltIo+GlBOXHGcZ6V+iv/BRj9uj9oT9mr47ab4B+FVxYxaPdaDaahILmyFy/2iW4uY2+ckcbYl4r8tPjT/wUJ/aa+Pfw51L4WfEOfT5tC1Zrdp0t9PEMpNtMk8eHBJHzxjPqKAPguv6nf2mP+URdv/2Jng//ANGadXwZ/wAE3/2HvgH+0t8HfEPjP4uW9+2q6br0unw/Z7w2qfZ0tbeUZXByd0rc186/tLftlfG57Dxx+yBFc2TfDzw9fS+HbOIWqm7/ALP0O7EdoDcZyzhbaPc2Pm59aAPK/wBlL9iX4n/tfW/ia4+HOr6Ppa+FWs1uf7VmuIi5vBKU8r7Pbz5x5LZzjqMZ5r9xfgD+3h8KPhrrfgX9iLWtG1q48b+FZLLwVdXtvFbNpT6hZbbKSWKR7hJzAZEJUmAPt6oDxXz3/wAEPj9m0v4xfaf3W+bQcbuM/LfetfT/AO0V+xp8EfhZYfEH9snwfb3yfEbw+L/xbaTS3bS2Y1SMtdBzBjBj8z+HOMcUAbf/AAUZ/Yy+Jv7X9p4Ct/hzq2kaW3hV9Te6/tWW4iDi8FsI/L8iCfOPJbdnHUYzzj3n4G+FNQ/ZB/Y+sNF+I0kWpzfDXRdTv9QOklpUljt3nvWEHniAlihwN4Ubu4HNfz//APD3j9sn/oI6N/4K0/8Aiq63wF/wUc/aY+PXjrw58DPiFe6ZL4W+IupWfh3Vo7awWCZ7DV5ls7kRSgko5ilYKw6HmgD9pP2W/wBv34R/ta+MNV8F/D3Rdd0y90ax/tCV9UgtY4mi81IsKYLiY7suOoAxnmvwC/4KcWcup/t6+PNPhIWS6OhxKW6BpNLswM4zxzX9FH7PP7EHwJ/Zf8T6l4t+FVpf2+oarZ/YZzd3jXCGHzFl4BAwdyDmv56v+CkH/KRDxb/18+Hv/TbZUAev/wDDlT9p3/obPB//AIF6h/8AIFH/AA5U/ad/6Gzwf/4F6h/8gV+uP/BR79on4k/syfAzSPH3wtmtYNWvvENrpsjXcAuI/s8trdSsApIwd0K8/X1r8SP+HvH7ZP8A0EdG/wDBWn/xVAHo3/DlT9p3/obPB/8A4F6h/wDIFfCX7UP7L3jz9k3x5p3w9+IWo6bqWoalpseqRyaXJNJAIJJpoArGeGFt+6FiQFIwRz1A/YL/AIJ//wDBQH9oj9ov9oiz+GvxKvNNn0WfTb26ZbWyWCTzIFBT5wTxzyK+a/8AgtZ/yc54S/7E+0/9OF/QB/RZ8MRn4SeDx/1BtO/9J466nZXM/C0Z+FHg8f8AUG07/wBJo67LZQBS2Gk8vNXfLpdlAFHy6PLq9so2UAUfLo8ur2yjZQB//9L98tpo2mpdoowKAItgpNlTbRRtFAEW00bTUuBRgUAfOn7R3jFvDngwaLaSbLvW2MXHUQJzJ+eQv0Jr8+lavc/2kfER1j4kT6fG+YNIijtwO2/HmN+rYP0rwZWr+D+PM1eOzqrr7sPcXy3+93PybNsQ62Jl2Wi+X/BLitUytVNWqZWr8zPALitUytVNWqZWoAuK1TK1U1aplagC4relTK1U1avY/hT8LL/4gX32u73W+i2zYllHBkI/5Zx+/qe31r2Mty7EY/ERwuFjzSl/V32S6nXQozrVFTpq7Zi+Fvh34v8AGNtLeaFY+bbxHBeRxGhPopbqfpXMXlnd6Zdz6ffRNDc27GN424KOOor9H9S1Lw18PPDXnzlbHTrBAscaDk+iIO7H/wCufWvz08XeI38WeJdQ8RPF5P22TcEHO1AAiAn1wBn3r9H4t4XwOSYehTjWcq7+JaWt3XVK+iue3mOAo4WnBKV5vcx1aplaqatxUytX5IfOn2x8EvEra54XbTLh83GlkR9efKPKflgj6AV7Psr4q+Betf2d43ispHIi1GN4T6ZxvX9RgfWvuMIo7V/dHAGavH5NT9o7yp+4/lt+DR+r5PiPbYZX3Wn9fIpiImpREoqxtFGBX6ge6RbTRtNS7RRtFAEW0189ftPrj4SX/wD18W3/AKMFfRWBXzz+1CMfCO//AOvi2/8ARgr5Pin/AJEuL/wS/JnnZh/utT0f5Hyj+ywM/FaP/rzuP6V+kd/YxahY3FhKSI7mJ4mK9QHBBx781+bv7K3PxXi/687j+lfdXxd8S6j4N+HOteI9JkEN5aRx+S5CuA8kqxjhgQfvd6/MfDrEQw/DdWvW+GLk36JJs8LJZqGBlOWyb/I8wtf2U/hZbjEv265PrLcAf+i1Wm6n+yr8MLy2eOx+2afKR8skc3mYPbIkByPy+tfK1v8AtG/Gu7k8m11QTyddsdnbufyEdfTv7O3j/wCIfja+1uHxxI0kdpFAYN1ukHLlt33FXPQV5+UZjwnmmIhgqGBs5XV3FW0Te6ba2McNWy/ETVGFLfyX53Pgjxd4bvfBfinUfDV1IHn0ycx7143gco49MjB9q/WD4a63ceJvAOga7eHdcXdnEZW9ZAMOfxYE1+b37QfHxi8Sf9dYv/REdfoJ8CQP+FR+Gv8Ar1P/AKMavJ8O4fVc+x+Cpv3I8yt6SsvwZhkq9njK1KOyv+DPzS+KX/JTPFX/AGFbz/0c1fqh8O1/4t/4Y/7Bll/6JWvyw+Kn/JTfFX/YUvP/AEc1fqp8OgP+FfeGP+wXZf8Aola18OP+Rxj/AOurHkf+9Vv66ng/7XAx8NbH/sLQf+iZ68U/ZDGfH+q/9gx//R0Ve3/tcjHw00//ALCsH/omevE/2QBn4gav/wBgx/8A0dDRnP8AyXeG/wC3fyYYj/kbQ+R9JftLrj4Pav8A9dbT/wBKI6+Qv2Xxn4t2X/Xvc/8AouvsH9pkD/hTurf9dbT/ANKI6+QP2Xefi5Zf9etz/wCi6fFX/JZ4H/tz/wBKY8w/5GlL5fmz77+JmlajrHgLXLLSJ5bW+Fq8sEkLmOTzIv3igOpBG4rg+xr89fg58TfE2n/EnQzrWs3l1YXM4tZY57iSSPE48sEhiR8rEHPtX6lbRX49/Evw7J4L+IetaJADElndu0GOCIpP3kWPopFel4kuvgsRg82oSa5XZ66Ozuvv1N875qU6eIg9n/wV+p+i/wARvgX4S+JusRa5r1zeW9zBbpar9mkjRNiMzgkMj85c9+lfnR8TvA7fDvxnfeF/tH2qO32PFKRgvHIoYZHqM4PuK/VrwP4gj8V+D9H8RpjOoW0crY7SEfvB+DZFfnh+1IMfFu6/69rb/wBBrh8SMqy95ZDNcPTSnOS95dVJN6/gZZ3h6PsFXgtW1r6o+zf2ftUn1n4R6BcXTmSWCOWAlueIJWjT8lAFfDn7SQx8ZNdH+zaf+k0VfaH7Mgz8H9K/67Xf/o5q+MP2lOPjNrv0tP8A0mirDjKpKpwhgZzer5P/AEhmWZtvLqLf938mfb/7PC5+Dnhz/duP/SmWmftFrj4NeIfpbf8ApVFVj9nYA/Brw5/u3H/pTLUf7RoH/CmfEf0tv/SqKv1J/wDJI/8AcD/2w+h/5lv/AG5+h8Q/s1jPxj0T/cu//SaSv09vbNL6znspCQlxG6EjqA4xxX5h/s0f8lk0X/du/wD0mkr9FPiF4zsPh/4Sv/FN+vmi2TEUQ/5aSvxGuewJ6nsMmvi/DKvSoZBXq1naMZybfkkrnl5HKEMJOU9k3+SPHrH9lT4W2kYW4+23p9ZbgD/0Wq0mr/srfDG+tZItNS602Yg7ZY5zJg9srJnI9Rx9a+StQ+Ovxl8Yan9n03U54pJ2/dWmnRYP0TaDI34kmrwuv2nWGQniXn/pnc/4V8us+4ZqqUMNlbnHa6ivzu2vvucH1zAyTVPDtr0PENSsZ9B1q70242vPp1xJC2RlC8TFTweoyO9fq/YeDvCfiXwBHpsemwadZa5ZwvMtlGkHEirJgFB61+TWqHUTqd2dY8z7eZpPtHnZ8zzd58zfnnduznPev2J8BAf8IN4c/wCwbZ/+iVrHwupUquJxlKcLxaWj7Xat92jJyGMZVKsWtP8Ahzx6T9lz4TPbmFbS6jcjHmi5fePfnK/pX54+NvDv/CI+LdX8NCQzpptxJCrkYLoD8pI9SMZr9m8CvyQ+N/8AyVjxP/1+P/IV2eJuSZfg8FRrYSjGEua3uq11ZvW3oXnmFo0qcZU4pO/Q/TP4bX82rfD7w3qNyd8txp1s7k938sZP4mvhT9rIY+J9uP8AqGwf+jJa+3/g8M/C3wr/ANg+3/8AQK+Iv2sxj4oW/wD2DYP/AEZLX0nHc3PhajOW75PyO7NnfARb8vyPo/8AZWXPwqT/AK/bj/2WuN/bA1G7t/DmgaVExFvd3UssuOhMCgKD/wB/Cfwrtv2VAD8KU/6/bj/2Wun+OnwyufiX4QFjpbhNU0+X7RbBzhJDghoye2QeD6gZ4r1fqWIxnBcMPhlebpxsu9rNr5pNHR7KVXK1Cnvyo+Mf2evhX4Y+Jmo6t/wktxKI9MSIx28L7DJ5hbJJwTtTbjjuRz6/V837L3wllTallcRH1S5kz/48SP0r8/7/AMGfETwbfO93pGoaZcQEjzkjkA/4BKnyke4JFWrD4qfE7Rph9m8S6ihj/hluJJEH/AZCR+lfh+S51lOW4ZYTNMu5ppu8mld69mla22/Q+WwuKw9CCp16F33/AOHP1K8D+CdJ8AeHovDWiyTSWsDySKZ2DvmQ7iMqEHU8cVwXi74AeBfG/ia48Va893Jc3QjVo0lCRYjUIMALu6Dn5qofAD4s33xN0C8i1xUGr6U6JMyDYsscmdkm3oDwQQOOM8ZwPM/2h/GXxa8KeKUm8IS3ltocdlFJNNFbiS3SUySA75TGQDjbxn09a/oHMMzyaWQ0sZKg6mHVrRSva11s3bTVPU+wrV8M8JGo4c0Oit/Wx6M37L/wjaPYLC4U/wB4XMmf1OP0r5F+O/wbtPhZfWF1o9zLc6XqfmBRNgyRSR4JUkAAgg8HA6HPqfSfgF8WfiH4u+JFnoniLWZL2ykhuGaJkjAJSMkcqoPBrsv2xQB4c8Pf9fcv/osV+b5vQyPNeG6+Z4DCqm4OydkndNX2dmrPqeJiYYXEYGdelT5bfLt2Kn7H+u3V1pPiDw3O5eCylguIQe3nhhIB7ZjB+pNfZu018J/sbjOq+KP+uNt/6HJX3jgV+oeH1WVTh/DuTvbmXyTdvwPeyeTlg4X8/wA2RbTRtNS4FG0V+nnukW00bBUuBRtFAEOyl2mpdoowKAItpo2mpdoo2igCLYKNpqXAo2igCLaaNpqXaKNooAi2mjaalwKNooAi2mjaal2ijAoAi2ijaalwKMCgCLaaNoqXaKMCgCLaaNgqXAowKAIgtQTplRVzaKayZXFAGZ5dGzFXdho2GgCl5dO2Vb2GjYaAKmyjZVvYaNhoAp7DR5Yq5sNGw0AU/LFHl1c2GjYaAKXl80eXV3YaNhoApeXS+Xmrmw0bDQBT2GjZxVzYaNhoAhgTbKDX86v/AAW7/wCSqfDX/sDXf/pSK/oyiXDg1/Ob/wAFu/8Akqnw1/7A13/6UigD9Bvit/yiai/7Jton/pFa1/J1X9nfw1+GOgfGf9hvwD8LPFM11b6R4k8DaFaXMlmyR3CxtYQHMbSJIoPHdT9K+Sf+HLX7Kv8A0MfjD/wPsP8A5X0AfgF+yN/ydV8HP+xw0H/0vhr9lv8AguJ/yK3wj/6/dY/9F2tfS3w8/wCCSv7Nnwz8feG/iLoOu+KZ9T8LalaanbR3F5ZPA09nKs0YkVbJGKFlGQGBx0I6180/8FxP+RW+Ef8A1+6x/wCi7WgD7D/4J5eJdP8ABf8AwTv8F+MdX3nT9C0/Xr+4EQDyeTa6jeyybASATtU4GRz3r5B/aD+L3hP/AIKn+D7H4C/szJdWniXw5fJ4luW8QRixtWsbeKWycJJC1wTL5t5FhSoG3cc8YP0F+yN/yibT/sVvF/8A6U6jX5w/8EU/+TnPFv8A2J93/wCnCwoAwrH/AII7ftaW97b3El54a2RSIxxqE3QHP/PtX9Cv7RP7RPgH9mLwDH8SfiTHey6TLew2CiwhWaXzZlkdPkeRBjCHJz6cV77X5P8A/BZH/k0ez/7GbTv/AERc0AO/4fI/sk/8+fib/wAF0H/yTX3v8bfjh4M+Afws1H4xeOI7uTQtM+zeaLOJZbj/AEuZIY9qM6A/NIM/NwM1+A//AAT8/wCCevwT/ap+COo/Eb4iatr9jqlrrlzpqR6Zc2sUHkwwW0qkrNbTNvzM2TuxjHHr++Px0+BXhD9oP4Tan8GvGtzfWmiar9l8yWwkjjuR9knjnj2vLHKoy0YDZQ8ZxjrQB/Lv/wAFGP2m/hx+1T8X/D/jn4ZxX0WnaZoUWnSi/gSCTz0urmY4CSSArtlXnI5zxX2h+wF/wT6+PHgT4w/C39pLW7jRj4Te0bVAsN3K159n1PTZRD+6MIXd++XcN/HPJr4n/wCChv7Lvw7/AGT/AItaB4D+G19qd9p+qaHFqUr6pNDNMJnuriEqphhhATbEOCpOc89q/qO/Zl/5Nu+E/wD2Kehf+kENAH4xf8FyP+Qr8G/+uOvf+hWNfbup/wDKJlP+yWW//psWva/2p/2KPhR+13ceG7j4l6lrNg/hZbtbX+yri3gDi8MRk83zrefOPJXbjb3znt+SEX7VfxE1D4vH/gm1NZaYPheurH4d/bhDN/bn9kQSnT1l8/zvs/2nylBL/Ztm7ny8cUAfnL+zH+x78WP2s5vEUHwtm02JvDC2rXf9o3ElvkXhlEfl7Ipc/wCpbOcY4qjbeFtS/ZO/av8AD2kfFIxyXHw58SaPfan/AGexuA0VvNBdv5JYR7j5XQHbzx71/Ux+yx+xT8KP2RbjxJcfDPUtZ1BvFK2i3X9q3FvMEFmZTH5XkW8GM+c27Oe2Md/HPjT/AMEuv2e/jv8AFDX/AIteMNb8S2useIpY5LiKxu7SO3Vo4khGxZLORgNqDOXPOaAPU/2av27fgp+1V4r1Twd8MYdWi1DSbL7fMdRto4I/K81YvlKTSEnc44wOO9fz/f8ABSD/AJSIeLf+vnw9/wCm2yr98/2Yv2B/g3+yZ4u1Xxn8NtV12/v9YsP7PlXVLi2miWLzUlyohtoSG3IOSSMZ4r8DP+CkH/KRHxZ/19eHv/TbZUAfq9/wWl/5NV8Of9jhY/8ApBf1/L1X9tv7TP7M3gH9q3wDZfDr4i3mpWOmWOpRapHJpksUMxniimhClpoZl27ZmyNoOcc9Qfhf/hy1+yr/ANDH4w/8D7D/AOV9AH5df8Ehv+TyNN/7A2qf+i1r0f8A4LWf8nOeEv8AsT7T/wBOF/X63/s7f8E4fgX+zJ8SYfil4B1fxDfavDaz2gj1K5tZbfy7gAMSsVrC2eOPm/A1+SH/AAWs/wCTnPCX/Yn2n/pwv6AP6MfhV/ySnwd/2BtO/wDSaOu62CuH+FH/ACSvwd/2BtO/9Jo673aKAItpo2mpdoowKAItpo2mpcCjAoAi2mjaal2ijaKAP//T/fyiioy6qCT0XrQBJRWdazTSM0jn92KZDPNPPtBwnXGB0rTlM/aLTzNSiqCzSS3RjjOETrQssstyUjOETrRyhzo/JDxvq39teMdb1XORc3k7r9DISP0rm1aq8jP5r+Z9/Jz9acrV/mRXqurVlUlu2395+HTlzScn1LitUytVNWrpPC/h/UPFmv2XhzS8fab59iluAOMkn2ABJpUqU6tSNOkrttJLu3sEYuTUY7szlapVavdvH/7PfiTwTo39u2V0usW0AzcBIzHJEP72Mnco7nqOuMV4GrV6eZ5VjMtrewxtNxlv8vJrRnRXw9WhLkqxsy4rVOrVSVq9r+Enwm1D4hX4vbvdbaHbNiaYcGQj/lnH7+p7fWssty7EZhiI4XCx5pS/q77JdWKhQqVqip01dss/Cf4U6h8QL4Xd3uttEtmxNN0MhH/LOP39T2+tfc2p6n4Z+HXho3FwUsdMsVCxxqOp/hRB3Y//AFz3NN1TU/DHw38MGe4KWGmWCBI41HU/wog7sf8A657mvz7+IfxH1j4h6uby9Pk2cBIt7YH5Ix6n1Y9z+A4r+matXAcEYD2VO08VNf032S6Lds+4lKjldHljrUf9fd+Za+IPxE1f4gawby8Jhs4iRb2wPEaep9WPc/h0rhlaqatUqtX8w4zGV8ZXliMRLmnLVtnwtSrKpJzqO7ZcVuKnDVSVqmDVxGZ13hDUv7K8T6TqGcCC6iY/QOM/pX6ZV+VMLN5ibPv5GK/UtJWntt8Zw+P1r+pvCSpJ0sXS6Jxf33/yPu+Hp6VI+n6luiqsMpngypw3T8abayvKhWT76HBr+lLH2yknYuUVjfap4ptkzZUHngVdujKsXmQtjHX6VXKJVE02XK+d/wBqIf8AFob/AP6+Lb/0YK98tZzNEQx+cda4Txz4Vg8eeGdR8H6pOYY75QFlUAmORGDRtjjIDAZGRkcZr5/PMDUxmXYjDUfilCSXq1oceLXtKEoR3aaPz0/Zz8R6J4X+JUOo+ILyOxtXtZ4vNlOEDuBgE9s4r7X+NdxZeMPgfr994euI9QtnijmSWFw6MttcK8hBHBxsbP0r5dv/ANkbx9bS/wCjarpksRPDO0yH8QImA/M19jfCjwXceFfhnYeCfEPkXkkC3Mc4jy8LpPNI+351UkFXwcj1r8P4MyvN6eCxGS47D8lOcZWk/wCaVlbe2138j5jLKOIVOeEqwsmnr5vQ/PL4DeMdJ8EfEey1fXJPIsZI5YJJcE+X5g4c45xkDPtX6TyfE/4cxWpvX8T6Z5AGci7ib8gGJJ9sZr5E8Z/sjauL+W68CahBJZudy292WSSPP8IkAYMB2Jwfr1PnQ/ZZ+LZk2G2tAP732lcf4/pXg5HX4m4cozwMMD7RXbTV3vpuumnkc2EljsFF0VSurnmPxQ8TWnjHx/rniSwy1reXBMJIwTGgEanB5GQAcV+ofwi06XSvhl4ZsLhdkiWMLMPQyDfg+/NfMPgH9ky5s9Sg1X4g38EltbsJPsdtlxIQc4kkcDC+oAOfUV9ny3gUCK2ARRwDj+Qr7TgDh7MMPicRmeYw5ZVOnXV3b8tdkd+U4arSnOvXVnLp+LPyX+MVnJY/FPxTDJ1fUbiX8JW8wfo1fdvwq+Nfw6m8A6JZ6rrVvp17ptnDazw3D+Wd0CCPIzwwfGRjPXHWsb4xfAKX4mX3/CUaDcxWWr7BHIJgRFcBOASVBIYDjODkADjGa+bT+y98UVuvs8gskTP+t+0ZT9FL/pXxdPLuIOHc4xFbA4b2sKjdtG1Zu62d01s7nmQhisFiJ1KcLqR137Rvxq8M+O9NtvCHhbdd29rdC5kvCCiFkVowkaEAkfvDknHTjPWoP2P/APkoOr/9gx//AEdDXXQ/skuvhG8RdSjuPEc3lmB3LxWkWHBYfKHZsrnkj04HWuv+BnwW8UfCrxRfa14gu7G4hubNrdVtJJXYOZEfJ8yJBjCHuT7V04TJeIK/EmGzLMaO9m+W1orVJPXf5vc0p0MXPGwxFeP/AADvP2mh/wAWc1j/AK62n/pQlfEf7PPiDRfDHxOstT1+8jsbTybhDLKcIC0Zxk9s1+jvjTwpH4+8Laj4X1GQ21tqEYXcBko6OHRscZwyg4yM18P3/wCyR45t5mW01nTJYweDI80bn6qImA/OvZ42ybNnnmGzXAUfaKCjt3i27PW9nc6szoV3iYYmlG6VvwZ+guj6zpPiCwj1TRLuK+s5dwSaFw6NtODgj0IxXwb+174a+x+J9H8VQptj1K3aCUj/AJ6W5yCfcqwH/Aa+r/g/4S1rwJ4A0/wrqhhkubRpyzxFzGfMlaQY3Ih6H061n/Gn4aX/AMTvBw0Wxnhiv7e5juIHnykYxlWBKqzcqx7dQPrX3fEmWYnN+HnCpTtWcYy5e0lZtfmj1cZSqYrBWcfesn8zwv8AZ2+MnhDwz4Al0HxhqsdhJp1xIYA4Zi0Ev7zgICThy3518wfF7xpa+P8A4gan4k09GSzlMcUAYYcxxIFBI7bsZx2zXri/sj/EMttbVdI/4DLO5/LyK9Y8BfsmaVpN9BqvjXURqvkEMLSFCkBYf89Gb5nHthffI4r8QqZTxVmmBw+T1cPyU6dveem10r6vZPZHzDoY/E0oYaULJdT2j4C6NPoXwk8PWV0pWWSF7gg8HFxI0q/+OsK+Gv2n7OS2+MGpTP0u4baVfoIlj/mpr9Q1VUUKowBwAK+f/jV8FIvijb297aXItNXsEZYpGTKSIxz5cmOcA8gjOMng5r9g4r4YrYvIKeX4LWVLlstr8qt99nc+jzLAyng40aWrjb8FY4L9nr4v+BdN+Hdj4Y1/VodLvtLaVWW5PliRJJGlVkY8H72MZzx05Fc9+0B8ePB2ueE7zwN4Wk/tSS/MfnXCZSGIRSLJhWI/eElQOOMHrnivJB+y58Umufs8S2Tj/noLjA/IqG/SvXPD/wCyKtvol/J4i1KO51mW3kS1SEultFOR+7Z2xvcA4/hGPQ1+cUK/F2Kyz+x44Tkio8rlJWfKla2rtdrTRHjU6mYVaH1eNOyta/keI/sz/wDJZdE/3Lv/ANJpK+s/2sIbmX4WK8BwsOoW7S+6bZF/9CIrg/hJ+zv42+Hvj3TvFetXmnzWdmJw628kryfvImQYDQqOp556V9aeJtA0/wAU6FeaFqSCa0vojHIvHIPQg9iDyD2PNfT8KcOY3/VrFZdiYOnObla/mlZ+l0duAwdVYGpRqKzd/wAkfm9+zb4w8M+DPHs994omWzhurOSCKdwSschkRuSM4BCkZ/xr9F9D8beD/E9w1r4e1m01KeNfMZLeVZGVcgZIBJAyRXxHrH7JGti8dfDuuW8kBPyi8R4nHsTGJAfrgfQV6p8D/gf4y+FviDUNZ1m8sriK5tDABavI77vMVskSRRjGB6k1y8G0+IMqnTyrEYW1Lmd5dr+abTMcrli8PajKn7t9z4d+Iv8AyUDxP/2E73/0c1frX4B/5EXw5/2DbP8A9ErXw94n/Zl8e674n1fWbfUNMji1C8uLhd8swISWQuMgQkZwecE19z+HNLu9I8M6VpEkqmextILdynKFo4whIJAOMjjgfSungHJcfgcwxlXF0nCMtm+urNcnoVadarKcbJ/5nTV+Rfxv/wCSs+KP+vxv5Cv1oguCx8qYYkH618OfEn9mjx34p8a614n06905LTUJzLGssswkAIH3gISPyJr1vEnKMbmGBo0sHTc5Kd2l2szpzqjOvRiqcb6/ofUvwd/5JZ4V/wCwdb/+gCviH9rYf8XQt/8AsGwf+jJa+8vh9o9x4c8FaN4dvJI5LnTrSKCUxElNyLgkbgDj6gV418cfgVd/E28s9d0q/jt9RtYvIKyqfLki3FlyVyQVLN2Oc9sV0cU5Li8dw3TwmHhepFRfL10VmtdLovH4edXAxpwV2rHMfsxeOvCGmeA4fDmpavb2upSX0gSCWQJI5l2hNoPXJ4GO9fUPiTxPoXhHS21nxHdiyskZUaVgxAZzgfdBPJr4a8I/su+P9J8T6Rrdxf6Y1vp95b3EgSSbeUikDELmEDOBxkivqv4z+BtY+Ifga58N6JNDFcyyxOPPLLHiNsnlVY59OKnhrEZzh8kqUa2G5alKNoJ/astL699NAwFTExwrjKGsVp5mpbfF34XXS7ovFWmqP9u5jj/RyK+Pv2pPHXgPxWuj2Xhq5h1O/tHkaa5g+dUiIGI/MHDZPOATjHvXGz/sr/FqIkR29pP7rcgf+hAVs6L+yV8RL6dRrF3ZaZBn5j5hmkx7KowfxYV+e5xm3E+b4SWXzy/l5rXdn0d9G3Zep5GJxGPxNJ0XRtc6/wDY2tbg6j4mvMHyFitoyexcmQj8gD+dfR37QP8AyR7xL/1xi/8ARyV0Xw8+H+g/DPw5H4f0cswLmWeeTG+aUgAsew4AAA6AeuTTfid4YvvHHgLV/C+jyxR3d/Gio0zERqVdW+YqGPQehr9UyzI8RgOGJZfJXqcktF3ld2X32PeoYWVHAug/is/vdz86P2e/EGi+GfiZZ6v4gvI7G0jguA8spwil4yAPxNeg/tM/FPwx45k0jRvCl19tgsDLLNOEIQvIAFVdwBOADk9ORg9aiT9kP4jvyuqaQR6ie4/+MV0+i/sday9wreI/EEEUII3C0jeRyO4Bk2AfXB+lfgmDyrieOVTyWlhLQnK7bsn00u3a2i6HyVLD4/6u8LGno3ubv7G+lTpZeJtbdf3U0ltbof8AbjEjyD8pEr7brlvCfhXRPBGhWvhzQIDBaWwOATl3Y8s7nuSep/pWubiV7ryomwo68enWv6h4ZyeWV5XRwM3dxTv2u22/xZ9zg6P1ahClLdfrqaVFZdxcS+eIYTjt+NSXM0iNHBGfmbqa+t5ZHf7RamhRVC4llV44Ij8zdTS3EsitHBEfmPU0coOa1L1FU3lfzkgjPPVj7VG80j3QhjOAOv8AWjlBzRoUVX8zBdj9xP596kj37F8zr3qbF3JKKKKkYUVG0kcYy5ApI5Y5RujOaLCutiWiqkVwzSmGUbGHT3qKSeS3n/eHMb9Paq5SedWuaFFICCMilqSwoqndNNGBLEeB1FP3NNBvhOCf84qrdSObWxZoqjaXDSgpIfnFOglbe8Epyy9D6im4gpp2LlFUkldbgwynIPKmoLqa4hf5X+U9OBQo3dhOaSualFVldp7ffGcMR+tVbS5dpDHKcntT5Q51dLuXivNJtqjczTQSj5soecYFW5pHWHzYue/4Ucoc618h+2jbUVvdLOSuMEVbqWrblJp6oh20bamqoVumk4cLH7Dn9aSQ27Eu2jbVWe+SP5Y/mf8ASqsU15M21G/QYFUoPcydVJ2NTbRtqPzBbp++k3Gqonurlv3I2p60KJTmloXttG2o2kWBf3z7j/ntUAnubg/uBsT1NCiDmloW9tG2mb1hX99Jk/57CoxdNKcW8Zb3PApWHzJbk+2jbUarcscySAeyj/GnmWJflZwT+v6UWKv3HqMGvxY/4Kj/ALI37QH7SHj7wRrfwb8MDX7PR9MuLe6c3tnaeXK8+9Ri6miJyOcgEV+06Pu6Aj6jFSVIz+SaL/gm5/wUJhjWGDwdcxRxgKqr4g0wKAOAABe8AVJ/w7f/AOCiP/Qp3X/hQ6b/APJtfpf4M/4KV/FbxJ+2m/7M9z4X0WLQ18V6hoH2xFuftf2eznmiWTmYp5hEYJ+XGSeK/aagD+Sr/h2//wAFEf8AoU7r/wAKHTf/AJNqhff8EzP2+9T2LqXgeS6Eedvna7pcmM9cZvDiv0z1H/gpn8WbP9tBf2aU8LaIdDbxnB4a+2EXP2v7NLerbGX/AF3l+ZtOfu4z2r6S/wCChf7ZXjr9j7SPBOo+B9E03WZPE899FONRE2IxarCVKeTJH18w5znoKAN39nj4H/E/wJ/wT4X4F+KNJFl41GgeI7L7D9ogkH2i/mvXt086N2h+cTIc78DPJGDX5k/sY/DHxv8A8E6/iXq3xm/bB08eBPCGu6RLoFnerNFqpk1Ke4guo4fJ0xrqVcw2szb2UINuCckA/rT8Ev2kvFPxP/YtH7TGraXZWuuHR9b1L7HB5n2TzNLluo41+dmk2sIF3fNnk4xxX5dfC/4za9/wVq165/Z6+NNja+D9G8M2reKYLvw/vFy91bOlisT/AGtp08ox3rscKG3KvOMggHD/ALSvwX+PX7ZHxq1D9pD9l60uPEvwx1VLOO01BdQh00O+nxJBdD7LezQTrtljYcxDdjIyCDX01+2H8Zvhz/wUE+E8HwI/ZK1U+NvHFvqdvrMli1vNpYFjaRyxTS+dqMdvD8rTRjbv3HPAODjwL4lfta+NP+Cb/iG//Y/+Fmj6d4m8NeHIkuIb/WfNN87arGLuUP8AZpIYsK0pC4QcAZya/MT9l79pXxX+yp8SZPid4O0yy1a/msJ9PMN/5vk+XO0blv3To2QYxjnHWgD+lb/gmf8AAr4pfs8fs+6p4H+LujDQtaufEN3fRwC5t7vNvLbWsaN5ltJInLRsMZzx05Ffib/wTO1/Xr79u7wfa3mo3NxC39t5jkmdlONPuiOCccGvaf8Ah9n8ff8AoRfDP5Xv/wAkV+a/7P8A8ePEX7PPxi0r40+GdPtdS1TSvtmy3u/M+zv9sgkgbd5bo3AkJGD1AoA/Rj/gtf8A8nJeDv8AsUrf/wBL72vqbWf2lvhT+0P+xZoX7I/wL8RS6x8YNU8N6DptnpS291ZFrvS1tZryMXtzHDar5cVvMdxmCtjCkkgHnfhd8IND/wCCtmiXXx8+NN7c+D9Y8K3DeGYLbw/tFtJbQIt6JZPtazv5he7YHDAYA4zknc8c/sN/D3/gn14Uv/2wPhnr2qeIvEvw7EctnYav5JsZzqEi6e4l+zxRS/LHcsw2uPmAzxkUAYn7GHiC9/4J123iyz/bgvpvBk3j1rKTQld31n7QumiYXZzpxuxFtNxD/rNu7Py5wcfnr8OvFvh/x/8A8FNtJ8c+FLn7doviD4jm/sp/LeLzbe41AyRNskCuuVIOGAI7ivvb4VWcf/BYSPUtR+N7HwXJ8KzFFYDw7wLgazuaUz/bPP8AufY127Nv3jnPGPp74U/8Ek/gt8JviV4a+J2i+MPEF5f+GNQt9RghuDaeTJJbuHVX2wK2CRzgg0AR/wDBUP8AZ0/aD/aBsPhzD8B9Kl1STRJNVN/5WoW9hsFwLXyc/aJod2fLfpnGOcZFel+E/AvxC+E//BM7xB4I+I0EmneK9E8EeJhdxm4S4eOQw3ksf76B5FJ2MpBVjj6iv0XrifiH4MsPiP4A8TfD3U55bax8UaZe6XPLDt82OK9heB2TcGG4ByRkEZ6igD+er/gi5rOsan8efG8WpX091HH4aZlWWV5AD9st+QGJrZ/bz/YM/ar+NX7VfjL4mfDPwaureHtXXTfs1z/aWn25c2+n28En7ue4jkXbJGw5UZxkcYNejfFH4XaR/wAEjdItPjV8FbufxjqnjGf/AIR64t/EO028VuVN35kf2QQN5m6ADkkYJ4zX6dfsq/HzxJ8ef2X9F+OviPTrWw1bU4dUke1tPM+zqbG6nt02+YzNyIQT83UnFAH87n/Dt/8A4KI/9Cndf+FDpv8A8m0f8O3/APgoj/0Kd1/4UOm//Jte8f8AD7P4+/8AQi+Gfyvf/kiv2J/YS/aV8V/tVfBSb4neMdLstJv4tWudOENh5vleXBHC4b96ztkmQ55xwKAP5/v+Hb//AAUQ/wChSuf/AAodN/8Ak2sy8/4Jj/t66nKJtQ8BtdSKNoaXXNLkIHXGTeHjmv1L/Yo/4KTfFX9pz4+Q/Cbxb4Y0XStOlsr25M9kLnzt1sAVH72Z1wc88V+ztAHF/D3S77Q/AXhrRNTj8i80/TLO2njyG2SxQojjcCQcEEZBIrtKimkEUZkPaqsU0i25mlOfSmkQ5JOxfoqhFM6W5mmOfSiOaSO3M85yT0FXyi50X6KoSzPBbguf3jVIjSeUgY5dv0H/AOqp5R86vYt0VArM8rAH5V4/GpcH1osVc//U/faV/LQsBk9h6mqN4/lxLDnJPJ/z9ask+Zcbf4YuT9TVBf8ASbvP8Oc/gK1ijmm76Ill/wBHsxF0Z+v9f8KWH/RrRpT95+n9KhuSbi68teg4/wAamuR5ksdsvQf5/lT9Sera6aISL/R7Qyn7z9P6f40qf6La7/43p0wE1xHbr91OTRIDc3QTrHH1+tHqO1tvQ/IXxrpjaJ4w1nSiMC2u54wPYSED9K5xWr379pvw8dD+JlxqEabINYijuFPbfjy5P1XJ+tfPatX+b2d4J4TMa+Ga+GTXyvp+B+PYql7KtOm+jLoat7w7r+o+GNas9f0lxHd2UgkjJ5HuCO4IyD7VzStUytXiU6kqUlUg7NO6fZo5IycWpLc/Vf4Z/EvRPibof2q2xFfRALd2jHJjJ7j1Q9j+B5r5m+OHwPbQmm8Y+DoS2nMS91bIMm3J6yRj/nn6j+H6dPmfwv4p1jwhrVvr2hXBgurc/wDAHTurDup7iv0x+GXxN0T4maJ9qtcQ30IC3doxyYye49UPY/gea/qTKs1wPGGB/s3MvdxEfhl381+q6n3+HxFLMqfsK+k1s/1/zR8UfCD4Sah8Rb8Xt4rW2hWzfvphwZSP+WcXv6nt9a+9dT1Pwv8ADTwuZ7gpYaXYIEiiQck/woi92P8A9c9zT9b1rwx8OvDb394I7DTbMbY4olC5J6JGgxkk9vxr85fiP8StY+I+sm+viYLKAkW1sDlIk9T6ue5/AcVrWq4DgjAeypWniprf9X2S6LqOUqOV0eWOtR/1935lr4i/EfWfiJrBvr4mCzgJFtag/JGnqfVj3P4DiuCVqpBqnVq/l/GYyvjK8sRiJc05ats+Eq1Z1JOc3dsuK1TBqpq1TK1chgXFapg1U1aplag0Ov8AB+n/ANr+KNK07GRcXUSH6Fhn9K/Su1BguHt26HkV8M/ADRDqvjyK9dN0WmxNOT2342L+pyPpX3VdqwCTp1jP6V/X3hRg3Ty6tiJL45WXol/m2foGQ0uWhKp3f4IiU/ZrsqfuyU6f/R7hZx0fhqL1BLCsqdufwNSRkXdrg9en4iv3/wAz6y28fmiG/h3ASr24NOsZRIhibnHT6UtnIJYjA/VOPwrPIe1uMj+A/mKaV1ykN2amupKP9DucH7h/kanv4cgTL261Ncxi5hEsfJXkUyzlEsRhk5wP0ov9ofLvDvsSIReW2D1/rVC0lME+x+AeD9afETaXBjb7h/yDT7+DB85foaF2Jd2ubqiS68yBxPEeD1Har0ciyoHXoaqwOt1AY36jg/41Tt5WtZWik6Z5/wAaVr6GnNZ36M2SARg8iqv2KHfvx+HardFQnY2cU9zJuLibd5Male3uadFbx26+ZckZ9K08DrWZdW00km5TuB/SrT6GMote9uRS3U1w3lwjAP51OkEFovmTHLf56UFo7FNo+ZzTI7dpT590ePQ1X5EW111YvmXN0cRfu4/WnhLazGW5b9fyprXDynyrQYHrThDb248ydt7e/wDhS8hrv+ICa5n/ANUnlr6mneREo33Mm4+54qu97LIdkAx+ppVspHO6dv6mna3kF77akrXsMY2xLn9BTRcXcv8Aqo8CrkdvFEfkXn1qRmVRljge9Z3XRGvLJ7srxfat370rj071bqFZY3O1Dn6f409nVBuY4FJlKyW5DLbRynd91vUdamUELhjk+tIjlucED3polDEKvzepHSpK03JqhSMR8J09P8Ke8iRjLnFKDkZ6fWgZUubVZvmXh/51FbyTxny50OOx9K0AwYZU5p1VfozPk15kZ1zZLJmSLh/TsapxTzWz7HHHcGt2mPGkgw4zTUujIlT1vErskN3GHU89j3FMS4eJvKuuPRuxqaOCKJsoMfjUrokg2uMii/Qvle/UqSWiMfMhPlt7dKtoGCgMcn1pflRfQCovPTyjKPuj9aWrGklqT1AJ0aXyl5I6+1U4JHEL3MhyT0/z9abCfItmuD95+lVykc+xYEzyzmNOETqagkc3VwIlP7tevvSf8e9ln+OT+v8A9aktv3Fs856npVW6ozu3o/UivZDJKIU6Lx+NWShihS2j/wBZJ1/rUFnGCTPJ0T+dW7YGRnuX/j4H0oegoq+r6luNFjQIvQU+iqtwSdkK9XPP071nudL0RG8pWF7g9W+79O3+NV7UCGCS4b8P8/WmXrb5VhT+Ht7mnXhEUaW69uTWiXQ5nLVvsJYpukad+3f3NSW372aS7fgDp/n6Ukn7izCfxv1/z+lLKDBbLAv3pKNwSt8gtvneS8k6dqW3P37yX8P8/pROCkaWkfJPWrL2waJYc4Qdfek2Uk9u35laAlYpLlhlnPH+frT7KF0DySDDv61eRVRQq9BTd6btgIz6VLkaqFrXBUAQKefrTyQBk1n3k80XCDCnvUdrdnPlzHr0NHK2rk+0SfKXo7iKZiqHJWqdzNcQShv+WfamXUDRN9oh49cdqswyx3cZV+vcU9tSG2/de4rpHeQhl69vasuKSS2l5HTgirAMllNhuYz/AJ/OrNzbrcJ5sf38ce9WtNOhDXNqt0PljW5jWWI4Ycg0o2XcRR+COCPQ1mW07QPtb7p6itSRTuE8XJxyPUVLVtC4yUtfvKsErW8n2afp2NalUpokuowy9ex/pUNrcFW8ifgjgZqXrqVF8uj2NIjPBqokZglwv+rf9DVyipTNmrmXMvkXSzj7rdf60t4DFLHcr24NXLiLzoinft9arpm5tNh+8OPxFaJ9Tncd0hbpRLCJ4+qciiQC7tty9eo+tRWMmVMLdulFufs9w0B+63Io2HdPXuQWM3lyeW3R/wCdOvYzFKJ07n9aZfQ+XLvXo/8AOrsTLd25V+vQ/wCNW39oySvemwlVbu3DL16j6+lR2Eu5DE3bp9KitZGgmNvJ0J/Wi5RoJhcJ0Y/r/wDXqbfZL5tp/eQSK1pcZXtyPpWhcAywiaEkEcjHpRcRrcQCSPkjkf4VBp83Jgb6ijdXBLlfL0ZbtJ/Oj+b7w61arFlBtLjzE+63+SK1kdZEDr0NRJdUawlf3XuQS2cMp3EYPtUVxKbVBHCmB69q0KQgHrST7jcOxkQ2xk/f3JwOvNOmvAB5duMAd/8ACrN3DLMv7s9O3rUEUKWq+dN97sK0vfVmLi1ovvEhtePOuj74P9aVrp5D5Vov400Ca9bLfJGKledLceTbjc9UStFpohFtooh5ty2T7/55pftUknyWseQO56Ui23/La8fPt2pkl8qjbAvA7/8A1qncq/L5fmTC2dhuuZSw9BwKT7RawDbEM/T/ABqutvdXJ3THA9/8Kux2cMfONx9TSlbqNXfwoihupJ3CiPCdz1r8kf8AgpH8O/20fGvjfwdd/suz+IotMtdOuE1D+xdXOmx/aDNlPMQXEO9tvQ4OB3r9fq/NX9uP/goBd/sdeKvDPhq28Dp4rHiGylvDK2omy8rypfL24EE27PXORUM6Iprdn89/7Onih/hL+2f4a8T/ABz1CXTbnw14kuD4gu712uZo7qJ5UuWmdPNaV/NzuYbixycnrX66ftl/FD4pftcy+EX/AOCe3i7V/ECeFRfjxJ/wj2oXGj+Ub3yPsHn+bJa+bu8m42Y3bcNnGefwI+KHjVviV8S/F3xGezGnt4q1e+1U2wk80QG+uHn8rzMJu2b8Z2jOM4HSv3G/4Iaf8evxo/3/AA9/LUKkZ+XPwQ03x1ov7cvw90n4mm5fxbZ+PdHi1Q3s/wBpuTeJqUQl82bc/mPuzltxye9f1M/tMeOf2UfBNloMv7U0OhS2t3LcDS/7b0samokQJ5/lAwTeWcFNx4zx1xXyDe/8EvLG+/arX9p1viNIki+KovE39l/2UCuYrpbr7P8AaPtXQ7du/wAv329q93/ba/Yqtv2ytM8Kabc+Ln8J/wDCLTXkwZLIXvnfa1iXGDNDt2+V75z2oA/Hb9pPwX+03488Q+MfiN+yRNrMX7OF1ZmXTY9B1E6VoQsre0WPU/K00TQBIzdR3Pmr5A8xt7Ybdk/n9+zf4Q/aN8Z+Nb/TP2Y5NXi8TQ6fJNcnRtQOm3H2ESxK+6UTQ5j81osruPODjjI/UH4lftfXP7EHgnxN/wAE+bbwsvjK38OabeaWPET3psHmGvwNfGT7GIZwvk/bdmPPO7ZnK5wPz3/Yx/atn/ZB+Jeq/Ea28Mr4qfU9Il0r7M12bMIJbiCfzfMEU2ceRjbtHXOeMEA/Xv4OeNP2Yvhd8K4PBH7fEWi3Hxvtftb6lJ4p00a5q/kyu0ll5t8YbouPIMfljzjtXA4xiv5xK+lf2nvjxL+1J8c9R+K8+ijw0+tJZW5s1uPtYj+zwpBnzCkW7O3ONox0r9ef+HG2l/8ARY5v/BEv/wAm0AeRf8E7/id+wj4O+BmpaT+0vb+GZfFT67dSwnWdEGo3H2I29sI8Sm1mwm8SYXdwcnHNfubF+y9+y/NGk0Xwi8HlJAGB/wCEf0/kHp/ywr8j/wDhxtpf/RY5v/BEv/ybXP8A/D7jVNL/AOJaPg9DJ9l/c7/7dYbvL+XOPsXGcUAfu14L+H3gP4dadNo/w+8N6Z4XsLiUzyW+l2cNlE8pAQyNHAqqWKqBkjOAB2r+Yr9s34X/ALeml6n8VPFnje48Tt8JW1y9mC3OuGfTfsEuof6F/on2lh5eWi8tfK+XjgY4/dn9iP8Aawuf2v8A4aaz8QLnwyvhVtI1eTS/s6XhvBII7eGfzPMMUOM+djGD0znnj1j9pT4KxftE/BLxN8GptXOgr4kS2Q3qwfaTF9nuYrj/AFW+Pdnytv3hjOe2KAP4vfBPxU+J/wANVvF+HPjDWfCqagYzcjSdQuLETmLPl+b9nkTfs3Nt3Zxk46mvXPCHx4/a98e+KNL8GeE/ih4x1HWtauI7Sztk8Q3ymWaU7UQF5woyfUgV+uH/AA420v8A6LHN/wCCJf8A5Nr83Pgf4Aj+FH/BQ/wn8MI746kvhTx7FpYujH5RnFnfeV5nl7m2btucbjj1NAHtn/ChP+Cuv/P348/8Kp//AJOr9ef2W/2pPAPw68A+Bv2fP2g/HMsHxqglXTNR07U2ur2+N9fXTG1ilugssbs8csWD5pABAJGOOr/bq/bcuv2NLXwZc23g9PFv/CWvfoQ9+bLyPsQgPaCbfv8AO9sY75r5E+Ev7Gtv+1x8RfB//BQi48Vv4XuNf1ex8QHw6tkLxIm0e5SIQ/bTNCW837Lnf5A27uhxyAfsN4z+HngD4j2EGl/ELwzpniixtpfOig1Syhvoo5dpXeqTo4DYYjIGcEiv5k/22viN8Q/hD+2d4j+E/wAKfFGqeCvBFhPo0dtoOh3s+m6VAl3Y2s04jsrZ44FE0ssjyAINzMxOSST/AFRV/I3/AMFNb46Z+33451IJ5n2WTQptucZ8vS7NsZ7ZxQB+j/8AwVv+C3wd+Hf7NWg658P/AAJoPhnUZfFVlbyXOl6Xa2U7QtZXrmMyQxoxQsikrnBIB7Cvwb8IfGz4y/D/AEk6D4B8e6/4a01pGmNrpmqXVnAZXADP5cMqruIABOMnAr7n/bL/AOCj17+158LdO+Gdx4Bj8LJp+rw6t9qXUjeFjBBPD5Xlm2hxnz87t3bGOePzFoA/rO/bF/ZpvLL4GTXn7H/gOy8M/EY3ln5d74Yt7XRdT+yEn7Sou4fIkEbDG5fM+buDXVf8E5fCH7R3gz4Ma9pv7Tcmry+J5tfnmtTrOoHUbj7CbS1VNspmm2p5qy4XcOcnHOT+eMX/AAXE1WKJYv8AhTsJ2ADP9ut2/wC3Kv1G/Yk/atuP2v8A4Yav8RrnwyvhZtL1mbSvsy3hvA4it4J/N8wxQ4z52Nu09M55wAD7EuEMkRQdyP51UuB5ssdqvQdf8/StFmCqWPQVnQHast3J36VpExmruws376dLZPuryaWQie6WEfdj5NLaRttaZ/vyetWIbdYdzZyzdSaL2Eot6lORHuLoZU+WnGa0dvz7vbAod0QZcgfWmTM6xlohuaovc1SSuyRQB0GKdWAbu4Jzv/LpR9ruP75rT2bMPrCP/9X96HYxWeT9+Xr+P/1qZa/uoJJz9BTNQk3TBB/AP51YmikFulvGMk9f8/Wtuhy9dOhBYrmRpW/hH86ntB5s0lx+Aqxb24hiMbfNnrVhQFGAMCobNIw0VyCGAxs0jNln/Sp/lUZ6AU6kIBGDSuapW2Pmj9pzwS3ibwIuv2KeZdaAxm4GSbd8CX8sBj7A1+bimv2mngiEckEyCW1mBV1bkYbgg+xr8svjP8N5/hx4ultYEJ0i9JmspfvZjPVSfWMnB9sHvX8reKXD8oVY5vRXuu0ZeT6P5rT5H59nuEfMsRFeT/RnlitzUytVJWqZWr+aj4kuq1dF4b8Ta34T1WLWvD901ndRcBl7g9Q4PBB9CK5ZWqdWralVqUpqpSk01qmtGioycXzRep3/AIv+IXizx5cRXHia9NyIBiKNAI40z1IUcZPc9a5JWqmrVMrVriMTWxFV1a83KT3bd397LnOU3zTd2XA1TK1U1aplauQyLitU6tVJWqZWoAuq1TK1UlavVPhP4DuvHviSO1KkWFriW5fsEHRfqx4H4ntXpYDBVsbiIYXDq8pOy/rsup0UqUqslTgtWfV/7P3hNtA8IHV7pNt1rJEoB6iBeI/zyW+hFe9FdwKnoao2jRwxrZ7RF5QCqo4GBwMVoV/oflGWU8twVLBU9oK3q+r+buz9kwtGNGjGlHoVooiiNE3Kdvoe1UrfNvcmBuh6f0rWrPvoztEy9Ur3k76M3krWa6EFxm2uRMvR+v8AWpr2ISRiZOdv8qfMBdW29OvUf1qOwmDqYW529PpVeZFlfl7jLCfnyW78iop1a2uBKnQ8j+oqCeM282B25BrV+W9t/Rv5Gm9NSErrl6oZcRrcwCSP7w5H+FFrKtxCYn5I4P0qtZTGNzbvxnp9aJlNrOJk+6e38xU26F3+395Gha0ucN93ofpVq/h3KJ0/h6/Sn3Ua3EQlj5IGR7im2MwkjMD8lf5U/wC8Ll+wwsbjevlP1HT6Vo1gTRtazfL9Qa2IJVmjDj8frUyXVF05fZZN0BxUUMyTruSpqzbX91dSxevNSkaN2aLjQRM4kK/MKoTJczy+Uw2x/pVj7UEuDBJ+Bqnp2vaHqzvHpWo296yDLCCVJCB6naTVaolpPQmlmjth5MP3u5qrFby3B8xzgepq+LCMSbySR6Gr1F7bGfJf4iGKGOEYQfjU1Md1RSznAFZUk0t2/lw8L/nrQlc0clHRE015k+XByT3/AMKalnn97dN9ef5mnEwWS4HzSH/P4VVUTXrfMeB19BVryMXvrqy4LncfJtEzjv2FPASEhpSZJW6f/WHamF1iP2a1GX7n0+tDvFaDcx3Sv/n8qVi/UlbJXfcHan93/H1qIXEkx8u2GAO5qrHHLevvkOEH+eKkmulQeRbfTIpW6C5uvQn/AHNqcsTJIfxNPI+XzLk7R/d7fj61BHGtovn3BzIaVEL/AOk3XAHQdhQNdiwrPMN33I/1P+FRiYufKtV4HVj0H+NV98l6+1fkiHWrIP8Ay72/AXq3p/8AXpWsO99h4by/3YJkc9f89qeGKfK53Mew/wA9Kr79p8i2GX7k9vr71ZjjEY9SepPU0maImqGaZYU3t+FPZguM9zis65/e3MUPUDr/AJ+lCVxSdloS3LsYUTo8uBUN5wsdtH/n0qwf3l4F7RDP4mqy/v79j2T+lWjGWot0P9VaR064HmTRWy9B1/z9KSH99evKei9P5U61IluZZ+w4FGw9/mQ3rGSZYl7cfiadenaI7dO3/wCoVHafvrsyH3NSJ+/v2bsn9KexG9/MW4GyGO1Tq3X/AD9a0UQRoEHYYqgv72+J7R/5/nWnUyN4dWFUYnBeW5boOB9BU1y4jhdvbH51Ruj5FskHr1/z9aUUKTsRWima48w9uTSf8fN57E/oKntlaO0aRRln6Y/KpLS1eJjJJ1xjFXe1zBRukhsv7+9SMdI+tWmgLziVjwvQVMqqucDGetPrO50qPcTHOaaGVshSDjrT6pyxOj+fB17j1oRTdgS4YTGGUbSfu+9U7m3aBvPh4H8qukRXsX+cg02GVg32ef7/AGPqKfoYtX0YsEyXUZRxz3FZdxbtA2OqnoaszwNbv58PQfp/9arkbxXcJB/EelVtqiGub3ZbkNpciRfKl69veq00T2koli6dv8KrzRPBJg/UGtSCZLqMo/XuP602raoF73uvccjxXkW1vxHpVWOR7KTypeYz0NQyRyWcgdDx2P8AQ1oK0N7D/nINLb0K39SO6tlnXzYvvfzqraXBibypPu/yNSRySWT+VLzGehqee2W4Hmxfe/Q0eTC1/ejuSuhjbzYxkH7w/qPemTQR3SCRDz2NVrW4aNvIm47DPap5Fe3YzRDKH7y/1FFrMq6aG29wyt5Fxw46E1o1UZYLyPI/PuKiSWS3YR3H3Ozf41LVyk7bmhVVIzHKWX7snUehq1RUF2Mm4U29ys69D1/rUl+mUWdOq9/ardxEJoinft9arWriaAxP1HB+lXfqYuO8e4/i7tff+orNtpjbzfN06GprWQ285hfoTj8aL6HY/mr0br9atLoZPVcy3RLfw5AnT+HrU0Trd25R+vQ/40yylEsZifkqP0qqpNlc4P3P6VNuhpdfF0ZNaSGKQ28nrx9aiuojBMJE4BOR9asXke4CePqOuPT1qVGS8t8N17+xov1Dlv7n3BIou7YMnXqPrVKznMT+W/3D+hp1pIYJjBJxk4/Gi+h2t5y9D1+tVb7JLd/fW5sUmOc1Rs5/NTy2+8v6ir9ZtW0OlO6uQLMjSmLowpZIY5hiQZxVKf8AdXkcvZ+P6VYuLjyCpYZU07diL78xFdeeFEUC4U8cf54poEVlHluZD/n8q0AwYAjoaqTWiSyeYSR60J9GTKPVGdi4vH/zgVpw2kUPP3m9TVhEWNdqDAFPocug400tXuFVLi7SH5Ry/pVW4uyx8m369Mj+lLHDFbJ5s/3vSjl7icr6RHQR3EsgnmOAOgr+dT/gt3/yVT4a/wDYGu//AEpFf0URXTz3KqOE54/DvX86/wDwW7/5Kp8Nf+wNd/8ApSKJeZULW0PT9Y8G/sUeL/2IdP0D4caf4O1f406j4Q0uO3s9N+yT+IJtZNtCZljhiJna5379wA3Zzmu8/wCCO/wg+K3wot/iyvxO8Iat4TOqNof2QapZTWf2jyBfeZ5fmqu/ZvXdjpkZ61+DX7P/AMVY/gf8ZvCfxal006wvhi9W8NoJfIM+1SNvm7ZNvXrtNf1Q/sQ/twW37ZqeMpLbwc/hIeETp4O++F79o+3/AGj0gh2bPI9857Y5g0Pete/aj/Zt8L6ze+HfEnxR8NaXqumSvBc2lzq1rFNBLGcNHJG8gKsDwQRkV+bv7fvxv+JXxN0jwZB+wr4yv/Fl9YT3ra4vge7a/kgikWIWxuxYlyqsRJ5e/AJDY6GsH42/8EgNR+L3xf8AGHxSj+KkWlL4q1O51EWh0YzGAXEhfy/M+2JuxnGdoz6V55Y6Gf8AgjYzeJdSn/4WwPij/oixQr/Yn2L+yv3hYkm883zPtGMYXbt754APxe+JVj8Z9e+Kt5pnxatdYvfiHqE1rBcQapHMdUlnkiiS2jeOQeaWaIxiMYyVK47V+o3/AATT/Y28TT/G7xAn7S3wgvV8Mjw7cG2/4SPSJUtPt32y02eWbiML5vleZjHO3d2zXx/r/wAbov2jf28vDvxnh0c6AviPxP4bIsmn+1GL7K1pa/63ZFu3eVu+6MZxzjNf0tftnftWwfsgfDTSfiLc+Gm8UpqmrxaV9mW7FmYzLbz3Hm+YYps48nG3aOuc8YIB5f48+HP/AATW+HGp33hvxjpHw78Oa/ZxCQ2d79gtrmMyR74j5chDDcCCvHPUV+Vf/BOf9s7x5P8AtAXC/tGfF65HhX+xbsr/AMJBquyz+1+bB5WDcOE8zbvx3xmvX7v9jm5/4KdTn9sKx8Vr8O4fFWLQaNJZHVGg/sv/AEIt9qE1qG8zyt2PKGM45xk1v+HG+q/9Fjh/8ETf/JtAHmf/AAUh/bN8bQfHnTF/Zu+L1wfC39gWpm/4R7Vd9n9t+03XmbjbuU83y/Lz3xt9q+R/+Cc/grwl8TP2wvBnhP4g6RbeIdGv49Va4s72MTwymPT7iVCyPkHDgMPcZri/2xv2XJ/2RvipZ/DK58SL4oa80q31T7UtobMATzTReX5Zlmzjyc53c56cc8x+yl8eYf2aPjp4f+M02it4hXQ0vENktx9lMn2u1ltv9aY5cbfM3fdOcY460AfpF/wUl8XeKP2TfjL4e8B/sy6pc/DDw5qugRandaf4fkOn209691cwtPJHCVBkMcUaljzhQO1frV8Ev2w/2eW+DHgN/G/xg8Of8JEdA0s6l9t1m1F19t+yR/aPODy7vM8zdvzzuzmv5tP23P2sLb9r/wCJejfEC28Mt4VXSNIj0v7O94LwyGO4mn8zzBFDjPnYxg9M5548n/Zr+Csv7RPxt8M/BqHVxoLeJHuUF60H2kRfZ7aW4/1W+Pdnytv3hjOe2KAP69P+GxP2Uf8AosPhL/wdWf8A8drw1PFn/BNOPxv/AMLKXX/hwvir7adS/tMXunfa/tjP5hn83fu8wv8ANuznNfnn/wAON9V/6LHD/wCCJv8A5Nr8Wvi74APwp+Kni74YyXv9pP4U1W90s3Qj8kTmzmaLzPL3Ns3bc7dxx6mgD9wP+Cos0P7V1j8OLf8AZkcfFd/DMmqtqi+GP+JubBbwWotzcC08zyhL5UmzdjdsbHQ1+j37D2l6j8Kf2L/A1n8TLWXwnP4e069n1KPVFNm9lFHdXEzyTiXaY1EfzktgBeelfzsfsK/tuWv7Gd14yubjwe/i3/hLUsECpfiy8j7EZz3gm3b/ADvbGO+eP0Jl/wCCrdj+0rG/7OkHw0l8PyfFQHwompNq63IsTrn+gC5MItIvNEPnb/L3ruxjcM5AB7z+3n8e/FPxK+HHh/Sv2H/HE/irxXa6qJ9Sg8E3hv72PT/IlXzJ0sS7iHzigywxuIHXFfidqv7On7aHxH+IEPi/4lfDbxpr+p39xbC9vdQ0q+lklji2RDzJHj5CxIF56AV+ldn8KpP+CPch+N+pakPipH4zH/COixih/sU25b/S/PMpa83/AOo27dg+9nPGD0Ol/wDBbjTNV1O001fg/NH9rmjh3/26p2+YwXOPsXOM0Adv/wAFJv2MvBcPwI0d/wBmz4QwN4o/4SG1E/8Awjulb7z7D9lu/M3C3Qv5XmeVnPGdvtXmX7Dvww/ZS+HfwYn0D9tDQPDPhfx++q3M6WnjKO2stTOntHEIZBFebJfJLiQKcYJDY6Gv08/bL/amg/ZD+Fun/Ey58NN4pXUNXg0r7Ml2LMoZoJ5vN8wxTZx5GNu3vnPHP8un7Zv7TkP7Wfxdh+KcHhxvC6w6Zb6d9ke6F4T9nklfzPMEUPXzMY28Y60Ac5N+x9+1S0rtF8IPFZQk7SNFvMY7Y/dV/Qt/wST+G3xC+F37PPibQviT4a1HwtqVx4oubqK31O1ltJngaxskEgSVVJQsrAHpkEdq/Ui0/wCPWH/cX+VWaAIZozLEYwcZ709I1RAg6Cn0UCt1GMyghScE9KgnmeHa4XK9/WpJoVmXB4PY+lQxStu8if73Y9iKpEt9BJ4UuoxJGeexqrbXJibyZenQZ7VOVa0fevMR6j0pbiBLhPNi+/2PrV+TM2ne63G3Fl5jeZF8pPUVB9gn/vU+3uhHmK4+Xb0P9Ks/bLT/AJ6ClaQvcZ//1v3rSyzK00xySc4FaNVJbuKF9jZzRLEl1GCrfTHSq9SFZbEszSIhaJdx9KzYL9w5E/Q/pUkc0tq3lXPK9jUtxarOPMi+9+hprzIbb1ReBBGRS1iwXD2reVKDj09K10dZFDocg1LRcZXHEAjBrzX4ieANI8eeHZ9B1RdsZ+eGYLl7eUdHHt2I7j869LorkxOGpYmjKhXjzRkrNPqiKlKNSLhNaM/Gnxl4N1zwJrk+h67F5ckfMcg/1cqdmQ9wf/rHniuZVuK/XTx/8OPD/j/SG0vW4C4XJilTCywOf4oz/NTwfyx+cfxH+DXi34dTPcXMJvdKdsRXsIJjOegcdYz7Hv0Jr+KuLOBsTlE5V8OnOj36x8n/AJ7H5hmGVTwzc4K8fy9f8zy1WqZWqmrVKpr8iPnC6rVOrVSVqmVqALgap1aqQapg1AF1WqZWqmrV6r4B+FXifxzMktvEbTTs4ku5RhOOu0fxH2H4kV6WCwGIxtZUMLByk+i/rbzZvTpSqS5KauzD8I+FNY8Z61Bo2jRGSWQ/M/8ABGndmPYD/PNfox4L8IWXw80aLR9NHmqfmmlIwZZMck+nsPSrHgfwL4b8FaQmm6FH83Blnb/WyN6sf5DoK7j7w8uUA5/I1/aPBfBlPJYe3xFpVpLXtFdl+rP0zLcsWGjzy+J/gRfuLyPPp+YpqySQnZccjs/+PpVaS2lgbzbb8v8APWrEF1HOPLkGCe3Y1+un0CffcvUVUCPB/q/mj/u9x9KsK6uMqazNLjI4liBCcAnOPSsidGtLoSJ0PI/qK3arzwLOm1uMdDTTIlG60ILuMXNuJY+SvIrPsp/Jl2t916v2wkgPkSdD909q+Kv2hvjR480Dx/pXwg+ElvE2v6rGkkk8iI5jMpOxYxIfLGApZi4IAI963hHmfKjCo+W0z7Mv4SrCdO/X61bQpfW2G69/Y18EQ+Df26EQ3kPjLTblz96BvJP6PaBR+Br62mvde0TwRNeai4XWLXTDJM6AFPtSQ5LAY2keZyOMUShbqTGerdtDb1yHVLnw7rGk6VKbfUp7S4S1kD7Ck7xkRkN2w2CD2r89/AHxE/aq+HGm3Gj674E1TxPO108our0zyyICqJ5YkG8FflJGD3NezfsyfF3xL44+HHiHxp8T9Zjk/se9aM3UkcNskUAijfnylQcEnk881y9/+0D8XfjPr9x4b/Z10dE0uy+WfWL2MbN3YjzPkQHspRnI5wBkV0xi4txaMZNSSab8jrfB/wAbfjx4p8T6VoviD4Wz6Tpl5OiT3jLPtgQ9XOVxx719YWsxtpir9Dwa57wOninS/Dem2fje4ju9bSFFvZYQBG83dkAVBj6KPpXzF8Q/C37X2veMtWl8H69ZaR4c84/Y95hV/J7ElYZZPzNY6SdtEXqlzatn2/VCeMpPHcL2OG+h71+Y3jrxx+2F8DtI/tDxJrNpqumXH7hbqOKK4S3kP3TkxRMCe24Fe3WvpX9mjwh4/FlP8TfHni//AISc+K7K3kt4gZGS3jOZMDfsCn5sFVQAEdaUqXKua5pGtzvlSPprU4+VccZGM1+Xvij4L+MvgJ8Y9E8UfBbQdV8RaZZ2qXDlgZQZJDLFLA0kMa8bQCRjPNfRfxE8O/tf614r1ZPBev6fpXhtZv8AQ/NEPmeVtHJPkSyZznvXjHiXxJ+2L8EtOPirxHqln4j0C1ZBcALFLGgkbA8zEUMyhicZBwCRntW9JNbNamFVpu7TPoH4X/Gj42eMPGmn6D4u+G02g6RcCXzr5xMBFsiZ0zvUD5nAX8a+tq+bLDxv4s+KfwVTxV8JZY9L8Q6tDH9nM+11t5o5wlwreYrKQArgErzwcV8w+PLr9s/4RaS/jnXvFNnqun2zqbiOFIpVRHO0bo2t4vlyQD5ZyM/jWbp8zsrI2jV5Y3d2fo3dR3E8oQD9329PqadLLHZJ5UXLnqf8a8t8A/FZPGXwatfio1i7ubKe4ntLfljLab1lji3kdWQ7MnuMnvWX8NfijpPxt8G6n4k8DRzWU9vLLa+XebPMScRh1b5S42ncMZ9DWPK+vQ1bW8d2erwwyXUvP4mp9RuZrW0li06PzZ0jchR3IHA+pr85fE/xQ/a5+Bi2mt/ENbLWNGlmWKTbHBsywJ2FrdY2jJAO0kEZ9eh+9dH8QJ4h8B2/izw1/rtZsBdWYk25DSxb4w/bgkbqucHGzMack7rqfIq/tC/tH2i7P+FPXAY85KXOf/QKgHx7/aRmYv8A8Kgun9fkuf8A4mqx8G/txa+7PP4t02wJ52DyU/WK1b9TXLy/G79oX4B+K9O0L43eRq+h6i2BcxJFnywQJGikhWPLJkErKuSD2yDXUop/Clc5XJ/absfoHpWqXl/oWnXN5bGxubi3iknh5zDI6gvHzz8hJBratoEt0+0T9ew9P/r15V8TvihpHwh8KReN9Z0+51OxeeODFmI2KeYCUkPmMo25GM56kVleMtZ8e/ED4Y2niD4J3UdpqeppbXVq1wItoglw7hhIsi7sHB4ODXHy39Dsv1e57TCrXTm5uOI06DtTXaS+m8tOIx/nNfAPhf47/G/wD8T9H+GXx1t4J4Nalihiuoo4kIMr+XHIjQ4jZfM4YFQR19j+hIAjxbW/X+I+n/16JwcNwhJTQBePs9vwB95v896o3t7BZ28pLiCG3RpJZT91FQZYk+w6mp55dgFrbjnocV86/tV+Lx4E+B+tiCTZe67s0yI+v2jPm/8AkESfjUxV2kaSlZN9jyP4R/tkN49+JOneB7/QYdNsNVllihuROzSb1QmIMpUDLkBeO5FffdfkR8Qvhde/DH4F/Cv4m6TF5Gs6ZdC7uXA533pF1bF/TyvLWP6mv1P8L+JLPxbo2meIdMObPUrWK6j9cTIHAP0Bwfetq0Y6SgZUJP4Z7nCfGn4gy/DH4f6541t4lnuNLgUQI/3TPPIsUZYAglQzgsAQSAa+S/hbo37VPxR0yy+Iz+PodLtb9mlit2hX54hJt5RItqggHb1OOtZv7Wvif40z6H4m0PUPDFtF4GF1bhNTD/vyEZTHx5x6ycf6v/Gr3wM8cftMWXhPwrpuieB7C58KKtvEL1pAJPsm/wCaTH2gchST9z8K2jG0Lq1znlLmq2d7H6ExSpGtzdyHCAkk+yCvzY8D+Mv2i/2i9f8AEGr+BvE0XhTw/pkoEa+WM4csY14VmkfaMyEsFz0HavqD43+J/jV4fsLa3+F/hm21zT7q2uPt007gNCeg2fvouq5PQ18Ifs0eLfjp4f8ADGtW/wAKPClp4gsJrtDcy3D7HjlEYwo/fxcY56GilD3XLQqpP31HU++/Ed547+Hf7PWsapqesi88VaXp80h1CONMPMGOxgjrt4BA5Wov2ZfGXiTxv8GbLxP4rvDf6lcT3StMUjjyElKLxGqrwB6VX+LF34ivP2YtbuvFlmmnazcaO7XdvGcpFKVyyg7m4B/2j9a+PPgX8Y/ipZ/DKw+H3wf8Gf25fafNO95eXX/HtGZ5GeOMYkiGcc5aQfTHNSoc0W/Mpz5JpPsfqPYfu4JZz/naKxdU17SvCfh3UvFGuTi3sdOhaaZz2SMZ49SegHc8V8Q6V+1D8U/AXiqw8JfHvwpBo9rqhAjvLcOmwFgDKT5k0cqr/EFIIHPPQ++/tQ2N/efs9+KrbTULz+TBKQvXyo7mKWX8o1JPtWTptNJ9S41Fa66I+fdP/as+LvjSa6uPhL8N5dS06KTb9omEsvTnDGLaiMc/d3Nj3ru/hz+1jqOo+Obb4b/FnwtL4R1i+dIoJG3rGZJP9WskcoDKJDwrAsCSBx1rrP2P9Z0G++BugaXpE0RurBrhbyFWHmRytNJIDIOvzAqQT247V4D+1zdWPiH41fDjw94YkS68QW86rMISHePzLiIwo+OhBDtgngHPANbWjKThykJyjTU1I9m+Pv7RHin4YeP9H8CeGPDA8Q3GpWcd1GitIZnkeWWPy0jjVi3EeeOea86n/aU/aFndWf4L6mAB0Fpff/GK+pvFHwW8KeLPiZoXxU1K5vE1bw9HHFbxxSRi3YRu8g8xTGWJzIejDtWb+0b8Qx8NfhHrmtwSeXqF1H9issdftFxlQV90Xc//AAGs4yjpFR1NJwl70pS0PO/2cf2idZ+Nmr6zpGo6DFpMekQRybopHky8jFdrbgMdDX1wc44r4+/Yw8AR+FPhEmt3SbL/AMUS/bH7MLdPltx9CMyD/frgvEv7T/xG17x5qPgP4BeG4df/ALMaSOa7uA7xuYzsLriSJI0DcBmYhuw6VM6fNUah0CFXlppz6nuv7R3jbxV4F+Emu+JvC91/Z2p2ZtRFKI0k2eZcxRtxIrKcqSOR9K6r4D+Jtb8ZfCPw14m8RXX2zU7+2LzzbUTe4kYfdjCqOAOgFfBfxx+Mvxfu/hlq/gT4zeCl0e41U24sr+0z9nMlvcRyur/vJVJKqcbZOv8ADjkfWP7PupS6H+zv4d1bGUttOnmweh8tpD/SrnTtDzuRCr7++ljmPi7+1pp/grxU3w98A6JL4s8RRv5MqxlvLjn7xARqzyuO4XAB4zkEDG8J/G39pzVPEukWev8Awx+w6Pf3lvDPN9nuUeCCSQLJId0hxtUk/MoHFeJ/skeMfh34H0zxT8U/iVq0FnqepXgtIppt0lwwI86by40DyHezKWIHYfj9seEf2lPgp421WPRdB8TxG+nbbFFcRTWxkPYIZkRST2AOT6VU4qGijfzCEnP3nK3ke1TQuj+fB97uPWnHy7yP0I/MGnTTRWsUlxO4jiiUuzOcBQOSST0AFfAMv7UPxZ+JPim/0n9nzwbFqdnYkq93eZIcZIWQkywxRbsHarMSQM+oHLCDlsdM5KG/U++opWVvIuevY9jXxD43/ar1OHxzeeBvgz4Vm8WX2nNJHcyrvaLfGcN5aRAkxqeC5KjPTjBPoHw88XftI6hfarZfFnwpYaZYWunXE8F1ZurM93Ht8uMhbibqCx+6OleL/sAQWSeHfFmoOB9smvLeJnPXasZYDPuWNdEYKKcnqYSk5OMVoPb9rr4keD9RtLb4z/D2TSdOu22i4gSWIrjqYxLuWUgdVDA+9fTnxC8ean4V+Hz+OvBGmN4nllW2ls4YNx+0R3LqA6CNHYja27AHSuF/bH0qyn+Auv3cqrvtJbKWLPaQ3MceV9Dtdh9Ca6n9mG6Oq/ALwg1ySzpbSRc9QIppI1/QCh8vKppdSFGXM4Nnzw/7R/7TUNrJqWo/CgmxQFmAt7tJFC9SckkAeu2vdPgZ8edC+M2m3N3plvJpuqaaUFzZyuJNok6OjjG5CQRkgEEcjoT7ffzwaNC9/f3CW1vACzzSOERQOpJPA/Gvz1/ZKkg1f9of4j6/oKj/AIR+db3yio2xn7RfLJAAOMZjViB6VXuyi2lsS+ZSSbPX/iT8c/jjYeNtT8I/D/4by6xZWLRqt60FzJHIWjViQ6iOMYJI+8elcZpH7XvjDwd4is9C+NXgmfw5b3pAWdRIuwZAMgjlHzqM/NtckehPFfeE1q8R823zx27ivg39vDxD4dufAmhaC00T66NSE6RAgypbiGVZCR1ClygwcZI74pU3GTUOUqpzRvNy1PsTx34+8HeCPCUvjXxLeeVpcYTbLEhlMhk/1aoEznd26DuSBzXx1oX7bF94k+IHh/wppPhUw6Trt/bWcV1dTETmOeYQmQIo2cZPAY8jrX0zoHgOy1r4WeE/Dvj3TU1EWthpzXFvOCyfaYIVz5i5wcNng5B7ivkP9oaK0i/ak+ElpaQrb28UmkIsaAKqgai2AAOAMUqcYu8XqOpKStJaH6MzwSW7m4tuncVXvtZ0uw0y71TV5UtrSyieaeST7iRxjczE+gAzWoC0fDHK+vcfWvhL9qvxbqvi3X9G/Z28AHzNX8QSRyaiVPEUH3kR8dBgGWT0RR1DVzwjzuxvN8i5kdn8Bf2l7r4yeONc8OQaMtjpenwSXNvL5heZ4xKsab0xgEhskAnBr6C+InxG8MfDHwnc+MfFE5jsYMKioN0k8rZ2RRr3Zsd8ADJJABNfn7+x5o9t4T+Pvj3w1FI0kWlQXlmrv1It71YwTjuQOa6f9tyRta8YfDrwGJPLtNQuHklAfALzyxQo57DaN2D7muqVOLq8q2OeFWSpcz3Ltl+1f8cPHTSXvwv+GL3elhiqTSrPcKdvUGSPyow3sCce9fU3wV8WfEDxl4bu9X+JPh3/AIRnVYbt4Ft9kkYkgWNHEuJCTyzMM5xxXGf8NM/s6eDEt/Clt4iht4dNUWqR2tvPNDEkQ2gCSKNkIGMZUmvcPCfjTwt460hNc8IarBqtk5x5kLZ2n+64PKt7MAfasp7aRsb09XrO54x+0D8dNB+CthZPcWzaprOqbxbWcbBMqnWSRsEquSAMAkngdCR4JJ+0j+0odPfWLj4UsdLCbyfIuvMCYzuPcDHOfLxWR+1L9n0j9pf4Z+I/E2E8PItkGlk/1aGC9Z5ifZVZGb2r7/bUdO0+ybW5LyEaYI/Ma4Mi+UI+u8vnGPfOKv3Yxjpe5j70pys7I8T+B3xx0L4x6NPqel27afqGnMkd3Zu4cpvGUdWGNyNggHAOQeK8h+K37aHhfQL640XwDpMviO709mFzcSb4LaEIdr4+UyPhuM4Vc4wTXBfsgQjVPil8TPEXh+PHh+SZ/JIGExLcySQgdOkYPHYGvZvj14P8KeDP2evHFr4a0uDT/tggmlaJf3kshu4iTJIcsx54yTjtVuMVOzRipSdPc9l+CHxCufij8NtK8Y39oljPqH2jMMbF0Ahnkh4JwTnZn8a9G/48br/pm38v/rV82fsmB4f2fvCUy9/t+Pwvp6+oHVL233L1HT2Nc00lJpHXTblFdyK/gEiecnJHX6U+0lW4iMUvJAwfcUyymODBJ1HTP8qrzI1pcB06Hkf4Vl5Gn95EDpJZ3Hy9uR7it6KRZYxInQ1WljS7gDL16j/CqNpOYJPLfgN19jQ9QXuvyNC8g8+LC/fXkVBdDzrNZO4wf8a0qiMY2NH2fP61KZo43Ktm5kt9ucMvH+FOtroTHY4w4qnYsY52ibvx+IouB9nuxIOh5/xqrGak0kzZqhfeeYwsS5B6461NPMYVEgGV71LHIsiB06GktNTR66GfHGljF5svLntWc7TXUvPJPQVsXNoJ/mBw36VEqpYxb3+aQ1afUylHp0JYY4rXbFndI3+fyr+c/wD4Ld/8lU+Gv/YGu/8A0pFf0U2cbyyG5l/Cv51v+C3f/JVPhr/2Brv/ANKRUM1jsaHjf4K/8E/rP9hePxroMvhw/FY+ENNuiIvELyX/APa8ltC0/wDoX2wjzfML5i8rg5G0Yrtv+CGn/Hr8aP8Af8Pfy1CvxI+Dvwu1r41fE3w78K/Ddzb2ep+JbpbSCa7LiBHIJzIY1dgOOymv6ef+CdP7FvxI/Y/h8fxfELWNJ1Y+K20s2/8AZck8nl/YRdeZ5nnQw4z567cZ6HOOKks+AP2i/j//AMFOPD3x28e6J8MoPFbeErLWbyHSzaeF47m3+xpKRF5UxsZDIu3GG3HPqa6r9nW61f8AaGvdbtP+CpIeDTNEjgk8Mf8ACWr/AMIpGbiYuLz7O8a2PnnasO8EvtGDgZ5/dD4j+OtM+GXw98T/ABH1qCa50/wrpt5qlzFbhWmkhs4WmkWMOVUuQpAywGepFfiD8Zdatv8Agr5baX4d/Z+R/Clx8M2lu79vE+IEnTVAqRCD7Cbwkqbdt24L1GM84APgv9oz4B+KPDP7TGseJv2QvA+q6p4D0m70678PanoNnd61pxlt7a3kkeC7C3Ec3l3YcN87AOCh6ED70/ZM0n9o/wDbA+IOpfDn9vrw7ruveAtM0uTVdPh1jSJdDgXWIpobeJ0uLWGzdpBBPOAhcggk7cqCP1d/Y/8Agx4j/Z5/Zz8H/B3xbeWmoav4eW9E89iZHt3+1X09yvlmVI24WUA5Ucg9uab+1N+1H4J/ZN8B6b8QvHmmajqljqWpx6XHFpiwvKJZIZpgzCaWJdu2FhwSckcegB+Gn7VP7QHxg/Yy/aB1H9nf9mjxE3gr4eaMthNaaVHb294sT38MdxcHzryKec75ZGblzjOBgYFfqx/wUx+NHxO+A37Olt43+E2tvoGtya7ZWbXKwwzkwSxTs6bZ0kTkovOM8da/nT/bA+O/hb9pP9pjUvi34OsbzT9K1MadFHDfpGlwDbQxQtvETypglSRhjxX9MX7ef7NvjL9qn4IwfDHwNqOn6XqUWr2uoGXUnlSDy4Y5kIzDHK24mQY+XHXmgD4l/Yl+FPw//b5+El/8af2ttJHxA8Z6drE+iQajLLLYFNPtoYLiKHyrB7eIhZbiVtxTcd2CSAAPcPDn7Hn/AAS28X65F4Z8Jaf4Z1vV7nf5VlY+J7i5uX8sFn2xRX7OdqqScDgAk17B+wH+zN40/ZQ+C2ofDXx1qWn6pqN5rdzqay6a0rwrFNBbxBSZoom3Awkn5cYI5r4i/Y//AOCZvxp/Z6/aW0D4z+LfEfh+/wBI0r+0fNgsZbt7k/bLWa3TYJbaNOGlBOWHGcZoA+i/F37Ff/BMb4fahFpXj/RvD3hq+uIhPFBqfiS6s5XiJKiRY5r5CV3KRkDGQR2r8vP2Q/gT428I/wDBRfSPEnh3wRq9p8ObPXvEB0vVBY3T6W2lvbXqWUsV66GOSGSMp5cu8hwQQTkZuf8ABa//AJOS8Hf9ilb/APpfe198fsU/8FGPhB4/Hwr/AGYtJ8P67B4kj0a00o3c8VqLLz9L0/dK25bhpdreQ2393nkZA5wAfpv4x+J/w2+HTWifEHxbpHhh78Obcapf29kZxHjzPL85037dwzjOMjPWvg/Vv2e/+CYnxb8eXmsX0/hTxD4r8WX8k8otvFEjXF5e3chdtkMF8Ms7k4VF74Ar4g/4Lkf8hX4N/wDXHXv/AEKxr8r/ANin/k7f4Q/9jNpn/o9aAP6bf+HZn7Dv/RMIf/Bnqf8A8l1/N7+1poGk/s7ftk+KNM+DVv8A8I3b+CtU0+70hVZrj7LPBDBcxuDcmUtiX5sOWHY8cV/Td+1h+2h8Of2QLfwxc/EHR9V1ZPFTXi2/9lxwSGM2QhMnmefNDjPnDGM9DnFfiv8AtAfshfED9qyx8a/t8+BNV0vS/A+vWFzr8Om6lJOuqpbaRbGKaN0hhlg8xjasUAmIwRkjnABf/ZL+PGnftieNNY8Dft/eM9O17wfoth/aOlxaxcWuhxJqXmxw70mtfsbO3kySDYXIwSduRkfoNp/7Nn/BJmG/tprC48Hfa45UaHZ4ukdvMBBXC/2hyc9sV/K1XQ+E/wDkadH/AOv23/8ARi0Af0yf8Fpf+TVfDn/Y4WP/AKQX9fy9V/UL/wAFpf8Ak1Xw5/2OFj/6QX9fkB+zJ/wTn+L/AO1R8OJPiZ4G8QaFpmnRX0+nmLUpbpJ/MgSN2OIbeVdpEgx82evFAH6CfsYftMftnL8abMftd6tqnhv4ciwujJd+I9It9D08XWwfZ0N3JbW4DE52r5nzehr9gv8Ahpr9m7/orHhP/wAHth/8er8Hf24f+CkHwd/aV+Adz8IvBnh7XtN1V7+zuPO1CK1S32WpO4ZiuZWye3y1+KtAH999rdW17bRXlnKtxBcKskckbB0dHGQykcEEcgjrV2vNvhju/wCFS+D9vUaNp3T/AK9467i2vA+I5eG9fWqsQ5WdmaNQzQpMuG69j6VNRUltXKUUrbvs9x97sezCmFWtG3JzCeo9KtyRJKu1/wD9VQI7xkRTc54Dev196DNoSW2guwHzn3FQ/wBlw+pqQwzQsWtSCG6q3QfSjOpf3U/OruFvI//X/fEG3vY/X+Yqk0VzaNuiO5P89anks8N5tsdj/pTorwhvKuB5bevagzavuOingul8thz6H+lR+VNandD+8j7r3p01nHL88fyP6jpTFuJ7c7LoZH94VXoHqT/uLxPX+YqiY7izbdH88ff/AOvVwxRT/vYmw395f60olli4uFyP7y9PxFSDV9x0N1FOPlOG9KtVRktIZx5kR2nsy00SXNvxMPMT+8OtA723NCqc9pbzxvDNGrxygh0YAqwPXINTxzRyjMZzUtDV9GVufNPjb9mLwN4meS80ItoF4+TiEbrcn3iOMf8AASB7V8veI/2aPiXoUj/YYItViHQ28gyR/uSbTn2Ga/Teo5I0lXY4yK/L818P8mx7c/Z+zk+sNPw1R4OIybDVtbWfl/Vj8eNT8DeNNDJ/tbQ7y2A/ikt5An5kYrnljl3+XsO/0xzX7TRI6Dazbh2J61DNaLI3mRny5PUV+dVfCOk5fu8W0vON/wBUeJLh1fZqfh/wT8itL8E+MNZAbTNGvLhD/EsEhT8wMV6x4b/Z1+IWuSR/bo4dIifvcSDfj2RNxz7HFfo0lzJGdl0mP9odDSTWMUw3xHYT6dDXr4Lwpy6m08TWlP0tFfq/xOinkFFazk3+B8+eE/2bfCXhsx3upsdbu0wcSjZBkekeTn6MSK9/tTaGBbRI1iRBtEYGAAOwA6U1Lia1Pl3IJXs1WpIIbtfMU89mFfsuW5Rgcth7PBUlBeW79Xu/mz6ShhqVFWpRsUpbWa3bzbdiR+v/ANerdvdxzjY3D+nrUazz2x23I3J2YVJJbQXQ8yM4PqK9k6krbD2Z4OWy6evcfX1pHgt7kb179xUkImC7ZSDjoR3+tOSCKNy6DBNA7XI4UuIzschl9e9WNqg7gOTTqKCkrEBuIQ/llhuqekCqOgpaBiEAjBr4L/aK+D3xR/4WjpHxt+ElsuoX9lFGk1vlfMDxZQNtcrvV422sAdwx78feteOfEf45/Dn4T6lYaZ44vZbKTUonliZIJJU2ocHPlgkHJ9K2pSkn7qMqsYuPvM+P7j9q740+AZIrv4lfDVrO0LiNpQs9ohz2V5RKpPcDNfYMvizSPiL8ILjxv4fLNZ6lpdzKgfhkxG6ujYyN0bAg4OMg18m/tHftPfCHxn8LtU8G+EbuXXL/AFbyY0P2aWCODZKshZjMkZJG3gKDzivaPgv4b1jwZ+zLBoGvQtbXh0u/uDHJwU+0+bMqkdjtYZHUHOea6px91StZ3OOD1cE7qx8B/s/fBfxv8bNFvNBXXm0XwdZ3fnXAVfMaW88tcYiBXcQoHLHC5+UEk17n8T/gd4w/Z48DSeNPhn4+1eKLR5InmtGkKQOJZFj3CNT5ZwzAlWVgRnJ456z9hDenw91+de2rdff7PHXvP7VhSf8AZ78WSjtFbEe3+lRVpOo/a8vQyhTTpc3U634R+M7r4k/Cnw945vlVby+tmNxs4QywO0UpA7AuhOO2cV81z/tc+LfE2vX/AIe+DHgWbxTBp7FTdlnKOMkBtka4VWwSu5gSOwxXpP7KiPffs3aBpayeU1zDqKI390vdzj+ua+Sf2bvi34a+Az+JfAnxPiuNG1Bb0SGTyGkw0Y8to2EeW4xlSAQQTz0znGCvLS9i5Tdou9r7lr47/Ej48+IvhvqeleO/h8NA0eV7cyXeJP3ZSVSg5YjlsD8a+3/2YZPM+Avg7nJFoR+Ur15R+0b448OfEX9ljWPFfha4N3p9zNaiNzG8ZJjvY42+SQBhyD1FegfsxztbfBLwgW+69oc/9/ZKJu9La2pVNctXe+h48/7Z2s32u6tonhj4aX2vDSriSCSS0uWl+VHZVZlS1fbv2kgE/ia7vx74lvPG37M/iPxDreizaHcXumXbSWF1nzYHikITdvWM5JUMMqOv418w/Cb4gaR+zX8cPHXhn4iwzWWn6vOdl0sbyKiRySSQS7EBYxyxydVBIOBjrj0j9of9qD4V698ONV8M+BtTfWdT1qL7MQsE0UcUbkb5HM0a5+UYAGTk81Tp+8lCPzM+e8W5y17HoP7GxdPgbp0u7IF7eAe2JM16f+0yqz/AfxdKB0s8/wDkRax/2YPCWoeF/gToGnarE1ve3Hn3jRMMMnnys8YI7Hy9uQeQTir/AO0NKW+AvjOI9Ussj6eYtYt3qXXc3irUrPsc1+xqVl/Z+0SM4OJr0EHkc3EleHfsyO3wu/aF8efBu4/dWl6Xms0P/TufMiA92t5ST/u17J+xnL5XwP0RT0kmvB/5MyYrxz9qNH+Ffx48B/Gq0Qi2mdYrzyxyfs52y/jJBKVH+7Wi1nOHci9qcJdj2v8AbSRG+A2qOwBK3Vng+n74U34feKj4F/Zb0PxrPB9ti0jRhN5Ifyy+CQE3YOMnAzg/Svm/9or9oXQvjdoFl8LfhRZXmrXWo3cUkrGEpkR52JGmdxJYgkkAAD8vrrxH8M9RH7NE/wAL7AC51G20GO2RY+k1zBEGwucffkXjPrU25YxjLuO6nKTj2PCNC/bF8WavZRX+i/CbU721uCVS4gnlliODg4dbQg4PXnrWZ+3hCj+B/Dd2yZkTUnUN3w8LEj8cCsL9mP8AaL+G3gn4ex/Dz4i3Muh32kTz+VK8EsiSJLIZCD5SsVZWJBDADGMHOQOQ/aX+LXh/486n4V+GnwnWXWCt0ZDP5UkQkmlHloipIqthRksxAAHsDXRGFqukbIwlK9LWVz7a8f8Ahh/iP8DLjwlEnmz3mkRNAO5uYo1li/8AIiivK/2KvG/9u/CA+F3fN54fvJLfHfyJ/wB7GfzLqPZa+ttFsItH0uCE8i3iSJf91AAPzxX5qeEfGuh/szftH+N9O8Uebb+HtYR5ovJjMmDKwuIMKOoUSPF9a54e9FwXqbz92Sk3vodV+2PCLf4o/C7y/wDW+dyR/wBfMOK/RCVxZxbAcyvyT/WvzE1DxNN+1D+0P4VvvCOnzr4b8KyQTXFxcLgeXFL50hfBITzNojjBOSeT3x+mtujXc5nk+6P84pVdFGLKpauUo9S3Z2+webJ99q/Ob9rnXNN8Z/GTwN8KL+/hstKs5I7jUZppViij+0yDdvZiACkMZIyR9/Hev0id0hQySEKqjJJ4AA7mvys+FHw80L9qX4u/EDx14y899EjlH2cRSeU5MjbLcZwc+XBFgj1IooWTc30HWWipx6n138Z/E3wk8efCjxH4Ot/GGhmWeyY2sY1C1/11viWED5+PnQDjtXG/sQeMj4i+E8mgzyb7rw3ctb4PXyJcyxH6ZLKPZatr+xN8DSZc2+oYQ8f6WfT6V4Z8DIk+CH7T/iL4WK7ppWuwMLTec52L9ptiT3IjLp7satKLpuMX5kNyVSMpryPf/wBsDP8Awz3rLHvd2f8A6ULXoP7O+E+A3hJvXT4/8K4H9sLj9njVv+viz/8ASha739n/AI+Afg0eunxfzNS/4fzNft/I9P8AEh2+F7settJ/6LNfDf7BnzeBPEkf9/U4/wD0SK+5fFfHh67X/phL/wCizXw1+wQM+DvEA/6icf8A6KWiH8ORFT+JE+lv2kWH/CmPFy+mmz/rivM/2Pwi/ATRtoAL3N6T7nziMn8q9I/aRy3we8YAdtMlr49/Zp/aD8F/D7wFp/g34iR3Whxbp57O+MEssFzFJK28jy1LDbICpIBHHUHIohFunZdyKjSq69jtf2+baE+A/CV0UHmx30iBu4EkOSPxKj8q99+NPxIuPhp8Eh4riiju76S3t7eBZhujee4UDLjuANzEd8Y718aftKfFTQv2gta8JfDD4TGXWHW6YmcxSRI8sgEaACQK2EG4yMQABz0Br62/al+H2o+L/gdeaJ4eha7u9GMF3FCvLyJbAq4Ud28ssQOpxgc1VrKEZBe/O4Hyl8Lv2Np/iP4ZtPiF4s186TLr6G7itbG2jRUilyUPBVFDAghFUAA49hjeIPA2s/sX/ELw/wCNLC4t/Eeiao7wuZ7aNLiMJjzVQncY2KsSroRnkMMcH234Hftb/CvSvh1ofhbx1eTaJqWhWkVk+63lmjkS3Xy43QwrIeUAyGAwc9RzXjn7QHxK039pTxR4Y+G/wliuNR23DyPcPG8aF5AEyA43BIlyWZgPauhOo5NT2MJKkqacNz9SnnllijurMh4pFDAjuDyPwr85v2ptWvPi58ZPBvwK0VyI4pUkvNvOyW45LEf9MbcGT6Ma++59a07wj4enu9TbybDR7UvI56rFbx5JP0Ar4J/ZG0O++JnxK8ZfHXX0IaSaSG2zyEmuTukCH/plDtjHs1clJct5vodVV81oLqfoCmkQ6FpcNnoqCG3sYRFDGP4EjXaoHsAK+Df2ADb/ANj+Mryf/j4uLm0VpD1IVJDgn6sa/QPzpYB5N4NyHjcK/Lj4B/EHQP2cPG/jD4cfFJZtOt554zDdrG8qIYNwDERgsY5UYFSAenI54KacoyXoFS0akZep9afthWka/ADxLMoxsayOPf7XCOPTrUfwblik/ZRsIW+8NEveD/226V89ftHftHeDvH3w71XwD8PFudfW48qa6vEgligtYLeaOTefMUNywC8gLz1zgH6i/Z20+z1n9nbwzpdwfluNPlhfHUCSSQH+dNxcaa5u5MWpVXy9j40/Y1+C3g/x5peueMfFunR6v9iuUtLaCbmJCIxJI5ToxO4AZyB/L0f9rD4JfDjRvhnceNvCmiQaFqujz2+42ieVHLFLIIipjHyghmBBxnjHQ153+zt8W9L/AGcNZ8UfC/4rQT6d/pgkWdYnkCSIPLbKJlikihWRlBBHsRXUftMftGeBvid4NX4bfDBp9ev9YuYA7x28sYVI3EgRBIFkaRnC4AXGM85xXS+f2t+hzL2apW6n0RB4w1PxF+yFd+LLycz6hP4YuhLKfvPKkEkTyH3JUn61zX7DWn21r8FmvIlAlvdSuXlbHJ2BEAz7Ba9N8O/DLVtM+AMfwsudhu5tEmsZhnKR3FxCwfB7gSOeRXx5+zD8ePDfwa03V/hT8VxNoVxZ30kscrxSSBHYKskUgjDOCCuVIUg5OSMDPNbmjJR7nXzctSLn2P08eNXOeh6Z/pX5qw/Db4+fs2eMtavfhNoyeKfCustuFvgylEQkxiSMMsoljDEBlyGHXngfaXgr45/C34ja/J4a8Fa4uqahDA9y6JBMgESMqE75I1U8sOAc1jeKv2kvgt4J8RXvhTxT4h+wapp5QTRG0upNpdBIPmjiZT8rA8Gsoc0W42NKihJKXMfC/wAcfEn7SXxB+GmoX/jjw3F4T8K6O1vPNGweOa5keVIolIkZmO133Y2qOMkkhRX2X+yvbOP2f/CE0XySeTcH6j7VL/Svl/8AaR/aN8NfFvw1D8KPhNDc65c61dQebKlvJGHEbh0iijcCRmMgUklQAB3zx9Yafqeh/s3fBfQF8YSS/ZtJgtra58hPNxcy8yFeR8nmE/hXRUvyKNrO5hBLncr3VtzyP4qfshaX8UvGGr+MG8Tz6Xf6kyN5LW4lhQpGsYx+8Q87c9e9ea/sy+IPEPw1+KOsfs7eJLe1ZoDO8M9vEkbvLEolyzgKZFkh+YF8sMAdOB77cfthfs9TWLXR12YzKMiEWVz5p9gTH5f5tivnn9n7+1vi5+0hrvx2GnzW+h2gkWGSUcl3hFrEvGQXEIJfBIXpnkZqLlytT2M5KHMuR6n2t8T/AARbfFPwTe+BtUv5dOivGiY3EIBkTypBJjB9cYr87vip+zZrf7O1pZ/FnwnrMOu2+m3UW+K9s42MRkOI3w5dHG/AzhWUkEc8j7U8SftR/BXw74n1Dwl4l1C40++02XyZXNrLJHuAB4MQckfhXzD+0b+0f4N+IfgmT4YfDOS41241ueASSLbyxoEikEoRVkVZGkZ1XgLjGec8VNH2iaSWhVb2bTbep90fCzx9H8RPAWh+MJIhbnVbcSMnUJICUkUZ7BgQD6V8U/tLRCP9q34VCHjfLpRH1/tFq+x/gn4Ol8FfCfw34P1EKLzT7X9+inOyaVjLIA3fDMRnoa+N/wBpGM2v7VnwpBO4LLpRH0/tJuKilb2jt5l1b8i5vI+1viL8SdM+GPgrVPF2ujcLGM+XH0aeduIoh7s2BnsMnoK+cP2Tfh9rN4uqfHzxuv2jxB4ukka33DaY7RzksoP3fMIAUdo1XBwa9E/aH+CWp/HfStG0vStdTSIdNmlmkSSNpFlZ1CocKw5T5sHn7xrxm2/ZZ+PdjBFaWfxl1CG3gVUjSOa9VERRgBUE+AAOABRHk5LXs2VLm5r2ukc9+zLHHN+1H8Vw69ZdUPv/AMhEVg/traC2tfFjwH4ejkKf2lClqrf3PPufLz+teUfBr4YePfEvxt8V+GtG8ZXGlapoU9yb2/jkmEl75F2I5NxWQMfMb5juJ56819Lftu+H9bsLjwZ8VtGtzcR+HLlluCASIz5kcsLNjkKWVlJ6AkDvXRoqqs+hypXou66n0XYfs2fA7T9IXRk8IWU0aIEMsyeZcNx1MxPmZPsR7Yr5J+Bdonwh/av8VfCzSZpE0S8hk2QuS+MRrdQZPUmONmUE8kE55r3nT/20fgTd6Qmo3mq3NldFQXs5LOZ5Q+OV3RoYj9d+PpXiX7OK6l8XP2ivFnxzWxktNERZIrZpRyXkVYYk7gsIYyZMEhSQO4rGKklLnOiTpuUfZ7mj+1J4j1r4m/EvQf2cvC8Frm88qe4u7iJZHjkYGT925BKBIV3MUwzZ25xkGB/+Cfekf2Z5MXjO5+2AZDG0TyN+P+efmZxn/arO/aBfU/g5+0x4b+OU9hLd6HcIkczxckMsTW00fOAG8pwyAkBvXg49+k/bL+ACWBvV1yeSXbn7MLK587OOmTGI89vv496d5qMfZbCtByl7Tf8AQ8p/ZH8Xa14X8WeIv2efE9pbR3GgGeaGe3iWPzTFIscm8oBv3Aqysw3YGCegHsn7V1sYPgR4sZfuGK3x7f6TFXz/APssW+sfEj45eMvjrLYyWej3Szw25k6mSeRNqg9GMcUeHx0JFfSn7V//ACb74v8A+uVt/wClUNTPSsvkOKvRfzsZX7I8a3H7OfhWPPI+3/gft09fQNrMYJvLfgHg+xr51/ZEMtv8APCcxGYpPt+cdv8ATp6+kb+DePPj6jr9PWsKvxM2p/w4tdhL2IxuLmPj1+tWfkvbf3/kaZayrc25ik5IGDVKJ2sbgo/3O/8AjWZr59GLazm3lMUnAJwfY1PfW+R56fj/AI069thKvnx8kdfcUWNx5i+TJ1HT3FLzFb7LH2Nx5qeW33k/lWhWDcRPaTiSPp1H+FbMMqzRiRe9JlxfRmPdgwXPmDv8wq5eqJbcSp25/A1LeW/nx/L99elQ2TeZC0En8PH4Gncnl1a7i2xFxaGM9Rx/hUdhLgtA3Ucj+tQ2jG3uDA/fj8e1LdKbe6FwvQ8/40xdmaH2gLP5DjBPQ+tTsqsu1hkVQvl8yJJ4+qc59jUzTMbYXEfpkj+dZl37kpRg0e04Veo/Cvmr46/shfAH9pLVtM1v4xeHZNbvNGge3tXW+u7XZFI+8ri3ljDZPc5NfSsEyzxiRePUVPQUj+SX4C+DdO8Af8FL9N8L6DZPYaD4e8d6lZWYcyOkVpa3M8UQMrkk4RQNzEk9Sa/VX/gqT+1r8aP2cZ/hqnwR8TQ6QPEC6wb/AP0W0vfM+ymz8n/j4il2Y81/u4znnOBVn9oD9tH4UftD/wDCdfsPeBrLVrfx/wCIbq88MW1xf28MWlrf20xjdpJo55ZRFmJsMISenyivw3/ak/Y1+Kv7I0nhqP4nX2k3h8VC8Np/Zc80+37D5PmeZ5sMOM+cu3Gc85x3Bn9TXwX1qz/aA/ZP8Kn4u3kOqyePfC8MetAOtqbgahbbLkYg8vytwY/6vbjtivy4/bF0vT/+CdGneF9Z/YmX/hEr3xxNdW+tPuOs+fFYCJ7YYv8A7SIthmk5QKTnnOBX5+Wv/BNz493fwBb9pCHU9AXwuNAk8R+Sbq5+2/Y47c3BXy/s3l+btHA8zGf4u9db/wAE4P2wfhd+yTrXjrUPibZareReJbewithpcEM5VrZ5i/mebNDgYkGMZ79KAP6B/wBiD4teLvi/+y/4H8f/ABP1WO98VawL/wC1yGOK2ZzDf3EMX7mJUVf3SKOFGevU5r4//wCC0lvcXP7M3hJLaJpWHi+0OFBJx/Z9/wClfO0n7KXxI/bL/aQ0T9u74U3emWXw98QazpGpW9rq00tvqoh0N4LK5EkMMM8IYyWchQCYgqVJIJIH68ftNftO/D79lPwRp/j/AOJVrqN3pup6jHpkS6ZFFPKJ5IZZgWEssICbYW5yTnHFAH5RfsJ/sQ/st/Ff9l3Q/iX8UfDRu/Fs02peZM+pXlsf9GuZEh/cxTxoMKg/h575r4Km/wCCon7d8C+ZP42WJOmW0XTQP1ta8v8A2yfjp4O/aN/ae1L4r+BLa8ttG1NdNiij1COOG4DW1vFC+5Y3lUDcpx8549K/dP8A4LI/8mj2f/Yzad/6IuaAPx9h/wCCon7d9wvmW/jZJkBxldF00jP4Wtf1n2l0o0y3u7yQJvjjZmYgDLAfh1r8o/8AgjD/AMmo63/2Nl//AOkdlXnHxl/a8+GP/BQjwRqv7IHwPs9U07xr4ueJrOfXYIrbTlGlTLfzebLBNcyjMVu4XERy+AcAkgA+/wD45fsj/sxftG+J7Lxj8X9FXWtVsLNLGGVdSurULbpJJKF2280an5pWOSM89elfFX7Rn7L37PH7HXwZ8SftI/s46QPD3xG8GLbvpN82oXOoCFry5ispj9mu5poXzBPIvzRnGcjBAI/P/wD4cw/tXf8AQb8Jf+B95/8AIVfCPgn9nLx54+/aDf8AZo0W5sI/FSalqOlmaeWRLLz9MExmPmCJpNh8htp8vJ4yB2AP2D/YptYf+Cltv4uvP2yh/wAJxP8AD1rBNFMJ/sr7MmqCc3QI077MJfMNtF/rN23bxjJz+TfxWttR/Z4/aq8W3Pwmt5dGj+H/AIqvv7GdkNyLdLC6cQZNwJBJtCjl92e+a/oc/wCCbv7HHxU/ZHsvH9v8Tr7SrxvFD6Y1p/ZdxNOFFmLgSeZ5sMOM+cuMZzz078p+0D+3B8H/AIvXfj39iTwvY6xB4+8SzX/g62uLq3hj0sajI7WoeSZJ5JRBv5LCEtjnZnigD8A/jl+1F8ff2oYtHh+Lmt/8JCnhw3DWYhsba2MRu/LEufs0Ued3lL97OMcd66PQ/wBtn9pnwj8HpfgBpPidbXwW+n3eltp7adZM32S+Ennx+c8Jm+YStzvyM8EYFfvj/wAE3f2LPiz+yPe/EC4+J19pF4vidNMW1/su4mnKmzNyZPM82CHGfOXGM556d/xi/bk8Har8Q/8Agof4x8AaI8UepeJte0nTLVp2KxCe8trWGMuyqxChnGSASB2NAHS/8Ewf2ePhJ+0h8W/FXhX4waK2t6Zpuhm9giW5ntNk32qGPdut3jY/KxGCcV+0Gs/8E1P2HvDen3mq2Pg422oadC9xCzazqBKyxKZIzsa6weQDgjBryT/gnX+wX8Z/2T/id4l8Z/EnUNFvbHV9HOnwpplzPNIJftMUuXEtvCAuEPIJOe1eKftxf8E3Pj18dP2g/Gvxs8H6noFvoOpQ2UkUV7dXEd0BZWEMEm5Y7aRRlom2/PyMZx2APyg+N37an7Rv7RXhK28D/F3xOms6NaXqahHCthZ2pFzFHJErb7eGNjhJXGCcc9OBU3wV/bb/AGkv2evB7+A/hN4pj0fRJLqS9MDafZXJ8+VVVm3zwu3IReM44rmP2af2afH37VXjy8+HXw4utPtNTsdOl1OR9SllhhMEUsMJAaKKY7t0y4G3GM81W/aO/Zy8d/su/EGP4Z/EW50+61WWyh1APpssk0HlTtIqjdLFE27MZyNuOnNAH6+f8FDv2Hf2aPgV+zRc/En4YeFpdK8QLqOnwi4bULy4Hl3DHzB5c00kfP047VyH/BMj9jD9nP8AaO+BviDxp8XfDMmtavYeIrjT4Zlv7u0C20dpaShNlvMin5pWOSM84zgCvuX/AIK3f8mWXf8A2FtJ/wDQjXAf8EU/+TY/Fv8A2OF3/wCm+woA/W7StMsPD2j2Wjaenk2WnQRW8KFi22OJQiDJyTgAcnmrM1pHMN8XB9uhq4+3ad+Me9Vvs7wndbnA/unpQQ1fcqR3Mts3l3IJHY/561qI6SDchyKreakn7qddpPZuh+hqI2bxNvtX2ex6UAro0aYyq67WGQaqrdlTsuV8s+vargIIyORQVe4xVKDGcj3p+T7UtFAz/9D94Fe5sThxuT9PwrQD294m08+3cVOWwMSDj17VUksY2PmQHyz2x0oItYh8q6tTmA+ZH6f5/pU0V9DKNko2H36UizXMHFyu4f3lqQx2l2MjDH1HWgXoI1qM+ZbN5Z9uho+0vFxcpgf3hyKiFtcW5zbSZH901Kt2PuXKmM+/Q0APCRyfvITg+q/1FP3yx/6xdw9V/wAKhNpG37yBvLJ7r0oElxDxMnmD1X/CgBxit5xvThvVeDSgXUfAIlHvwaQG3uDlT835H/GnbbhfuSBvZh/UUGhIjluGUqff/wCtU1IM96a8iRruc4oFtuPoqrFM8zZVcR+p71OrhjheR61TVgUk9UPoqJZFdiq846ntSmRN2wcn0FFgvEcwDDBGRUaQxR8xrj6U95EjGXOKZFKJRuAIHvRZ2uK6vYlIB60tFFSUFFQSzxwj5zz6U0T4i82QYB6Cq5WRzLYkllSJdz9KRpgkfmOMe3eqkWXJup+AOgqFd15NluEH8q0UF1MHVfTrsWoZJJCZnO1B2p6SNITIfljHTPf3phCynb92GP8AXH9BUJZruTy14iFVa4czVuv9fkWEnaWTEY+UdSa5XxN4I8D+MpIV8WaDY61JCCsbXVtHM8YbqFZ1JUHvg10zyEn7Na8Y6n0oylsPKhG+Q/55ot2Fzd/69DgtB+D3wr8M30epaF4T0yzvIjuSZLaPzUPqjkFl/A16FPBDdQyW1zGssUqlHRwGVlbggg8EEdRUeFgHmztvkPT/AOtUkbyAGWY4B6LWbTetzWMktLGJoXhLwt4XtJdP8MaPZ6RbTt5jxWVvHboz4xuKxhQTgAZqS+0DTNXsJ9H1y0g1PTrkDzbe5iSWJ9pBG5HBU4IB57gGt4HIBIxT6m8jW0TlrXw5pHh6wh0/w7YwabY2+dlvaxLDFHkliVSMADJJJwOpzVTU/CXg3xeoPifQrHVpVXbm7topzj2Mimu0pmxN2/Az60XJ5TzxvBPhGz0b/hFH0HT30InP2E2sX2Q/P5mfJ2+Xnf8AN068109louj6fpdvpmhWkOn2duuIYbeNYooxnOFRQABn0HWtqWJJk2SDioYLbyCQjEqexpXuJRscTrXg3wb4yVLLxlodlq/kZERureOUx+oQuCR+FZ2ifBb4TeHrxNQ0fwjpltcxHckotYy6N6qzAkH3GK9EurTzyJIzskWrMW8IBLjd7VXM+jBRXVEMMXkOyr9xuR7H0rntV0vTL9J9M1izhvrC6GJYJ41likQ9mVgQRnsR2rrKz7+HzIvMHVP5VKY5LQxbXw/onh3TotP8OWFvpdlCTsgtYkgiTeckhYwAMk5PHJNM8QeF/DXjXTIrXxLpVpq0MLebHHeQR3CJIARkCQEA4JGfQ1t2UgntzC/bj8KhtHMEz20nc/r/APXq7smy+8xdC8H+EtCtCPDeiWWlMy7T9ktorfOOx8tRXQadNuQwt1Tp9Kk/1Fzj+Cb/ANC/+vVO6Vra5E8fQ8/40tx2tqcl4i+Efww8W3b6j4k8K6bf3kn3p5baPzm+sgAY/iav+GPhv4B8FSNP4S8PWOkSuMNLbW8ccjL6FwNxHtmu1R1kUOvQ0yZS8ZUcHt9aXM9rj5VukLLDHMu2QZFcP4j+HHgfxVfR6nr3hzTNTu41CCa7s4Z5QinKgNIpOBk4Gcc12VpKZYfm+8vBp0NwkxZRlWTqDQm1sDSe5hQaPpmj20elaDYQ2FqDny4IxFHnp0QAV0MMSwxiNe1S0UXKSsVbi3gu4JLS7jWWGVSjo4DKysMEEHggjqK5rw/4X8M+FZJbHwvpFno1vJ+8aOyt47dHfgbmEagE44ye1daRnHPSohCBOZ88kYxRcTXUrg/urk+7fyrk5PBnhHUb5PE2o6HY3esWw/c3sttFJcx7OV2SlS64JJGDxmuxWDCSpn/WEn6ZpUtkSIw5JBp37C5bnPa5oei+INBOleINPt9Ss5dhaC6iSeIkHIJSQEHB5HFT2umWGk6La6Xo9pFZ2kCKkUEEYjjjTHREQAAewFb3lR7BGVyB2NPAAGBwBSuHKUbu1W6RYpFVozw4bkFT1GO+axtC8HeFPCsbw+FtHs9Gikbe8dlbxW6O+MZYRqATjjJrqaKL9CrLcztR03TtYsptN1a0hvbO6XZNDPGskciHsysCCPYiuWvfh78PL7RrXwxf+HNMl0u03/Z7R7SHyYixy3lR7dqkk5O0Dmu6pjosg2uMihNg1c4Pw98OPBHgrzJfBfh+w0iZ12PJb28ccrr1wXA3EexNdEl3c27bJfn9j1rQ8uaH/VHzI/7p6j6GnEQXa7XHI7Hgine+5HL2POda+Ffwp8YXcl/r/hTTLy9mOZJpbaPz3PqZANzfia3/AA14H8KeCUkh8I6JZaXHNjzBa28cDPjpkoBux71qz2EsXzR/OP1ohv5Y+JPnH60Xb0uQrJ6ok1TSNJ8QWE+m6vaxXlrcLslhmjEiOp7Mjggj2IrF0bwzpXg60Nh4Y0610yy3GQw2kCQRbj1JjjAGTjk11Mc0Fzyh+YfgRU2XXryP1pX6GjinqVIbuG5HlyDBPY9DXHeKfhx4O8YCM+I9EstX8oEJ9rgjlZAeu1nBI/AiuzltYJ/m6H1H9aiUXltwf3yfrQnbYTV9JHFaZ4H+H+kaTdeHbXwxptnp18Atxbx2cQinA5Hmpsw+P9rNdVp2h6NpdhBp2hWkOnWluNsUVqixRRjrhUQBRyewrREltdDY3X0PBqE2TId9tIUPoabfcVjkvE/gDwb4u2Hxl4estc8oYSWe3jkkQegJGQPoaj8MfDf4a+FZRdeE/DthpdyAV863t445sHqPMA3Y/HFdoLiaPi5j4/vDkU54ba5HmIefVetHM7WHZXuSfv0/6aD8j/gf0rjPEvw9+HnjiQSeLPD1hqtwibRJc28bzKvoHI3AfQ4rrv8AS4f+my/kacJbef5JRtPo3BpJ21Q3Z6M4jwz8MvA3ge4a88HeH9P0u4dDE0sNtHHMYyQShlA3kEgHBOOBWbr3wd+FvivVJta8TeE7G91C5KmWeSBXkkIAUZYcnAAHPavS/KkXmJzj0bkf41Mnmbf3mM+1Pme9w5VtY4vwz8N/AHg2Qz+E/DthpMzjBltreOOQj0MgG4j8a6DWND0bxBZNpuv6fb6lZuQTDdRJNGSOhKOCOPpWuSFGTwKqfaTI+yAbvUnpRq9QbUdDzAfAf4LC5+2DwRo/men2KLZ/3727f0r0yxsLHTLOLT9Lt4rS1gXZHFCgjjRR2VVwAPpVwvg7Ryaa0iqQnUnsKG29wSS2OB174UfDHxPcy33iDwppl/dTHMk8tnE0zH1Mm3cfzqz4a+Gnw+8HT/avCvhzTtKuNpXzre2jjlKnqDIBvI/Gu2eRY/vHr0FOLADc3A96Lu1gtG9yL7PDu3hQD6jiue1Twd4R1nV7TXtX0Oxv9TsCht7ue2iluIDG3mJ5cjqWXa3zDBGDyOa6BLhJX2xgkDv2qxS1QKz2EAA6UtFMd0jG5zgVJZzOl+DvCOh6rd67o2h2On6lfFjcXVvbRRTzmRt7eZIqhmy3JyTk89a3rmC2uLeS3vI1lhkUq6uoZWU9QQeCD6U6KfzcsBhB3NVgxu5do4iT9a15XfUyc1b3ep5iPgb8F57ptRbwRpG/JOTZxbD6/u8bf0r0TT7W0sreHTNFt4rKythsSKGMRxonoqgAAewqaeUzOIIunT6//Wqxs2AW8XU8sfStH5nOnd2j/wAOVdQsrLWraXS7+1ivLOUbZo50WSNx/dKsCD+IrzRvgh8F1vfPg8DaO0/cfYovLH/ANu39K9Slk24trfr0NKStoqxxjMj0LTYbd73/AK9BLe3stKtIrKzhSCCFQscMKhEVR0CqMAAVDqmk6Tr+nTaVrtlDqFjcgCS3uY1lhfBBAaNwQcEA8jrVgKkA864OZD/nil2NL++ueEHIX/Got1Ned7P+vUq6No2keHdOh0fQLGDTbC33eXb20SQRJuYu22OMBRliScDkkmtjHaqcckkz7x8sQ/WrCOHG4DjsfWsmn1NIyT2KYtGhm82A8f3T6U+7txOmR99en+FXaKRVomTZXBU/ZpeD2z/Koru3MD+fDwM9uxrYdEb7wB+tKQGGDyDVXJ5dLFSOSO9gIYfUehqjEz2M3lycof8AOaurZLE/mQsUPp1FTXECTptbg9j6VINNk4OeRVVots4nTvww9vWi1jmhTy5SCB0xVugrcyNRjKuk69+Px7VZkAu7TI69fxFWZ4hNGYz3rKsJDHIYH7/zFBGz9SexcSwNC/8ADx+Bp1oCnmWsnOzp7g1WlzaXnmj7j/5NXLj5Sl0nO3rjupoEira7oLtrY9D/APrr8nv+CkP7cPxn/ZR8ceDvD3wxh0qW013T57q4/tC2knfzI5vLGwpLHgY9jX63vEHminX+HOfoRSXFlaXRDXMEcpXoXUNj86DRKx+Yn7O37DPwY8Qap4D/AGyb+fVh498Tw2njC6jjuo108alq8Iu7gRw+SWEPmTPtUykgYBY9a+P/APguV/x9fBj/AHPEP89Pr+gFESJAiAKijAA4AAqGe0tLoj7TCk23pvUNjP1oGfnHof8Ayiek/wCyU3X/AKapK/Gb/gmz+yJ8Kf2sda8d2HxQl1KGLw3b6fLa/wBnXEduSbl5g/mb4pM8RjGMd6/cfx3/AMFIP2RPhr4t1r4c+LfElxa6r4fuZrC8gTS7uWNJoSUdAyRFWAIxkZBr4H/a21Sw/wCCkWn+GtF/Yub+373wLLdXGsiZTo/lxXyxpbEG68kS5aGThc7cc4zQB+y/wR+D3hT4B/DDRfhL4Ha5k0PQBcC3N5IJZz9onkuX3uqoD88rY+UcYrj/ANpP9mf4dftUeCbDwF8TZL6PTdO1GPU4jYTrBL58cUsIyzxyArsmbjHXHNfyA+Mvg/8AFzwB8ZD8BfFEbW/jNbyysfsq3aSR/aNQWJ4B5yuY8MJkyd2Bnnoa/cv/AIJq/saftJfs7fG7X/Gfxj0qOw0e+8PXFhC6ahBdk3Ml3aSqNkUjkfJE3OMdu9AH5G/tn/A7wZ+zt+1Bqnwp8AyXcmi6aumSxG9lWWfdcwRSvl1RAfmY4+XpX7n/APBZH/k0ez/7GbTv/RFzX6j6rpVrfWtyGtopZpYmUFlBOSuBya/Dv/gnb+xD+0p8B/j9ceN/jLokNtoMui3dmrf2hbXn+kSywsg8uORz0RuccUAfmJ+zj+398df2XPAdz8O/hrBo8ulXd/LqTm/tJJ5fPljjibDJNGNuIlwMdc814D8E/jf4z+AfxT074weBktJNd0r7T5QvIjLb/wClwvDJuRWQn5ZDj5uDiv6zPjr+2R+zB+zl4xt/AfxY1E6ZrNzZx6hHFFps9ypt5ZHjVt8UTLktE/Gc8e9fWkOn6PPDHNHaQlZFDD92vQ8jtQB/Lx/w+Q/a3/58/DP/AILpv/kqv1q/Zl/Yl+Dv/CQ+Cf2y/O1T/hPvEtmniW6j+0x/2eL/AF60Ml0I4fK3iIG4fy1MhIGMk45+a/8AgpZ+xD8ff2ivjN4d8X/Brw/a3+kafoEVjO73ltaFblLu4lI2SupPySLyBjt2r8tfip+wR+1t8Efh7qvxL8faLHp/h3QlhNzLFqttMYxLKkEeI4pSx+d1HA4+lAH7b/8ABSn9s34vfsmXnw+g+FsGmSr4nj1Rrv8AtG3kuMGzNsI/L2SxY/1zZznPFeNzfsufDSw+CA/4KMW8uof8LVfRU+IJiM6f2T/bM0Iv2H2by/M8jzmOE87O3jd3r+cue6urnH2iZpdvTcScfnX9EvhD9r/4E/E/9jPQ/wBkbwbrM938TNf8HWnhWzsGs7iKJ9Vks1thEbmRRCq+bxvLbe+cUAfF/wDw+Q/a3/58/DP/AILpv/kqv0e/Zs/ZO+F/7UVj4G/bo+JM2oR/EbXL2DXLiPT7hINN+16VdeVAEgeORwmLZNw80knPIzx+DX7QH7Jnxu/Zig0Ob4xaPDpK+IjcLZeTeQXXmG1EZlz5LNtx5q9eueOlZf7LF9eJ+0t8IrdLiQRf8JfoA2BjjB1CHIx0oA/pm/4KN/tQ/Ev9lX4XeGPGPwyi0+W+1bWRYTDUIHnj8n7NLL8oWSMg7kHOTxX4133/AAWD/ax1GxuLC5tPDXk3MbRPjT5gdrjBx/pPoa/Xr/gpv+zl8V/2lPhN4W8J/CPTItV1LS9bF7OktzDbBIfs00WQ8zKD8zgYHNfO/wAEv2j/AIHfsY/AGz/ZZ/aJvTo3xL8MW+oJf2cNlLfxxtqU019a4uYEkibdBcRE4Y7c4OCDQB8Xf8EW/wDk6rxF/wBifff+l9hWP/wWS/5O3s/+xZ07/wBH3VflRBcXFu++3kaJiMZUkHH4V9dfBT9iP9pT9pHwe/xB+GWiQ6vo8d1JYmafULaB/OhVWZdk0gbAEg5xjmgD98/+Ct3/ACZZd/8AYW0n/wBCNfhN+zb+3r8cP2V/BN/4C+GUGkS6ZqWoyanIdQtZJ5fPkiihbDJNGAu2FOMdc81/Rn/wUE+B/wARvj7+zTcfDf4ZWEeo69JqGnziGWeK3Xy4GJkPmSlU49M818M/smfEXwB/wTj+Hup/Bj9r118OeL9e1STxBZwW9u2qo2nTwQ2kchmtFlRSZrWYbCcjGcYIoA/aPwPq114m8D+H9d1RV+0arp9pdTBBhPMniWRsDJwMnjmuhENxB/qH8xf7rf0NU9K1Gw8RaFZaxpUhay1GCK4gbBTMcqh4zg4I4I4q2Ptlvwf3y/rQSx4uYZP3cw2H0apPLdf9S3HoeR/jTBLb3I8txz/dbg0z7NNDzbScf3W6UEkpkXG24XZn15H5/wCNN+zKnzW7mPPpyPypBdFfluIzH79RTxDGRugbZ/u9Py6UGgge6X70Yf3Vsfoad5tx/wA8P/HhQBcA9Vb3Iwad+/8ARf1oA//R/eaHUf4Zx+Iq+pjkG6JvypktrDN95cH1FUTYTRHfbt/Q0Ee8Xy0iffXI9V/w/wD10zy7W4+ZcZ9RwarLeyxHZcxn61ZAtrr5lwSO44IoK3F2XEX3HDj0br+dJ9pT7k6mPPr0/OjZcxcxt5g9G6/nTkk8z5JIyp9CMj86BjfIX78DbM+nIP4UvmXEfEke8eq/4UfZVU7oiYz7dPyqwoYKAxyfWgCLZFONzJ+YwamUBV2jt+NDMqjcxwKhlnWOLzPXpVJXJbS1YlxcrAMDlz0FU4oWmPnznj/P6U23iMzGefoPXvVkN9oJLcQr+tb/AA6I5L87vL5IkB8wZ+7Ev4Z/+tUYZrj5Y/liHGfWoC73kvlpxGKdNJ0tIPocf5/OhR6FOd9en5j/ADDI3k23AHVqSSZLZfLj5buaWRltIfLT75/zmorW33HzZOnYetPS13sQ3K/Kt/yHwQNKfNuPm9Aa0qKTPOKwlJs6oQUVoLVcS73fsid/eonk2xPL/E5wv9P8ahmP2eBIR1PWqUSJVLakaZu7jc33B/KnyE3Nz5S/dT/JpY/3FoX/AIn6UQ/6PbNKfvP0/pW3mvQ5kuj9WMupDI4t4ug4/GrBQRKLeL7z9T7dzUNqgjQ3EnbpUu8xRNM/+sk6f0qX/Kio/wA76/kR3L9LSEfWnSE26Lbw/wCsamWy7Fe5l/CnQ87ryT8P8/pVPTTt+YLXXv8AghWZbOIRrzI1OQC2j82TmRv84qOFd7G7l6DpUqkHN1L0/hHtUvsNd/u/zBVEf7+4OXPQensKkGf9Y4yx+6vpUcStI32iX/gIp884gGTzIegqHq7GislzPYGCR/vZzk9h2H0p0Uskp3bdsfbPU1Vjh63F0fwNP/fXXP8Aq4v1NU0hKT/r9S8CD0PSopWdRmMBsdRUJkgtRtHJ9uv41YjcyIHI257GsrW1NlK/u9SCG7WR9jDaasM6oQGOM8Cq9xb+Z+8j4cfrSqRdQlX4ccH2NU0nqiE5L3XuWiQOtLVaMtJFtlBBHB/xqULlNsnzetZtGydySkIBGDUMUCQk7Cee1T035Ar9TEEbWVyHP+rPGfan6hEVZJ1+h/pWq6LIpRxkGomiDwmFjnIxn+VSKxCCLu2DD7w/Qiji9tsN8rfyIqjZytBOYZOAePxq3Ifstz5v/LOXg+xoEmQWMxjc20nHp7H0rYrJv4CD9oT8f8at2lwJ4+fvDrQC00HCHy5jJH0f7w9/WqVx/o12s4+6/X+ta1VrmHzoSnfqPrQU0Vb5XUCeIkY4OP0qSxuDMpWQ5YfypllKJomgk6px+FUPns7n2H6igm/U0jeCOYxSjHvVuR/LQvgnHpVC/iEsQmTnb/Ko7G66QSH/AHT/AEoC/Q0IZknXcn4ihZVMhjPysOme49qz54ntJPtMH3T1FWgYr2LI4I/MGgq427luYvmjUFPXuKWC7juF2Nw3p6/Smx3TRv5F1wezdjUdxYgnzIOD6f4UE+gOk9od8Pzxd1ParMF3FPwDhvQ1Ut70qfKueCO/+NSXFksn72Dg9cdjQHoaVFYkd5cQHy5hux69a0obmGb7h59D1oKTLNQSQpJyw5XoR1FT0UDIB5qcE7x69D/hTJrSGflhg+oq1RQFjBksJ4juj+bHcdafFfyxnZMNw/WtuonhilGJFBoIt2I45YbgZQ8/kaUmZP8ApoPyP+B/SqMmnAHdA+Pr/jSC4vLfiddy+v8A9egq/cuE2052SAb/AEPBpPJlj/1EnHo3I/xpFntrobWxn0PWl8iWPmB/+AtyKBh9paP/AF8ZUeo5FHkwTfvIzg+q8UqzyA7ZYmU+o5H6UptYWO5RsPqvFACf6VH1xKPyP+FPVo5xteM8dmFPRXQEO2/04qWgCNI0jGE4FJLKkS7npRIhUsDwO9Zfz3cvoo/QVpGN9zCc7K0dxw829fn5UFXFwP3UHAHU/wCe9Rlst9mt+APvH0qOaXbttrf6cVq9dDFWjq/68iQyfN5Fv17mkaRYP3UI3ynr/wDXprMtnFsTlzSwotvGbiX7xpW6lXd7f0hSVtl8yU7pW/z+VQIs14+5ztQf54pkcb3cpd+nf/CtdVVFCqMAU5Pl9SYx9p6CIqou1RgCn0mcVAT+8LE/JGP1/wD1Vhudl7A8jeYIk6nk+wqldOZphAnb+dSq5SKS5bq/T+lR2a/enft3/nW8VbU45ycrR7/kLctsVbWL+LrRMwt4RAn3j1pLceZK9y/Qf5/SmRKbm4MjcoOf8BV2tv0IvfVddF6EsCC3i81hlm4Ap0jm3iyeZZOp/wA+lPVhJI07f6uPgf1NVYgbqcyN90f5AqN9WW9Eox/rzJYgLWEyv95ulLEBCpuZuXbpR/x9XH/TOOmtm7uNo/1aUepO3w/L/MdCDITdT9B0pwBuD5svEQ6D19zTiBO+wf6tOvuabk3T4HES/rS8y7dP6f8AwCQESjceIh+v/wBalYbxukO2Mdv8f8Ke7oieY/CjoKpKsl42+TiMVKXUuTtpuywk5kIECfIO54FWsjO3PNUjI0n7q2GEHVv8KcEgtvnc7m9T1ocSoyZabdj5MZ96qfbNr7JV21NDP52cKQB3pZoUmXDdexpKydpDd5LmgyRnVF3t0FKCCN2eOtVLdmXNvN1HT3FOhDROYSDs6qf6VLjYpSvYtA55FLUSIUyAfl7e1MFvGJfNXIPt0pWQ7vsWKyL23dZPtMX1PtjvWvRUlNXM64UXVqJU6jn/ABFJYSiWJoW5x/I1cjjWLIXoecelY8gazuty9Oo+npQS9NTRtnKFrV+sfT3FflP/AMFEP27/AIsfsjeM/CXhz4eaNouqW+v2E93O2qw3Mro8cvlgRmC5gAGOuQTnvX6uGNZJI517fqCK+Q/2lPjR+xz8MNc0ax/abbSBql7bySWH9paJLqj/AGdXw+147WfYN3YkZ64oLR+J3/D6v9p3/oU/B/8A4Cah/wDJ9H/D6v8Aad/6FPwf/wCAmof/ACfX6P8A/DXP/BJv+/4W/wDCRuf/AJXUf8Nc/wDBJv8Av+Fv/CRuf/ldQB/M38UfiHrHxY+IviT4m+IIILbU/E99PqFxFaqywJLcMXYRiRpGCgnjLE+9e8/sq/tj/En9kO/8Ral8OdK0jU5PE8VtFcDVYriUItq0jJ5fkTwYJ8w5zntjFfvX/wANc/8ABJv+/wCFv/CRuf8A5XUf8Nc/8Em/7/hb/wAJG5/+V1AH88PxG/aP8a/E79oY/tKa3Yafb+JDf6bqP2a3jlWx83S44Y4htaV5drCBd/7zJJOCOMfvd/wT5/4KDfGH9rH4xa38PfiFomhaZp+m6FPqkcmlw3UcxmjuraEKzTXUy7NszEgKDkDnqD9UXXw2/Zs+PX7OuveMPgV4H8OavD4l0XVYtFu4dFt7KSS7WOa2TZ9ohheJhOpAZtuCM5xzX5RfsS/DTxr/AME9/ihq/wAYf2wdNPw+8Ia5o0ug2d80sWpCXUZ7i3uo4fK0x7qVcw2szb2QJ8uC2SAQD+jyviP9vX9pLxt+yv8AA+3+JvgKw0/UtTl1e009o9Tjlkg8qaOZ2O2GWFtwMYx82OvFfl1+0J4W/a3/AGqfjPe/G/8AY+1TXNb+FGqrZxWN1Y63/ZFu8lnEkN2FtLq4tZlxMjgkwjceRkHNfop/wUt+CnxP+Pn7O1t4G+EuiHXtcj1yyvGthcQW/wC4iinV233MkUfBdeN2eelAH80P7Tv7TXjj9qz4g2nxK8f6fp2mala6dFpixaZHNHAYoJZZQSJpZm3kzHPzYwBxX3fb/wDBaT9pm2t4rZPCfhApEqqM2moZwBj/AJ/6+d/+HYf7c/8A0TGT/wAG2lf/ACZX6aftB+Lf2P8A9pv4M6r8Bv2StK0LWfi9rH2P+zrOx0P+yrl/sU8VzebLy6traFNtvFKTmYbgCoySAQD5Z/4fV/tO/wDQp+D/APwE1D/5PruPht+3D8U/+CgPjXTP2Qvi/pGjaJ4R+IbSRX15oUVzDqMQsIm1CPyJLq4uoQTLbqG3Qt8pIGDgj45/4dh/tz/9Exk/8G2lf/Jlf02fs+fATwN8O/hp8P31HwNo2keM9F0LToLy6isbT7ZHepaJFc/6TEpZmLbgzhzuyeSDQB8I/wDDlP8AZj/6G3xh/wCBen//ACDXd/C//gkx+z58JviN4b+Jnh7xL4oudT8MX0GoW8V1c2LQPLbuHUSCOzjYqSOcMD7ivm7/AILN/EP4geBNR+Eq+CPE2p+Hhew62bgadez2nneW1ls8zyWXdt3Hbnpk4616D4Y/bT+E3xF/ZA0b4C+CPiDc6h8b9d8JW2iWduI9QivJdfktFiCfb5YkhEpm485pwued+OaAPtz9qz9jD4aftfweGbb4i6tq+mL4Va8a2/sqa3iMhvBEJPM+0QT5x5K4xjqc54x8NeJ/+CXfwJ/Z08N6t+0H4M8Q+JL/AF/4YWlx4o0631C4s5LOa80WM31vHcrFaRSNC0kIEgSRGKk4dTg16N/wTS+EP7W/wtvfiE/7Tw1URalFpY0r+0tYi1UZhN15/liO4uPL4aPOdu7jrjj8g/8Agop8V/ilp/7WvxS8H2PjHWbbQDPBbnT4tQuUs/IlsYPMj8gOI9r7juXGDk560Aeyf8Pq/wBp3/oU/B//AICah/8AJ9fnD8ffjb4n/aK+K2t/GDxlZ2djrGui1E0NgkiW6fZLaO2TYJXlcZSIE5c85xgcV+iH/BHnwT4M8c/HDxpp/jXQbDX7W38OmWKHUbWK7jST7XANyrKrAHBIyOcGv1w+Ivxc/wCCcHwm+Id38K/iDpfhfSvFVi1vHNZnws85U3UaSwjzYbJ4jujkU8McZ5wcigD+Rev6nP8Agjd/yaPef9jNqP8A6Itq8q/4K8/Cz4Y+Cf2ZtA1XwZ4R0fQL2TxXZQNPp+n21rKYjY3pKF4o1JUlQSM4yB6V/P54Z+K/xS8F6a2j+D/GOs6DYtIZTb6fqFzbRGRgAz+XFIq5IAycZ4FAH93FfzFf8FrP+TnPCX/Yn2n/AKcL+v1M/wCCpHirxR4P/ZCu9c8J6xeaLqI1TS1F1ZXEltPtZjuHmRFWwe4zzX56fsHftSfsqaT8J9Zt/wBsrXrTXvGLa3M1lP4h0u6167XTPs1uI0S5NvdbYhMJiIt4wxZsfNkgH74/CpWb4VeDgrbT/Y2nc/8AbtHXb77mL76iQeq9fyrO0W40rUdB0+98PFV0y5t4pbQxp5a+Q6AxbUIG0bcYGBgcYFaPmXMX+sXzR6r1/KgTDfa3PyNjPoeDS+VNH/qpMj0bn9aeUhuFy6fmMGkSBo2+SQ7fQ80DEEzfdliK59OR+lSCCIHcq7T7cfyqamF1DBCeT2oF6j6Kz7m6aNvLi5I61W+2XFa8jZk6sU7H/9L9/KKiEsTNtVwT6ZqWgLhSAAdKWigAoquZ18zylBZu+O31p0s0cK5kOPaqtInmW5NRVBZLmf8A1a+WnqetTeYsQ2u5Z/Tv+Qo5RKaZK8SSY3jOKhuLbzyDuxipFaVjkgKPfrTmkRSFYjJ7U02thNRa1Kc6uzR26AiPuahu5Qu22i6DrWtVL7Iv2gTA8dSD61cZdzOcH06kTEWcAUf6xqbbqIYjcSfh/n3pssEtxcbipVc4z7VbntzMFQNtUdqq/RkKLvdLbYowo91MXk6Dr/hWzUUMSwpsWpaynK5rThyrXcQkAZPaqcTb4nl7yHA/kKtsoYFW6GkCqoCgcDpSTsW02yq+HuI4h0jG7/CqM7Ga62D12itcIocsByetQpaQxuJFHIrSM7GM6bloVrv55Y7ZKS7JeWO2jq59nQTefnmo0tttw07HOelCkhODd/P8hrKHkjt1+7Hyf6VWnY3FyIl6Dj/GrapJGssuMyN0/pVe1UwJJNKCuPWqTtqTJX0YXT5ZbSPtipJUDGO1ToOT9Khs13yPcP2/nUyt5cT3TD5pOn9KHpohLW8n1/IewEkggX/Vp97+gpn/AB9zf9Mo/wBTTJSYLcRDmSTr+PWpvL2qtsvflj7d/wA6nYvd2f8AXZDzKoQzN90fd96rxR4zdXH1AqYqsr724ii6ehI7/hSD96fPl+VF5UH+ZoTtsNq71Ex5n76f5Yx0U/1qpLdvM3lwjAPp1NNmkkupAkY47D+pq9BAluNq8ue9PbVmavLSOxHBarFh5OX7Cp2OP3kzbQOg/wA9abNcJB8o+aQ0yO2eRvNujuPZewpNt6s0SS92KLEM3nAlVIA6E96kCKCWA5NPorP0N0u4U0kAZPFUJr9VO2IbvftUSwXFwd9wSo9P/rVah1Zk6uto6lp72FTtXLH2p8ckz8mPYvueagMlra/Kgy3t1/OkWS6n+6PLX1p2FzO+r+40aKpqsVud0khLH1P9Kso24ZwR9ayaN077mbfWxP76MZPf/Gpoit5bbX69D9fWr9VxAqyeZHxnqOxpBYr2shYNaz/fTj6iqEiPYz7k6dvcelaVzbs5E0XEi/rTgq3MW2ZCPUH19qAsTxSrMgkToakrGCzWEm778Z61rK6yKGXkGgZSmt2jk+02/UdR60XUS3MAkj6ryP8ACtCmBQucd+aBWM7T5tyG3f8Ah6fSqFxAbeUr2PIq3dxGCRbmL15+v/16tOqXtuGXg9vY0E26EdpcrOvlS/fx37iq0sT2UnmxfdP+cGqBDxPg8OK2ra5S5Typfv8AcetFw3H/ALm+h9x+YNU1mnsm8uUb4+x/wpksMtnJ50J+T/PBq7FPDdp5bjnuD/SgsdJFBeJuVuexFUw1zYnaw3x0SWs1q3m2zFh6f561YgvYpx5cmAT+RoAlWS1u12nBPoetU5tNYfNAc+xqSewBO+3O0+lV1u7m3bZMM+x6/nQQ13GLdXVu2yTn2ar0eoQvxJlD+YqRLi1u12Ng+xqvLpqk5ibHsaCzSR1cZQgj2p9QwwpCmxPxPrTZriKEHcefQdaEribtqyxRUMUnmru2lfrStLGh2swB9KqwXW5LRRRUjEwKWioZZkiwG5J6AdaLCbtuTUVGZFVN7/KPeqv2mSY7bZcj+8elUo3Jcki9TGVXXa3INQqTCu6eTNLvlf7iYHq3+FFg5u4SQK0XkqdoqB0e3g2xKWY9SKuM6oMuQKcCCMjvTUmJwT23M12+x24Qf6x6bbKsMRuZPwqzc2onIYHB6VDdxyybYok+UflWid9DCUWne22xDbBriYzSdBzTZZGupxHH07f41eFuVt/JRsE9T/Olt7VYMnOSe9Pn6k+zdlH7yeONY0CL0FSUUVznalbRFQP5lyR2iH6mo5iTCFXrMf5//Wq2saAHA+91oMaFlYjlelacxjyuxmXzhNsC9AM1JIfIsgvd/wCtWZLaGVt7g5pZrdJ2Usfu9qtTWiM3Td2ypJ+4tAndutOC+TbBF/1kvH51PPbedIrE8L2pzRs1wHb7qDj60ubQOR3/AAKd24ijW3T8adIfslsEH32pqRPLeGSRCFHPPt0qNsXN3t/hH8hV+Rk+r+SJlBgteP8AWS9PxqQqYI0t4v8AWP3/AJmnjEs5f+GLj8e/5VGsgCvdv34X6VFzVJL+vvEkz8tnF+J9qsKF/wBUn3V6/wCH+NV4d0cLTHmSU8f0qQxnAt1PXlz/AJ9aH2Gu5CFN5LvPESdPepebg7I+Ih1Pr9KcR5v7iPiNeCR/Kql1cAj7PB06HH8qrV6Ih2irv/hx014sY8q3HTvSRWzP+9nOB79afb2qxASSj5uw/wA96tSypEPMlP0FDdtIhGN/emBUuuP9Wg/A/wD1hRHcRu/lx5IHftVZRLefNJ8kXYetX0RYxtQYFQ9NGbRbeqAqpIJHI6U+iqc95HCdg+ZvSoSb0Ro5KOrLlVpLqGPgnJ9BzVBftV532r+n/wBerCx21qNzfM3v1/Kr5UtzLnb1WxItxNJ/q4sD1Y4q2M45rP8AtM85xbrgepqRYfLIlnlJI98ChoIy7al2ql3B58WB94cipklWQ5TJHr2qWsjbcy7CUjNvJwV6Zr+db/gt3/yVT4a/9ga7/wDSkV/RwYo2kEhHzL3r+cf/AILd/wDJVPhr/wBga7/9KRQNG98J/wDgjn4c+JPwt8HfEa4+KN3YP4p0bT9Va2XSo5FhN9bRzmMMbkbgu/GcDOOleg/8OO/C3/RXL3/wTx//ACVX19408Ra/4R/4Jb6b4m8Lalc6Pq+n/DrQ5Le8s5nguIJPsVsN0csZDKfcGv5q/wDhrr9qr/osfjD/AMHt/wD/AB6gD9lv+HHfhb/orl7/AOCeP/5Kr4C/bu/YQ0r9jfSvCGpab4wn8UHxRPeQss1mtr5P2VYmBBEsm7d5vtjFc5+zB+0/+0l4i/aS+FWg698VfFOpabqXinRba6tbnWr2aCeCa9iSSOSN5SrKykggggg4NfpB/wAFxP8AkVvhH/1+6x/6LtaAPub/AIJg/wDJjPwy/wBzVv8A07Xld9+2P+ypYftefDbSvh1qPiKXwzHpmrxaqLiK2W6ZzFbzweXsZ48A+dnOe2Mc189/sQp4hk/4Jg6OnhL7T/bjaD4oGn/ZC4uftf22/wDJ8kr8wk8zGzHOcYr8Z/7D/wCCsX/PT4rf+Beq/wDxygD+kv8AZb+AFp+zJ8GtJ+D1jrEmvw6VNdzLeSwi3Z/tUzTEeWGkA278dea439tT9pu9/ZN+EEHxS0/w/H4kll1S2077NLcG2UC4jlffvEch48vGMd6/mE8SfHr9tn4c+M18G/EL4jeOdB1m3eAzWV9rGoxSokuHTdG8ucMpBHqDX9gvjTwB4G+JOkL4d+IPh7T/ABNpaypOLTU7SK8gEqAhZPLmVl3AEgHGRk0AfNf7Ev7UV/8AtbfCO++J2oeHovDUtnrFxpYto7hrlSIIYJfM3lIzk+djGO3Xmv5XP2dvjtd/s1/H7TfjHZ6QmvTaHJfoLOWc26yfaoJbY5kCuRtEmfunOMV/WjdfEX9k79l6X/hXk2s+Ffhibsf2l/ZcZtdLWTzf3X2jyIwgO7ytu7HO3HavHPB2jf8ABNT4leJrfwl4H0P4aeIddv8AzGhtLPT9LnuJfLQyyEIsZJwqlj7AmgDpv2Hf2r9Q/a9+GWtfEHUPDkXhmTSdXk0sW8VybkOI7eCbzN7JHgnzsYx2619rV8z3Pjn9k79ldx4Hm1Pwr8Lm1Qf2l/Z8f2XSxPv/AHP2jykCBs+Vs3Y/hx2ra8IftRfs6fEDxHZ+D/A/xH0LXNb1EuLezs76KWeUxoZG2orZOEUsfYGgDwT9tX9hfSv2yrvwhcal4um8Lf8ACJpeqohs0u/P+2mEnO6WPbt8n3zn2r+en4JfD+D4Vf8ABRDwp8Mbe9Oox+FfH0WlrcvH5bTCzvvKEhQFtpbbnGTj1r+rr4j/ABt+EPwgbT4/il4v0zwq2qiU2g1G5jt/PEG3zPL3kZ271zjpkV8qL8U/+CaUXi//AIT9NZ+HA8Ufazf/ANqBNO+3fbC+83H2jb5nml/m8zOc85oArft4/ttap+xra+C7nTfCcPin/hLH1BGE141p5P2IQEY2xS7t3ne2Me9fm58Rv2OdO/a2+D3iz/goLqHimXw1qGv6LqPiE+H4rRbmGJ9It5IhCLoyxswk+yglvKGN3Q457j/gpxPH+17Y/Dq2/ZccfFSXwtLqj6svh3/iYmyW8FsLcz+Ru8vzTDLsz12nHSvVPAvxf+F3wp/4Jz6v8A/iV4p07wx8R9P8HeIbCfw/f3CW+pRXd3HdtbwtbsRIHlEqFRjJDD1oA+Qv+CJv/JffHP8A2LLf+ltvX6DftC/8Ev8AQvj/APH/AFb48XfxAuNFn1OWwlNjHpyTqn2G3htwPNM6E7/Jz93jOO1fzLeBviV8RPhhqE+r/DfxRqfhW+u4vImn0u8mspZIsh/LZ4WQsu4A4PGQDXqUH7WP7V9xNHbW/wAX/GMkszBUUa9fklicAD993NAH77/8Fpf+TVfDn/Y4WP8A6QX9fy9V98eN/hD/AMFIPiXpUWg/EbQPiJ4p02GYXMdrqf8AaF5As6IyCQRzFlDBXYA4zgkdzX6NfsQ+Cf2WPhB8GpvCn7aXhzwr4c+ID6rc3Mdt4xsbRNSOnSRxCFwLtDJ5JdZAvbIbHegD9Sf2pf2c7L9qb4MN8Jr/AF2Tw9FcXNpd/a4rdblgbbnb5ZdBznrnivzC/wCHHfhb/orl7/4J4/8A5Kr5P/4J9/tgeOLP9pO1l+Pnxf1T/hDRp1+GGvazcSWHnbR5OUnlMe/P3eM+lfvd/wANrfsj/wDRXvDP/gyh/wDi6APffCuhr4Y8MaP4bjlM66TZ29oJCNpkFvGI9xHOM4zjNdHVCzv7LUbGDU7GZZ7W5jSaKVDlXjkGVYHuCDkVZilEn3Qcep70WFfoTUVTlu0U7Ix5j+goRblzvlbYPQU+XqyedXsi5USxRqxdRy3U0wzg/wCqHmH26fnUib8Zkx+FPYLplZbMByzndmpPssXpUyyI5IU5x6U/FXzyM/Zw7H//0/33jhjiGIxikMqb/LXlvQdvrVa5lYsLeH7zdfapYYVhXy06/wARq/NmaetokxYk7V/E+lVDI0p8m24A6tTJJGnf7PBwP4jUwXA+zwcY6t6f/XppWJbvsMLCL9xbDLdz6fWkEUUH72c75D/ngUu8RnyLYZbufT60HybX95Id0p/Ogi3cl/fS9f3Sfr/9aomuILf5Yxub2/qaqmS5vGwnCfp+NXIbeOD7vzv/AJ/Km1bcabfw/eNUXU/Mh8pfQdalVY4+IVyfX/E1JtL/AOs/Lt/9epuBUtlqPUjUPnLn8BUlMZlVdzHAqusrzf6kbV/vH+gpbl3toWsjOO9BIAyeBVPzURjFCPMkPX/65obZEPMuX3HsO34CiwuYnEhP3Bkep4FK8scY/eMBWY95PM2yEY+nWnx2Qx5ly31/+uavltuZ+0b+EnN6GbbCpc1NH5/WXaB6Cqr3cMK7IRn+VNEVzdczHYnpRYSlrvcsyXkSnan7xvQVLE0rf6xQntnJqoZba2GyFd7e3+NOEcso33LbU/ujj86LApO5Z85SdqfMfapGIUZJwKpfaSx8q0XOO/YUogAw9y/mN2Hb8BU2NFPsW1ZXG5TkU+oMO3C/IP1qLzbeAYMmT9cmlbsPm7k5iQoUAwG644pjRB2j5wI+cfyqJblpf9TET7niraliPmGDRqgVpFQws935r/dQcVKFzk9Gf9B/n9anyM4paLgopFMhZX8sf6pOvufT8KpzPJeS+VF9wf5zWhJAGh8qM7BUSxPbw7IRlj1NWmYyi3oJGiRDyYOX7n0+v+FNll8o+VD88rdTQ7eQvkw/NK/U/wBant7cQjJ5c9TRfqykm/dQ23thF878yHvVuioGLlti8Duf6CobvuapKKsiUkAZPAFZFxcPcP5MOcfzqS7M8h8uOM7B7dalSP7HFuCGRz6VcdNTGbcnboJHDFar5krZf/PSoWmuLpikQ2r/AJ605LaSc+bcnA9P89KnWQH91argDq3Yf4079SbaW2Q1IILcAt8zdu/5CpSJ5e/lJ+v/ANao3mgtsgfM/f1/E0Iksw3znYn90cfnS82WrL3UPQQRHEQ3t3xyfxNSbZmHLbR6Dr+ZqpJexxDy4Fzj8qYsN1cczNsX0/8ArUW6snmW0S41zbxDaWzj8akjlWZdygj6iqoW0tOvL/makEk83+rTy19W6/lUtFqT6lyiqn7qA7pJCze5/pUL38Y4jQt+lLlb2Lc0tzRorNEt7J9yMAe//wBepAt6fvSBfoM1XKLnvsi9RUMSyL999/4YqaszRDWVXUqwyDWSqTafIW+9AevtWxRQBnXNsl0gliPz44PrWF88behFdUsapnbwD27VTvLMTjenDj9aTQmhlrerMPKm4fp7GobqwZT5tt27f4VkspUlWGCK0ra/K4jn5Hr3FT6hYfbaiR8lx+f+NWprSG5G+M4J7joaS5s47gebEQGPfsay0luLOTb09QelV6jJ1uLmzby5huTtn+hrQSa0vBsOCfQ9adDLFeRkFPqD/jTE0+3V9/J9AelMCF9MiLZRyo7jrWkiBFCr0FPrLnu2dvKtuSeM/wCFUo32IlJR3Jbi5IPkwcuf0qNIIrZfNuTlqcAljHub55DTY7Z7hvNuenYVpsjDVvXf8hPNubs7Yh5aetW4bWOHkfM3qanAVFwOAKguZxCmf4j0qL30Roope9Ie8qR/ePJ6DvTyxx05PaqUEJj/AHsvzSt0zTp5jF+7j+aVqLdEVzaXY6SXyz5cfzStTPlt/mb95M/+fyoRPs4wPnmk/wA/lSkpb/M3zyt+f/6qryI82N8gv++uzwO3YVKrvINsA2J/eP8AQVHs4828P0XsP8arSXcszeXbjGfz/wDrU9ybqP8AWpbZoYPmkO5vfk//AFqaJbif/VL5aeppkVosf7yc7z6f561dwzDH3R7daV0Uk3voQLFFE2TmST35P/1qmIlbqdg9uTUiqqj5RinVm2aKNgpCQOtVTcb28uAbj3PYU1mjhwZCZJG6ev4DtTsHNEu1F5oPCfMfbp+dQYkYb7g7E/uj+pqrLe4+SAYHr/gKajcUp23NMuEG6QgVVe+iB2oC59qqx2s0533DED9f/rVN5tpajbHy3t/jVWRHM99iZGuZDkgRr78mny3MMPDHn0FUg93d/c/dp61KEtbMZY5b9aLApO2n3smilmkOfL2p6k8/lUrSop29T6DrVVWuLjn/AFUf6mkM0UH7qAb3Pp/WpsNSsi+CSMkYpiSI5IUg49KqCGSQb7l8L/dHA/GplGF2wqAPU/55pWLUmWaYEQNuAGfWoCY4TvlkJPuf6Co/tqudsKGQ0WfQHJdSZ4AYnjQ7d3eobiBpBHEn3AeasxtIwzIoX8c1ISB1p3aE4pohK/NnHCDj61E5YHyUP7yTkn0H+eBVyo9gBJXgt3qUxtGdczCMC2tx7HFPhhS2UO4zKegqSG28jdIf3j9qTd5CmefmRug/oK1v0Rhy680v+GHSSiAeZJy56Co4bd5G8655PYU6CBmf7RcffPQelX6lu2xoo31YUVDIzAYUZJ/IfWq9w8qJ5cSlmPU4qUrmjlYiurrbmKI89zTLezAHm3HA64P9ada23ljzpQcjoKRkuLt/nzHGOxra9tEc1m/el9wst4znyrYfj/hSx2iRjzbk5NSBorc+VAu6Q/55NOZo4P3lw25u3/1hU36IfL1l/wAAdulcbYV2L6n+gpvlwxnLkySe/J/KmJJcXR+T93H696HngtRsQbm7/wD1zS8i7rdljM7+kY9+T/hTTJFApDyZPvyfyqmGvLrlfkT8v/r1KLa2gG6U7j7/AOFFujBSb1X4liK4jmYqgP1xxX85f/Bbv/kqnw1/7A13/wClIr+jOOcSkCJDt9egr+cz/gt3/wAlU+Gv/YGu/wD0pFQzSLuj9Bvit/yiai/7Jton/pFa1/J1X9efwc+Mf7KPiP8AZR+Hvw0+JXxC8IzWk3hHRLHU9MvtbsY2DR2MIkhmjMwZWVhhlOCCMGuR/wCFU/8ABJr/AJ7fDb/weWf/AMk1JZ/OF+yN/wAnVfBz/scNB/8AS+Gv2W/4Lif8it8I/wDr91j/ANF2tfX3h3wX/wAEt/COv6b4p8M6l8OtP1fR7mG8s7iPXLLzIbiBxJFIubnqrAEV8Af8FjPix8LfiT4c+F1v8OfGOjeKXsLvVWuV0rULa+MKyR24UyCCR9obBxnGcGgD9J/+CYP/ACYz8Mv9zVv/AE7Xldt+2l+1dH+yB8M9J+I0nhc+KxqmsQ6V9mF59i8vzbee483zPJnzjyMbdo65zxg+CfsQXPiGz/4JiaNdeEPPOuw6F4new+yoXuPta3uoGHylAJL+ZjaACSccV+GHxPtP+Ci3xq0G38M/FTwx4/8AEul2lwLyK3u9CviiXCI8YkGLcchXYfQmgDyv9qb9oZP2lPjxqPxrXQT4eXUEsk+wm5+17PscMcX+u8qLO7Zn7nGe9frX/wAPyrT/AKIw/wD4UI/+V9fjl/wy1+05/wBEi8Yf+CDUP/jNfZf7DP7O+leH/jTPfftk+BJvDHgI6VdRx3fjC0m0jTW1BpIfJjFxdiGMzFRIVTdkgMQODQB87/toftSJ+1z8WLL4nR+Gj4VFnpEGl/ZDefbt3kTTy+Z5nkw4z52Nu3jGc88ft1+yV/wS2n/Zx+NHhr43P8Sl8QDSIbr/AEAaObXzPttpLb/677ZLjZ5u77hzjHGc16d/wqn/AIJNf89vht/4PLP/AOSa/Q3xF4r8IeBvD7+JfFesWOg6HaCMSXt9cxWtpGJCEj3TSsqDcxVVyeSQB1oA/m8/4LX/APJyXg7/ALFK3/8AS+9r5h/4Jl/8nxfC/wD67al/6bLuv6G/ihe/8E6vjVrdt4k+KvinwB4l1K0t1tIZ7vXbFnSBXaQRjFwOAzsfxr8M/wBjm28MWX/BUTTbPwR9nPh2HxL4mj037I4ktvsS21+IPJdSQ0flbdhBIIwc0Afth+3N+wpL+2bd+DbmPxoPCP8AwiSX6EHTvt/2j7aYD/z8W+zb5PvnPbHP80tt+zw9x+1c37L39vgOvimTw1/av2bjKXRtvtH2bze+N3l+b7bu9f2SeNvir8L/AIavZp8RvGOjeFH1ASG2Grahb2JnEW3zPK+0SJv2bl3bc4yM9RX5x/HfSP2Jr3wz43+JPwQ1DwjqfxsuIbzUtEuNF1O2vNZn118yQyWsEM0jy3DTHKqsZJboKAPUv2Gf2FJf2MrvxlcyeNB4u/4S1LBABp32D7P9iM5/5+Ljfu872xjvnj52/aS/4JN3H7QPxu8U/GJfiguhDxLNDL9iOjG58nyoI4ceb9si3Z8vP3B1x71+Z/8Awtb/AIKyf88viT/4Jbz/AORa/oZ/ZM8TePE/ZX8I+Kvj9dXeneI7exu7nWrjXENlPAkNxMTJdCYR+UEhAJLgAKMnjmgD8pf+HGt1/wBFnT/wnj/8sKP+HKdz4Y/4qQ/GBbn+yP8ATPK/sEp5n2f95s3fbzjOMZwcelfsb/w1L+zF/wBFe8H/APg/0/8A+P1ieIf2m/2br3QdTsbL4seE7i5uLaaOKKPXbB3kd42CqqibJJPAA5JoA/J7/h+Vaf8ARGH/APChH/yvr8rf2yv2nV/a0+LUXxSj8NnwssWmW+nfZDefbc/Z5JX8zzfJh6+bjG3jHXmuE/4Za/ac/wCiReMP/BBqH/xmj/hlr9pz/okXjD/wQah/8ZoA6b9kf9nBv2qPjHbfCWPxAPDJuLO5vPthtftmPsyg7PK82H72eu7j0Nfqt/w41uv+izp/4Tx/+WFe9ftxfCH4bfsj/s+T/GP9m/w9b/D7xtb3tlZpqmmgpcpb3JImjy5YYcDB4qT/AIJs/tjaX4j+Cev3v7Svxa0tPEkfiG4S2/t/VbS0ufsItLQrsSV4yYvNMuDjGcjPFAH6weF9CHhjwlo/hmSYXQ0mytrQy7dgk+zxrHv25OM7c4yfTNbJMt1wnyRevc0kF1Z39nFe2syXFrcIkscqMHjkRxlWUjIIIwQRwaUGS6+7mOL17mrXcxlvYcpihPlW6b274/qacV43XDjHp0H/ANeq8lzDAPLgAP8AL/69Rx201yfMuCQKu3Vk3+ytfyJzdbj5dsu/+VO8gkb7p93t0FTRqqrthAA9f89akEYB3Hk+pqL22KUW/iGBjgeWmB7/AC/pS7pf7o/OpqKVzWx//9T97oYzEu5uZZKjuZWGLeLlm6mpZJhFEZz1bhR/n86gtk2IbmTl36fj/jWvmzBr7KJ44xCghi+8eSfT3/wqOSQgi1tvvdz6Us0pt4/WWT/P6Uz5bKLc3Mr0eYPTRCySR2Uflx8yGoILV5z50p+U8+5p0MG7Nzc9OvNXQDP8zjCdh6/X/ClexKjfcFGRshG1B3/w/wAasKoUYFOrNnuWkb7PByTwTULU2bUdyZ7kmTyYBvbuewpJZUthlzukP+fwFRM0dlH5acua8X+I3xq8GfDS2MurXaz30gJihj+dzxwQoIzz3yq9RuBGK7cPhquImqVGLbfRHnYzHUcJSdbETUYrdt2SPZ1ieX9/dnAXkDtXPX/i/Q7eMs17GluhKtImZACOoPlg7fxxX5hfED9qjx34tlkg0fbpNnnKZxLLwSR1HlgjsQu4f3j1r541fxDr2vzefrmo3GoSZzmeZpMfTcTj8K/V8BwDiqqU8VNQ8t3/AJfifz/m3i1gKDcMDSdTzfup/r+B+v8Aqvx/+GuhM1qNVtC6cE/aYjz7iMs36VxLftP/AAxkk2yatAZM/wDTfGP97yMV+T1FfX0/D/Ape/Uk35WX6M/PK3i7mkn+7owS87v8mj9ldH/aA+G2oulvZ6paBn4BNzEM/hIUc/gK7228U6RqirLFep5bMFUyZiViemwuAD+Ga/C2tjSPEOvaBN5+h6jcafJnOYJmjz9dpGfxrgxHh7S3oVmn5r9f+AethPGCvpHF4ZNf3Xb8Gv1P3nSKG0XfKct/npUBmnu22x/Inf8A+ua/KDwL+1B448MSRwa2F1WzB5xiKXBOT0HlsT3JXcf7w619/fDj45eDviJYIukXAivAP3sL/I6nHJKkkgE98svQbiTivzHNeGsfl/v1Y3j/ADLVf8D5n7nkHG2VZxalQnyy/lej/wAn8mz2j/R7Jf78n6//AFqYsc12d83yx9hRHbpGPPum59DU43z/ADyfJF6dz9favjbn6La+j+4crAjZagAD+Lt/9eo5biK3Jz88n+fyqvLdmT9zbD24/pTorIL+8uT+H+Jot1ZV29IkBe5ujtXp6DpVqO1hhG+Y5P6f/XqwjlxiEbU9T/QVHJPBAcs2+T9f/rUXeyJUEtWS7pn4jTYPVv8ACmlABumlLfjtH6VnvfTynbHx7DrT0sppDulbb+potbcOa+yuWRdWkX+rH5ChbtpD+5iLe/SpY7SGLkDJ9TVqpujVKXVkUZcjMgAPsc1LRUckiRLvc4FQXsOwM7sc06q0U3ncopC+p/pTWlLsY4O3Vuw/xNVYLxLdFVWkbPlQ/M3cnt9aheWG1+8fMlP5/wD1qLEuVjQorPWKWYeZcnCddvT86XzWm/d2vCjgt2H0osHMX6KomVIB5MeZH9Ov51JH5q5knk2j04wPxosHN0HC2gDbwgyKbcW5nGN5A9O1IlwZXxEMoOrHp+FTGRd+wcnvjt9aNQsmrFeG1SBd+N7/AOelVJJbuZ/KVTHnt/8AXrYop83VkuGlkZqwwWi+ZKct/npTDNdXBxANq+v/ANerzW0Tv5jDJqYAAYFHN1FydFsZ0dgv3pW3H2q6kUcY+RQtMmmEWFA3M3QUhlMMe+4IHsKG2xpRjsTsyqNzHA96AykbgeKo4aX9/c/JGOQv+NN3SXpwvyQ/qaVh8xYFyruY4hux1PalnuY4R83LelU5rqOBfKtsZ9aSC2z/AKRddOvP9au3Vkcz2RfhmMkXmONtT1QINz8zfLCP/Hv/AK1OWQyMBD8sS9/X2FZtFpl2ioVlV3Krk46ntTvMTd5eRu9KRdxklvDKcyICfXvVVtOtm5GV+h/xrRooGUre1aA4WQlT2Iqy8ccmPMUNj1pXdUXc5wKaJEKeYTheuTxRYLktGRWS91JcSeTb8D170XUwgjW3iOD3P+fWtOUz9otxl3cGRvKi+Ye3c1OiLZx72GZX4A/pTLaJYE8+Xqeg7/8A6zVuKIl/Ol+8eg9KbfQzUW3zPcjht2L+fPy57elTzTRwDLn6CpSwAJJ6daxo1N5cF2+4P5dhU76sp+7pEuRM0mbibhB90f1pkQ85zdSfdH3RUc0n2mYW0f3B1xV35R7Rxfz/APrUyVqRzzeQm8/6x+gqKCPyl8+TmR+g+tRwqbuczyfcTpVoyKFNzJ0H3R/n1o20GtfeGySfZ1y3zyv2/wA9qYoFupuJ+ZG/zimwDObyf8KhRJL2XzG4jH+cU7EtjAJr19x4A/IVoRokQ8uEZbuf8f8ACgHePLg+SMcFh/T/ABqyqKi7VGBUtlxhbURU2jJOT61FNcJDhfvOegFNurpYBtHLnoKgjUW6G5uDmQ0JdWU5dETFjGPNuD9FH+eTUA869OT8kX86bHG923nz8RjoKjnuTKfJg6HjjvVJGbffb8yd59mLe1GT60uIrRfMkO+Q03MdjF6yP/n8qzsyTy/3mamlclyt6kzPNeSbf07CroWCxG5uXNNd47GLYvMhrNy80n99nqt/Qj4fUsSXM03yjgHsKsRWiRL5twenanKsVjHvk5c1TLy3coXr7dhRvsVazvLVlmS8aQ+VbD296ekEUA864OW/z+dKzw2KbV+ZzUUcMlwfPuThf8/pU+g+uurHmWe8O2L5I+5qdFig/dQrufv/APXNIrmX91bfLGvBb/CopbmO3Hkw8t3P+e9LyL0WrJ2ZIQHnbL9h/gKpPeTzNsiG3Pp1p0dnLMfMnJGfzq2jRJ+7tl3Hue34mjYWr8itFY/x3B98f4mrStgbbePj16D/AOvRI0UQ3ztk9h/gKoy6gx4iGPc9aNZB7sC/5Tk7pZDj0HA/xqIy2cR4wT+f61TW3ubj5nPHqf8ACr0VjCnL/Ofeh+o029kM+3BuIoy5qzG8zf6xAg+tSqAowBgU6ouaJPqwppAPUdKUkAZNVVulkfbCC2O/apKbRboqvJKEOxBuc9v8abvMY+Y75G6Af56VVguWqKpHbF++uWyew7D6VGrT3Zyv7uL9TRYnm6GjRVHzI4f3FuN0n+etLuW2HmTyF2Pb/AUWDmLtQSW8Mp3OuTUKfaZDuY+Unp3/AFp7XA3eXCPMf9B9TRZrYLp7kkkRePYp2fSqsVgiNukO/wBKttJsA3ck9hUo6UXaBxTd2ZlxPcA7Y4yo6ZxSR2wA866P4H+talQSwRzY8wZx71XMQ4Xd2V47vzJhHEvy9zX5k/t8/sDeLv2wPF3hbxJ4b8VWPh9PD9jPaPHdwSytI0svmAgx9AOnNfqEiJGNqDApssiRIXc4FS/ItaLU/nH/AOHInxT/AOilaN/4CXNH/DkT4p/9FK0b/wABLmv6M43lYebLiNfTv+NMSWSd8xnbEvf1/Oiwcx/Of/w5E+Kf/RStG/8AAS5o/wCHInxT/wCilaN/4CXNf0WvcPK/lW3UdW7U+a5W2QKx3PRYOZHz7+yZ8E9T/Z2/Z+8J/BzWtSh1e98PC8D3VujRxSfabye6GFbkYEoBz3FfR9ZVu93Od2/CeuB+lWXkaV/LgONvVv6UcoKd1cuV8b/tw/sz65+1d8GYfhh4e1m30K7i1W21D7RdRvJGUgjlQpiPnJ8wflX168zFvKh+Zu57D609pAhCcs57D+ftRYq5/OV/w5E+Kf8A0UrRv/AS5r9mf2svgHq/7RH7O2ufBPRtVg0i+1b+z9l3cI8kSfY7qGc5VOfmERA9zX1A7pHy7Bc+tSVIz+cL/hyJ8U/+ilaN/wCAlzX0N+yn/wAEr/iB+z18f/CXxj1nxxpmrWfhx7ppLWC3nSWT7RaTWw2l/lGDKDz2FftvSZFAH5rf8FAP2HfFX7Y154HuPDXiey8PDwomorKLyKWXzftptyu3y+m3yTnPqK+RfgR/wSL+I3wj+M/gr4n6j4+0rULXwtqtpqMtvFbTpJKtvIHKqW4BOO9fu/HKkoJjOQO9Urm92nyoeW9apK5DkkrmlXm/xd8GXXxI+FHjX4d2NytnceKdF1HSop5FLJE99bSQLIwHJClskDnFd1JM9tBmU5kPSorWS4l/eSP+7HsOaXL1DnV7H86v/DkT4p/9FK0b/wABLmtDSP8Agin8UdM1ey1J/iPozraTxzFRa3OWEbBsfpX9EkZeV/MBxH2Hr71Zz2pFJ3CiqBuC1y0EfYY/H1/Cm3M8nmrBA3z96qxLmj5b/bT/AGdda/ai+B918KNA1e30S7uL60uxc3UbyRgW7EkYTnJzxX47/wDDkT4p/wDRStG/8BLmv6NSx3LEpyRyx/z61XM0k1x5UJwqfeNFgcjE8I6A/hvwdofhm5lEz6VYW1pI6jAc28SxkjPQErmtK4uGmPkW/Tpx3/8ArVLdTtK/2WHn1qWONLVQqjdK/wDn8qpaGcnzOyGQ2yW4Dy8v2FXArPy/A/u/40iIVO9zuY9/6CnySLEhdzgCpbuXGKSFd1jUu5wBVVJJLjlfkj9e5/wqBd16+9+Il7U2WVrl/s9v90dT/ntVqJLlfUlku8Hy7ddwFR/a7j/nlUhkgsRs6setJ/aUXpR8g1/mP//V/eWUG6uhH/BH1/rVzcrOXb7kXT69/wAqrQKY7fzF/wBZLwP6f406ZCRHaRdO5rQxXcbAPMdryXoPu0yNDdTGeX/Vp2qzPBI6LDFgIOtTG3QxCIEhR6Urhy9CNM3B8xv9WPuj19zVymhQoAHQU6oNUipdeeyeXAOT1NQwQC1iaRmG7GST0ArRzivkr9pf42HwBop8P6FMP7YvwVTHPlj+Jznsvb1bjorA+rgMFWxteOGoq7Z4mbZnhstwk8bipWjFf0l5s439oD9oqHwq9x4V8JyLc6u4xLL1SAH1Hdj2X0+9x8p/OTU9T1DWb6XU9VuJLu7uDukllJdyfqarTzzXM0lzcSGWWVizMxyXJOSST1JNRV/WeSZFh8so8lNXk95dX/kvI/z34m4pxeeYh1aztBfDHov833YUUUV9QfBhRXaw+C7i8m+zWFwJZZ0iktQwESXBkHzosjsFyp4xkknsOa9C0T9n/wAWazZy3iXNufs4JkS38y8cY6gGBXUkegavl8RxFlmHjz1qyXyd9ddrXt523PvMJwbneKm6eHw7la+t1bR2te9r+V7nhFFekeIfhZ4q0KB76KD7fZpH5ryQ8yRp/wBNYv8AWR475GPevN69nCYzD4un7XDzUl5f1p8z5rMMrxmX1nh8bTcJdmvy6Nea0Cr2manqGjX0Wp6VcSWl3bndHLESjg/UVRortlFSTjJXR5sJyhJTg7NH6Xfs/ftG2vixrfwn40YQ6pEMQydI5wP7g7MO6+n3eBtH2UWk1A4iOIuufWvwMgnmtpo7m3kMUsTBlZTgoQcggjoQa/VH9m741S/EDQh4e1eVRrNjhZCeN6npIPZu/o3HRlA/nbi7hdYW+Nwa9zqu3mvL8j+x/DzjqWYWyzMJfvF8Mv5kuj81+KPqoGG1/dQLukP+eaUxgfvrx846DsP8aYzw2S7V+ZzVMLPePk9PXsK/Hj+jW+hJNeyS/JD8o/U0kGnu/wA0p2D071pQ2sUA45Pqas0r9h8l9ZEUUEUIxGMVLRWcbmSeXyrfgd2qDS6Ro1wGv/EvwL4auzp+t6/YafcjBMdxdRxyANyD5ZO7B+ldZPKzsLWHk9z/AJ/Wvlv4nfsxaB8QvGd14s1LXLi3a7SJfIhjT5fKjCZ3OTnOM9K9zLKODqVnHHVHGNt0ru/Y+ZzvE5jRw6lldJVJ3tZuytrr+X3nsNv8a/hTdyC2svFmmyzNwAbmNMn/AIERn6Cu1knto7STWNSuI4rSFDM0jsFjSMDJYuTgKByT6c1+fHxO/ZEs/CngzUfFfhvWpp5NLhe4lt7pF+eKMZbDR4wwHOCDn1Fav7Kuqal498E+L/hNq164sPshS3b77wR3iyRShM9gcFR0BJ9a+wxOQ4CWCeOwNdyjFpSurNJtar7+x+c4PizNYZlHKs2wqhUnFuDjK6bSbs997W30PrV/jV8KJbkWa+MNMjXpn7XHg/8AA84H516NaXlrqNvHLpEsc1tIMiaJg6EHupHBz61+ePxO/ZL0Lwh4L1TxJ4e1q5urrSITcPHOsfluiffA2gEHHI6+nvXR/sVeJtSfSPE/hiWUva2klvcQAn/VmfzBLj0ztU/XJ71GMyHAyy+ePy+s5KDSaatvZfqXl3FeaQzinlOb4aMHUTcXGV9k3rv2fY+29a8RaH4ct9+pX9vp8f8Az0uZUiTP1YgZrh4vi/8ACO2mxceMNLeY+l3E4H/AwcZ/GvzL/aR8NSeGPi3q8El3Jd/2gft37zrH9pdn8ocnheg6cV9SyfsR+F3sJHi8SXkNwR8jPHG8YPbKjBI/4FXbPIMqw2Go18ZiZL2iurR9PXa55lPi7PsbjcThctwcX7F2fNL1t2Wtn6H2hp9/aeIbSPU9PuorqwlGY5IJFkjkHqGXIIq/uaT9xafKg4Len0r8uP2Wdf1zwx8YP+EAluWFlqhuYLiEEmPz7aN2DAev7sjPoea/UKW5C4t7Uc9Mivk8+yd5Zi/Yc3Mmk0/J/wDDH33CnEUc7wH1tw5JJuMle+qs9PKzRKWt7Ndq8uevqfrTFhluT5lycJ2XpTobZYsSTfNIeg96szSpCu+Q/QV8xfsfeW7jsDbj7ij8P/1VUe758q1TcajCT3p3P8kfYVoRQxwrtjGBUBq9iolm7nfdtvPp2q8AFGBwBQzBRuY4AqtHcecx8vhF6k1W40kiSWZYgCeS3AA71HLOYE3ScsegFRq6ktdyfcThf8fxqGDM7m6l4Ven+fapE32JFxbIbifmV/8AOKjiQuTd3R4HQU2MG9mMr8RpUn/H7LjpDH+taEbiBXvG8yX5YV6D1qG6u9w8mHhelNuroP8AuouIx6d//rVJaQqq/aZuAOmf50E76IW3tUhX7Rcdug9KnGZ/30vyRLyAe/uahTdey734iTtU/wDx9N6Qp+v/ANagtLsHzXJ3N8sI/X/61P5lHHyQj8M/4Ck+WQb2+WFeg9cf09qql5L6TYnEY60BsSmZ5T5FoMIOren0q3DAkI+XknqT1NPjjSJdiDAqpNI8sv2eE4/vGsx7asubl5Ofu9aohvtLmR+IU/U+tRzNvYWdvwB1qSRQ7izi4UctQNu4AfaX82XiJeg9fc1Su7lpztXhB29akvZxn7PHwq9aSyhDsZX+6v8AOr8zJ6vlRMiiyt97f61qhtYPMc3EpyBzz3NNLNeXGF6fyFaQVWPkoP3adfc+n+NFwSv6CohkbzX6D7o/r9amlkEUZkPapKpSHzblIOyfMf6VBu9EV52aK0EZP7yTr/X/AAob/RLQIP8AWPSMftN8F7R/0/8Ar1HdMZ7pYl7cf41oYPuTWUflxGXHztwKS7JCJbJyW6+//wCs1bUDzFjHSMZ/oP0qpb/vZ5Llui9P8/SlfqW1pyosBFVUtV6Yy30/+vUEgN3ceV/yyj61IztHAZQv7yXoO/t+Qp0cEkUGyP8A1jdT6UwavoV5S11MLePiNetWMBj9ni4jT7xH8v8AGn29v5MZXPzHqRU0cSwptX9am5Sj1Y9VCgKowBTZGZUJQZPYVJRUmhl21pIJDNccnt9fWpZLR5phJM/yL0UVcLKF3k8DnNVxeW5IVXzn2NVeRlypaMdNAZlEYbYvoKZBZxQHcuSfepJ7hYAGYEg+lKsweHzUGeOlF5FWVyvLYpK5dnbJqWC1jt8lOSe5p8cwli8xR+FTAgjI70XewKK3RlS6fJI7OZMk+1WIrf7LGSg3uatu6xqXfoKEdJF3ocg0XkJQSd0YUsN1LLmRDk/lVxiljHsTmV+9alRPFE5y6gmq5iVC2qMyC2GPtNyeOvNTfvLw8/LCP1qzNbicjeTgdqhuRO2IYlwp4zSuHLYhlnZ/9HtBx0yKckNvZKHk5f8Az0pSyWYEUQ3ytSqiQDz7lsyH/PFMLdWO2SzjdOfLj/u+v1qCa8VB5VuMY7/4VBJPNdv5aDj0H9avQWKR/NJ8x/Sl6i1fwmfFazXDb2OAe5rVhtYYeVGT6mrVFJu5cYJBRVG4uzG6wxDc5ps0zW0QUnfK1Fh80Saa5EbCNBvkPahpvJj3XBGT2FVkC2kTTTcyP/n/APXUMML3TmeY4T+f/wBapI5mOAnvm+Y7Ih6VMZAp+zWajPc9hUUlw0rC3tRx6/57VIStoohi+aV60Eh/Fv8Auoh5kr9Sf5mkd0tQWY75W/z+AppYWUe9/mleobaEzsbif7nv3/8ArUDv0QRQtO32m5Pydh/ntUxkluj5dv8AJGOC3+FGWvH2rxCv60jTbz9ntBwOpHalcVh+Utv3Nsm6Q/55pQkdv+/uH3SHv/hUbyQ2SbE+eQ9f/r02K3eY+ddHj0pj8kLuuL04X93F69zV1IliXZEMeppxZETc3yKKoNLNdnZANsfc1mVt6kstzFCSqfNIf89aYIbm5+a4bYn90VYgtYoORy3qatVVxct9yOOJIl2RjApWdY1LNwBVVroNIIofnY9+wpJP30oi6pHy3uewqTS/YkWfKGZ/lj7etQIPPb7VNxGn3R/Wo2Y3s/lqf3adaSd/tEq2sX3R1/D/AArQybF+e/kx0gX9aV2a4P2e34QdTSydRZQf8CPtTZ5ktU8iDr3P+e9K4vUJZo7ZPIg69z/nvUFtaGdvNlPyfzplrAbh8n7o6mrUspuH+zQcKOpH+elVcnfVkpcznyYPliHBYfyFKcv/AKPbDao6t6fT3pGzxaW3GPvN6f8A16eqgfuIOAPvN/nv/KkagBtHkW3GOren+JpjSpCfJgG+Q9f/AK9Qy3HItrQe3H+f1q7b26wL6sepqfUN9ENit8HzZTvk9fT6VZ3Ddt71WupjEoWPmR+BVeR/ssW0HdNJ1P8An9KNx3S0JZpGmk+zwnH94+lMf9832WDiNPvEfypvNrEI15llNJM4tIViT7z9T/WqIfmMuZwi/Z7fgDgkU2zgVAbmXoOlVYIjPIEH4/SrN3NlhbxdF449afkZ7+8yMLJe3HPA/kK09gk/cpxGvX39v8ajijMEYiT/AFj9T6f/AKquIqooVegqWzSMe4+qCyYEt2eR0X6D/E1JduVjCJ96Q7RVS9O1Y7ZP8+lJFSY21HkxSXb8k9P8/WnWq7Ee7l5Zun+fc065UAQ2i96slQZFjH3Yhn8e1O5KRDM7Qx7R/rZf8/8A1hTWIsoBGn+sanQhprg3DjAXhc05LeR5/Pnxx0FFwtfVEcUYtY9xG6V+AP8AP61dii2fM3LnqaTyh5vmkknoPQVPUtlqNgrKnhnupQCNsY/zmtWkzzimnYpq+jKssDGIQwkIvenRW4hi2RnBPeke7gjJR3wR7GpUlSSPzE5FGpNlcpHToydzyEk0n9nQ/wB41PDdxTkqMjHPNWMp61V2TyxP/9b9+QigAY+70p9VJJ2jnSNsbH6H3qC5kkt50lyTGeCKBXL+9d23Iz6VXe6jSYQMDk9+3NMnGNl1Hzt647qaZewiaITJyV5+ooJbHXk00ADR4wf50sxM9r5kRIOM8fqKSFlu7Yq/Xofr61BYyNHI1tJ17UCMTXvEVpoXhy71W9lWMW0bHc3RcAncRkZCgFjg5wDivxT+IHjG+8eeLL/xJelsXEhESscmOIfcT645J7kk96/Qn9r3xLLoPg3+xLZ2jbVGjiGOhRyWb8QItp9nr8w6/ongDLYwoTx0lrLRei3+9/kfx34t53OriaeVwfuwXM/Nvb7l+YUUV9R/ssfCrTPiL4wudX8RRrPpPh5Y5HgbpPPIT5SuO6jaWI74APBNfqeZY+lgcNPFVto/0l82fg+S5TXzXHU8Bh/im/klu2/Rannfhj4L+L9e0qPxDeQnTtLk5jllQ75B/eReu3379s1Q8UfDibQdLuNUin81Lcxt13h4pSV3Z2Lgq2AQQfvA5r9kvEGjWWoaXPE0YxtwoA6ADtXyN4m8HxaD4S1UX8Akgu4rbT4/MAO+S4uY3PB9AvFfzr/rzmEsZGrJ2pp/Crbdr738z+yv+IWZRDLp4aCvVa0m29JdHZO1r9O3U8N+FvwKvPEWiaNNfF4/7fn8xhlgEtIxknGcEsOmR3FfU3j3xrp/wn8Ba5baDbrG9nZ28cMYyg33haKIcYPyqpcnOSeMivZvBOlww6XpF1EgAigMWMdM4/wrxT9oH4Tax4wsp5NAfY80McUiEEo/kP5kecZIKknBAPDEEdCPjp46OMzFYnGfDKScv8N9V9x+jU8rqZbkjwOXP34Qai31lZ2evd69j8trGW//ALWF7p7tFeyyZDRfJgnrgL0HsBium8P+Dp/FF6LDTTNHLJ91p4PLiJ92DMQP+A19U/BP9nfxTo/jG38S+Joohb6fvZY8McuQQD8yqOM19nweFNPSQFLCOP02oBX6PnfFccNXjTyZxUUtWorV9tVsv1Pxjhnw/qY/Czq8SqUqjb5U5O8V1ejtdvvfY/IDxd4E8WeBbxLPxRp0tmZeYpDzFKPWOQZVvfByO9cjX7V+JtH0fUtHm0LxJYpqGmXAw0UoyPqD1Vh2YYIr8rfi58OYvAOvf8SiZrvRrwubWVvvxlPvwyf7S5HPcYNfd8NcXQzKX1evHlqfg/Ts/I/KeNfDutklN4zCy56PW/xRvtfo15nk1dl4A8Y3vgTxXYeJLIti3YCZVODJEfvJn1xyD2YA9q42iv0atRp1oSp1FdNWZ+L4bE1cPWhXpO0otNPzR+7fhi+tvE2k2mtQTieK4RW3L3yAQepwGBDDnOCK7JVVFCqMAV8cfsd+LpdY8DyaFcO8kmmO8Qz0CIQyfiRJtHtHX2VX8X5pgng8XUw0vsto/wBM8hzKOY5fRxsftpP0fVfJhVS4mZNscXMknT/GpiGLjkbR19c1ULbPMu5Rz0UH0/8Ar14x9CyK7mZFFtGcu/U/X/GmuwsofLX/AFrdT6Uy0XJa7m7Z/Om26tdXJlfoOT/QVoZbk8K/Y4DNIPnftXwX+1v4X8S6ULb4mWmvzW1vcyW+n/Y4nkj+fZLJ5u4MB/DjGPxr72AF3OZX/wBVF096+cP2m/Bni34leB7PQvBtj/aF3BqMU7R+ZHF+7SKVS+ZWQdWAxnPNfV8NYtYbMaU5ySi3Zt2tb57H5/xtgHjMlr06cXKSV4qN78y20Wr9Dgvhtf32o/snazeancyTumm6zl5nLk8TADJOc9hXlv7FHnDxJ4lMQ62kCk/WQ/4Vx8PwP/aYfQU8ETwS2eh7txtjqEH2fLPvyyRStn5+eQea+zv2e/gz/wAKf8PXs+rTx3Wr6oyPO8WfLRYwQkakgE4LHJwM56cV+hZpiMFhcDi4068ZyrSulF3sr31t5H5BkOEzPH5rl1WrhZ04YanyylNNXdmtE9d7HYfGoJafCDxZD1kk024z/wB8Gvkj9hxYhqHi+aTpHFZH9Zq+w/iZoereKvh94l0zS4fPvL6xnhgi3ou6R0IA3OQo+pIFfO37Kvwo8eeAb7xFJ4y0z+z4r2O2ER8+GbeYzJkfupGxjI64r5jLsTRhkGKozmlJuNldXeq2W7Pus4wWJqcXYDEwpSdOMZXlZ2Wj3ey+Z85ftdSmb4xzyEYBsrbH0wa/VUlr+bavESV8A/tHfBX4l+PvifLrfhDRvt9gbW3hEguLeP54wcjEkqnj6Yr9AZW+zRC2g5kfuKOIMVRq5dgadOabjF3SabWi37C4QwOJoZzm1WtTlGM5pxbTSlrLZvfdbH5TfCFWP7UcKRdf7T1QDH/XOev1ehhS1AAG+V/8/lX58/DT4I/FLwx8fbfxnrGieTpAvb+XzvtNs/yTRzCM7VlL8lx/Dx3r9Bmb7PwP3k8n+fypcZYqjiMXRlRmpJQS0aet3poV4bYHEYXA4mOJpyg3Uk0pJrSy1V+nmPlmEA5/eSv0A/z0pkVqzN51187+nYVLBb+WTJId8jdT/hVuvzY/abdwphZVIU9T0pJHEUZkP8IrOgdir3kvpgUA2MvpGllW2j59frUrJsRLKLq/3j7d6hs1wJLyXtnH9alifZFJeS/efp/SgjzGXJMsqWkPCjr/AJ9qLpvu2UPtmltR5MUl3JyX6f59zTbMf6y7m9//AK9BO5LKuxEsoer9T7d6ivJlhjFpF6c1MrmCF7uX/WSdB/IVlIjzy7RyWPWgG+xYtLbzn3N91evvUssjXcwgi4Qf5zTrqQW8QtIfTn/PvT0X7HBnH71+AKAt0JHAYrZw8IPvH29Pxp3Ez/Z04jj+97+3+NMYNBGII+Zpe/8AM1FOwgiFpDy56/j/AI0FDJZGu5hBF9wf5zWrFEkSBF7VFa24gjx/EetWqBpdWQXEwgiLnr2HvVEsbSDc3zSy/wCf0qQH7RdFj9yH+dUyTe3eP4P6CgTZNbAW8DXUn3n6U5Sba0Mrf6yXn86bKRc3aQL9xOv4df8ACodQl3zbB0T+dBO2xSUM7BR8xNaV2wt4FtU6nr/n3qPT4wXaVukdNTN3d7j0zn8BWhKWhagT7Pb+Zt+d+APr0q/GgjUL19T6mqyt512T/DCMD6mr1SzdIKzYpNsU15/fPH4cCrsys8ZVDtJ4zUJhiS3EUh+ROtCBlKxARJZ27f8A66LGKQzGaQEfX1NakaJGgWMYFSUXJUdissZIkDnlyenp0pYoEij8ocjvnvT5ZBEhkbJA9KiuZWhjEiAEZGfpUllqmFlUgMQM9Kp3ZcwiWJyMc8elOyt5bZXg/wAiKBX6ElxcpbgFwTn0omlcQebBg8Z59KjwLu22v8rdD7EVXsZSM20nUdP6igVye2mNzEQxww4OPeoLOV0le3mbJzxn1qIf6Hd4/wCWbfyP+FPv42V1uU/H+lBPmX1G1jEeh5H07isK4h8iYx9uo+lbSv58Kyx/eHP49xUN5ELiESJ1HP4VVwkrocuLy0wevT8RVfTpdrGBu/I+veotPm2S+Wej/wA6W7Rre5E6dDz+PejyJvtItwfubiSDs/zLVmPjdF6dPoar3OHiW5i6x/MPpUrMGVJ16Dr9D1qS1oTAhwQfoRWbHmyn8tv9VJ0PpVyRvKYS/wAB4b+hp80KTx7G/A0FNFO6jkib7TBx/eH9at2863Cbhwe4qtbSsjfZJ+o6H1FV5oms5fPh+4eo/pQRfqXGvEify5gUPr1FWlZXUMpyDVV0ivoAy9ex9DWfDNJZyGKUfL3/AMRQO9tzZ8tN3mYG71qhcWck0u/zOPftV4sSm6LDf1qKO6hkOzO1/Q8GgppMfDDHCu2Mfj61PRUbhyuEOD6mgYk8ohjMh7VUeeSGHzJv9Y/QelSMm+ZQwxHFz9T/APWqgM313/0zX+X/ANeqRDY+ACCM3k/LP0/H/Gi1Qyu13P0HT/PtUc7Nc3Ahj6Dgf1NWZl3sllD8oHLfSpIsRKjXsxlfiJOlNuJ2uHFvB9zpx3/+tTruYKBaW/AHBx/KnqF0+He3MrUB5Cs0enx7E5dqbCogQ3dxy56VWtomupmkl5A5Pv7VLIWvp/LT/Vp3/rQHmJDE17MZpfuf54qZ2N2/kRcRL1Ips8uSLO2+h/z/ADp00i2UIhi+8ep/rQVawk8hJFlbD2P+f506R0sYvKi5kbv/AFpIlFlAZZP9Y/Qf0psMQUG8uTz1Gf8AP5UALDAIx9ouuvYH/PWrbOFXzp/lA6D/AD3qMsFH2m54x91fT/69EcLzv59wP91fT60DStsRiKW7YST/ACx9l9a0VVUUKowBTqKCkrDGZUUsxwBVK+n8uLavV/5VGrtdXWB/q4jn6moRm7vCeqL/ACH+NVYlu+w+BfskBlYfvJOAP5Us7G1txEDmR+p/nUiH7TdFz/q4en1qKIfa7szt92Pp/T/GpF5Icf8AQrXA/wBY/wDn9KIh9ktvMI/eSdP6VED9su8/8s0/kP8AGrYxJO07/ch4H17mgSIifsUG48yyf5/Ss2KN7iXaOp6mlnmaeUufwHtWgoFjb7j/AK1/8/pWhO/oNuZBAgtbfqev+fepFX7HEI0+aaT/AD+QqGzj2hryf8P8anRtqPezdT90e3asy13HYMCiCLmWTkn+tQ3MvkqLWD756nvz/U0/cbaIzy8yvRZQH/j4l+8/T/GgPIntbYQJk/fPX/CrRYKCW4Ap1Z90xldLRP4+W+lBey0GRsGLXsvQcKPaobUGeZ7qXon+f0pt7JucW0XRew9akuT5EC2kf3n6/wCfeggkgYSySXkn3V4X6VlSytNIZG71o3ZENvHbr36/h/8AXqhbxedMsfY9fpWhEuxfixa2hlP35On9P8ajsIxlriTov+c0XzmWcQp/Bx+Jqy6gGKyXvy30H+NA7almEEgyt1f9B2qzRRWZsUf9be+0Q/U1Th/f35k6gc/lwK0IIDEHLHLSHJIpYIoUUmHv1NBlYrRZlvnkIOEGAa0AoGcd6dVO3ladHV/ldCQcUGi0LZOOTUZddnmDkdeOao2k7iR7eZtzKeCamiHkStB/A/K/1FAXJLe5SfOzIx61VS6kF15EuAOnH6VDIPsd0JV/1b/5NS38W5BcJ1X+VBF2F00lvcJKCSp7VbZsBZ16d/of8Kh4vLT/AGv6iobCbIMD9R0/rQP7Qmow5AnXtwaZpsuC0J78itBFG1oG6AcfQ1hur28+O6niqXYiWjuSXkYgnPZW5FVd6+tdBJFFeRox6dRUH9mQ0XBw1P/X/e2RftdtuHDDn8R2oGL20wev9RV4AAkjvWef9Fud3/LOX9DQAyxmODbydR0/wqeI+TKYD91uV/qKq3sTRSC5i49atOBd24eP5XHI9jQSisV+xXG8f6qTg+1OvYmVhdxdU61PFIl5CySDnoRSW7FM2kvJQce4oCx+Xv7YfiBNT8Zadp0MhMcULz7T2LkQ4/8AIBP418f17r+0Xdm5+J1zEePs9vbrg9i8fmn9ZK8Kr+yeG6Ko5XQgv5b/AH6/qf5u8aYl4jPcVUl/M1/4Dp+gV+gv7Pfhq98P6bZGzaRBrEMV1cMvZwzeX7EbWKkeozX59V+uHhXU9P8ADPww0LWYYjIbjTrSZVUZJ8yMP/WvzzxExMoYejQW0m2/lb/M/YPBvBQqYzE4uW8IxS+bd/yPpKG2Q26o5L8DOa+e/jHu8R3+k+GtO/49dHu7e9vnHRMOAifXBLH8K3ND8a+KPGduINOgGnRnhpTy49cZ707xNb+GfDHhu4024uY4pL8OGkmniieWRxyd0rKCfxr+ekm3ZH9hyaSvJ6HaeBbxJtJXDfIWY4/uHJyv4HI/Cuu1GUwwmVeq18OfDX4xz2Gs3K36GazuH8u9ERD/AGa8HDEYJBjl/wBYuDgg8Hrn61j1oavYebY/6TG44aP+o6j8aTVhp31Qr63Ct6iTyDYTiu4QROgZMEHvXyZ8RNP8T20A1yzSb7Mvy3flIZJIMf6ucRjmSPHyygcgBWAOCD0Xw68d+LbqwQLFBrVmnHnWkgkx7ED5lPswBFFgZ7z4gvdO0zS5rvUIw8CA5HFfn78ZdBg13w/qq6HYSiJGfUJZZSMRmKLIVU6jcuefY19NfEDUPE/irTX0rTrL7IHBy8pIH06d6+evFnxCsNK0CTS9RgNvqA0y5t7iE9xFGzAg9CQVIB7hq78DiJYfEU68N4tP8Tyc1wlPFYKthqu0otfej8+6KKK/uE/y1Prr9kPWxZeLtT0uSQok0UdwAO5jJh/9rg/hX6h2V35gEUrfN2PrX48fs5XjWvxPtEXkz29wAPUxp5o/WOv2IuLEOfMh+R/Sv5f47oqGac6+1FP9P0P7s8KcTKrkSh/JKS/X9TSqOSNJV2uMio4RKU2zgZ/nUXlTxv8AunBj9G7fQ1+Xn7oE1uxt/Ig4A9ahZDBbpbx/6yXj/GtIZxz1paBWMe7cQRLaxenP+fenqBY2+48yv/n9Ktm1iaUT87utZ95DcPIXIyg6Y5oEyrBE1zNtPfkmr8wNxMLaPiNOtJCPslqZSP3knT+lK/8AoVvj/lq/U0CSI7qTews4BwOKfM4s7cQR/ePU/wBaZZosMTXUn4VWiV7y4+bvyfpQItWqLbwm5kHJ6f596fEPJQ3c/Mj9BUzATzbf+WUPX0J/+tUKn7bcbv8AllH096CrEikxIbmUZlk4A/kKngh2Zkk5kfqf6Uka+bL57dBwv+P41boKCoZZFiXc30A9TU1ZrDzr8L2iGfxoAbfyNsSAdX6026GyOK0j6t/n+dKv7+/J7R/0/wDr06A+fdSTn7sfAoMxtwP9VZR9+v8An9abdZkljtI+g/z+gp1s3mSS3bdB0/z9KbZ/O8t3JQA29fLR2kfbH/1qtNGv7u0X7o5b6D/E1UslM1y07dufxNWXl2QyXP8AFJ936dv8aAKN9P5s20dE4/GrFuq2kBuH+8/QVTtYfPmCnoOTVi7ka4uBBH0HH40B5haRmWU3EvRec+//ANarELedI93JxGnC/wCNJMNqx2MPU9T7U+RQzx2afdXlvpQVYQP5aPeS/ef7o9u1MsYmkc3UvJPSorljcXIt06Lx/jWwqhFCr0FBI6ql1N5UBdep4FOnfBSIdZDj8O9VZv317HEPux8mgtkc3+jWYiH35Ov9f8KS0AhtpLg9T0/z9aZdLLPcERoSE4q41uz2qQZ2dM/5+tBNtStp6/6ydu3f+dZrMXYsepOa34LdI4TFncD1qKOW2jlESR7T0ziqSb2Jdla7GRxOtjsjHzydfx/+tUlrbm3RjIQCe/pS3ck0eGQ4FPYLdwZHXt7Gny7NhzatLdDoY44oyYvmDc+uacsvmxl4uvoao2cpjcwtwD/OrWPJm/2Jf0P/ANercbaGcanMkxLabz0Kv94dadFxm3k5x09xVa4VreYTx9D1q0dtxGHQ4I5B9DQ11WwRb2e6/Erh2tH8t+Yj0PpV8EMMryKrqy3CGKQYYdRVX99Ztx88Zptc3qJS5PT8jRdA6lG6EYqnbAsj2045Tj6g1ZimjmGUP4VJgZz3FYNW3OhNPVFC0JAe0l5KfqDVeFjaXJib7j/5Bq3dIyMLmPqnUeoptzEt1AJY+WXkf4UBYfL+4lE/8DcN/Q1DeRMrC7i6r1p9rKtxCYpOSBg+4otpDG5tJeo+6fUUFCzIt5bB069R/hSWri4tzHJ1HB/pSKPsc23/AJZSnj2NEyG3m+1J908MP60AQWjtbzNbyfxH9f8A69X1/dzFf4JOR9e4/r+dVb+Heizx/eT+VTRSC6g64YfoR3oEuxmXcRgmynAPIrSYC9tcjr1/EU+SMXUBRuHH6GqFjKYZTbycZ/nQKxLp8uVaB+o7fzqa2PkStat06r9Kr3SG3nS6j6E8/wCferNzH58SzxffTkUEkqgDMD9D0+np+FQxMbaT7PIfkb7h/pT45Fu4QwOHH6GlIS6jMbjDDr7Gg0HXFuJ19GHQ1FBMXJt5x849e4pIJ3jf7Pc/e7H1qaa3WYc8MOhHagXmUXjksZPNi5iPUVcZYLyLP69xTYpWY+RcDD/owqpNby2rma3Py9x6f/WoIBGmsX2yfPEe9Wbm2S6QSRH5ux9aIbqK6Xy5BhvT1+lM8uW0bMQMkTdR3FBVita3TQP5U+ce/atuqU9tHcru+63r/jRapcRAxy4Kjoc0AtNC2QGGDyDUK26RKwh+UtTJYZd3mQPtPcHoanTft/eAZ9qCjPhhNnHJLLyR0xRuNtbtI/8ArZTn/P0rUqtPbRz435yPSgVuxn2cSopu5ug6f41Tlle4l3HqeAK072GV0WOEfKO1V7KDYzTSjAT1oIa6EkoNvClrFzJJ1olcWMIij/1j9T/WnxNgPfS9/uj2qrbq13cGWToOT/QUATwKtnAZpB87dB/SoLSM3E5nl5A5P1pl1M1xNtQZA4FXnTZGtnF1f7x9u5oKsNVRdTGaT/VR9M96ej/aHM0nEUfT3PrUU53MtjDwO9TlFdlt1/1ceC3v6D+poJFjU3D+fKOB9wf1q9RRQaDSQBk8AVTluMWzSrxnhf8AP60y/JZY4F6yGorz5nitU/z2oE2JF/o9kZP4n6f0/wAaF/0Wx3fxyf1/+tTrgebcRWq/dXk/5+lLL+/vVi/hi5NBAyX/AEayEX8T9f6/4Usn+i2Yj/jfr/Whv9Ivwv8ABH/T/wCvUVxm5vREOi8f40ATwIYbXcv+sl6fj0/xqO8cQRLax+nNXcgzEnhIR+p/wFYjs1xMWHVzxQUyzYQBmMz/AHU/n/8AWpCWvbnA+5/IVNdOLeBLaP8AH/PvTkH2K23n/WSUE26EsgFxKLZP9XH9/wDwp3E824/6qH9T/wDWqLDWtuFHMsp/U/4Uy7YQQLbR9+v+fegBqg31xub/AFaf5/WtmqtrD5EQU/ePJqWaVYYzI3QUFoczqoLHovWs2F9sct7J1PSi7ZkgWHq0h5pLtWEUdvEC2OuPagGQ2CGW4aRudnP4mlj/ANIvt/ZTn8B0q1aQvHDJkbXbpn9Kda2gt3LFtzEUEJGdfPvuT/scVa06MgPLj2FTSm3gfJjyzc5//XViZ38rfEff8KrlYrrV9inb2kqy+fNjPJx7mraRxec0qnc/Q+1R28ouIzG/J7+4qkN1pcc9D+orVQ3XUzdRJJrY1EmV3ZMYKetV0nf7Q0MuPanzDG24j5x19xUd1F5iCaPqP5UkkEnJarp+RL/qZefuSfof/r1FMrwSefHyp+8KdBItxEUfr3/xp6uUPky/gfUf40bD0a0+QG4Taki9CcH2zVeb/R7lZx92ThqnS2WORmH3WGMGppYlljMbdDWbt0NI3a94oX0RRhdR8EdasEi6tw6cMOR7EU23bzEa2m+8nB9xVSBjaXJhf7rf5BqQLmFvLcq3B7+xFR2jkq1rKOU4/CifNrMLhfuNww/rT7iLzAlzD99OR7ig0K8GbW6MDfck6U27RreZbiP+I/r/APXq06peQBl69R7H0ojIuoDHLww4P19aCbDy3mRrPFyRzj27iq97CJohOnUD8xUdlI0MptZfw+tXl+RzH/C3I/qKB7lGwnCq0Uh6citHzYfWsS8g+zyZBwjdD/Sqe8f36DPVaH//0P3tivUbiT5T69qufK47EGqsltDMNycE9x0qk0VxbnK5x6jpXRywlscvPKHxao12VSuwjg8VmxbrKcxP/qn6H3ojv2HEi59xVpbq3kGCcZ7GodNo0jVjLqVrqN4JBdwj/eFTyILmJZYDhhyp/pVoFXHGCKpxQvbTERjMT/oayNj8c/2i7Rrb4nXMj9bi3t2P1SPyj+sZrwqvsP8AbH0FbDxrp+qQxlI54pIMnoShE385yPwr48r+yeG6yrZXQmv5bfdp+h/m5xphnh89xVOX8zf/AIFr+oV+jn7O/j3SPGHhKz8L329LzwvZmJg3KPF5ipGwOeysVxjgAc1+cdegfDXxy/gDxINYaBrm2nhkt54o3COY5B1QkEZVgGGQc4xXi8XZM8wwXNT+OF2vPuj6Xw74kWUZooVv4dW0W+2uj+V9fJn6IfEH4pWPwr+Hj6jpAjl1O8byLRT9wSEEl39lAz7nA718N6v4E8Z+K7iXXte120vNRn+aXz7kZQn+Ek/KuOQF6DGBVn46eI31TVNK0VLKbT4tOtRJ5cxz5j3OJPMBAAYFduCFA9BXjml3Jh1CJ5riW3jdgJZIn2PsJ5AP09a+a4dySvh8uhi8PNRqSu23HmduiWummrtq2z7fjLibDYzO6mX42nKdKDUUlLlSl1b0d3fRX2sev6Ddaj8EdS0zXnuYL+XURm606Mh45bTJAYSgEBgynHDA8+ma+3dF+P8A8KLjRI9XL3GiGQDia0n2ZJKf62FZI+qkcsOnSvg6fVfhjqcCQXWnXVoYPlWVbuSSUjJJ+RlaNQSSSATyfvisDxr4qGqyDQtJAg0bT2McCqT+8A4Ej+pwOPT3615E8hjm1SMnCcakm3Oco8qt2S89Ldj6OHFtTh6jKKqU50oxUadOEuZ8z6t2T01vor32P0i8N+Jtb+Jdy+qaPr9pF4Xs2/fGF3luZCP+WbhtoiU98qSR0x1ryr4wavpn/CM6pqeiR/2R4j0CePN3a/up0fqm50+9DPHnbngOu3kmvnX9nXWNa0bxVq91phP2ePS7ua4H8B+zr5sWfcSAY+p96674xazBpd5Legf8S/WLS50WUf38Rx31gf8AtkskYz6knvXwmYZX/ZebRw8Jc2sWvn0a/q5+qZRnyz7h+eNqx5G1JOz2aW6e/mj6B+GvxjtPFfgOfWPEWoY1GzikjlikOf3ka5Dj1B4PtyK8M+PMfhTyLi1nuwNUtIBNZ5/1k8Fw8WxT67Y2lH0UV5n8CPGVv4V8T3FteaJJr8WoxeUII/LBEgPDEyFVVcEhmzwpJweled+ONcvNf8S3d5ezx3DxYt1kiz5ZSD5AVyAcHkjIHWvsKfCl8+lRjpSjafyey++69EfnFbxA5eE4YqbvXneH/byWr+5p6dWclRRRX9EH8bHu37OVm118T7R06wW9wQfQyL5Q/WSv2TknSEfvDz6Cvyy/ZB0YXfjDUdWkjJSCKOAHsC5M3/tAD8a/TuC3e4PmOePX1r+ZOOaiqZk0/spL9f1P7k8LKMqORqSXxyk/0/Qm86e4O2L5B6//AF6k/dWgyxLNUU10ka+Xb8e9QQ28k3zHgHua/NeXTXRH7ZzNOy1Y972eQ7Y1x9OTU8MNyfmlkIHpmnF4LQbUGWpvl3FzzIdielD200RSWvvO7J3u4I+N2T7c0RyzSH/VbV9Sf6VFvtbXhfmf8zVd72VztjXb+pqFC+yLdS3xP7jUZEfBYZxyKp3Nl577w201AsN1LzI5UH1/wq1HAlv8zSH8TgVDil1NVNvpoV76OUxpFCpKr1xTYVa1t9+P3snAH8qvm5gXq4p6skgDKQRUWkWmnszMum8iFLWPln6+/wD+uphH5cUdov3pPvH27/4Vaa3haUTMvzjvTQsXntJuyxGMHtUlk4AAwOAKdRRQBTWRnvGiH3Yxn8TUSNsS4uD1ycfh0p0COktxK4+8ePoKgnSQWMcSqSTjI/X+dADID5FjJOerdP5U7PkabnoZP/Zv/rUXsb+XDbRjP+cVLcxl5ILdR8g5PpgUARTn7NYpEfvt1/maSX9xYKneT+vNJdxyTXSR7TsGBnHHPWpLuKS4njTafLHU/wA6AFiXy7RY/wCKY/z/APrVX1GUB1hXoorTKs1wrY+RF4+p/wDrVnyWE0s5kcjBPrzj8qTAdEfstkZj96Tp/T/Gm2arDC93J+H+ferdza+fjL7FT2p7wwzoEByq9gaYFO2Yqkt9N1PT/P6U63Zo7d7puXk6f0qRpraNfI2ZCdu1WQ2Yd0OOnA/pVcrW5mpp7MpafC67pZAQTwM1q1St7nzSUfhqqXUTxvuyWU9M9qtQ15WQ6to80VcusscUpuJW5PA9qfF5LAzRAZbvUcTrcwFX69D/AI1UgdracxydDx/9eqUN11E6lmn0ZfgmEwORhl4IqxWfco0Li4j/ABq5HIsqB16Gs5Lqioy15XuU3JtZ93/LOTr9aW6gEq+bHyf5irckayoUfoapws0D/Z5Oh+6a0TvqtzOUbe69mSQut1AUfr0P+NVIXa0mMcnQ/wCc1NMhtpPtCfdPUVLNEl1GGQ89j/Squl6Mhpv/ABIhvIMjzk7df8alhkW5hKP16H/Go7WYqfIl4I6Z/lTJontn8+LpRb7L+QX+2tupaX51ME3Jx+Y9aqAvZS4bmM1cylygZTgjoe4NGVlBilHzDt/UVCdtGauN7NP0EliEwEsRw46Gmx3CyExTDD9MHoahAksmz96I/pU8kMVym9Tz2NOy67Epvdb9iCW0ZT5lufwpIr0r8k46d6RbiW3by5xkVaKW90u4c+461T/vEJXd6bs+xOkiSDchzSqqrwoxWVJaTQnfEc/TrQl7KnD/AD0vZ31iy/bW0mrD5ont5hcwrkH7wFTXMIuYhLCfmHKmlS9hb72V+tWUaNh+7IP0rFxa3Noyi9mVIJUvICkg56MP606GQ5NrPyw6Z/iFMmhdJRc24+b+JfUVBqlzY2dr9sv7mOzSMjEkriNQT2JPHNSaF2MGFvKb7p+6f6VTdTYz+av+qfg+1WLeZbqIFupAPHQ+hBqfhwYJecj8xQAh4IlXkEc47j1qreW3mjzofvj0706Ldav5TcxOflPofQ0l5fWOlwm71C4jtYM4LyuEQE+5IHNAD4JUu7cq/Xo3+NQW0jW0xtJeh+6af5fzLd2ZDhxkgHhge4NT3NutwnPysOh9KAK0ytaTfaIx+7b7wq1ICwWeHkgfmPSm25ldTFcIcjjPYis27vrLQIzPqdxHb2ROPMlcIiE9iTgc0AaUkcN7Fn8j3BqvFdPA/kXfHo1TfLIourVg4kUHg8OD0IP8jUzxx3CASp+HcUASSRJKu1xmmxrIg2udw7Hv+NPVVjUKOAKh88O2yL5j3PYVSVxNpbgLSAP5gTmpJJVTg8k9AOtRvKQfKj+aT9B9aheRLYEk75W7/wCe1NRMpTsWfM2JulwvtVN7ySRtluPxqqBNdyc8/wAhVtnitF2xjL9//r1vypepz+0cle9kOWJYR5ty+TUUl+x4iGB6mqwWW6fPU+vpV1YoLUbpTlv89KbSW+rJTlL4dERxJdTHczlB/ntVsyxQDa75P5mq3mXF0cRfInrThFbW4zI25vf/AAqXruXHRXj97JFuXkP7qIkep4qyVDrtcdeorOkv26Rpj3NNVbyfncQPypOHfQpVei1LlxbCaMRg7QOlQmCSC1MUXzOeppUswh3vIc+3FWDcQL1YVk49jdS/m0MyzhMZaecFAnrU/m+XA92/3n6D27f41eSWOXIQ5pssEUwCyDIHSotYta7GfajyYXu5OWfp/n3NaEMflrtPzE8k+ppkiR5j3naIzkDt/kVaoBBVO4lKtFCv/LQ8/TvVyqMkbveRvj5EB596BikF70Z6Rrn8TVa3/fXks56L0/l/KrPzL58wBz2/Af41UjR4dPbCndJ2+vFAD7Rg7zXTdP6U21bZBLeP1b/P86Xa8Wn7QDvk/r/9akukdLWOCJS3rgen/wBegBLH93BLct1/wpLAbVkuZO3/AOs0+aKRbGOGNSxOM/z/AJ1N5DLbxW6jjI3fTqaAIbhzDaBT8rynJ/Hk/wCFQ6egy9w3Rf8AJqzeWs1xIuzAUDvUn2Yi0Fur7fU9fr6UAUrcG7uTM33Qc/4CpY2+13e7/lnF0q1DDEkJt1fJ7kdabm3sh5ag80JN6ENpK7ZFC32m7eX+CLgVDCr3F35zqQg5GfbpWhbSROh8oBcdRUIunSYxzAAeoq1BvQTmlZmhVeaJZCrucBOcVXvInK70Jx3FNsZsjym/Cq5NOZEe097kaJ1a3nkDDlk6Zp4n/fGJxg9ves+ZGtpxInQ8j/CrkyCeJZYuo5FPlXyIU5O66ouVSulZCLmPqnX6VJbTiZOfvDrVggEYNRrF6mztOOhVZY7uHK9e3sahtJSpNvJwR0pCptJd68xN19qluId4E0X3l5471tpt0MNb83VFWZGtZhKnQ/5xVuVEuoQy9e3+FLG6XcRVuveqkbPaS+XJ9w9/609X6onRf4WPtJsHyJPw/wAKsp+5fYf9W3T2PpUdzb7/AN9F9/270sMy3CGOTr3HrUvX3kXG6fI/kQTwvBJ50XT+VWgYruL/ADwaUMUOyTkHof6GoJIHhfzoPxFF777hblu1t1Qw3Mtv+7lG/wB/UVaiuYpeAcH0NIk0FwnzY54warS2HeI/gaej0loF5LWLujR2qW3EcjvVa7thcJx94dKzxNcW5w2foatJqCniRCPpzUum+g1Wi9HoOt3+0QmGcfOvBB/nUVu7Ws32WX7h+6auLPBIQVYZ/Wi4t0nTY3XsfSsGmtzdNPVFeTNrL5w/1Un3h6H1qWRSrCeLn1A7j/GiAStGYrheRxnsRUMXmWr+S+WiP3W9PY0FC3UHnoJYfvryCO9PglF1D83yuOvsfWpT+5Jb+E9fb3/xqCaF0k+0wfe/iX1FAFgYcbWALDqD/Ol8pf8AnmtIpSdA6kj+dL5I/vGgD//R/eNori1O5D8nqOn4irEd8p4lGPcUsV8pOycbDT5LWCYbl4z3HSulvpNHFFNa0n8hTDaz/MuM+oqu+nt/yzb86rvaTxHcnOO4qWB7x22qeB1zVJNaxYnZu0o6kf2S5U5UfiDV6CKdfmlkP061cGcc1DLMkXDnk9AOtZObloaqlGGp8e/tieEpdY8Dx67bo8j6Y6SnHQIpKt+JEm4+0dflxX7zeK9JtfEGhXOjXsQmF0hUIcc7hggnBwGBKkgZwTivxL8f+Dr3wJ4rv/Dd6GxbsTCzDBkiP3Xx644I7MCO1f0HwBmSnQngpvWOq9Ov3P8AM/kHxcyWVPFU8zpr3ZLll5NbfevyONooor9nP5mPXtX1GTxh8MbO8vf3moeFZo7QSn772Vxu2ofUQyAbc9pcdAK8uv7KWwkjjlB/eRRyg+okQMMfTOPqK6bQbu3tvC/iOO5nUfao7eKKInl5PN3ZA/2Qpz9a0LeXRfFekW1hqd7Hpmr6fH5UM02fIngH3FcjO0r0Bx+eePiMNOpgXOHK/ZRm9leykk18k21psfqWOpU81jSquSVedOL1aXNJNxau9LtJNX6o88r1z4d6F4c8Sao9vc6RqF7G8e1obUJOUfjEiESRygD3jYYOMk81l2Pwl8d6s2dGsI9Qi6iWC4heMj1z5nH412Ok/CS10CZNT+ImorBbQHP2SxkWWeUj+AzA+RCPVmfPoCa487zTBVcM1RxnLLpyNNvystfnpY9PhbIsyw+OUsTlznDrzpxivO7023TTVj3/AFWw8NfDD4ZeJJdB046fvsrndJM/mXEsphMaCQ5IUK0qr5YPG8E/NkDwf4ua1pur6DpTWB8yOWQ3CkjqEt7exjYZ7FrKbB71r+KfEF98SoT4f8NxRaf4fsBGbu4GUs7a3gyYoUJAZgpJYkjfNKc4wFA8V8Xa1a6repDpqFLCzVILcP1EEQ2xg44yeZG/23kwSMV+b5Hk1etmFLEYqTdS/NJPVqKWnN2bdrLfQ/auKuJsLhsoxGDwMIxo8vJFx0UpN6qNrXSV7vq2jrNBMPhn4a6v4h4Goa5N/Ztqe6RJhrhh6ZGI/wAa8mr0bxPfW994J8LxWMkfl2K3EU0YceYk7vkll6/MBkHGMcZzkV5zX7XlNPSrWn8UpSv6J2S+5I/mLiCsr4fC0/gp04283JKTfzba+QUUV2fgDwde+O/Flh4bsg2LiQGZlGTHEPvP9ccAdyQO9ezWrU6MJVKjskrs+Yw2Gq4itChSV5SaSXmz9Df2QfBsmmeCDrl2jR/2kzzc9HR8Io/AR7h7PX1xcXJc+VDwvTjvXPaBpVvoGi2ehafGkcdvGiFV6ZAAABwMhQAoJGcAZrpkjS0TzZeZD0FfxxmWMeLxdTEz+020j/SXJctWAwFLA03pCKTfd9fvY2G1WNfNuOB6f409p5Z28u3GF9ajRJbxvMkOIx0p8l0kI8uAdO9eRu+7PodEuy/Fj1jhtBvkOX/z0qpLdPMdq8A9hSRwS3B3fmTVzNvZjH3n/Wq0T7sWslpoiGGzd/ml+UenepjNbW42xDJ9v8agzc3h4+VP0/8Ar1+SP/BS79sH4zfsq+JfAel/Ci4sYovEFnezXf2y1FyS8EkSrtyRgYY1nJ/zMqEf+fa+Z+uPm3dx/qxsH+e9PWxH3pmya+H/APgnp8ffiP8AtJfAGT4ifEyW2l1dNYvLLdawCBPJgSIqNgJGcuea2v29fjV41/Z6/Zx1j4mfDye3TXrK8sYYjdxC4j2XE6xyZjJA6Hj0qeftoaez/m1PsndZRdMfzp4vIO2fyr8af+CbP7b/AMcP2mfiV4q8LfFafT5tP0jSFvIBZWa27CU3EcfJBORtY8V8c/tVf8FJf2tvA3x88f8Aw78CeJbXR9H8Pavd2doItMtJ5RBA5C7muIpcnHU4qW+rLSd7Jo/pfW6gdtobk0ssKSj5uvY+lfyqfDb/AIK5ftZ+EdbtrrxzqFh450oMnn2t3ZW1nI0efm8qayjh2OR0ZlcA9VNf0x/Cb4p+F/jH8NvDnxP8KSN/ZfiO0ju4VkGHTeMNE3bdG4KNjIyDip/wlva0z04Zxz1pkisyEIcHsa/Fn9t7/gqdq/wP+I+o/B34JaJY6prGhlI9T1PU/Nkt4rgjc1vDBE0RZkBG6QyYDZXYcZr53/ZX/wCClv7U/wAX/wBobwL8PfFs+ltoPiDU0troW+nCNvLZSSFk3Ejp15qDQ/ojtZ3d2jlPzCmTXM0MuxsEdfwr8U/+Cj37c3x5/Zj+O+j+Bvhbc6fBpV94fttSkF3ZrcP9oluruFiGJHG2FePXPrX6B/sWfFjxl8ev2XPBfxY8fNDLr+tDUDctbxCGJvs2oXFum2ME4+SJc+pye9dCcHM5XGoo76o+sp5XSLzYsEf0o80tb+bH1xn/ABr+fH9un/goh+0t8Ff2ivFfwh+HGpafpWiaGth5EjWEdxcN9psYLl97zb1PzykDCjAwPeviGP8A4Kk/txxTeYnxDj8vr5f9j6Vs/wDSTd+tQ7LQ0V3r3R/XVazmZDu+8KiindJjDMc+hr+dv9m7/gsJ49h8Y6Z4d/aK03T7zQNQmSCbWLGJrW4sxIQPOliBaKWJOrBFRgMkbiAp/oR1DUdMj0hvEbXcQ02OA3LXG8eV9nC7/N35xt2856Y5q1yN2IftFC/VHR0yRBIhQ96/mw/aE/4LC/FvVPFWpaJ+z7bWOg+G7SV4rbU7m2+1X92EJAm2TfuYkfqsZiZgOrZ4Hy9bf8FR/wBua3mE8nxEWdSfuvo+lbDjt8toD+RrHZnRutT+uO0lyDBJ94VDk2c+P+Wbf5/SvhD/AIJ7ftBfEX9pH4Cy/Ef4lyWsms22s3enb7SD7OjxwRQSKWQEjcTIc4wPapP27P229E/ZL8F6aNLsIde8beIy/wDZ1hM7JFFFF/rLqcp82xSQoUFS5PBAViOi/XozjSb93qtj7wu4N486P8fpUNnP5beW33T/ADr+TXW/+Cqn7bWtXrzaZ4xttDickrb2Wk2Lxp7A3MM8mB7ua9t/Zb/4KSftX+Nfjr4F+HvjfxDZa7pXiXWbLT7nztNtYJBFcSiNyjWscOGweCQR7VMZJrlZU6bT9pE/pgu4SjeenHr9fWrEMqXKFH69x/WvmT9q39pCL9l74K6h8V59CPiR7S5t7RLMXH2YO9y+0Ey+XLgL3+Uk1+Cfi7/gsZ+03rF0x8JaVoHhq2BOwJay3c+P9p5pTGfwjFDdlaW4RV3zQ2Z/TyN9pNzyP5irtxCJ4xJHyR09xX8kE/8AwVM/benuxeHx3CkAP+pGj6b5R9sm2L/+PV90/slf8FdvEms+MtK+Hv7SNnYpYaxOLePxBaj7ILSSTiM3UPKGIsQDIpTYOSCATUud9eo1StePQ/fS1mEi+TJ1Hr3FR/PZy+sbVj+LNSTw74e1TxP5ZlXSrWe7aNTguIIy5APYnGK/nR+In/Bab416281v8OfBei+G7R+Fa9abUrlfcMGt4gfYxNj9apyW66goN6PddT+lcEMMjoajliWVdrfga/kYvP8AgqT+3DdzG4s/HkVlEp3eVBo+mtGvtmW2kbH/AAKvpT4Cf8FjPjBoXie10/4+WFn4o8O3MsaT3lnAtnf2iE4eVViHlTBRyY9ik44YVjs9DptdWZ/SfGxIaCbkj9RVPL2cu3rGf8/nTNI1fSvE2jWHiHQrtL7TtSt4ru0uYTujmgmUSRyIR1VlII9Qa/Kv/gp1+198ZP2W7r4eWvwpnsoU8SJqjXn2y2Fxk2ZtRFtyRj/Wtn1/CrUl1MZQb23R+sUsUd0gdDz2NJDMWJhm4Yevevz5/wCCc/7RfxI/aP8Agfqnj74nS20+qWuvXOnp9mgFvH5EVtayp8oJ53Stz9K/Mfwv/wAFMf2pLb9pXSfhR4+vdKbRrfxZFompbNPWKUW4vhazkMG4YLk/Wreis9iE7ttb9T+jmSJ7Z/Oh5XuKsK0V0mR1H5g18u/th/HS/wD2df2dfF/xM0xov7asII7fTfOXejXl3KsMRK8bhHuMhHcKa/Kn9hj/AIKRfG74y/tG6J8Mfizc6bJpfiK3u4bf7NaLbMl5FEbiLLBjkMImjA7lh3xSb77glbWO3Y/fhZCD5c3U9D2NQvDJC3mW/I7rX5yf8FJf2rPHv7Mfwt8L6z8MZLSHX9d1j7M32yAXCfZIreV5cISOfMMXPbkd6d/wTX/aM+Mv7THww8UePfi5PaXEdhq402yNpbC3A8qCOaXcATu/1y89sVG2hdrq5+jySQ3K7WHPoaqSWssPzwEn+dWZrZZP3kR2v1yO9QrdSQny7kfjWsf7plNJ/wAT7xsd+y/LKM+4q1/o1x6E/ka/JT9vP/gpTa/s5eJJPhL8KtKtdf8AGsUMct9dXu42eneem6OMxxlGlmKEPjcqqCudxJUfkBqP/BUT9tm/vDdW/jqGwjzuEMGk6aY1HpmW2kfH1Y1LcfQpRqbOzR/XE2nj+BvzqA2c69AD9DX8sOk/8Fef2wNN8PXWjXV5oup3k/3NRuNOAuof9xYnjgP/AAKE19NfsEj9tj40ftN+DPjx8ZG8Q6x4Hit9SmW+1A/ZtNH2izmiia1tsxREM7AAwxY79Bml7RoHQi+lj+gqGC56s5QDtmv53f2/v2iv2itL+GPin9nX9p3wTZ2d34g1CPUPDeuaNP5llNaW12sphcPhj5cZ2ByEfgboufMr+jF3RFLOcCvwl/ay/wCCdB0r4P8Ajr4j6TdeIvjD8VNd1O3+w3F20lxcWmnvdhvLjiQsXKQ/I0jEjH3EiBxUNuWprGKhpc+m/wBjj9or9or9ofxNomvaB4IsvDfwI0fTn037Xfz7tTv7uCNY0lhCZ+66AFNoQKz/AL2RwoH6fSSLGu5vwHrX53fs8fsNeFfgd8SNJ+Mvw88Qax4X0vUNKzqvhLzZHsZr+aFQJH3tuAiJc+WwYh8bWVQUP6DoeDdTfgPQVSj3E59EWHm8uPe4wT0Ffzoft+ftE/tGaZ8MfFP7O37T/gmzsrvxDfx6h4c1vR5xJZS2ttdrKYWD/MdkZ2ByEfgb4uS9f0TR/Pm6m4H8Ir8Mv2s/+Cc50f4P+OfiLpl14h+L/wAV9e1O3+wz3TyXFxZ2D3Ybyo4kJ8xo4P3byMSMf6tIhxUuIRlfVn0n+x3+0d+0V+0J4l0PXdA8EWfh34FaTpz6aLq+n3anfXVvGsaSwiPP3HQAptCBWf8Aeu4UD9QRuQYc7pG7dv8A9Vfnl+zx+wx4X+BvxI0n4x/D7xBrHhnTdR0v/iaeEvNc2M+oTQqA7b23AREufKYMQ+NrKgMZ/Qsb419ZX/If/WFML9RzuwGxfmk/Ifj7V/On+39+0T+0Xpnwx8U/s7ftPeCbOyu/EGoR6j4c1zRp/MsZbW2u1lMLK/zHy4zsDkRvwN8XJkr+jBIwq46k9T61+Fn7WX/BORtJ+EXjr4h6Pc+IvjF8WNd1O3+xXFy0txcWlg92H8qOJGYsUg+R5HJGPuJEDipfkaq/U+lP2Nf2iP2h/wBobxJomueHfBFl4a+BGkae+m/a76fOpX91bxrGssITI+R0wU2hArN+9dwAP1DyM4r86PgB+w/4W+BvxM0j4t/DPxBrPhjTdR0sf2v4S8520+XUJYVAkcO2QIiXPlMGIfGxlUFD+g0zG3iEWcyP1NUoMydVK/kMmka4l8iLoKlZhCBbwcse9IuLOHc3+sehf9FjM0nMjVr5I51e93v+QOyWibV5dupqnFE9w/8AM0kaSXEvueSatzTJbJ5MXXuavbRbmXxe9LZCzTJbL5UPXuf896hgtmmPmScL6+tLDbrt86fhae0kl23lxcRjrRtovvK3s5fJD3uMfubUZPrQtsq/vbl8mlLw2S7F5Y1SJmun9T+gpJdthylZ2er7Fia9JOyHgetQxW0sp3HgHuatJDDarvlOT/npTGnnnOyAYFNP+QTV3eo/kTBbW05PLfmaiN1cSnbCuP1pyWkcY3zvu/lVlWYj90mB6nj9KzbW+5soy22Kos5JDunb+tP2WcP3sE+/P6VKyKOZ3z7dBUX2i0j+4B+ApXbHyxj/AMEeLq2HC/oKcbuDu+PwNRfb4egBqT7ZGf4W/Kly+Q1P+8iwypKuG5BpsUflJszkDpUX2qEdWx+BqdXVxuU5FQ00bJxbuh9ZolmiuRFK2VNaVUryHzI9y9V/lVQtezJqp2vHoF1LLEQU6GpIpTNBvT739ajjIurbaevQ/Wqtm5jmMT8Z4/EVpy6W6oy5mpJ30Zdtp2mU7uGFRQ3DmYwy4z2xTX/0e6En8MnWkvEKkXCdR1/pSsm/UlyklfsPmnkgmBbmNqughhkdDVaRRdW4K9eo+tVLSfY3kv0PT2NLlutN0ac/LOz2ZrVmo32e4MR+69aVUbyLfHvHVP5VMHrZl1U7cy6Ed1G0MguYvxqVwl3AGXr2+vpSWswnQxSckfqKgBaymw3Mb1rrt1Rz6b9GVopGt5c+nBFaFzELiMSx8kdPcUXNusy+bH97+dV7SbY3kv0PT2NNu/vLchR5XyS2Y+0uOkMh+n+FR3ELQv5sfT+RpbuHY3nJ0PX2NT29ws6+VLyf50be/ELX/dz36EgKXcHPX+RqrbOYJDBLwDQVeyl3LzGasyxR3UYdDz2P9KWi9GXq9ftIjuInif7RD+Iq3FKsyb1qpbXBH7ibhxwM0kkb2z+dDyh6ipav7rLTt70dupfZQw2tyDVWMG3fyzzGeh9D6VYjkWVQ69DTmUMNrDINYp20Zu1fVGfcRtA/2iLgd6nVoryLB/EdxUwX5fLbke/pWVIj2km5enY1sve06nNL3NbaMtRu9s3lS8oehp09uWPnQcP1+tOimiuk2N17io8yWh+b5ovXuKet/MqytZ7fkSQzrMDFKMN3Bp25oOG5j9e4+tJLCk6iWJsN2YU2K458mfh/51Fr7FXa0k/mJParMN8WAx/I1UWe4tztlGR6H+hq1MWtR5kXKk8r/npT0uLe5GxuvoapN211Rm4q+jswS6t5htfj2NMeyhfmM7fp0pklgp5iOPY1SKXNsc8ge3SqSX2GKTa0qK5Yawl/hINNS2u1OF+T8f8ACrlsbkjdMePTHNXal1GtGONGL1WhFEjIuGYsfeparidHk8uP5iOp7CoXczy+RH9wfeP9Ky5W9zfmSWhdyMZqJJRISV+6O9VWYzyeRFxGnUj+VI589/ssPEafeI/lVconPsTiSSUnyeFHc9D9Kdi5/vr+VR/M58q3O1U4J9/Sl8q5/wCetWSf/9L98niguVz39R1qi1tdW53QnI9v8KvMizDzIm2t6j+tOhM+SswHHcd61Tsc8oKT1+8itZppc+auAO9XaKzvMN3N5a/6pevvU76ml+VJPVlt5UjTeenb3qjCNzG8n7dKbK5ubgRJ90f5zT5z5ki2kfQda0StoYSld37fmLB87Ndy9B0r5W/aQ+C8nxD0I+ItFiA1ewy8eOPMTvGfY9vRuejMR9UT4d1s4uAOtNuyshFmgyOhFelgcbWwleOIou0l+X/BPFzXLcPmGFqYPEq8ZafPuvNdD8CZ4JraaS2uIzFLExVlYYKEHBBB6EGoq/TD9oL9m238UGfxX4NUQ6rGu6aM8JOB/ePZh2b0+9x8w/N3U9M1DRr6XTNVt5LS7tztkilBRwfoa/q/JM9w+Z0eem7SW8eq/wA15n8AcT8LYvIsS6dZXg/hl0f+T7oo0UUV9QfBmtpes3ek3AuIBHIRxiVA4x+PtkewJx1NdHd+M4LphI2hWO/vmM4PtwQR+BFcNRXzlXIsBUquq4Wb3s2r+tmkz7ahxZm1KjGgqvNGO3NFSt6NptfI39R8Ua9qluljc3jJZR/6u2i/dwJ/wEdT7sS3vWBRRXrYXB0MLT9nQgory/XufO47McVjavtcXUcpba9F2XZeS0Ciir2maZqGs30WmaVbyXd3cHbHFEC7k/QV1ykopyk7I4IQlOShBXbK0EE1zNHbW8ZlllYKqqMlyTgAAdSTX6jfs5/Bo+AdF/tjWoh/bOoANJ38sfwxjHYd/VueiqTh/AH9mxfCscHi/wAWxpcavIMwx9Utwf7p7sf73/fPHzH7Qs7XyfmYAY4A9K/nniziiOKvg8I/cW77vsvL8z+xPD7gSeAtmOPjao17q/lT6vzYxESyj8yTmQ9BUUMTXTmec/KKne1lmk3yOB9PSrEsBeIRRnYtfj3N5n9GKD7aIoXV0X/dRcL/ADp1vaAjzZ+F9Ksw2SxNuc7/AEpZ7eWY43gL6U+ZbIn2bfvSRWkuXkIitRj/AD+lPjtYoh5lwcn0/wA9atLCIExCMn3pqxlR50v7x/bt9Knm7F8jveX/AAB4Mkn+wn6//Wr+dr/gt35P/Ca/CpYjuxp+qZPX/lrB3r+hrbcXTfPmOP0r+ef/AILewrF4z+FOxcA6fqnPr+9gpPTQ0i23c+yv+CPUU0v7I0oEm2P/AISPUenX/VQV1n/BWK2jh/Yt8SMuSf7S0rk/9fS1y/8AwRxlil/ZIuUjcMYvEuoqwH8J8m2OD+BB/Gup/wCCtNxBD+xjr8UsiI0+p6UqKxALsLkMQB3OATx2BNRzPYvkV7n5wf8ABEof8Xw8f/8AYuJ/6Vw1/SNDZWls0kltbpE8zFpCqgFyepOOp+tfzbf8ETZEj+N3j9nOB/wji/8ApXDX9IbXxZtkCbj/AJ7U1FvYJTUdz+YX/gsX4F8K+Ef2lND1bw3psOmzeI/D8N3fCBBGs9ylzPF5zgDG8oqKT32gnnJP67f8EqLua5/Yi8ExSnItrnV4k9l/tCd/5sa/K/8A4LVed/wvzwOZup8Mp/6W3FfqB/wSlnih/Yo8IhidxvdW4HP/AC/S0ra2Qc2l2fz/AP8AwUC+GHjL4aftX/EJvFdpNHb+JdXvNZ064dT5VzZ30pmTyn6N5W/ymA+6ykV/Qt+zn+35+x747tfBvwr+H2qP4e1rUo4bKy0B9Nuk8iXb/qfOihNvxg/P5uD1Jya/B79vD9p34jftJfHvWvAd3qTWng7w5rU+maRpwfy7ZTbytbfa5sfelk5Ys2dinauBnP7ffAj/AIJc/AD4G+J/DHj+31LWda8W+G5Y7kXEtxHHbvcgEEiCOIYjyThS5IHVjUl3Pyw/4LS/8nVeHP8AsT7D/wBL9Qr9hf8Agl4GH7DHwzycgjWMe3/E3vK/Hn/gtGSf2qfDZIx/xR9h/wCl+oV+w/8AwS+P/GC3wyJ9NY/9PF5QB69rnxe/ZQ8N+MNQl17xv4JsPEUExgvhdanpkN9HLB+6Mc3mSCUNHt24blcY7V0tj8Vf2ePixcDwh4b8Z+FvGN1NE7f2ba6jY6hJJEgyx8iN5CVUdflwB1r+Qr4s6fJ4+/aw8ZaTqVz/AGdL4j8a6hbzTsu/yDd6k6M5XK52bs4yM46iv6Dv2Sf+CYMf7LHxks/i4nxJPic2tpd2n2I6P9j3faU27/N+2TY2+m3n1FXzdTL2as0fit/wUd+FPgv4P/tV+I/DvgDT4tH0TULaz1KOygXbBbSXMX71Il6KhkVmVRwoOFAUAD97/hprHiDxx/wTBh/swn+2ZfhteWVvt+ZnkttPlto8d9x8sfie9fit/wAFcJrZ/wBsnVoLdwTb6RpaSKP4HaIyY/Jgfxr99P2EbKax/Y7+E0hXax0aKT8JHdgfxBFNJN2FJuKTP5Yf2UPiN8OvhL8f/CXxB+K2jf274Z0iaZ7i3EUdwVaSGSOGYRSEJIYZWWTB/u5HIFf0uaJ/wUs/YT8YW8Wk3/jSGzWTCi21HSr2OIfV2t2hA+rV458a/wDgkR8B/ir4kvfGHgLW77wBd6lJJNcWkEUd5YCaQ7y0ULmN4gST8qy7BwEVQMV+W/7XX/BNDxV+yx8OH+J8HjS28V6RbXUFtcobJrCeP7Q2yORU86dXXdgH5gRnoecTZ7F3W9z+n74f3Pw31nwtDrHwtfS7jw9qhNxFPo/km1mc4BkBg+QtwAT14welfzlf8FodP1m1/aJ8IXl0S2mzeGYktzjC+bHe3RmHucNGT7EV67/wRI8feIP+Ej+I3wvmuJJdENnbavDCxJjguVl8iQr2BlVl3euwelfsX+0j+zD8KP2pPB0HhD4pWMsgsJGmsb21fyruzlddjNE+GGGGN6MrIcAlcqpAn0Bx15j8gv2BP26v2Rvgn8BdI+HvjqObwn4rspbk399Hpz3CagZZ5JI5TNbLJKdsTKmJFG3bgfLiv1G+FH7SH7IPx/8AEVrbeBPEOg694jibz7WOe2+z6gWj+bfFHdxRTFl65UZHWvzD8R/8ESdONw7eF/ixNbR84ivtIWU+2ZYrqP8A9F1+NXxJ8D+Nf2avjVqvgufUlg8TeB9QXyr6xdgBLFtlhmiYhWGQVYZAI6Grd0rMhWb5on9l/wAcNHsr/wCEvjS3v7WK8tJNHvy0UyCRMiCQjKMCDg8j3r+SL9g62hu/2wPhXa3CCSOTWYwysAwPyP2Nf1h6l4om8Z/s3ah4nvUEdzrHhOW9kUDAD3FgZCAp5GCelfye/sFuY/2w/hS69RrMf/ot6JN3SYoJJNrY/sSvdJsJrWTS9Qs4bmymQpJBLGjxSIeCCpBBB9CK/jX/AG0vBPhv4dftT/Enwh4Rs49P0iz1R5La2jG2OBLiNZ/LjHRUQyEKBwAABxX9pamG9i5HP6iv44v+CiKGP9tD4pIe2oQf+kkNEnffcmnHlemx/Wl8Htdvdd+FfgvWdYbfc6rounXUjHnLz20cjfmTX8h/7dOn2GlftdfFOw0u2js7aHWpvLihURxplVJ2qoAHJzX9cnwFEN38CPh0vp4c0ge4P2OKv5IP29EMf7YfxXQnONal/wDQVpSNYXWnQ/rx+D8dm/wm8H20cSxp/Y2n5QAAc20fOBX8u/8AwVS+Hvhj4d/tbapD4VsIdOttc0yy1OaGBBHH9om3xyvtHAMhj3NgDJJPUmv6iPhhblfhd4OuIeCNG08nH/XtHX81H/BYWRpf2tLaRlxnw3p34/vbim1pdERetpbn7vf8E+tYu9c/Yz+FN5fHdJHpP2Uf9c7SaW3jH4JGK/Lz/guT/wAhP4N/9cde/wDQrGv0e/4JxTH/AIYo+F1xA3mxfY7xDjsUvrhT+RBr82v+C4F5aTav8HreKVGljt9ckdARvVXeyCkjqASpAPfB9KhrqaKV3Y+mf+CNEAn/AGUNdxw48XX+D/25WNfir+3j4eu/hp+2t8RlsgbeZdYj1iFv9u/jjvtw/wCByn8a/bP/AIIv/wDJqevf9jdf/wDpDY1+dn/BZnwf/Yn7T2i+KYY9sXiTw7bSO3964tJpoX/KIRUX0sHKr8x9G/8ABYz44Weu/DL4VfD7RZf3fiUt4luEB5WGOERWufUOZ5T9Ur8otQ8K+Mf2Rfi18KvHd+G+1S2GgeM7RcbGaC4ImMLfijxsPwNaeq+JNa/a4+N/wn8CkylY9N8MeEIifvJHaxRRXUv081ppc+nNfqh/wWf+FtqPBfw0+J+jWiwR6JNP4fn2DgQTR+daL7KnkzAdvmptdUJStZS3OB/4LUeO9N8R6r8H9H0a4Wezk0y/1hGQ8SxX7QJC/wCULY+pr9Df+CVnhf8A4RH9jHwld3EXlSeI7rUdTc/79y0EZP1ihUj2r+Zn40/GC/8Ai7Z/Dz+0t32jwd4WsvDp3dCthPcGNh65ikTJ9cjtX9hf7MXhqLwP+zx8NvBUkflT6X4e0yGZT3n+zIZj+MhY0IG7aXse77cDdFjnnHY0h8qceW459D1qIxSQHfByO6n+lPBiuV9x+BBot1Jv0P4kf2iL3UfHX7T/AMRJ55N9zqvivUoULfwq148US/RFwB7Cv7GvhR8J/Avwd8Had8PvAOhW2l6Vp0CwERxIkk2AFMs7AAyySYy7NkseTX8Y3xjv7jSf2gPHGp2uDPZ+J9TmTcMjfHeyMMj6ivsNP2bv+CkH7Uo/4WRq2k69q9trn+lRT6pqUOnxFJOVaG2uJ4dkRH3BHEE2428YoTNHG9rM94/4LKfBfwP8PfiP4E+IPg/SrfSJvGttqKahHaxpFFNcae8B88xoAPNdbkBm/i2gnnJP6B/8Ed/FGoa/+yPPpd9NJLH4c8R6hYW4c5EcTw293tT0G+4Y49Sa+Ov+C0Ftdaf4a/Z/0y+G26s7PW4phkHDpHpikZHB5FfRn/BGOUj9l3xVEvV/GN5n/wAF+n0kruwpSUVc/X3JvZ8f8skpT/pc/lr/AKqOiQfZbcRL99+tK+LS3EY/1j1t6HL/AIvn/kB/0u42f8sov1oc/a5xEv8Aq060SYtLYIPvNTo18iEBf9bL0/z7UeaHvo/n/kS5EkmTxHD/AD/+tVeLN1OZn/1cfSluOFSzi6t1qcoAEtk6Yyx9v/r1OxW7sCHzG89ug4Uf1/GrCLjJPU9aRcMd3YdP8alrJs3igqvcy+TCWHXoKV5cSCJfvH9BWfeOZZxEvbj8TVxjd6kVJ2TsJZRgkzP0WpIf3sjXcvCp0p8qlUjs4+p6/So7ggslpD0Fa3uYW5Vbt+YsObiU3UnCJ0qrNI9zNhfoBVm5cRqtrH+NPtYDEhlK5Y9BRe3vEtXfJ94jutlEI05c96it4Rt+0T/d689/enrbSyTb5xx1NT3FvLOQoICDtU3tpcrlb963oimXkvZtg4QfpU006W6+RD17n/PerUVv5MRSM4Y96rDTxuy77h3p8yHySS03ZUt7d5zuPC9zVuS5itl8q3GTVqaJ2Ty4iEFNt7VIfmPLUOSerGqbjpH7ytHaPIfNuj+FWlYkbIAAvqen4etJ5TyNum6Doo6fjUUklzK3lRIYx6mpvcpLlWn/AAR7PBbnc53v+Z/+tTM3c/QeUn61NDaxw8/eb1NWqTlbYtRb3KS2MWd0hLn3qdYYl+6g/KpGZVGWOBRuGMnge9S5NlqEVsh1FZ8t9Gp2xjef0poF5Nyx8tfy/wDr0cr6k+0Wy1NKiqY8q35kkJPuT/KlE8kv+qj49W6U+Urn7luioQfLX942Sf8APFODMx4XA9TU2KuRJAI5TIhwG6iq93AzETRfeHXFaNICD0pqTTuQ4JrlKjL9rt+Rtf8AkaZayebE0MnVOD9Kv1WeH96Jo+G7+4oT6EuLTUipbsbac279D0NNvoNp85Oh61Zu4POTcv31ptrOJlaKTlh69xWl/tIycf8Al2/kNs7nePKkPzDp71o1hzwG2cMnTsa0bW5E64P3h1pTj9pFU5v4JblC4ie1lEsXTt/hV5TFew4P/wCo1ZdFkUo/INZBEllLuHQ/rVJ8y8yWuR+TJIZXtJPIl+76/wBaku7XzP3sXXuPWppI47uIMvXsaq2twYW+zy8Y/SjzW4NJe5LboTWtwJ18qX738xVO5t2t23p93sfSrN1b4PnxcHqcfzqS2uVnXypfvfzovb3oktX9ye4QTJdRmKXr3HrUOHspM9YmqK4t2t28yP7nr6VcguEuV8t/vdx60PTVbAnd8stx00KXSB4zz2NR29yc+RccOOOe9MIeyfK8xHr7VPNCl0gkTr2NT5PYvW91uRvE9u/mwcr3WrkcqSrvQ5FUILsqfKn4I4yf61NJA0bebbcHuOxoa6McX1jsXajkjWVCj9KihuEm46MOoNWaz1R0JqSOekjltpPp0NaVvdpN+7l4b9DVqWJJk2PWHNC0DYYcdj61ump6M4mnSd1saZikt2MkHzIeqf4U8iC8jz1/mKqW99jCTcj1qzLb7j50DYbrx3qGrPU0i017u3YIxJbnZK+U7E/ypk1ij8xfIf0ohud7GC4G09Oe9SNFLFzbnj+6f6UapjspLa6KQa8tzg8j8xWrGWZAXGD6UqFioLDB9KZNKIYy5/CobvpYuMeXW+hISOAe9U7ucr+5j++1MjcpG93N1PQe1R2w3F7qXoKtRtqTKbei6jn/ANGiWGP/AFknWlf/AEeEQR/6x6S3/eu13LwB0otz5rvdSdB0qvUheX9IWQi0hEUf+sanqnkRCNP9bJ/n9Kig/wBIna4b7idKl8wBWun78KPb/wCvQ+w466/1Yjnm8gLFCeR1qv8AbLj1q3ax8GeXq/rVz917VO2gveetj//T/fQQqH8yM7c9QOhqxRSZGcVTdxJWKV7MY49q9W/lULf6LbbR/rJKbF/pV2ZP4E/yKjkJurrYvQcfhWyXQ5ZO95fJEtuBBbmdhyelLB+6ha5f7z9KJ/306WqfdXrRc/v5ktk6L1o33Dbbp+YW37qNrqTq/wDn9TSWo2I13L1PSnT/AL6ZbVOFXrUpxLOsS/ci5P17UrjS/D8xkrGCAs3+tl6/59q8a+I/wL8HfEWyCajaiO+CnZMvyOnHQMAcDOOMMvU7cnNexL/pd3u6xx1aLkI0ndjhf6V00MTVw81UoyakuqOPFYPD4ylKjiYKUH0auj8l/Hv7LXjvwpLLNouNWs1bAziKTk4A5PlsT2Abcf7o6V886v4e17QJvI1zTrjT5M4xPC0efpuAz+FfvpGnloEHaudvfCfh7UImhuLGMRuSzLHmMOT13BCu78a/VMD4gYuklHEwU/PZ/wCX4H4JmnhFgK7c8FVdO/R+8v8AM/BWiv2c1f8AZ7+GurzPPLpFohfkgW0Q/WMK361yv/DKXwu3eb/ZsG/PpPsx/uefivroeIWBa9+nJPys/wBUfnlXwfzVO1KtBrzuvyTPyNrY0jw9r2vzeRoenXGoSZxiCFpMfXaDj8a/YLS/2fvhposguU0i0fy+cfZYj+rhmH516Xp/hbw7aWwSzsYzGDuVZcyBGHTAkLbce2K4MT4h0kv3FFv1f6f8E9bBeDtdv/a8Sl5RV/xb/Q/LrwB+yv498WSxz6xt0qzY/N0lkwDg9D5YI7gtuH909K/QL4afA3wZ8NbVf7PtFmu3A8yZ/nduOcsQMjPYBV6HYCM17JbXHmgq4xIvUVar8vzbiXH5heNWVo9lov8Ag/M/deHuCMpye1TDw5p/zS1fy6L5JDHZUGWIA96dkYzTXRXUowyDVGGRoJfs0vQ/dNfHJXP0Zys9S3HPFKSIzkijzR5vldDjI96oXSNbyieLuefr/wDXqeb99CtxF95OR/Wr5Ykcz1T6E0lwkciRsD8/Q9qdLMkIBk4BqvMou7benXqP8KIyLu22t16H61NkHM9kWo5UlXdGcigSRk7Qwz6ZrItJTBN5b8A8H61Lfw4YTL361XKr2Eqj5eY1q/I//grZ+zV43+Nnwu8M+PPh3p02s6t4Cnu2nsLaMyXE9jfrF5skSLlnaF4EOwAnazEdMH9ZInNxbZVsN0z71DaXLtIYpjz2qOUvnWnmfxa/AX9rr9oD9mKLVdL+E/iD+y7LVH8y7sri2iuYTOg2eYI5lbZIAMErjIADZwMegePoP20P2s/A+t/Hf4kSapr/AIS8GWpuTe3ca2enojyLGws4Y0jikk5zIYlJCr87fdB/ro1fwb4F1TUE1LW/D1he3g5W4ns4ZZB/wNlLV18Zj8seVjaOBjpUl3TZ/NR/wRSgM/xu8ejOAPDyk/8AgXFX9JbTW1oCkYy3f/65q7IgdSmSM+lVo7OGHLkbjWqelmZSi73ifzR/8FqJJZfj74HeQbc+GUx9PttxX6g/8EpHhj/Yq8IkDdKbzV+B1/4/pa/Rjdc3B2qDFH696RpbezXZGMt/nqaLai5tD+Vv/goJ+xD8Xvhr8Z/FfxN8MeHrzX/A/ivUJ9VivNPgM4spr2VpZbaeOPc0QjkYhHI2MpXB3ZUcP4W/4Kc/to+AtFtvCh8Vx3kemosMZ1LTraa5VVGAJJWjEjnH8Tkse5Nf1mlp7t8dT6dhV1LWGAeZOwJ/T/69Dil1BVG9kfxF/H39oX4m/tK+MrTx78VryC91eysI9Oie3t47ZRbxSyyquxOCd0zc9fyr+oD/AIJhW0LfsNfDOWU8Y1j2H/IXvK+9TdSzHZbL+Jpwt40Hm3bbz79KSVgbUuh/KP8A8FGP2UPiD8H/AI7+KfijoWj3V54G8WX02q2+pWkbPDa3N2xlnt52XPksspYpnAZCNpyGCz+HP+Ctv7YXh7w7DoM+oaPrMltEIlvb7T912QBgMxikiR2x3ZCT1OTk1/VeblpP3dvHkdOelcVP8Kvhxdz/AG/UvC+kTTjne9hb5/76KZpOPctTvsfx1+F/A37Qn7bvxnutSs7a68UeJ/Et2j6jqbx7LW2Q7Y/MmkRRFDFFGAAox8oCopOFr+x74ZeBdN+GHw58MfDfSW8yy8M6ZaabExGDIlpEsW8jnlsZPJ5NdLYwaTpFqlhpNslvBHwsUEYRB9AABV4Pcv0QJ9Tn+VKw+aJ/Jraf8FS/2zfC+o3Vk3iu01SO3mkRReaXaE7EYgAmKOIn6nn3rx346/tqftKftU2Fj4J8east3pi3CTQ6XplmkCS3AyEJWMGWUjPyqWIB5AzzX9heq+CPBmvuZtf0DT9Slbq1zaRTE/i6ml0PwR4M8MOZfDOgWGkuwwTZ2kVuSPTMarRcpJLY/J//AIJRfsveOfgV4M8Q/Ev4lWEuj6z42FtFb6dcRmO4trG1MhEkytgq8zSZ2EAqqKTyxA2P+CpX7Tvxq/Zws/hjqvwY8Q/2I2tTasl8jWttdJOtutqYwwuI5Mbd7crg89a/WueBJ02t17GsC6sYZY3tdRto7q2k+9HKgeNvwIIq4pNabmDk4u72P5Wrn/grP+2TcWD2Z1nSklYYFwNLg81fcA5j/NCK8J+B/wABfjZ+2p8ZFmYXt6Ndvzca54iuIne3tUc7ppZJMCMyYyIoQRk4UALyP6/V+FvwruJBdt4P0Z5R/GdPti4/Hy8120dhaQ2yWlvCsEMY2okYChB6ADgVHkzXzicV4j8GWt54Gv8Awbpv+j21xpsmnR/9M0eEwg/gK/izv9E+Mv7LvxWt7vULC68J+L/Cd8JbeWe3ygmhPyyJ5qmKaJhyDhkdT3Br+4KKR428mf8A4C3rVS5tmibzoeB7dq030Zl8N5JHwf8A8E8fjn8Sfj/+z6PiP8TLyK91j+17yz82GCO3TyoEiKDy4wB/Eea/nf8A+CiT+b+2h8UpOm6/g/8ASSCv7GoJ0uU8uT73cetUpYpLV/MiPHY/0NNq+j3JT5fejseTfAhZbT4I/DqQdD4c0jnsf9Ei4r+ZT/gpj8FvHvgn9qHxj45v9Guj4a8Vzx6hZaikTvbP5kSCWMygbBJHIGBUnOMHoRX9aUNzHcDY/B9PWoHtpLd/OtuR6Unro9wj7vvR1R+Ln/BKX9q74zfGzWfEHw6+JWsRano/hDRbJdOxbQwyqFk8keY8aqz/ACADJ+p5rif+CxX7M3jXxRqPh79oXwVpk+r2OlaadL1mK2iMklpDBLJcQ3ThckxfvpFkbGEwpJweP3hBhvYsf/rBqJJXtj5VxynZqixpzdeh/Gp8EP25f2l/2fPCEvw/+F3idbXQ5JXmhtrizguxbyynLtD5yMV3HkryucnGSScH42fDj9pbUvDNr+0t8ebTUfI8YX32O3vdWzHc3DiIyqUgYAxwbAfK+VUIH7sYFf2SN8P/AAP/AGr/AMJBbaBp8eqZyLtbSIT59fMC7vxzW9HLPaHy5hlf89KFG+wOdnqj8nf+CMdzHH+ytrscnGfFt+c/9uVjXjf/AAW98IC58KfCzx/CnFje6jpkrj+L7XFFNECfbyJMfU1+6bJb3a5HPuOoqstrcQt+6k4/z2osh80l0uj+Wn/gkN8L18cftT/8JfeRb7LwNpV1fbj9z7TcgWkKH32yyuPdK/c/9v74Tf8AC0f2S/iJolqnmXmm2B1i1GMuJdLIuiF9TJHG0f8AwKvthN2PnIJ9qfSTa0LcU9Wfwe/DPwo/jv4jeFPA8QJfxDqtjpwA6k3c6Q8f99V/dfJYRCMLbAJsGAo4GB29q06KE2thSipKzMiG4ng/dyqSB+dXikc4DqcH1HBqzRTcuqFGFtGz+ID4hKG/ag8So43g+MbwEHv/AMTB6/t5mkEMRf06VNWVdsZpkt0/H60RV2E5WWh+A/8AwW+VynwWlf8AjPiT9P7Nr6B/4IrxBv2Z/FUjdE8YXn5/2fp9frreuAEto+g/yKdN/o9ssC/ek6/1rS19e5jey5ewsP8ApNybg/cTpSQ/6TcmY/cj6f0pZv3Fstun3n6/1pZf9GthAn33/wAmn6Ct39WIg+13JkP3E6VOJAS1y33V4X/PvTGXyYktU+/J1P8AM1FdHc0dnF+NTuPZX6/qOtgTuupOp6f5/SrGCP3f8b8sfb/PAp4Chgg+7GKIBuBl7yc/h2pN9TSMbaE4GOBTXYIpc9BzT6Y6LIpRxkGsjZ+Rn2u4RyXLDLP0pLSBxI00wwe2fetJVCjaowBTq1c9zJU9r9CvHDtd5WOWb9B6UqQRRtvUfMe5ojnSUsqdV9aiWdlnMUwC5+6an3h+7oXKQnHJpaKg0GKysMqcj2pn2iLzPKz8/pVOTdaS+Yn+rc8j3p13EJohNH1HP1FaqKMnJ203LckqxYL9CcZpJpRCm9gSPaq8Li6tyj9eh/xpYG86JoZPvL8pqbW3Dmvt1LPmDy/N7YzTIriKY4jbJqvaMULWr9U6fSqDg2tz8vbkfSrUd0Zuo0kzaMkanazAH0zUlULqNZ4BKnUDI+lMsJcoYj25H0qOXS5fP73KzSpDnHHBrLM80E/lyHKE9/Sr80oiXeQSPahxaKU07kSxFMySkysOn/1hVBvtN2+3G0Dt2Fasc0cozGc1LVKViXBS2ehnBLezGXOW/X8Ki8+5ujiEbE9f/r1Y+xRGTexJ9jRJJNu8i3jxjuelNMzaa0ei8hiwW1uN8rb29/8ACpwZZf8Apkv6/wD1qh2w2v7yU7pD+f4VSluZrg7BwD2FUlcHJQ0Lz3MEGQnzP/nqaq/arqdtsQx9P8afDY4G+c4Hp/iaka7jT91bLk/pRp01I95/E7CLZu/zXMhb2qVGtovlhG9v9nk/nTRBJJ8923Hp2pDdRR/urZd59qnctWjrt+ZbUyt1AUfXJp7uiDLkD61UWO5l5mk2D0T/ABoMlpAcjBf8zUWNuYuggjIqtJaxu3mL8j9cikEs0n+riwPVuP0qdN+P3hGfalqh6S0E2b02ygHPWsaaGS0kDoeOxrez2pjKrqVYZBpxlYmdPmXmRW9ws6+jDqKldFkUo4yDWRJBNav5kXIHf/GtC3uUnGOjdxTlHrEmEr+7PcpgSWUnPMTf5/OrFzAtwgkj+9296uMqupVhkGqID2jesJ/SmnfXqS4W0exFa3JU+TNxjgE/yourYqfNh+pA/nUt1aiYebF97+dRWt0VPky/QGr/AL0SbfZn8mS2t0s6+VL97+dVri1aE+bF90c+4qS6tCD50P1Ip1teA4SXr6/40LT3okvX3an3kttcrOvlyfe/nUZD2b8ZMJ/SnTWgY+bD8rjtT4JxKDFKMSdwe9Tpui7PaW/cS4t0uUEkZ+bsfWqkF08B8qYcD8xU5WSzbcnzRHqPSp2SC7TIOfcdRTvZWewOLbvHRiSwRzgSxnDdiKhW6lhby7kfiKg2XFm25fmX9KupNBdrsYc+hpW+aBavTRllJEkG5DkUrAMMEZFZrWMkbb7d8VeiE2MTEH6VDS3TNoyb0kilNYKeYTt9j0pIVurc7du9PY/yrUoo53syfZK90QtHHL8zjqMc0Rx+WMbiR2z2qailfoa26hWTITdXQjH3E/yauXUvlQlh1PAqrBi3tWlP3n6f0q46amM3d8pHdOZphbx9Bx+NSXXHl2kVMs12h7mToP8AJp9ryZLuSrvb5Ga117/kFz8ojs4v4utF18kcdpF1NFqMtJdyUW/zNJeScDtRewt/n+RMYwFW1Tvyx9v/AK9Qy/6RcC3X7idf8/pT1kMcD3L/AH5On9KS2Qxw+Z/y0k6f5/Wp21LeuhZaNJjhx8i8Ae9J9ktv7tMlV5CIYmK7Rkn+VR/Zrj/nqaj5mvyP/9T9+WYIpZugqldSmO3wfvvU0h8yZYh0HzN/SqEx+03Sxj7qnH+NaxXcxnLSyJU/0eyL/wAUn9abaAQxNcP9BTL1zJMIk/h4/E1JdjasVon8VX+pns/QLf8AdxSXb8lv8/zpbb9zC1zJ1f8Az+tLcLkxWifj9KS4xLLHaJ0HX/P0qdytv66hDmC3e4f770mfIstx+9L3+v8A9arE8DzOqjhFqyY0YgsM7elLmKUSnawstv8A7T/yq35S5X0XoKlrNlvwpKxrkj1qdWVpFamlTdw25Xn6VWDR3kJA4/oapQyvaSeTN93/ADzQog529CzHeLJL5bDZ6Z9a8vuvHyv4pbQxbnyBN9n8wvz5gO3OOmM/4+1en3VsJR5sX3/518yxfP8AEFd/OdUGf+/1ddKKd2cdaU1aJ9L2dzkeTJ17f4U7BtJcj/VSfoapXMDQPuX7p6Gr9tMtzGYpPvd/eud90dEX9l7jLqFlYXMXBHWrUE6zpkdR1FMiJhbyX5H8J/pVOaJ7WTzovump30K295GvVa4gWdMdCOhqSGVJl3pUtTsaOzRTTM0LRTcOOD/Q1DZMUZrd/vLzV/A3bu/SqV0BFLHcD1wapO+hDVrSG27eRcPbHoxyKd/x73f+xL/OmXyEbZ16j/IqWUC6tdy9eo+tPzItbTsVb+Ha4lHRuv1q1BIt1blJOT0P+NERF3blW69D9fWs2GRraf5u3Bp7qxOz5ujJ7ZmguDC/Q8fj2p17GYpROnGf51Jfw71E6fw9fpUkLi7tyj9eh/oaL/aDl3h9wsyi6tg69eo/wqtYzbX8luh6fWltJGhlMEnGf51HdwmGXzE4B5+hot9klvaaLk1xJBIu4bo2/MVcBDAEcg1V+W9t/Rv5Gq9nMVb7PJx6f4VFtDZSs/Jmi67lK5Iz6Vmf2cd+N/yfrWtRSUmti5QUtzMe5it18uAZPrUUVtJcnzbgnFaDW0LuJGXmqF49wW2EYTtjvWifRGElbWWw+S7SEeVbgcd+1JHbSSnzbluPT/PSlhhjt08+fr2H+e9NzPetgfJGKPQX+L7iRrpV/c2iZP6UC2Z/3l034UrSw2g8qIbn/wA9aQW8s3z3LYHpRsPfR6/kO+0wx/u7Zd59qeBeS8uREPQcmomubeAbIBu+n+NQhru5+7wv5Ci3Urm6fkW2W3i/1z7j/tHP6Uw38CcIC30pI7CNeZDu/SrixRx/cUCpbQ0pehDDcmVseWwHr2qywDDBGQadRUvyNUu5QNq0TeZbHae4PSriliMsMGgOrEhTnb1oLKCATyelDdxJJbA6LINrjIpiB1+RvmHY/wCNTUgIPSpKt1Mue0ZG823/ACHb6VNb3Kzr5Uv3/T1q/URijJ3FRn1q+buZclneJlXFo0Z8yLlf1FSW16R8k/T1/wAa1qpzWccpyPlPtVc19GQ6bTvASWA7vPtzh/0NOjljuFMUi4bupohgeD5S+5PTFOmt0mw3Rh0IqbmlnukV/JuLY5tzvT+6auAeZH+8TGeoPNPUYAGc49aQsoBJPTrSbuUo2GxwxxfcXbTtyhtpPJ7VVhuGcSStwi9BUFscLJdyd+lO3cjnWli2bgecsKDJ7+1QzXDmZYIep6moom8qBrl/vSdKSzGxJLmTmnaxHM3ZC3lwykRRkgjqaerSQW+5iWkfoDVW2Q3E5kfoOTV2I/aJmmP3E4X/ABqnpoKLbfMWIYzHGFY7j3NTUVXuHZE2p95zgVnudOyEMgAeXsvA/wA/WqNmozJdSdv8mi9YIq2y9AOadcfuLVYD1frWiWhzN63fQjtQbi6Mrduf8Klj/wBIvDJ1SPp/n9aRf9Hsi/8AFJ/Wgf6PY5/ik/r/APWoYkrWv6ixf6RdGY/cj6f5/WnQ/v7hrlvupwKbJ/o9qIh95+v9amMDrbCCM8nqf51RSX+YyBg7y3b9BwPpTLJTJI9w/wCFXY4FWERNyO9SgBRgDArJyLUNmyER7kKv1bk4/wA/hViqc92kB2EEmkt7pZwUfhvT1pWe5Skr8pcyDxVGW9EUvlspA9aqyLJZS705Q/5xV10ivIdy/gfSqslqyOZvRbiXSPLFuiY/QdxVC0ufJbY/3T+lTW0zW7/Z5eB29qW8tessY+o/rVL+VmUtffiTzxsrC5g6jqPUUs0aXUIdOvb/AAqtZ3W391IeOxq0V+zuXX/VN1HofWp20NE1JX6DbW4LfuZf9YP1q9WfdW5b9/D98enepLW5Ey7W+8P1pNX1RUZWfLIsuiyIUfoaqQboX+zvyDypq9TWAPXtzST6Fta3MxR9lvNo+7JT5z9nukm7PwanvI/MhJHVeRUb/wClWm4dRz+Iqr9TFq10vULtShW6T+Dr9KS8jE8AlTnHP4UWbiaExPzjj8KS0YozW0nVOlPb5D0foyOwm/5Yt9RUMym0uRIn3TyP6imXEZt5/k47itFwt3bZXr2+tU9HcyV2uXqhl5GJoRMnO3n8KW1cXEBiftwfpUVjL1gf8P6ioiDZ3Of4D/L/AOtSt9ku+0/vIo2a0uMN24P0rUuJJI1EsfIHUVXvod6CZe3X6UtlKJYjC/O3+VD194I+63AtwyrMgdfxqasWNjZzlD9w/wAvWtkEEZFRJWNoSutdzNmsGd96P165pf8AR7Jf77n/AD+FaVQywRTDEgz70c3RidNLWO5lgXF63Jwg/KrDSW9mNsYy3f8A+vT7ppIYwsC4XuR2qrbWu4ebNwv86vdXZjqnZbgiT3p3Odqf56VYaWC0HlxDL/56mo5LiSdvJthgev8AnpT1S3s13Scv/npR6jXdfeIIbm5+adtqegp/mWltwvzN7cn86YBc3f3v3cf86eWtLPheX/M0eQLv+LHBrub7qiIep5NOMSKMzyFvqcD8qpm5urg7YRge3+NSJYljunfJPp/jStbcpO+yuSfa7aIYjH5DFOW83nCxMR7VMlvBGPlQfzqxU3RolLqwqnLaI53xHy39RVymFlDbSefSknbYtpPcZF52MSgZHcd6mprMqjcxwKUHIzUguxCsZjPyfdPb0+lQXVqJvnThv51ez2oqrvclxTVjLtrloz5FxxjoTS3NkH/eQ9fSr7Ij/fUH605VCjavAp83VEcl1yyMWG6ktzsflR2PUVoukV2gkU89mHUU+W3imHzjn171BFaPC+6OTj0Iqrp6kKLXuvVCxzsreRc8P2PY0j2jI3mWrbD6dqtyRJKu2QZFNhi8pNu4v9am/VGvLfRjYXldf3q7SP1pywQq29UGalyM471U89pLjyo+idTS9BuytctMyqMscVDNMsIGRknoBVYf6TeZ/hi/nSRYnuXmb7sfAp8vchzvsTXNyYYx/fPamTTSQwDef3jfpVaLN1d+Y3Ref8KimLXVzsHToKtLoZubaui3Y+a+ZZGJHQZNXJGyRGOrdfpUaSKkv2deiLk1EJdsb3R/i4X6dqh6u5pHRWK9wftF0IV6Dj/GkvX3SJAnbt706yAUSXD9qZZqZrgyt/Dz+JrXb5GW/wAyS4/dxR2idW6/5+tLcjakdpH1alg/0i7aY9E6UsBEk0l233RwKCtxJxgR2cXfrTpwC8VonTv9KS0BlkkuWHXgVLbwOHaeX7z9vSp2Ktf+uhXuczTpbL0H+f5Vf2fOD2UcU9URSSBgnrTZpViTe+ce1Q3fRFqNrtihNmSvVjk0vz1mnUDn5U4o/tBv7lHKxe0if//V/eoOY7eS5bh5On9KhslC7526KMUl+2CkCdFGadKPJskjHV+v8636eph19BlopmuTI3bn8anhxNeNL2Xp/Kn2cDRwtu4Z6tQwpAu1KlvcqMdiCCNzNJPIMZ4H0qdIY0YuByepqamsuVI6Z9KzbNErCM4RSx6CoxIJ4t0TYz39KrxyPC/kTnIP3W9frTZImtnM8H3f4l/rVWJv1K8VzJBKUnYsO+e1Wrm2WdfNi+//ADp8sUd5FuQ89jVO1me3byJ+B/Kr80Tbo9irDK8Em4fiK1ZY47uEMvXt/hUV5aGT95F9/uPWqNrO0Lc8qeop76ohe77r2LFtcNA3kTcD+VfN0pP/AAsNivX+1Dj/AL/19M3VsJ182L7386+ZYfl+IKbuMamM/wDf6uqjZ3ZzVk1ZM+nYJkuozHJ97uKz5oZLVwynjsatXNswbz4OHHJAqWGaO7jaOQc9x/hXInbVHU1fR7ixSpdxlW4I6/4inIxJ8ibk9vRhWbLFLaSCROR2P9DWirR3sWRwR+amk0Un0e5VkjkspPNi5jPWtGKVJk3pVeOc7vIuOH/Q1E8Elu/m23I7rQ9dxrTVGlTJEEiFG6Go4ZlnXcv4j0qesti9ynGheAwTdV4/wNVrJzHI1u/X+tatZd4hikW5T8atO+hElazEz9luyD9ySjUIeROv0NS3qCWFZU5xz+Bp1s4uYDE/UcGnfqQ1vEjsZhJGYW5x/Kq4LWVzj+A/yqv81vN7qa07iNbmASR9RyP8Kp6MhXa80R3kWQJ4+o64/nUylby3w3U/oaisZg6GF+cdPpUKk2dzt/5Zv/L/AOtS8i/73RiWshhmMT8Z4/Glv4SriVe/86kvoMjzk7df8amhdbu3KP16H/Gnf7RPL9hklrP50fP3h1q1XPqZLSfnqOvuK3VdZFDLyDUSVjWErqzHdBzXzh8d/wBq/wCBP7Nc2jQfGTxE+hya+k72QWzurvzRbFBLzbRS7ceYv3sZzx3r6QryTxj8HvhP8Ubm3HxN8G6P4sbTBILQ6rYQXrQiQjzPLMyts3bVzjGcD0pWKbs0j5Bm/wCCo/7Dc0od/iDNhe39j6p/8i19gfC74ueCPjZ4G034hfC6/Op+HtXM4trkwS25k+zytBJ+7mVHXEkbDlRnGRxzX4a/EL4Q/CP9o3/gopYfsyeEvBei+D/APgKJ7jWP7G0+2sbnUZIYUmmV5reNJNpkdLcLkbQHcfMRj9+/Cng/wv4G8P2PhTwZpNroejaZH5dtaWcSwwxJksQioABkkknqSSTyc00+5Lj2NZVisU3v80hqo0lxdvtHT0HSp2s5pJiZDx61pRxpEu1BgVd0jNRb02RUhso4+ZPmP6VforMnvOfLg5Pr/hWWsi9IItz3McI55PpVJDeXHzZ8tD/n60qW6Qjzblst6f560x7uac+XANufzrRLsZt/zFktb2x5JeT8zTsSSDfcHy1/uj+pqJUis13P88hp5X/lvdHp0XsP8TSNSVSzDbENq+v+AqFp4YW2xjzJD/nrVZ55rt/Li4X/AD1qYmGxXA+aQ07GfNfYk2OR5l0+F/ujgfj61IjM4/dDanr/AICqsUbTn7Rcn5RyB2p+6S7bC/LEPzNIpMnEuTth+bHUnp+dDTLFhCS7nsKrPPki2tB+NSKq2w2L88r/AOfypWDm7E4dkXdNgZ6Af55qRWYrucbarEiIh5f3kp6Af0qZI2J8yTluw7CoLTJ6azKilmOAKdWbesXkjtx/EeapK45OyuTXE2LfenV+B+NVrn/R7dYF6nrU8g8y6jj7RjdVd/39+q9k/pVoyl/wAnBit47Zerdf8/WnXIwIrRP4utH+uv8APaP+n/16dF+9vHkPSPgfypCtf8iK+bBSBOgH/wCqluv3VvHbjv1/z9aji/0i939RnP5dKkf9/fBeyf0/+vVbaEPW77iyf6LaCMffk6/1q9BH5Uap6dfrVN/318q9o606mRrBahVJT5lw8h+5EMD696sSt5cTP6Cs+TMFkF/ik6/jSSKkyvCTc3W89M5/AU6cm4utnbO2pLMeVFJOfoKSxiJfzWHA6H3rUwUbpLuSXI824jtl6Dr/AJ+lTyRvLcIMfu4+fxqZIEVzL1Y96nrK5uo73IWijZxIwyV6VNRVFy9vIZCS0TdfaluU9NSeOeOVmRfvL2NUJXuLabexLIfyq1ND5uJoTiQdD60I6XUZjkGGHUelNdzOV3oDLFew5H4HuDWOyyQSYPDCrP7yyl9VP6itCWKO7jDKeexq9jNrn9RsMqXcRR+vcf1qiC9lNg8qf1FV1aS3lyeGFa5Ed5Dxwf5Gm9PQE+b1QTQx3cYdDz2NQWtwVb7PPwRwM1WikktJSjjjuP6ir80KXSCRDz2NS9NGNO+q3Kl1a7MyxDjuPSprS68weVL17e9FvcEHyJ/lYcAmormzZD5sHT09PpT8mTa3vRLY/wBHba3+qPQ+nt9KhubZgfOg4cc4FPtrlZ18qX7386UO1s2yTmI9D6expapmjs15EltcrOuDw46irVUZrYOfOgOH6/WnwXG8+XKNkg7etZtdUWm1pIt1ThQwSNH/AANyv+FXKKdymupjkfZbvP8AC/8AI/4VLeK0Ui3KdehqxeQ+bFkdU5FNjIurXaevT8RVX6mHLvEbcItxAJE6jkf1FVLGfy5PLbo/86lsJSrGB/wqtdxeVLlejciqS+yQ3tNE15GYZVnj4yf1q06rd2+5evUfX0ohdbq3KP16H/GqlrI1vMYZOhOPxpe99xel/Jk9lLvQwSdV/lVRla0uMr07e4qe6jaGRbmP15+v/wBerMqLdwBk69R/hSv1Fa+nVDLuMTQiVOSvP4VHZXGf3L/h/hRYzYzA/wCFVrmH7PLuTgHkVVvssG/+XiN2k5z7VXtpxNHu7jrVmsdjpTvqMDK2QD93rUNxCZ0CBttVZMxX6t2k/wD1VceZI3Cvxnoe1Xa2xF000ypLIlknlxD5j3NNihCj7Rdnn0NaLIrY3DOKoXVvPNICpBX+VCZnKNtSvNdyzHZECAfTqamgsf4p/wAhVuC3SAfLye5qzRzdENU76yGqqqNqjApksqRLuc4qG5ulgGBy/pVOKB5z59weP8/kKEurLcukR/2i5uWxbjanrU3lxQjfcybz7/4VBLeBR5VuOnf/AApYoQg+0XZ59DVWMk/mWA8s/KfJH69z9KFKLlIFye7dvxPem5e5+Z/ki9O5+vtUEt3nENsPbI/pRYu9tWWHeKD5pjubt/8AWHahTcTct+6j/U/4VCkKW6+fcnLf5/WmK016+PuRDrRYVy0jKf3dsAfVu3/16cXEZ2ZMkh7f54FQtKWP2a0429T6UjSR2q+XH80h6/X3qbDuWWl8obp2C+woV3f52GxPfr/9aqyp5X+kXJy3YVJ2865+Vey/4+posVdk6SGQ5UfL6+v0qUEHpVVd03zONqdl9fr/AIVbpMtBUImTazA5CdTUV5J5cJx1bgVWZSlpHGvWUj9aSRDlYWJjHbyXLfefp/SmW5MNq856t0ovjhY7dP8APYUXQ4htV9v8KsyenyHRjyLMv/HJ/Wkf/R7IKOr9fxp10A8sVt271FesXmES9v5mqWonotPQfD+4s3m7v0/kKbaqIYXuG+g/z9aW+O1Y4E7f/qFLeDZFFbJ3p7/MLW+Q2NXMJb+OdsZ9qS+YDbAvRRWmEREUdl6Vipm5uwzdCc/gKSd9S3GysWbj9xaLD3frSx/ubIv3eoroPPc7EGccVoyW6SBUb7q9qL9wSu3YrRxtHZbYxl5P6/8A1qspAogELdO9WaKybNFGwxFVF2qMAVHJMkTBX43d+1NnjkdQ0TYZeR6GmK0d3GUkGCOo9DTS6jfZDbxZSu6JyAOoFNtbpZh5Uv3/AOdETtbN5Ex+X+FqgurQg+fBx3IH8xVrszN33Qy4tGibdEm9T29Kr+XN/wA8K1rW5EyYbhx1q1ketVdrQXKmf//W/eX7M9zMZW4Qnv3FahVSQxHI6UjyIpAYgE9M1FcifZ+4PNW3clKxJLKsKb36VWgvElfYRt9Pem290JP3U42v0571XurQqfMh6dx6UJLZibe6Niisq1vQf3cp+h/xrVpNWKTuRyRpKuxxkVVjkaBhFMcg/dar1RyRrIpRxkGkmDRUeNrZjNCMqfvL/hT5I4ruMMp57GkV2tz5cxzH2b+hpJInhbzoBnP3l9fpVXFYit5mhb7PPxjoaS7tM5ljH1FWCsN7Fx/9cVFFM8DeTc/g1VfqibdGVbS6MJ2P9w/pXzjIN/xCYLznVDj/AL/V9KXVmTmWH8R/hXzREwTx+rN0Gpgn/v8AV2UWndo4a91ZM+lLW6MZ8mXoOAfSpri2Ibz4OD1IFSzQRXS+YhGT0NVYbiS2bypxx/KuS/VHdtoyxb3STDypR8386ie3ktX82DlO4p9xarMPOhPPX61Hb3jKfJueo7/40vQPJlllivYcjr2PoagiuHgbybn8DVkxAN5sBwT19DSyRx3KbXGCPzFTcdnuNeEM3nwnD+vY0+KYP8jja46j/Cs4NcWL4b54zV4GC7TIPI/MUMEy3THRZEKP0NQea8J2zdOzdvx9KtVBZWhiMcZib5l7fQ1lqTZ3WD0/oa3apXlsZlDJ94VafczlHsRX8IdBMv8AD1+lfjV/wUE/a/8A2sP2ePiN4f8ABfw0i0bSvDni1Nml6jLALq9kuY/KW5WQSyNFGsbTJtzDyDnJ5A/ZaycsjW0wwydj6V+D/wDwWJhNv8RvgCvb7XqhH/f7TqOlgS15kd7efBf/AILDzOmsT/GDw9BcJ8ywRi3j59Ckel+UfxJFdZ+yP+2N8fZ/2gLz9kH9riwt/wDhNVilk07UreKKJ55I4ftXlyi2xbNG9sGkjkRVxt2sCx4/Xobb629/5Gvwd+MarZf8Fi/hpLF+6eS2sfMYcEk211Gc/wDARj6Uw8uh9Z/t/ftl+Ov2dLLwl8N/g/psOo+PfHU0kVrJcx+clvEGWFNkW5Q80ssgEe7KDadwPAr56tvhN/wWPjSLxE/xT0O1vZkBNlJ9jJTPO0xrprW+R0OGP1r1z/gpR+yd8WfjBqXgb41fAhI7rxb4DkYmzMkcUsiLKtzBLC8pVC8UqH5GI3buORg+Bat/wUQ/bp+FejDVfjh+z2RpdhtW51CG2v7C3z0y9x/pMClj+Geg7UBbS3U/Xj4MWvxYj+EHh0fG2aC98ew27/2nJbeUIZZfMbbt8pVj5j29FHPavGf2Vv2yvAX7T+peLNB8N6RqXh/VPCEsMV5aaosKS5lMq5XypZAQjxMrehx61237LP7SPhH9p74WWXxL8JwS2Mcs0lpd2c5DyWd5AAZIS68MCrK6txlWBIBJA/K3RY/+GXf+CturaFj7J4c+MUEk0WeFMmqDzwQOmf7RgeJcdA1LyJ/vG18dfin/AMFVP2cZNf8Aizr1zpPiH4e6ZqDuIRbWEywWL3G2DzhbJBc7SpVWYMSuckjrX6kfs1fHDTv2ivg34V+M2l2jaeNfhZbm2Lb/ALPd28jQTxg90EsZKHglcEgZxXJ/trSrc/sf/FtXwWTw9e5z7R5Br56/4JIqZf2MdIRj01bVMe377P8AOlsW9VdHyb+zExT/AIK4/Gtx1FvrB/8AJqzr78/4KK/Gn4j/AAG/Zsu/iD8KtWGja7HqdjbLcm3hucRTMwceXcJInOOu3I7V8B/sxgt/wVs+Np9LTWCf/Aqzr6h/4K1yb/2Mb/PVNa0wf+PtR0C/v2PnH4e/tIf8FJv2vPCWi3HwA0nT/Bei6fZ2tnqHiXU44B/aWopEq3c0QmhkQRmUOQlvbt5ecF84Aw7P9qb9uX9jb46+EfAX7XepWni7wf4tmSJbyGKAgRGVY5ZrW4hit5DJAXUyRzqcqRgDcrV+of7D0hX9lD4Txdj4b08j6+SK/M3/AILeMo034OOoxNFd6zh+4BWzPB+o/Sk0Unc/U79rD49Q/s4/A3xR8VvsY1C40eKKO2tmO0TXVzKsMIYjnYGkDPjnaDjmvyp+Efjb/grN8fvDGnfF3wd4h0Pw74X1t3ks4ZrbT4/NgSVo3MSS29xMFBUgGVgSMEZBBP6f/tseEPhj41/Zj8daP8X9b/4Rrw2LWOeTUwnmPazwSpJbMkY5lJmCL5QwZM7AQTmvx4/Y8+On/BQTR/hTpPhX4OfDSDx78PdKnlt9L1XUraS0kNsJjkRubuFZFUkgYD7TlNx24FJ9CGup9df8FP8A9pz42fs9p8M5fhF4gGhnxDcaml7m0tbvzFt/svlj/SYpduPNb7uM556Cv1p/d2MW1fnlb/P5V+Ev/BbC3EFp8FM8sbvW8/lY1+69unBu7n6jP+fyouQla3clRRbqbm5OZD/nArPLTXswX9OwFE0j3Uv6AVeOyxi2jl2qtiN9OgksqWSeXHy56mq9tbmUmef7o5570ltAbly8n3e59ammkNw4t7f7o/z+VIW+rHFmvpdicRJ196ZcTFiLS2HHQ4qSZhAq2tv989afFGtqgAG+Vun+fSg0sOjjFqgjT5pW/wA/lTXkFt8q/PNJRLILVCc75W6n/PanWtuU/fS8yN69qXmPyRJbwFP3kp3Snqat0VB5oM3lDqBk1G5rsQyOz3SxD7qDcarx/vdQY9k/pxU0OGuppPTj/P5VFZdZZm/z3rQx3aJYCDNPKegOPyqvYnmW5f8Az3NOj+SwZz/Hn9eKagEenuR/F/jigOwtkSkEtw3J/wAKLUeVayTHqc/5/OiT93YKn9/+vNLMNmnog/jx+vNBOwzTwFWSVug4z/OlsOfNuH/z3NLGPL09mH8f9eKVf3VgT3f+v/1qbGlawun/AD+ZM/UnH9a1Ko2y+XbxJ3c5/rV6oZrBWVijdEs0UA6SHn6CobqKW4mEaDhB1PvV9o1ZxIeqjinsyoNzHAouJxve5HFCscQiPIFSkgDJ7VGxZo8wkZPQ9qpR3UsTeXcj8aNx3SFGoxGTZg7fWtAEEZFZ9zaJMPNi+8fyNVoLl7dvKl+5+op2XQjmadpG1SEAjBpFZXG5TkGnVBsZ5DWjbl5hPUelSSxebiaA4cdD2NXKpFGtiXjGYz1X0+lVczatoKjpdIY5Bhh1HpVNS9hLhuYm71ceJZwJoThx0P8AjSxyrMDFKMOOo/wqhNfeMuLdLlN8Z+bHB9ayoppbWXn8RWgPMsmwfmhP6VLPBHdIsiHnsfWmn0M5RvqtxzpDeRblP0PpWbHLNZSmOQZQ9R/UUyN5bSTpjPUGtb9xexf5yKW2g/i16jJoY7uMSRn5ux/oar2920TfZ7ngjuaixNYtxyh/I1ddIL2PcOo79xQPd3W4y4tCzedAcN1x61JDKtwhilXDr1B/nVOOaa0bypRlf89KvlIrkCVDhh0YdaT8xryKZaaxfB+eA9ParbLDdxh1PPYjqKfkODFMOv5H6VnyQzWjeZCcr3/+vTHa3oXEleJhFc9ezdj/APXq5VOK4iul2MOe4NKBJB0zIn6j/Gsyky3VWKHyZCY/uP1HoanRlddynINPoKtcxb6NoZhOnGf51ccLeWu5evUfWrE8YmjMZ79Kz7YvbS+TKNofp6Zq73MbWfkynbTmCbLdOhq/qEO5VnT+Hr9Khvrfa3mr0br9anspRJGYH52j9KpvqQlvBjreRbu3McnJHB/xqtbO1tMYJOjGo/ms7njp/MVcu4RcRiWPkj9RSHrv1RBexNE4uYuPX61bUpe2/PB/kabbSrcwmKT5iBg+9Uoy1ncFW6d/p60Fba9GRRSPaTYftwRW+GDAFeQaoXluJkEyclR+YqOwnx+4f8KT11CPuvlZLfxloxKnWPn8KZfAS26TL2wfwNadVjD/AKO0A6YIH9KlMqUb3GWshe2DDkgYx9KlhnjnXch/DvWfpz7WeI9+RTP+PW9z0BP6GqsClombVUbu5MCAJ99+ntVmSVIiN/APGacVVxhgCKSNHrojKtrcAfark8def5mq91dvOdq8J6etX76GWQApyo7VDbW6wr9om4x0FXfqzmcX8KFghS1Tz5/vdh/nvTkVrpvtE/EQ6CmKGvptz8Rp2qO6uBIfKj/1Y9O9IrRLyGXV09w3lx/d9PWrSIllF5knMh6D+lNtoVt0+0TdewqsfMvJ/wDPAp+ROu73EQS3s2W6d/YVbmlxizthz0JpZpBaxi3g+93P+e9CKtlDvb/WvRcpK2n3hLIllF5UXLnv/WiCEQL58/LnoO+T/WkgiCg3dyeeozU5YKPtFx/wEen/ANekNLqIxEf+k3H3v4V9P/r0kMbzsLifp/CvpUcCNdyfaJvujoK1KTLSvqFU7uR0QLHw0hxUssvlhR3c4FVpwGuoYz25/wA/lSQ5PSxDejc8Vuv+e1WJBuu4o+yAtUR+bUR/sD+lTRYN3M/oAKondlY/vdRA7J/T/wCvSx/vtQdu0f8A+qixw00s3+eeaLTISa4br/hzQR2Fg/e30kh6JwP5VBF++vy3UAk/l0qay/d28svf/AUzTkG929Bj86fcEr2Hf67UfUJ/T/69L/rtQ9o/6f8A16LLl5Z2/wA96LM4E1y3+e5pCWti5clvIYIMl+B+NQWdq0JLv1IxirqjCgegpFkRyVUgkdam+ljotrccqqvQYqrcXaQHbjLVDcSXUEnmffj9BU2YLyP6fmKdurJv0RLDMk6bl/EVPWCyzWUmR+fY1q29wlwvHBHUUNdUCfcs1VmgJPmxcOP1q1RUJ2LKitHdxmOQYI6juKZHI0DCKc5B+61SzQb8SRnbIOh/xpqus4MMq4cdR/UVoZkE9kWbfBhc9ag+w3P94VY8yS0+SUFo/wCFu/0NH2+L0ancVj//1/3tntI7geYhwx79jVSO4ntG8q4GV/z0qXyri0O6I+ZH3FWo5YLtNp59Qa0MxskUF2u5Tz6j+tRRyy258u55Xs1Me1mgbzLU59qmhuo5v3Uw2v0IPQ0AJPZxzjzIjgn8jVWK5ltW8q4B21c8mSA7rc5X+6f6U4SwznypVw391v6UrlWLKOsi7kOQafWWbSWA77Rv+AmpkvFJ8uceW/v0pW7DuXGAYbSMg1BGjRfKDlO3qP8A61WarXNzBZwvdXUgiijGWZjgAVIxskDB/Og4fuOxrnNY8WeHtNjMep3QWUdYk+aQH6Dp+NeT+K/iVeX7PY6ExtrXoZekkn0/uj9fp0ryoksWZmyTXfCg3rI8+piUtIHtknxbggzHZ2DzKPumVwh/IBv515TJqzSa8dd8sBjcfaPLzxnfvxmsiiuyNOEdjhlVlLdns+n/ABVihcC6smRG6+W4f9CB/OvStL8UeHfEaiKzuAZcZ8tvlkH0B6/hmvk6lVmRgynBHIIrOVCD2N44iS31PsPE9i2fvxGrTJBex716+vcfWvBvCnxJvLBksdfY3VoePNPMkf1/vD9f5V7dGsNxEl9pcoeOQZBU5BHtXBODi9T0ITU1oND3FkcOMp+laUcsVyu5DyPzFQpcxy/urgbG7g9DUb2TxP5tocH0NZepovIt+YufKmABb8jVWSyZW8y2bYfSp0YToVljIPcH+lOhhaEsPMLr2B7fjRsVa42KZ3/dzxlW/Q1MiCMkLnHp2FS0VAwoqsbaMv5vO71zVmgCNo1Zgx+8Ohr8IP8AgsoM/EL9nwD/AJ+9V/8AR+nV+8defeMvhZ8MfiJcafd/ELwjpHiifSC7WUmqafb3r2pkKlzCZkYoWKKTtxnaPQUAdHaytbTbJOAeD7V+GX7QAH/D4n4Z472en/8Aoi6r93bu180b0++P1rz6b4YfDHWvF9v4+1jwhpF54t09VWDVp9Pt5NRiVAQojumQzLgMQMMMZPqatvqZJW0PPPjr+0/8JP2bdE0fV/i/fXGn2Ot3LWcM0FtJcgSInmHeIgWAwOoBr4M/aB/4Kcfsl6j8F/Gfhjwbrc/i/VPEWkXunQWK6dd26M95C8IM0l1FEgQbsttJOOgNfpf46+GXw7+IVvBpXxI8LaX4qsLZ2lhh1SzhvI43IwWjEysFbHGRg18IftP+Gf2Wv2O/C2l/FTRv2etK8TS3F95bGx0+3zZCOJ5vtJMkMoiVfL+8AuDzmhgjC/4JL/DLxN4C/ZWk1zxJay2R8Xa1carZpJwTZGCCCKXb1AkaFiCeq7SOCDXk/wDwV78IanpWi/C79pTwsPK1rwPq62csyj5gJCLq0kb/AGYpoGH1l96/SX9lr9ovwr+1H8JrX4l+F7K50yB55rOe0udhkhmt8bk3Rkh1wykEYyCMgHIr1Hxd4N8K+L9Lm8M+N9DsfEWjXJRpLPUraK7tpfLYOm6KZWjJVgCMjggEUb6A9NT8Sf2sf+ClHwo+MXwJ1X4QfBiw1XWPFfjmCCxeM2jLHbpK6maMc+ZNKQDGoRSCTnPGD+m/7Bvwf134G/sr+B/AfiqIW+uCGe+voh1imv53uRE/+3FHIsb/AO0pxxXtfhX4L/B3wWyX/wAP/A2g+GrkA7ZdN0y1s3G4YIzDGp56Gu8spjDIYJOAT+Ro3GrLQ/nX8MfHL4e/sz/8FQ/jJ40+MFxcaVpF4upWayxW73DCS7ktZ4iUQF9rRpkEA9R2r7g/4KtX8N/+xjc3tqcw3eq6VLGSMZDsSDg9ODX6H+Mfgb8FfiHqY1v4g+APD3ibUQgjFzqmlWl7PsXovmTRO2B2Gau+M/h94J8Y6Mvhvxh4d07XtD3RsLHULOG7tQ0X+r/cyqyfL/Dxx2oXYJdzwv8AYwBt/wBlL4QSjofDWmH/AMgjNfmv/wAFwNp0b4OOO93rP/oFnX7e6foOiaB4fstE8M6fb6VpenRLFa2lpEsFvBEgwEjijAVFA6AAAVy/iz4X/DD4pWlnb/Enwjo/isaaZPsw1XT7e++zmXG9ovtCPsLbRnGM4GelD2EtGfJX/BSj4a+MPiz+yH4m0nwNaS6jqemT2uptaW4zJcQ2kmZlVerFUJkCjk7cAE4B+UP2Ov8Agpj+zN4J+AXhD4a/FG+u/CWu+ErCPTJlNhcXUE/2f5Flja1SU5dcFw6qQ+4cjDH9mrF2imeB+/8AMV5P4k+APwI8W65JqvjH4c+G9du7pi7z3+j2d1Kzt1JeWJiST3zSsUpaH4Af8FQP2qfgR+0r/wAKwi+DPiF9dfQLjUzfBrO6tPLF19kEWPtMUe7PlN93OMc9RX9K1+8m4R4xGOnvXib/ALLH7LEDqG+Dvg1CeQ3/AAj2ndR/2wr6EZVYbWGRSWg5K6sjKtUW3hN3L6cVVQS3k/Pfr7CtO7t3nVRGcbe1QHFjbcf6x/8AP6VVzJx6dBl1OsS/ZYfoaeoFlb72/wBa9RWMQYm4l6L6+vrUkX+lTm5k4jTpmmCvuLEv2ZDcz8yN0H1qQN5CG5n5d+g9Pao4z9quDM3+qi6VCS19c4HEafy/+vQP0JrSFpn+0y8+latNChQFXgCnVmzSKsFZlmwe4mkqxGx8yds8DAH4Cqlj8ttLJ/ngUB1Q+2Y/ZZZe5yf0pluNtjIx75/lihTt00kd/wDHFJ00v6/41oT/AJD5jtsYx67f8aLgYs4kHU4/lTb0bbWJR7fyqW7B822Uf3v8KCWtyO/OPLjX8qNQO0RoPem3fzX0Q+n86W9hmmmRYxkAfhQJrcdL8tgg9cf40+6jcwxQIMn/AAFT+QrwxxSfwY6ewq1U3L5SIIo2/wCx0/lUtRpLHISEYNj0rOuXu4ZPMBzGPy/GpLbsWZ7oW7AFCc96Vkgu48g59+4qOG6huV8uQYJ7HvUbWkkTeZaHHsaCN/QhxcWTZ6x/p/8AWq6slvdptP5HqKbDdJKfKlGx+mD3qOaxBPmW52OO3aglK22wBZrI8fvIv1FTPFBdpvB59R1qGO8dG8q7Gw+tTNbgnzbdtpPp0NBS7IpD7RZNyMofy/8ArVpQzxzrlD9R3qIXGP3dyuwnv/CfxqKSxUnzbdvLb9KAStsaNFZ63UkJCXaY/wBodKuqyuNyHI9qC0yHyyrl4+/Udv8A9dLLCJQG+646H0qxRQFipHKSfJuAA/6H6VAySWhLw/NH3HpV2SJJV2uKjj85Dsk+Ydm/xoJaG4t7yPPX+YrNkimtH3r09R/Wr8tr83m258uT9DRHdDPlXA8t/foaCGr7hBcxXI2NgN3HrUElvLbt5ttyPSnT6eG+eA7D6dqZFdyQnyrsHPrVegeUieOWC7Ty5B83p/hVR4Z7NvMiOU/z1q5Naxz4liO1+oI70yO6khPlXgx6P2NSDXckguY7gbG4b0/wqUuYv9Zyvr6fX/Gq0tlHJ+8gbYeox0qWGSbPlToc/wB4dDQWr9RktpFL+8jOw9cjpRHLcRHZOhI/vDmni2MbhonKr3XqKuUBbqReWu/evB7471LRVeW3jm/1mTjtmgv0LFMdFkG1xkUoUKNo/WnUARlAU8t+QeKw2V7SYH+7yPcV0FV54EnTa3B7H0ppmco32ILiNbqASR8kcj/Cq1hPtbyW6Hp9aLV3tpfs03Q9P8+9MvbcxP58fAJ/I1XkQ/5kOmU2k4lj+6f8kVauIluoRJHyRyP8KVSt9bc/e/kap2c3kyGCXgE/kaY7dOjJLG5A/cOfp/hUd5AYX81OAf0NF9AY28+PoevsauQSrdwFH69D/jS8xWv7rJLWYTx5P3hwatVz6l7K5weR/MVvKwdQy8g0maRd9zFk/wBGvN3bOfwNWL9AUWUduDT9QgLqJU6p1+lFuRcWhiPUDH+FPzM7bxFH+k2XqwH6iksJQ6GI9U/kag09ykjQvx/iKY3+iXm7+E/yNMd9pGssqM5jz8w7U2aBJ12tnjpVK+Uo0dynVTg1deZUiEvVTj9azLv0ZUuQ0EAiiHB6mqtnAJX3v91K2UdZFDocg1FLDviMUZ8vPpVXE4a3MmeZriXanI6AVbJWxi2jmVqbBbi1DTz9V6YqpGrXlxufp1PsKoizWvUtWkYUG6m6Dpn+dESm5c3U3EY6D6Ukx+0TC0i4jXrinTHzpBZw8IPvfhQOxKree32iTiNOg/rVYbr6bPSNf5f4mi6fcyWcHQcVpQRLBGEH4/Wswtd2JQoUADoKdRVWQn7REoPHJNBsVpSGv409P/11Ip3X7f7K1Cg3ak/sP6Yqa2O65uG9CBQYpEdt815K3pkfrTrdsRzzf7R/SotOOTK59v60tv8ALp7t67v8K0BBa/LZyv8AX+VHMenehf8Aqf8ACkHGmkjv/jRd/LZRL9P5UBbT5Cg7NOz0J/xpbH5YZX/zwKJ0drOKNBknHT6VLbQOlu8UnG/PT3FA0tURQKRYsQNxfOMe/FTwQEW3lvwW61aSNYkCJwBSeam/y9w3elTcpRsK20jae/FZc1nJE3m2x6du9W7m3a4wu7ao5/GoFuJbZhHcjI7NTXkU/MWC/Vvkm+VvXtSy2hRvOtDscduxqWW3guhv7/3hVTdc2XDDzIqPQn1LUUyXAMUy4fup/pVOazlibzbYk47dxV3/AEe9TI6j8xTQ88BxIPNj9R1H1FMsZb3qyfJN8r/oa0apPDbXa7x19R1qFRd2vH+tj/UVNgNOoJIlkwTww6EdRSQ3EUw+Q8+h61YqdgGIWxh+vtTs+1LRQB//0P3mhvyp8u5H4/41YltYp/3sR2v6ipZIoZxtkXn9ap/Zrm1Ja3fePQ1foAoup7dtl0uR6irBFteLnhj+opiXUMv7qcbD3DUyTT1zvgcxmmA4Jc233T5sfoetSCa2uRsbr6Hg1AJ7q3/16b19RU/+jXg7Mf1FADwksY/dtuHo3+NNLRSfu5hgns39DUflXUH+pfzF9G6/nSi6hf8Adzjyz6N0oAX7NJH/AMe74H91uRXzx4/8YS63dNpdo2LK2fBKnIlcd/cDt+depePtYOg6DILWQrNefuUHXaCPmI9MD9SK+Za7cPC/vs8/E1Le4gooorvPLCiiigAooooAK9L+Hvi99FvU0q+kzY3LYBP/ACzc9D9D3/OvNKKUoqSsy4ScXdH2rLBFMMSDPvT0RY12r0HrXDfD7W21rw/GJm33FmfJcnqQPun8v1Fd7XhyTi+VnvRkpLmQUU1iFGScCmJKrqXH3R3qLF3JCQBk8Cmh1K7gePWqQJu3yeIl/WopZWuJBBF92tlAzcy3FcebIVRflHenrMHcogyB1PaoNu3FtDx/eP8AnuajkkOfs1tx2Jo5U9ieZrctmePzPKHLe1SllGATjPSqOVtV8uIbpDQEWH9/dHdJ2/8ArUuWJXM+poVEYYy4kx8w71CrSE+dKfLUdv8AGnxTGXJC4UdCe9TytDUkxLmBbiPaevY15r8UPB2o+P8A4U+NPh1ayra3PiXRdR0yCeXJjjkvbaSBXbbk4BfJxzivUQQwyvIp1K/QrzPh79iX9mrxP+yh8G3+G3ifVrTWbyTVbnUBcWQkEWyeOJVX94FOR5Zz25r7UIS9t/Q/yNWnRXUq4yDUMdtHC+6LK56jtRcLGXbytaSmKXgHr7e9Wr218webF17j1qxdWq3C8cOOhplslxEPLk5XsQelSTboJZ3PnL5b/eX9RVt0WRSjjINZ9zbyRyC4t/xAq/E5kUOVKn0NUxrsyvbIYw9u/IHI9waowE2l0Yz91jj/AArZwCc+lZmox8CYduDUiaGXyGORbhP8kVYul+0Wwmj6j5hSxMLy1Kt16H61DYTEZt36jp/UUE2JJgLq0Eg6gZ/LrUljN5sO09U4NJCPJma37H5l/qKpHNldf9Mz/I/4UFeZt0xlVxtcZHvT6imLiMmP7w5oLIprfzIfJjOwVWukkSFbaFSQeCauQTCaESfnUiOjjKEEe1ArXMu6YW8K20fU9f8APvV20h8iLB+8eTUrRRswdlBI71LVXBLW4VV84m58kdFXJqx83GPxqsInF2Zf4CuKkGRqcR3Le7foKr2vFjKf97+VWkifyp1I5cvj8aSK3ZbVoWxls/rVXFYgkwunAeuP50k/Gnxj1xVxrcPbrAxxtx09qk8mMosbDITpn2ouFipeoz+UijPNWJIi88cnZM1ZoqbjsQmCMyebjLVNRUMsQkxhipHQigYy4maBN6oX/pVOHUQTiYY9xVkTSRHbcDj++On4+lRzWUUw3xHYT6dDQQ79B7QQy/vYTtY/xL/WniV4/lnHH94dPx9Kxj9ptH7r/I1ow6ijfLMNh9e1AlISfT0k+eL5D6dqrx3M9s3lzAke/X8K1FQAbojgHt2pWCSDZIvX1qrj5eqIWS3vEz19+4qqWurP7372OnNYtG3mWzYPoael4yHy7pdh9e1SL1JUnt7pdp79jUf2aWE7rV+P7rdKWSzt5xuj4z3HSogL63/6ap+v+NA/UmW5Q/u7hfLJ7HoalEJUZgbb7HkVGlzBcDy3GD6NTTayRc2z7f8AZPIoESmQgbZ12+/Uf5+tNNqoO+3by2Pp0/Kmi7KHbcxmP36ipBFGw3W7bc/3en5dKC9xPNnj4lj3j1Xn9KlSaKT7jA+3f8qZvnTlkEg9V4P5H/GnjbKu5kx/vCgZNRRUDzRodvVj2HWqSvsJtLcnqOSNJBtkAYe9OJA68ZoLBepxUjGpGsa7V4H1okjSVdsgyKkooApxWvknMUhx6HkVZdFkG1xkUm9N2zIz6VJQJW6EEUEcIITIz71PRRQMKKiWVHYopzt61WllaV/Ii/E1ai2RKaSuW1dWJCnOKge4AkEUY3H+VVppRABBD17n/Penxr9mQYGZX6CrUVuZOo27L5lmSYKwjA3Me1K8yxY39T2FVXf7KuB88rdTQirbr59wcyGjlQc72/pF3cAu5uB704EHpVFUeb99cfKg5C/404PJMcRfLGO/c/Sk4lKfkWZIo5RhxmhlVk2NyDxUQnDyeXGNwHU9hU4ZSSAenWs2mjVNPYy4YpbWc8FozxkU6/ti376PqOtalFO5PLpYz7W4W4j8qTlgOfcVQdZLKcMvI7e49K1PskIfzEyjdeKmliSZCjdKLhZsryxx3kIZDz2NVLOYxObaXjnj2NSQW9xbOcYaM9R/Wpby184b0/1i/rUi13L9UFi+zXBZfuS8fQ0+1lkdNsylWHqOtWyARg0F76mNeqYbhZ078/iKs3aC4txKnbn8KnuofOhKjqORVPTpsgwt/DyKDPl1sS27C5tTG3Ucf4UWvzwPbSdVyDVaM/ZLwxn7j/5FXZR5M6T9n+Vv6GgEVrGQxyPbP2PFa1ZF9G0ci3Mf4/WtKGVZoxIveqZUdNCWoPJRVYRDYW7ip6qW8rOXik+9GfzqSyJYXtIG8ob5D6VDH/olsZn/ANY/TP8An8a0g6ligIyO1Dxo4w6hvrQRbsZ9hAcGd+rdP8a1KaAFAA4AoOcHb1oKSsV7ibyjGo6yMBQebwD/AGD/ADpJ4nkeJl/gbJp21/te/Hy7MZ980DKdrzezn6j9amtcBrh/9s0tvA8c8srdHJx+dSwwGNZAxz5hJ/Om2QkUbLi2lf6/yp8YP9nHHfP86tw20cMZiGSD1zUyKqLtUYAp3BIpeQ72aQjg8dasyQRyhVkGQtT0VJVhAABgU12KqWALY7Ch0WRdrdDVb9/B1/ex+v8AEP8AGgZUXUmDkSR4Ht1FWyLe8XI5PqOCKR4ba7XcDz6jrWXLaz27bx0H8QoM22ty/M11boCD5gB69/xp8N3Dcjy5BgnsehqKzvJJSY5BnAzkVJLYwzfNH8p9ulX6jWuwx7aWA+ZaH6rTor9Cdk42N+lMWS6teJR5ieoqfFrer6n9RR6liPaxOfMgOw+o6Ugmmg4uEyP7y/1qH7JcQHdbyZHof84qVLwqdl0hjPr2pgShYZv3kRwfVev40/dNH94bx6jr+VQtawyfvIG2H1Wk8y7g4lTzV9V6/lQA8x21z8y/fXuOCKTF3F0xKvvwaVWt7rkH5l/AinFLhPuMHHo3B/MUAAu4v48xn0YYp32u2/56CkEpzh42B9uRTvNH9x/yqbAf/9H98IruC4G08H0NT4dfunI9D/jVCXTlPMJx7GoA17a8OMoPxFXbsVY0GaGT5JlwfRv6H/Cmi2aP/USED0PIpsd3bzjZJxnselSfZ2TmByvseRS2JE8+WP8A10Zx6ryKTy7S4+ZcZ9RwaPtEkf8Ax8R8f3l5FL5dtc/OvX1HBqQDbcx/dbzV9DwfzoM8D/JMNp9GFAS6i6MJR6Hg/nVgDzE/eLjPUHmgD54+Kt0p1q30+I/u7eHdjPG+Q8/oBXl1dx8RuPGF6gGAgiA/79Ka4evcpr3UeDVd6jOi8K6bp2q65b2OqymGCXIyDjJxwme2TW14z8FXHhuf7Va5l0+Q/Kx6of7rf0PeuDr3DwX40t9Vt/8AhGvEuJGkGxHfpIP7re/oe/1651HOL5kXTUJLke54fRXe+NfBVx4buDdWuZdOlPyt1MZ/ut/Q964KtoyUldGMouLswrvPBngq48ST/arrMWnxn5mHVz/dX+p7UvgrwVceJLgXV1mLToj8zdDIf7q/1Pauz8aeNLfSrf8A4Rrw1iNoxsd06Rj+6vv6nt9emU5tvkhudEKaS557HmPinTtO0nW7iw0uczwRYGSckHHIyOuDXO0UVulZHM3d3PVvhLftBrdzYFvkuYc4/wBuM8foTX0CJVZzGvJXrXy98PJvJ8XWbdiJR/5CY/zr6UZjDbbv+Wkv9a86vD3j1MPL92Qyk3dx5an5F/zmn3LF3W0h6DrRbAQwPcHq3T/P1pbUeWklzJzWe23Q2t+Il1IIYxbxfjUka/ZohxmV+gqG1Qyytcy9Bz+P/wBarCuDvu5Og4Ue3/16HpoJa+8RzuLePylP7x+SacoFnDub/WNUVuplmNzJ0HP+fpUkX+kzmdv9XH0oemg1rr9w5ALdDcTcyNREu7/Srg/QelRoDdzl2/1aV8D/ALVNv4z+G3jTQvjl4PvLo6bHcQw31p58n2Yyx/dLR52hJkBjbjggHq1VGPM7X1/rQiU+Vc1tP61PvwK1yfMk+WIcgevualyJFyfliH6//WrgrL4i+GNV8Ar8TBdeX4eFkb95D94Rqu5lI/vKQVK9d3HWvjf9mmTxf8YPid4h+OHii9uodDtZ3isLLzZPs5mdcKojztIghxnjl2DdQankbTb6Dc0mkup+g48xzk/u4x+Z/wAKck8cjbU5x37V+e/7U9v43+HPjHQvjl4SvLr+zknihvrMTyfZ/NThcx5wFmjBRjjggHq1fYll8SPC158P4/iRZzhNENl9ueY/8s4wuWBH98EFSOu4YolS0TCNXVpnpdQySrEMuDj1r89f2ZW8Y/GD4meIPjf4pv7qLRLSd4rGz86QW5ndcBPLztIgixnjl2DdQasftU2/jP4Z+M9A+Ovg2/un05J4otQs/Ok+z+anC7o84CTRgxtxwQD1aj2PvcjYOt7vOkfoHHNFL9w5qWvMbTx74YuvAMXxTtbkJoT2X25pD1SMLllI/vAgqV67hivjz9mtfGvxo+JfiH43+I726h0e1nePT7LzX+z+cRgL5edpEMOAeOXYN1BqfZJpyvoHtWmo21P0Roquj+fEGU4P8jUg3OvOVNYWOm9ySmOiyIUboa+X/wBqTwH4n8WfDi41jwrfXVrrXh7fdxC0lkiNxBj99EQhGTtG5epyuB96tb9mT4sj4sfDO1ur+XzNc0jbZ34J+d3Qfu5j/wBdV5J/vBgOlaOn7nMmZqpeXK0e5Wpe1ufJk4D8f4UXqGC4E0fGefxr89/G+veIf2hv2kbX4deEtSurLwv4V3i+ntJniDiNh9pbchGdzYhTrj744Jr9FWth9jW3QAFAAB9KJw5bXJhLmvboE372JJ4vvp8w/qKbcRrdwCSPqOR/UVBp0+CYW78iquo6fb31peaJelltdQikiby3KMBICDtYYIPPBHIOMVibl/T596eS3Ven0rSr82Pgj4q8U/B344az8E/H2oz3tvqEudOubqRn3yYzCQWJ4ni4Izw4C9c17V+1v8YJfAXw8Tw/oE7R+IPFBNvD5RPmRQDHnSDHIJyI175bI6V0Ok+ZRXU5Y1lyuT6H1hDGbeUqP9XJyPY+lVh/o19jokv9f/r14v8ABP4Y6h4X+EkXhrxleXV9q2tQvLqLyzyNJG9wm3yo5CSV8pcDKn7+WHWvln4KeKfFHwk+Nmt/Az4hanPf2+oy79NurqR5MyYzEULE4E8XBAPDqFHOaFC97PYp1LWutz9FbueaBg64KnjB9amtrgXEe7G0jqK+RP2tPi/N4G+HSeG9EnKeIfE5NvD5ZPmRQDHmyjHIJyEXvliR92u+/Z+8Fax8OvAdhp/ii7nutZvv9JvjcSPKY5JAMRAsTgRDAOOM5Peo5LQ5mNVP3nKj35LiNpDEDhx2NSsyoNznA96/LvUvEvxW/ar+I+s6J4H1mTw94L0R/LeaIyIHj3FY5JPLIMskuCyoWCgD1GT6x4N/Y6j0DxJpPiRvHWoXVzpl3BdyI0WFuBDIJCp/ekgNjB69a1dJR+KWpCrOT91aH3arKw3Kcg0isrZwc44NeLfF/wAD+J/G3hX/AIRjwz4hm8Myy3EcjXkBk3+UmdyYjdCc5GRuAOK+ZZv2IdQ8h77T/iTqDapglZniKgt74m3DJ96zjGLXvSsXKck7Rjc++Z7tIG2sp/pU0cqTx7oz/wDWr4T/AGTfiT44v/Evin4M/EW8bVb3w15hhnlcySr9nlEE0ZkPzOocgqTyOe2ANv4m/sq658QfG+p+Kb3xzd2el3TIYbKKN3ECLGqkAmYKMkE8J3qnTSlyyYlVbjzRVz7G+0y277LkZU9GFX0dJBuQ5FflD8RvCHxP/ZXfSPGnhXxndaxo9xdC3mtbjeI9+DII5Ii0issiq3zDay9sHBr9LfD+prrfh7S/FGnZS31W0gu0XOSEnjEgB9cA9amdPlSkndBCrdtNHaUVmQaijfLMNh9e1Y3jPRb7xP4R1fQNKv20y61K0lghu0zmB5EKiQbSDlTzwR9axRvfsdZVUwbTugOz27H8K+Bo/wBhvUSrXV38S9Qk1E8iYW5AB/Gcsf8AvoVQ/Z88c/EfwF8b9R/Z7+IGrvrkCrILSWZzI8bxxfaUZHbLbZIeShJ2nGMc56vZJpuErnP7VppTja5+hW4MNkybfryPzqlNpwPzQnb7GtWiuU6Gr7nOBri0buvsehrRhv4pPllGw/pWgwDDBGRVGXT4X5T5T+lBNmti2EAGUPHp1FRl1A2zrge/I/P/ABrNEN7bHMfI9uR+VWItQjb5ZRsP6UFXJ/syA74GMZPp0/KjzLmL/WJ5g9V6/lSiCMjfbtsJ7r0/LpSb7mL/AFi+YPVev5UDDda3Pytgn0PBpPImi/1MmR/dbn9aXdbXXytgn0PBoEM8X+okyPRuf1oAUTgDbOhj+vI/OkEEDfvIjt91P+RU0ZkYHzE2H65zTkjRCSigE+lACRq6j533fhinkgDJ4Ap1ZM8zXLiGLp/OrjG5nOfKiSS5kmbyrf8AOpY41gwPvSt/n8qaAtqBHGN0jUSOLZcD5pG6mtd9InOtPek9fyJHdYj837yU9B/npTWKwjzZzluw9PpTEAt0NxPzIaZAhkY3M54HSiy3DmexNyy+Zc8J2X/H1qBriW4fy4OBUUjyXcuxPu9v8a04YlhXav4mm7R33FG83ZbDYYEhHHJPU1YoqIsTIEHQDJ/pWGr1Z1pKKsgeQIQvUt0FUryU5EKd+v8AhUkbhme5boOF+lV7VTNMZX/h5/Gt4q2r6HLOTl7q6/kSSH7JAI1+83ehcWkG4/6x6bGPtF0ZD91P8imPm7udo+4P5VVuj+ZnfrH0Q61jABuZeg6f41OG8pDcS/ebgD0HYU4gSyiNf9XH1+vpVRybu4CL9wfyqd3dl/CrL+mSQKObqf8ACnRjzmNxPwo6Ckl/eyrbR8KnWknJlkFtF0HX/PtVb/10Fov63Y5S13JzxEvb1p7M0x8qH5YxwW/oKHHS1h4/vH0H/wBekZsn7Nbcbep9Kj0K23/ryJVAH7mHgDqf896ASR5cAwo6t/h608IiJsXhR1NVGmkuG8q34X1qUrmjfLuWjNHHiPJZunHJqxWfuS1/dRDdIamiSYHzJ2wfQdKTj1KjN7E7NtGcE/SokuYXO1W5NSJKkhIQ5xVa4tRJ88fD/wA6lJbSHJu14al2iqkLieJo5eo4NLA55hk++n6j1ocRqd7Fqiooy4yr9uh9ajCXAlzvBj9D1pWDm8izWFPG1rcCVB8ucj+ordpjosilHGQaktq5n38YkhWZO38jT7dhd2xifqOD/Q1NFCY0MLcp2+h7VlxMbO6Kt06H6etBO2poRfv4Xgl+8nyn+hqnaSNbzm3k6E4/Grc/+jyi5X7p4b/Go7+ASIJ05I6+4oB9zTqlJGUnW5T6MPb1pLK585NrfeX9avUFbmVfqY3juU6g4NWZpH8gTQHpzj2qxLGssZjPQ1n2MhUtaydR0/rQT9oktb3z28t1w3tViS4iicJIcE/lWPPG1pcZTp1FaFyi3VuJI+o5H9RQCZoVGkiPyjA/SsqxusYgkPHY/wBKknie2k+0wdD1FBV+ppbl3bc89cVFPOsC7mUke1Rq0V7HuU4I/MGkS4w3kXAw3r2NAXHwXUVxwvB9DUUsk9u/mH54j+YqC4sip8224I7f4U62vQ37ufg+v+NBN+jLsM8U65jP4d6nrLnsiD5tt8h9B/So4r90Oy4HTv3oKv3Niioo5Y5RujOaloGV3gDHep2P6j+vrQHlTiUZH94f4VYooAoObe1IuVH3vk4/z7VOjRTfPE3PtSzQpOmx/rxWa9hNGd8DZ/Q1SA0yzr94ZHqP8KhMNvcfMvDjuODVNb6aI7LlPx6GrgNtdcg5I/AinaxVg2XUX3WEo9Dwfzo+0xn5J0Mef73T86NlzF/q28wejdfzpPtUZ/d3C+WT2bp+dMkPssefMt28sn06flTvMni/1qbx6r/hTTbKPngcxk+nI/KnoblWCyAMP7w/wrMBuLW4PYv+Rp6xSIRtkJHo3P61I8UbkFlBI9al4FVcAoqrcXSW+Mjk1V/tNPSjlvrYOaJ//9L9/KKKKAKz2sD8sgz7cU6KBIRiPOPrU9FFwCohHGG3BRu9cUrOifeYDNPJAGT0oAWiqTXaltsKmQ+3SrKs+3MgC/jTaa3A+bvijbNB4qeUji4hjYfh8n9K84r3r4racLvT7fVoAXNmxVyOm2Tpz7H+deC17NJ3ijw68bVGFFFFbHOe4eC/Glvqtv8A8I14lxI0g2I79JB/db39D3+vVn/Cp/8Aif8A+u/4lP3+v7z/AK5//X9PevEq73/hY3iP+xv7I8xM42+fz5uz0znGe2ev481zSptO9PqdsasWrVOh2fjTxpb6Vb/8I14axG0Y2O6dIx/dX39T2+vTw+iitoQUVZHPObm7sKKKKsyPQfhnZm68URv2gjeQ/wDoP9a+gLxzLceWvOOB9a88+E+jtb6dcazMMNdHZHn+4nU/if5V6ZHZMswlZg3Oa8+pNe0fkevRg/ZrzG3RCCK3X/Pai6OxI7VKm8iRrvzW+6vSmrDI94ZXGFHSsFJaHS0K6bUjtF6v1+neobpt7Lbx9BUyNhprlu3A+gqtZLudriToP50J21JavoS3J8mFbaPqetOkRkgW2j+/J1/rUNvm4uDK3Qc/4VZQqWkum6DhfoKHpoTa4jKFC2kffqfauW8aeE9J8d+GtR8EavHvsNShMUuOqd1YZ/iVsMD6gV028wwPO3+sl6f0ryX41fE20+D3w21DxVMVbUZB5FlG3/LS7kB8sY7heWb2BoinfQcrWd9j8qbrVviXo9ne/smpcRPHPryQiTfgEmTaI89BDJJtmx1BHqSK/Xn4d+BtL8B+ENK8IaQMWWlwiPdjBlkPMkh95GJY/XAr8vrX9nbxNrHwKvfjZLLO/iuS4OsKMnzHshkvJ6+axJnB/ugY5Nfob+z98VIvjD8OLDWJHC6lZgW2ooOP9IjA+YDskow4+pHY121np7vzOCgtfe+R6R4x8K6V8QPDGp+D9Xj3abqULQyEdQeqMvujAMD6gV+ONzq/xJ0exvf2T454pI59eSEOHwCS+0R55Ahkk2y46gj1JFfqn8c/ipZ/Cj4fah4jBVroDyLKI/8ALW5kB8sY7hcFm9ga/Oi2/Z08S6r8B7z433E07+Kp7j+14lyfMexGS0nr5rEmcH+6Bjk0UdFeWw6/vO0d+vofp78OfAGmeAPB2k+ENL4tdMhCbsYMsh5kkPvI5LH61s+MfCWk+O/C+o+ENYiDadqcLwyccjPKsvoVbDA+oFea/AD4s23xb+Gtj4iu5F/tWz/0XUIhxi5jA+bHpKMOOwzjsau/G/4owfC34d6l4tlIFzjyLGJv+W11ID5Yx3C4LN/sg965WpOVmdKdOMLo/Ky41X4l6TaXn7Jkc8UiT69HCr+ZgEmTYI88gQySbZsdQRzySK/Yf4c+BtJ+G/g7S/BuiD/RtNhEZYjDSS9ZJT7uxLH61+Wdr+zp4l1b4D3nxvmnnfxZLcnWIxk+Y9gmS0nr5rE+eD/dAxya/RD9nz4rQ/F74b2OvzMDq1p/ouoxjjFxGBl8dlkGHHbkjsa3xDuvd+fqYYdWfvfL0PdAoGcDGadXzJ8av2dfD3xi8QWniDV9dvdMlsrYWwitdmxgHaTJ3Dr81ee+Cv2PfD3hHxZpXivT/EmpXMulXEdwkcvl7HMZzhsDOPpXNGnFq7Z1yqNOyifbLuiDMhAHvX5IfFS68QfssfFrxBcfD+RYdJ8Z6fOYIwcC3MpIyo7NBLkxHGNpx61+qWp3GmaDpl3rmt3AgtLKJ55pZDhUjjG5ifoBX5g+E/BGo/te+P8Axn8QNc82z0e2gkstLHQRS4P2ZDjqIgfNlA6s3oa2oJK7exzYht2S3Pq79kX4Vw/D74ZW+v3qq+s+K1jvZ3BDbYXGbePPsh3H/aYjsK+sa+Dv2N/iJqlvHqvwK8ZEwa14Wkl+zJJ98wo+JYs9/Kc5HqrccLX1t8RfBNp8SPBOqeCr26lsoNTWNWmgx5ieXIsnGeOq4+lY1U+d8x00WvZrlR0F5EYJVnj4BOfoatyAXlqHT73UfX0r4c/4YL8Hf9Dfq3/kL/CvrT4deB4fhx4T03wdYXct9a6ejRrLNjzGyxbJxx3xWUoxXwu5UXJv3lY+XP2xfhyfEHgy2+Kmhv8AZte8HOjPIDsd7bzAeD/eikIdfq2OSK8N+BA1f9or42f8LR8dIjWXhOG22W6fc+0AHyQEPO3zA8x/2sDpXoH7Wfi3U/HfjTRf2ePBEm+71CaKXUtvQE/PHG+P4Y1/fSe209jXBaroQ/ZF+Nuh6tpsssvgnxJbx288kmXI2BVmLf7UcmJhj+Fio713wv7Pl69DhqW9rzdFufqeGDAFeQa+J/2zvho2s+ELb4qaC/2bXPB7pIZVOx3tvMB4P96KQh1+rY5Ir66sbxVVPnDwyAMjA5BB5BBHBB9a+E/2svGWrfEDxhoX7OHgeTfdahPFLqJXoCfnijfH8Ma/vn9tp7GuKhf2isdddrkdzzr4Ex6x+0b8a3+KnjiNGsfCcNpi3TmMXGD5ICdQvmCSY/7WB0Nfo746Z7bwprGpQcSW9lcSZH+xGSDX52aloh/Y7+OeiapYySy+B/ElulrdGTLnACrMW9XjkxMMD7rFR3r9FvFaJeeBtbWzcSpcafc+WVOQQ8LYwR1HPFbVtWmtuhnRVouL36n5R/s1fE34geGPDmr+EfhT4QPiTX9Ruhczyy5NtBbpGEjDbWTktu5aRR6ZJ49quf2lfjn8L9Wsz8afBEVrplxJs860DIwPX5ZPNliYgc7cgkd+9af7BQt7fwb4ivo1H2iTUUjkPcxpCCo/MtivYP2zLawuvgJrF3MVMkE9k8JP983CJx77Wb8M1tOUXV5XEwhGXsudS2PpLSNV03xNpFtqunTLcWl7Ek0Ui9GSQblYexBrzz4ofEzSfg94QvvFOtsJBGNltBnBuLhgfLjT69WPZQT2rz74Ca7FofwD8Ma5r1wlpb2GnGSWWQ4RIIy2CfbaBXyjaRa9+2f8YTe3glsvh/4aOAvT92x+5/12nxliPuIOvAzzQprmd9kdM6mi5d2emfsY+BPEF4viT40eIcx3XieZ1t8jBkBlMs8v+60uAv8Aun2r63+IPxL0b4X+FLrxd4ognltLJ41YWyI8pMriMYDso6nnnpXS2FrB4ft7fSrOBYLK3jSKKJBhEjQYAQdAAOMVf1DTdM12za3v4IrqB8ZSRQ6/LyMg5HBrOc+aXMzSEOWPLHc/Kr43/HLT/wBpK40D4a+ALFtMt5b0TtcapPDbAyhWjQf6xlVQGY/eJY4Crng/pz4O06Pwn4Z0fwoWLx6PZ29mr4wWFvGIwSPcCvjv9r34UeCbL4V3vi2x0a007VNLmtzHPbxLAZUllWJ428sANw2Ru5GOMc59o+CX2n4kfs4aJY+Ibh/tGpaXcWLzZzKIwZLZZMnq2wA5PU9a3qWdNOOxhTTU2pbn0FLZwTjenBPcdKzmiurQ5XOPUdK+Hp/2EfDEPzL4r1V19R5X+FfTPwd+H2l/CPwm3hGxvrjUIjcSXHnXGN+ZAoI+XHA21hKMUtJXNouTfvKxxHxR/am8D/CHXh4Y8SafqF1fvbpcr9kjiMe2QsACZJVIOUOeDXzd+zwL742ftGaz8d7v7PY21kJPJsxcJJcAvALWMGMHdtEXLSFQpbhc84/QPWPB3hLxITNq+lWd+7Lt3TQRy5Hod4PHPSvze8XeFrH4R/th+E7HwFELK11k2jy28GRGiXckkEy7egXC79vQcEYwK6aTTTjHexjVUk1KW1z9TqKrwRyRx4lcuamZlQbmOBXAdw6io0kRxlGDfSpKACoXgil/1iA1NRQBWjtYYjujBH4mrNFMZlUZY4HvQAjRRufmUH6ipKarBhleRVeS7jjO0fO3oKaTYnJLVlqmMGK4U4PrUcbSOPnTb+PNBmQHavzH0HNOwcytcieKRYTHH87N1JqFQLSIyv8AffpWlTHRXGGGRVqXRmTp9UUEP2eI3EvMj1Hap5rG4l6D/P6VLewSykMnIHao7siKJbdPxrVO+3UwkrPXZDAWvLj/AGB/Klupt7CCLoOOPWp4o3htvkGZGptpatG5klHPajmW/Ynlb077lq3gEKY7nrViiiudu+rO6KSVkVyxacRjooyf6VFM22FmHWQ4H8v5VKkOwyNuyX7+lDRBmj54j7fyq7oyabRSum8mKOAfjTlPk2RbvJ/X/wCtT7i0aeTeH46Yp1xbvKI0TAQdatSVkjJxd3K3oQqfIst3eT+v/wBaiH/R7Zpj95+n9KkuoZJWjjQfKO9SOu64jQD5Ixn8e1F9A5bP00IZm+z26xD7z9f60R4tbZpT95+n9KgYfabvH8A/kKdckz3IhXoOP8afkzNveS9EPgPkQNcN1fpUij7PDvbmWTp9TT2USSpEPuRcn69hSKwkke4f/Vx8D+ppN3NVG2i/ruI5MCCNOZZKkijEIES/ePJNQwHJkvJfw+lPO9UwP9dL+n/6ql9gXf8Ar+mRzM1xJ9mi+6OpqTiP/R7YfN3Pp9aXAhUQQffPU+nuaimlS0Ty4/8AWHqf6mqvfRBteT/ryHNJDaDA+aQ9fWq6+fetycJ+lNgtTMfNlPydfrWn8oX+4g/Chvl23IUXPfREaqIx5UA57k1PvUEISN1UjNJMfKthhR/FViG3WHkcsepNQ13N4v8AlHmIGQSDg9/epNoznHPrTqikljiG6Q4qNWa6LUlprEKMk4FZrXskjbLdeactmz/vLpt3tV8ttzP2l/hRZN1Du2g7j7c1YByM1QNzbxfJCN59v8akjNzIwZgI19O9S4ijPoXKzdQt/MTzV6r1+laORnHelqDV6mdZyLcQGKTkgY/CltXMbGzl6jp7inNbFJRNb8HuvYinXMBkVZI+JE5H+FAWM2eN7KcSR9O3+FbEMyzRh1/GoI3jvISki4I6j0NUAJrCXJ+ZD+v/ANegNjcrNureQSC5g++vUVeR1kUOhyDUlA9yhIi3tsGXr1H19Kq2ExRzbvxnp9a01jCOWXgN1Hv61nX0BDfaYuMdf8aBW6lW8h8mXK/dbkVesroSr5EvL+/cVKCl9bY6H+RrEZXjfaeHQ0E7al6SN7KXzYv9Wf8AODV4+TfQ+/6g0y2uUuE8qX7/AKetU5YZLJ/OhPyf54NAiaO4ltH8m45Xsanmt4bpd6HBPcf1pySQ3ke1hz3HcVSeKexbzIzvj7//AF6DQI5p7NvLnGU7f/Wq80dveLuHPuOopsVxBdL5bjBPY/0qrLZSRN5lsx+negCN7K4gbfCc+460sWoSp8so3foaki1B1Oydc+46/lVora3YzwSPwIoIt2HxXcEv3WwfQ1arEl06ReYjuH61asoZo13SEgdloLNGiiigBrKrDawyPeqpsbcnOzH0Jq5RRcBiLtGBn8aVlVhtYZHvTqjEiMdqnJHpQAqIiDCAAe1PqOSWOIZc4qulw8p/dR/J6niqs3qFy5VcRHzfMds46D0qV5EjGXOKEfeM4I+tCuBmG0mmlZpOKd/Zx/vVqUVr7WRHKj//0/3yhgZDukcu36VYLBepqtdXHkrheXPSmQxsh8yb5pW6D0rS19WBaZtvA5J6CoJJjF+7X55T2qOacxnyo/mlf9KRVFuMD55pP8/lTSAX5Lf95Md0p/zxTfJluPnuTtT+7TsJb/vJfnlb/PFBjaQebdNhB/D2/GquFhyuoHl2q5Hr2/8Ar05kjUb7lt316flVSS8J/d2y/wCfYU6O1J/fXR/CnbqwI7yOLVbWWwMXmQzKUfPAwa+VvEGiXXh/U5dOuR9zmNuzoehH+etfXI3EYQbF/X8q5nxR4UsvEth9nmPl3EfMU3UqfQ+oPpWtOqoO3Q5a1LnWm58o0Vq6vouoaFdmz1GIxsOh/hceqnuKyq9NO+qPHatowooooJCiiigArb8P6Hd+IdUi02143nMjdkQdSf8APJqtpek32sXQtLCPex6nsg9Sewr6O8LaBF4esfslku+eXBmmPUn+gHYVlUnyrQ6aNLneux11tBaaZZw2cOI4YVCKPYcVPHOsw+TOPXFVfs8MP7y5fefenrLLNxAuxP7x/oK8mx7SLjMqjLHFOqi0kMB5zJJ+Z/8ArUD7TN9790vt1qeXqMuEAjB5phiQoYwMA+nFRKwUeXCpf3zx+dSp5gGZCPwpbARLbCKJkiOC3c0yWAsIoF/1Y6/hUjXUC8bs/Tmp1YMMindrVitEoSAz3aoR8sfNfEPxn+EvxR+N/wAZdEsdW0trL4eaNIB9oNzBmcY3zSCJJTKDKQIl+X5QN3GTX3fSbRx7Vcaji7oynTUlZmUlnbW9rHpFrCsdvGgj2BQEEYGNoHTpxj0r4b+Hfwl+JXwX+O+rHwfphvfh7r7bZWW4hX7Or/NH+6dxITAxK8A5QnGTxX3c0cscREXzSMeTUEUa2sfmuMyHoK1hOyZM6fNbyPhv4xfCH4ofGX4x6Hp+t6W1l8PtHkAM/wBpgJnGN8zCJZTKDJgRISvyj5jjJr7hWC0sLJLRYlSFEEaQqAFWMDAQDpgDirBb7OvnTcyv0H9BTYLdnb7Rccseg9KJT5kr9AjBRbt1Phr4ZfBz4l/B3476lc+GNGN78PNebEpW4t0+zo+XjPlSSCQ+QxK8A5QnGTxVr4z/AAk+KPxt+M+h6bq+lmx+HOiMA1x9pgzOCA8ziJJTKDJgRLlflHzcZNfddQu+GCLyx/T3qfbSb5hewily9CGG0tba0SxhiWO2jQRrEAAgQDAUDpjHGK+Evh58KPiT8E/jxq8vhDTPtvw+15tsrJcQJ9nV/mjPlSOJCYGJXgHKE4yeK+57y6KDyozz3PpTIIEhXz5+PQU4PlTv1HUjzNW6CW9mW/ez8Drj/Gnvdqn7u2Gf5fhUbNcXpwo2x1YVYbbCoPMlP5//AFqlvuNL+U+Vf2o/DPxf8b+E7bwZ8OdIN7b6jJu1Gc3MEASKMgrFiWVSdzfM2B0UDnJFez/CjwFYfC/wJpXgrR1Eps483E+MCW4fmWT1OW6DsuB2r0ZwgG+6YfTt/wDXpqTST/LAmxB/Ef6Cm5tw5SVTUZc3U+IPjt8FfiHb/FjQvjT8HrJL3Vo3H9oQefFbBzEAoJMsiArLFmJwDnAB7k19r2E9xcWcE72j2kkqK7ROVzG5GShKEgkHgkEg9jirLPBAcyHe/wCZ/wDrVB9quJztt0x703JyST6CUVBtrqaIJC5cj3rD8QX+rWGhX9/4fsP7V1GGGR7a1EiR+dKB8iF5CqqCepJ4FXRZZO+4k3VKskEfyWybz/s/1NYW7G3M+p8afsyfBDxp4Z8TeIvin8XbUR+KdWlkjhVpYpyiSnzJpcxNIgLnCqAcqoI6Gva/j38Kbb4tfDfUfDMUajU4/wDSrBzgbbqIHYCewcEoT2Bz2r2ZPOJ3SYA9B/jSPcQJwzj+dW5zcuYhQio8vQ+Y/ghbfGPwr8Hbjw9448MtPrvh6JotLiN3av8AbItn7mMyJMQnln5CWI+TGMnNcV+zH8DvGfhfxL4h+KXxctRF4o1WV44EMsU5RJD5ksuYmdAXOFUA5VQR0NfZR1CEHCgmlFzM33YT+PFaOctdNyVGOmt7HkXx8+FkPxd+G2o+GURf7SiH2mwkPGy6jU7Rk9A4JQnsGz2rA/Zt0/4oaF8OofCHxV0k2F3op8i0ka4gnE9pj5AfJkfBi+7zj5duM819CRNK3+sj2fjmpqy53y8hryJy50fmmfg3+0J8AfF+sX3wTtoPEHhvVn3C2lMZ2ICTGssbyRNujyQGjb5h164FfxH4I/ar+Pz2Phj4hWVn4S8OpMs8m3aELrwD5YlmmZgCdoJVM8nB5r9NKjkiSVdsgyK29s97K5j9XW13bsfEf7Snwi+Iep/Drwz8Ofg9YPd6PYL5V7CLiGImO2VBBvM0ke/JyxAz8wBPavGvAGlfti/DLw/B4a8I+EdPtrOEu5zLZu8jt1eR/tXzE+voABwBX6fxI0Y2btwHTPWsu+scZlhHHcVKrNQ5bIcqCb5k2j5i+D+tftQax4t+zfF3RLOy8PeRIWlge2Mgm48sYinkbB5/hxXLePNe/a88K+M9Vn8GeH7PWPDfnH7GZfJJMWBgMqTxS569RX1mjvGwdDgitu3vI7geVKAGPGOxqFU1vZFez0tdn5x+JPBv7Vv7RL2fh3x9bWXhLw8komkEZUI7pwCYxLNMzAE7VJVc8nBwa+9/DXg6x8F+HdO8OeHtyWelQJBEGO5yEGMk9yep963LuwK5kg5HcVHb6g8fyTfOvr3FKdRyVmrIIU1F36liHUedlyNp9f8AEVy/xBt/Esvg3VpvAKo/iHySbLeV2NLnofM+T1612MkMF4m9Tz6j+tVoLGeJ8+ZtHt3rJOxs1fQ+DYvGX7cumN9ifwRp9xK/Am/dH8zHdiP8xW98HfgH8TNQ+KH/AAuz47XcT6xECbWzjZXMcgXy0L+V+6VY1ztVCcnknOc/ddVLm6WAYHL+ldXtXtFJHP7JLWTbH3FwsC+rHoKppDLc/vbk4TqBRFEFzc3R59DTS0t82F+SMVmtNhSd9/uJGulTEVqm7+VSxwzE+ZPIc+gOB+lTQwRwjCDn1p8sixIXbtSb6I0UesmSZxSbhjd2rOiElx+9n4j7L61YmmWFfMk69hUW6FKWlxzyiIeZIfoKgALD7RdcAdF9Pr70RqR/pVz17D0pSoYefdcAdF9P/r1exDdxuZ7o/L+7i9e5py+TAdkKb5Pbr+J7UAy3PIzHF+pqOS6hgHlwAE/pR5E6L3mWCjMMzNgeg4H4mo/tMY/dWybz6DgVAkNxdHdOcJ6VcRVVdsCgD17f/Xo06lK720GbJGG6eTA9F4H51Ir8bY1yB3PAp4jA5b5j71LWbZoohTdq53Y59ajkmWPhuSegHWm5bHmSnywO3+Jp2KuWKazKoyxxVdZXm/1Ywn949/oKikuIYCcfO/8AnvRYlyW5eByM1G8scf32ArMEt3dcR/KPbj9anW1hiHmXByffpT5bbkc7fwonW4WQ4jVm98cfrVhiFGScCs5r3J8u2XPp/wDqpy2rP+8vHz7dqpoam+mpZW4idtqHJ9hU5IAyapC4B/dWqZ9+gFKwSIb7l9x9O34CpsNSLakMMg5FOqiJp5/9Uuxf7xqRQIsjJkc9f89qVhqVycIincoAJqGO2jjkMq5yaevmk5bCj06/rQ08KfeYUahpuyIxSRxybPndjn0qvOjJDHbR/wARwTV5JFkGUzj6VLT5rbicE1oVdi/LGPuR8n+n+NIzFPnAzI/Cj/P5mrWBUXl4kMvU4wB6UXG49ipJILWPAO6RuSf61BDbZH2i4PHXnv8AWpI4GMjXF1xjtUwbzf8ASJvkjTlQf5mrvbY5uW7ux5YFfMk+SMdB/j/hVcB71sn5Ih+tCq94/mPxEOg9a0QAowOAKm9jVLm9BERY12oMAU+oncIMn8B61FPceRHlvvnoKmzZs2kFzcrAuBy56Cs6KCW7fzJDx6/4UW8DTsZZT8vc+tTSXEkreTajj1H+eK2WmiON+9rLbsSvNDaL5cQyf89aiENxd/NMdielPjtobUebM2T/AJ6VOQ0i7pT5aenQ/iam9ti+Vv4vuGL5MB2QJvf2/qafsmk5lfYPRf8AGmC4XPlWqZ/QU4hIxvuWyfTt+AqS1b+thUaNeLdN3uOn51Om/GZMfhWe16znZbpu/wA+lKLa4m5uZOPQf5xTt3GpdI6mgHViQpBIp9UR9ktzhBl/bk1KDcOc4CD35NZtFqRNsTdvwM+tKyq67WGQaY8scf32Aqs1/AOmW+lCTYOSW7LMUMcIIjGAalqiLx2HyQMalSSdj80W0fWnytApp7FmmkAjB5Bp1FSWYbb7C43gFom/z+lXLm3W7jEkZ+bHB9avMAwwRkGoI4RCx8s4Q/w/4UrCsc3l439HFbdreJcDypfv/oafeWYnG9OHH61gkMjYPBFTsM0rizkhPnW2cDt3FTW2oq3yXHB9e1R2uoYxHcf99f41NdWKTDzYeHPPsar0AWexSX95Adh/Q1XjvZrdvLuQWx+f/wBeqsNzPaN5bDgdVNa6vbXse08+3cUwAra3q5GD7jqKz5LCeM7oDnHTsakOnSpIDDJgevcVqopVQrHcfU0ARWyzrH/pBy1SySJEhdzgCmzTJCNzn6CqCJJeP5s3EY6Cml1ZnKVtFuKjXF2ThvLj9q0I0Ea7QSfrVeG4SSXyYh8qjrUUk0s8vk25wB1NatN6BDbe5f3AnHcUwsWOAcAdTUaKiJsThR1NVSzXb+XH8sKdT60kjQl8x7hjHFxGOrev0pvmBP8AR7QZI6nsKdgyDyYfkjHBP9BSCQL+4tBkjqewqwEEEUX7y5bc3vUwMsh+VfLX36/lUJ8m1O6Q75D+dQeddXTYi+RP896LX1AttJbW5yeW/M0itcT9vKX9aIreKDp80lT7Xf75wPQf41LaQDEMcZIVizd85JqTzR6H8jT1AUYAwKdWdwP/1P3phUuTdzdT90VJPN9nXJ5d/wBKkZlUGU/dTgD/AD+VU7dTK73cvQf5/Stt9WBLDH5CeY3zSydB/n9ae7i3GT880n+fypWkEYNw45PCiooRsU3c/U9KN9WA5Qtuvn3BzI1U/wB9eyew/IU9EkvZd78IP84q6p3furfhB1b/AArS9vUAijjg+SMb37/57VYEfO5zk/y+lORFjG1arXN0IRtXmQ9qw1b0AllnSLhuSegHWkMmxPMn+QelVkUWym4uDmQ1Ckb3bebPxGKvlQFLUdNtPEMH2a/hD2/v1z7HqD9K8l1v4Xuk5/sC480H/llLwR7BhwfxA+tezzXDMRBbDA6cVJ+7sY/70rVtGTjsROlCe6Pli+8JeJNObbdafL9VHmD81yKwhDMZfIEZ83O3ZjnPpj1r60/eXEnqxr53OYfiBx1TU/5TV3Qnfc86tQULWe5nW/hTxHckeXp0yZ6GRPLH5tiu00r4aTuyyavcBB/zzi5J/E8D8jXshMk0n99jWikcVkvmScuelc8qzR1RwsVvqZmkaBY6XbCG2iEEQ5wvU+7Hqa0Xuwv7q1WqzPPdybB+XYVd/dWKf3pDXO/7251WtohiWwX99eNn2NKZpZz5VuNq+tRJFNdnzJThP89KtK+f3VqMAdW7VL8wsIscVvwo8yU/n/8AWqViqruuHAHoOn/16ryTR2wKR/NJ3J/rVZIbi6bzH4Hqf6UWvqwJZL9j8sAxSpbTT/NO5AqeNIIPljG+T9f/AK1SOON074HoOn/16nmt8IrDFMEPyQrub25/M1IPtL+kY/M1Ue+jQbYE/oKgD3dx93OPbgUcrerGan+r+aSX88AUxru3X+P8qqx2B6yt+VXY7eGP7qik7AOilWUblz+IxUuM0UVkBAYEaQSnkip6iEqM2xTk+1NkmEfyjlj0AqtWBPTcAEkDk1E0vlgb+WPQCmB2jUvcMB7f560WAl8qLOdgz9KV0R+GAP1qos005xCu1P7xqWSby8RL+8k9P8aqzFcsBQF2jge1RxwxxElBye9M80wx7rhhn2pIZpJTny8L2JqbSFoRvZCSTzJJCR6U6YThNtuAB7VMZow4jzlj2FSFlXqcZp3fUXLEyobPA825OB6f40571VGy3T/P0rVqEQxBt4QA0c19xctvhKKW8kv7y6bA64pz3cUQ8u3Td/KpZraSZvmkwnoBU8UEcI+Qfj3qrrqTyvoZ/k3lxzKdg9P/AK1TpYQr9/LmrckiRLvc4FNSXeu8javvS5pFci6jkjROEAH0qSqPmPctiIlIx1bufpSPOxbyLUZPc+lTYfNEtNLGp2k/N6d6c7rGNznAqj+5sxub55T+dV0Sa9k3OdqD/PFPlW5Lm9upqxSpMu6M5FSVRJJ/0a24A6t6f/XqXzgGESfO3f2+tS0Un3LNFM3KG2k8ntT6RZmzadDIzMhKE/lVRtMlB+RwfrxW7RSsBRtftSfu5xkDo2aWexhnbecg98d6u0UwIYoIoRiIYzU1UJ7wI3lQrvfp7UTTtbxDccyN+lVykcyEu7ry/wB3GfnPX2qG2hVV+0z/AFGf51HaweYTPL90c896uBDcuJJP9UPuj19zVbaGKTk+ZkYje8fzJeIh0HrV/wCSNOwUU+saV3vJ/KQ/KP8AOaW5o/d9S6kxnc7OIl6n1qL/AI/Jv+mUf6mmzvgC0t+p4NWVRVUW69AMt/n3qtid9GK0iInmvwo+6KqRKZmN1P8AdHQU1iby42L/AKtKt/K59I4v5j+go2D4mNZlUfaJ+APuj/Pc1Eqmf/SLjhB0FNQG7k81+Ik6Co5pHvJfKi+4P85osS2JNcS3DeXEpx6etWIreOABpPmkPQf4U9FS3HlRDfIev/16sxx7OWO5j1NDfRFRhrd7iBWfl+np/jT3kSNdznApssqwpueqSKbhvtFxwo6Cot1NG7aIspIZPn+7H6nqf/rVXa5eZvKth/wI1G7yXz+XHxGOpp0s0dqnkw/e9auxm5eehITDZjJ+eU/maRYy37+7OAOi9hUcUYhH2m6Pz9v8+tU57h7huenYU7XIbtv9xPNePKfLh4H6mnxWaovm3BwPSnQxJax+dL97sKozTyTtlunYVS7Ih6az3Lkt8ANkAwPX/AVFFbzXB8yVjj1P9KlgtURfOuOB6H+tRz3bzHy4uF6e5qV2iN95/cWXngtR5cQy3+eppiQTXB8y5OE9KIoI7dfOn69h/nvTC89621Pkjo9CvX7iZrlU/cWiZP6UqwJH+9uTvc0q+XB+5gG+Q9f/AK9K5S3HmzHdIf8APFL0Lt1kSku43P8Au1/X8+1VpL6OMbIBn37VVJuLxuPu/oKtx20FvtaU737f/WFFktybt/CV1S6uuWJC/kPyq0sVtb/7b/mfyqc7nGSdi/r/APWqs11bQZEY3H2/xou3sVyqOrJ907fcQKP9r/AU7aw5kkP6AVnG6upjtiGPpTkspZDumbH6mhq24KV9i+11bqP9YPw5/lSpPHJ9zJ/A0yO1gj6Lk+/NWqjQ0V+oVDLCkwAfoDmpqiMqKdpPPp3qV5FO3UkAAGBS0x5EjXc5wKjEvyGSQbB79aAuSkAkEjkdKa0cb8soJ9xUStK53H5EHr1P19Kia6aRvLtl3H1PQVVpEuS6lvYu3bgY9KEREGEAH0qAv9nj3TtuP+elLG8pzJLhF7Dv+NFguh/kReZ5pGW96huLYznmQgenahbkytiBNw7k8CrEkqRDLnFGqF7rRD5Rgi22ygn3qklpPM7NcHFam4bdx4HvTgQRkU1JoHBMzmube3HlxLuPt/jTEW5vOZG2R+3er7QxOcsgJps0byrtR9g78UXRDg+uxWM1tajZGuW9v6mot17c8r8qfl/9ercVpDFzjJ9TVokAZNF0th8je5nJp6DmRi/6VdSCKP7iAU2OdZT+7BI9e1RSTsz+TBy3c9hRqykoR1RcqN5EQZdgv1qo8otx5akySH15pFjCf6RdnLdh6UrA5di8GBXcOlRR3EUrFEOSKzXmmu38qMYT/PWrIC2q+XEN0rVXKLnvtsaFFVAxt0AkYyOegqcuqqGf5frU2NEySqdxZw3By2QfUVcoqRmI+luPuyA/Xj/GpreK9tyEwHj9M9K1aKVgK01tFOuHHPY96bDZwQEMoyw7mrdVp7lIBzy3pTSuJu2rLNVp51gTPc9BUaSusZnn4HYCs5Q95Plunf2FWo9zKU+iHwxPdyebKflHX/CrDs90fKg4iHBNSsPN/wBHi4jThiP5f41bRFjUIgwBVOQow6FOVTBAI7ccsce9PiiES+UnXqxpzzKJfLHJAz+J4FVrqQwp5S8yPyTQrvQ3jboNlc3EgtoOEHU1Y2jH2eLhR94/0+tNijMEYjX/AFkn6f8A6qjncjFpB1PU1e+iAVnMzfZ7fhB1NNlmS1XyYevc0TSC0jEMf3j1NNgt1hXz7j8BQrAMhtWl/eznA689TWgnzLtiG1fX/CkVHm+eXhey/wCNWs4rOUrgNVVUYWq/2gO3lwDce57Cq0kz3T+RBwnc0Syi3X7PbDL/AOf1qlHuVYnkuooPlkJZvao/7Rt/Rv8AP402OCGAb7pgWf1qTdYeq0WRJ//V/ee5JklW1i4AqztUssC/cj5P9BVW1+SOS6fknp/n60+YtHCIRzJKefxrofY0t0Gj/S59x/1UdIxa9n2LxGlOlUwwi3iBLt1xU6wPFB5cWN56mi9tQAASfuIfljTgkfyq0qqihVGAKSKNYkCL0FSVg2SyrdXAgTj756VUtoTzcygk9QO9aeBnOOadVKVlZBczFgmuJvMnG1F6CnXMdzL+7jG1B79avhlJwDUZmiVtrOM+lVzO+w7la2tmgQscGQ1VezuZGLtgk+9aryJHgucZp5IBAPekpvcVyjDA1tEWUb5TXzGyu3j8q33zqePx86vquvlr/mpH/cW/9r11UJXuceI+z6n0mFjsY9zcyGs4mWeX1c10RAPBpixRodyKAfaudTsdlzPdlso/Lj5kPU1HDBkfaLk8dee9W/sUZl81iW9jSSQSTy/veIl6Ad6OZFEYL3hwvywj9aZLcf8ALvaD2yKSWVpm+zW4wnT/AD7VJmOyXYg3ymqFYRLeK3XzJzk+lSgzT8/6qL9TUYiWP/SLs5b0qtNcS3DeWnAPYd6NWFieS6ihXy7dQfft/wDXqosdxdNu6+56VcgsAPmn59q0VAUYAwBU8yWwmUobGNOZPnP6VeAAGBS1TkulV/KjG9+mKz1ZJcqu9xHG2zq/oKgurhoUCL80p9KjUJaR+bLzK/8An/8AXTUQLrzLEm+Tj2qhunvW2r8kXeo4oZLtvOmOF/z0qSSZpGFtajA9atKwEu9Yz9mtRlu59KcSIPkX95M/+efamEi0URRDdK1IzLaJknfK9SA53S1G+Q7pX/z+VQxRPcHzrk/J2H+e1R28BlY3E5+Trz3qwd9621flgH61WwrAZZJ28q2G1R1anZjt/wB3EPMlP+eaY0+SLayH1PYUpeOyXA+eU9akY8RLH+/u2y36D6Uzzp7ptsHyJ3aoo4ZLg+dcHC1o5VEz91BTZNhkcSxDbEOe5NRyTQQHc53Sfr/9aoGuZbhvKthgetTQWUcXzP8AO1T6i9BqvdXByP3SfrV8AgYJzS1D5ymTyl5Pf2pblLQkZ1RdzHAqIzKqGV+F7etQHE8xLf6uL9T/APWqAE3s/wD0yj/WiwrkiASn7TccKPug/wA6jBe+f+7CP1psztezCCI/ux1NPkBcizt+FH3jVEg0jXDfZ7bhB1NJNOlonlQct3NNuJktU+zwde5/z3qvaWpuG3P9wdfegh72W5Lb2zzt5sp+X19ath/OPk2/yxjqw/kKhkka6k+zwcIOpqRuf9EtuAPvH0/+vQNKw7cW/wBHtuAOren/ANenKNg8i3HPdj2/xNCqAPIg4A+83+e9V5ZzkW1oPbI/z+tBWxMZI4G2Rr5krdfX8amijkz5kzZb0HQUlvbLAM9XPU0lxcGIiNBukboKn0H5st1TaRpZvKiOAn3j/Sop5WgQRId0r96RwYI0tIv9ZJ1P8zSSE2OdmuZPJjOI1+8fX2qvdXIUeRBwBwSKdPItrEtvD17n/PrVS1hM0uD9wcmtEZyb2W5ZtYlgjN1L+AqGNHvLgs/Tv7D0p91KZ5RFFyBwPrV1IxGggjPJ5Yj/AD+VFwUb6dB20SnaB+6X9SP6CrTMEUsegoVQoCrwBVW5PmOlsP4+T9BWRrsRSzOtoZG4aToPTP8A9ao4B9ktWlP3n6f0pLj9/dJAOg6/1pl6++UQp/D29zWhm+46xTG+6k/z61LdSGKHaP8AWS9f8/pVhVC+XAOijJ/z9aqoPtF4XP3Y6V+o7WVkSRRGCERr/rJOp9P/ANVR3GXZbKH5R3NTeYFEl2fov0/+uaihDQxGdhmSTpTBroNuGxtsrcfX/P8AOpkUQKLeLmR+Sf60lpC6KZXH7x/WrEETRBi5yzHJNK4JdR0cSxDA5J6k9TTpJFjQu/QVJSEA9ag29DGiSS9l82X/AFa9v6VPOk9w4iQFIh3rTpCQOtVcz5NLFN45UiENqMe5qvbWLJJ5k+DjoK0Xkjj++wXPrS7l2b88dc0XDkV7mbc29zO+cjYOgzTrayMR8yXkjoBWgHVk3g8etPov0DkV7mHcRXU0m5kOOw9Klt7ZYV8+47dB6f8A1616KfN0F7NXuc7c3D3D+iDoKuQxJaR+fNyx6CtHyoi2/YM+uKhntVnKsxPFHN0I5Gnczo45r2TzJDhB/nAq2ZCT9ntBgDq3YVLNFKVEUGEXuahllW1UW8A+Y/5/Oi4WsDyR2aeVF88h6/8A16jjtCx8+7b3x/jT44ktV8+4OXP+fzp4je4/e3PyxjkL/jRcdr7iiV5f3dquxR/GRx+ApHkhtQf+Wkh/P/61Qz3ox5dvwPX/AApsFk8nzzcD070wv0RVeS5u22jn2HSrsOn4+ac59hWjHGkS7UGBUlLm7DVNbyGKiou1Bge1PqvNcRQD5zz6CmtOY4vMkGCegqDW8SWWaOEZkOKFk3JvYbR71QhTfm7uenb/AD/Koi0t9JtTiMVViOYlkupZ38q1H/AqkAisl/56Sv8Amaa8sdovkwDdIaERbVTcXBzIaoz6j8CL9/cnMnYDt7CnHgfaLnjHRfT/ABNMX5R9queD2HpVQCW9myeEH6UFXH5mvn2/ciFTtKsH+j2qb3/z1pXc5+yW3GOp9KaWjsx5UQ3ymgm3UcES3/fXD75D/nijynn/AHtydqDkL/jSBVhH2i7OX7D0+lQ5nvW/uRj/AD+NK5XkTPdFm8i0XcfXsKligER3ud8p71LFEkQ2Rj6mq812AfKg+dzSv2KtbWRLKY1G+dvoP/rd6r/aLi4O22TaP7xpYrMs3mXJ3t6VoAADA4FSKzZHErouJG3H1qWoZJkiwDyW6AdTUM5aTFuvBblvYUGl7Eyyq5JXlR1PaqhJu32LxCvU+ppk7ksLODgdDRO4iVbWDqev+fetDJvuEkrSOLa04HcildhbqLe2GZD3oOLSIRR8yyUvy2Kbm+aV6CRAEsk8yT95K9U1We9k+Y9PyFNRZLmXGck9TV+WQW6i3txlz/n86dyd/QdlYMW1sMuep9Pc0rEQfJH+8mb/ADz7U0YtVCL880n+fypwXyRtH7yZ+v8A9f2pGw5VEHzH95M/+fwFNcpD+9uDvfsPT6f402WZbYED55X6n/P8qdb27E+fPy/YHtQT5IVFmnIklzGvZR/Wr1QTTLAm9vwFQea0UZnn+8ei+lZl7Ek8xTEcfMj9P8ajlkkQLBGd0rd/T3qKM+TEbmXmR+lKD9liM0vMr1oRcSSRbKPYnzyHqT/M1UtYGnlMsvIHJz3qEb55MdWc1eupFgiFtH1xz/n3oM99XsiC4le7mEUfQdP8aviPylFvF1PLN6f/AF/SoreL7PH5rDMj8AVejTYMHknkn3pNmkY9WORFjUIgwBVcSktIx/1cfH1Pen3EvlRFh1PA+tUro+RbpAOp60kXJ2GWgLPJeS9Bmlth5sjXcnQf5/SnTq0dvHAv3nPP+frU/lgCO2HQct/n3NadC4KyEMvlI1w33n6D27VFHi1iM8vMjdKCPtV1/sRUpVru4BIIiT9aryZrYbAgAN5cfUVbSNpCJZuvYen/ANekaFpJgXx5a9B71bqJSM2wrIuZ2mf7PDyOh9616aABwBipi7ajTsUSj28WyBSzt1NEFsYVMrDdIe1XyQOtN3Lt3Z49afNILmTJa3czbmx+dM+wXPt+dayyxycI4OPSn8etVzMrmkf/1v30EKhY07J+pp/lJv8AMI+b1ppmQTCHncRmoJLl4pwj48s96uzZdmy9Ufmxhtm4Z9KrzM8Uiy5Plngj096rX0WCLhOvf+lCjcFG5bnulgIDKTmieV1g82Hnv+FROBd2uV+9/Wo7GQPGYH/h/lTsrXKtpcsRSGeDKnD/ANaZOn2mDK/eHb37iqsLG1uTE33Tx/hWh/q5f9mT+f8A9eqas9AatsY1vL5Moft0NXdQi6TL9DVa8h8qXI6PzV2BhcWxjbqOP8K1b2ki30kOH+l2mP4/6inROZ7YH+Nf5iqdk5inML9+PxFWV/cXRX+CXkfWsmraEtW0LYcFRIOhr5alBb4hsq9Tqh/9KK+oFG12jP3X5H9RXzEo2/EYDrjVf/a9dFDS552K+z6n0zaz+bHtY4deD/jUS3LwzeTcdD0NLcRNC/2mL/gQqR0jvIQy9e3tXPpv0PQ03LbMFXcegpqyRyDKEGs+1nMTfZ5uNvAqO6tjE3nRcD27UuTWzDl6M18DOe9VUtliZpRl2PTNNtboTLtb7w/WrDSpGQH4z37VOq0Is1oZLQ3U837wY9+wrThgjgGF69zU4IPSlocm9AbuFQTzLCu48k9BTmZt4UA89T2qrlZJnmf/AFcXA+vekl3EkLPcNDGM/wCsft6VXiC2kXnS/wCsfoKjhU3Vw00n3U5/+tTDuvbnH8C/oK2t0NLFi3Xlryf8KZGjXkpll4jH+cVLKpuJRbpxHH1qG5mHFrB0HHHf2oEJNM05FvbjC9P8+1TMyWMXlp80h70ZSxi55leorSMyubiboOefWl+RNiSIfZ4zcz8yP0FQwRNduZZvu96Uhr649I0/l/8AXqSZy5Fnb8DoTTCw9ibt/Ki4iTqfWmzOXYWltwBwaSeVbdBbwfePU9//ANdOGLGHc3Mr1mTYHdLNPKi5kPU0kNsqjz7nr6GkhiEa/a7n73UCrBbaPtNzxj7q+n/16dwJGcKvmzfKB0H+e9VAkt62+T5Ih0HrUqQvO/n3HT+FfT61oVN7AMSNI12oMCn00ttBY9BVCGYzyPO3EUfQf1qAG6hcNGFijOCev0pqIbaAIv8Arpf0/wD1VHbL9ona4k6Lz/n6VPEwZ5LuT7i8L9KvyMyO6byo0tIfvHr/AJ96Jz9lt1gj++3XFJaje8l5L26UlsDcXDXMnRen9KYEmDaQBF5lk/z+lJI62MOxeZW6n+tSIwYvey/dHCfT/wCvWTJI88u4/MT0FJCY+CJ7iTaPqTV24kCgWlv9Dj/P505iLG32D/WvTLVFgiN1N1PT/PvVNjt0Jgv2aMW8PMr9/wCtOUCMC1h++3LH09/8KarGCNrmUZlk6D+QpHc2kBZuZpP8/pWQDLiXYBaWw9jVu1tlt09XPU1DZW5RfOk++3r2rRqm+g0uoyR1jQu3QVnRny0e9m+8/QfyqSU/aJxbj7q8t/hVO5c3VwIE6A4H9TQhsltQSZL2b8P8/pT4W2JJey9X6D2ptxgmOxj6cZ/z+tR6hIAUgTotUZ7Ge7tI5duSa1HP2O1CD/WPVayh82cE9E5olJurrYvTOB9BQSlbUsWUaxRm5k/CtCJSoLP95+T/AIfhUBw86Qr92Lk/XtV6pZrFWCs+JwWmum6DgfQVbmLiJigyccVVW3JtBBnaT1/nUlMr2I3NJcv/AJ9aitAZ7oyt25rThtkihMR5B61KkcaDEYC/SquQo7ECh2EsmMOeFz6Dp+tNt7YxQmNj8zdSKtMyqMscD3qOaZIQGfOCcVJdhWhjZQrLkL0FTVUuppIEEiAEZ5olLSQiW3PI5Hv7UBcneSOPl2C/WmzTLDH5jAke1Vp41u7cSR9eo/wpllIs8JhfkgY/Cgm/QtRSiaIyR8Hnr61BaXTTFkk4Zaq2xNrcmB+jcf4UXStb3IuE6H/JqrCv1NAYdXhft/I9DWC6vDKR0KGt5mBCTp0HX6GqeoQblEy9uD9KSYpq6uSzqLu1EidcZH9RUenyh4zA3O3+RpmnTcmA/UVC4+yXe4fc6/gafkK+0i9a/u2ktm52cj6GrMZOCndOP8P0qtdfu3ju1/h4P0NWGO11kHQ8H+lSWtNB7osyFG6GqFrI0UhtJeo+6at7vLkwfuydPr/9eo7q385dyfLInINANdURzzS28gc/NEf0q6jrIgdOQaqQSrcxGKYfMOGFU1Z7CbY/Mb0BfqaizRMdoPzenepsZrOu7YXCCWLlsfmKisrrH7mY/Qn+VVYL62Zde2SSUSuScdu1UbtbuV/LVfk7Y/rWq7BF3N0pFZXG5Dke1FwcblS2s0h+Z/mf+VXqKjkcouVXcfQVJSVthzsqKWboKrC5HlGdxtXsO5psw851tx06t9P/AK9Up2NzcCBPujj/ABNBLYsC+dI15Pwo6f59qcm69uNzf6tO1R3bAlLSHovGPerMgNvElpDzJJ/kmtCLdCKZnvJvIi4jTqaWeZbdPs9t9/uf896WR0s4fKi5kbqf6/4Uy2hWFPtVx+FZlD4YltE8+45c9B/nvSQBrhzdXHCp0HaqoMl9OAeB/IVYupDIws7ccDrWgELtJfTbV4QfoPWrcjmLFpaj5j1PpSSOtnEIYuZX/wA//qoUCxiMj8yvWZNgkcWUQhi5lahEWzj8+fmQ0y2Th725+o/z/Kkjja9kM83EY7UFDY4pLx/PmOEH+eK0FIYYj+WJe/r9PaowROP7sK/hnH9Kj+a8OF+WAfrQUlYa8kl0fJtvljHBarkMEcAwg57mpUVUUIgwBT6BpdWFVbqcQQlx1PAqGSZp5/s0fQfeP9Kqz5ubsQL9xOP8aqxLl2HWqlVe8nbOOn+f0qVnaCBp5P8AWy9Pb0/KlcCe4W3X7kXJ/wAKif8A0u72f8s4+tSLbYW3AtYDcScs3Si2XYjXk/Vun+femTsbu6EC/cXr/WrLqJplgA/dxcn69hQCQyP90GvJ/vP0HpWY7yXEu48k9BU13cefJhfup0/xqxbRrbxG6m69v8+9aEPXQexFhDtHMr0QKLeM3M/LP0Hfn/GordGupzcS/dH+cVZQieQ3Mn+qT7v+NZjQq5gUzS8yydB/Smyy/ZI9xO6aTr/n0FKrA7r2X5QPuj2/+vUNtG11MbmboOgoK8kPs7Y5+0TcseRn+dalFU7uRlUQx/fk4FVuXayIRi6uDI3+qh6e5qBSb25z/wAs0/z+tF26wRC0j9Oacf8AQrTHSST/AD+lSZepKp+1XRb+CHp9azrq4M8pYdBwKuy/6NZiMfefr/X/AArMSMyyCNepNaCl2NG0VYYmupPwqK1RrmcyycgcmpL5wuy2Tov+RU2wwwJbL/rJev8AWgduhZT96/m9QOF/qatU1VCqFXoKdWZsUZP3t3HF/DGNx+vaqhP2jUMdkP8AL/69XLZH3SzOMFzxn0FFraCBmYtuLUGdrkIImv8AHaIVeEYBZu7Uixxxkui8nr60kcwmjLRdR6+tBokyRI0jG1BgU4kAZPAqnbXDThkfh19KICcvbzckdM9watruXbuWUkSQEoc49Kgju0kk8raVPvVKIm0uTG33D/kU69jMUguE/wAmr5VexajrYmmuZIbhVbHlmrDkqyvn5Twf6Gq9wouLYSJ1HP8AjSWknnwGF+o4/Ci2lxW0uV7+HZJ5o6N/OpbCTKmFu3IqxtM0LRSffXj8exrJRmhmDHqp5q1qrFrVWHP5ltM6xnB/pR9puv71aF3AZwrx8n+lUvsM/pTU9AUtD//X/ey5HmRLcx9U5pZ1F1biROo5H9RVpIlQFV+6e3pVSDNvOYD9xuVrdPt0N0+3QLV1niMUnJAx+FPh5VraXkr+oqnMrWtwJU+6f8kVcuAWRLmHqvP1FDX4ja7dSvATa3Bgf7j9DRcKbe4E6dGPP9asOEvIAycHt7H0pImFxCYZfvjg/wCNO/UL9fvI72ISxidOdv8AKpIHFzBtY/MP8g0lqxQm1l6jp7iqozZXPP3T/Ki3QLfZL0ifaICp+8P5isy0lMM2G4B4NajfI4lH3W4P9DVK/t8Hz0HXrRF9Ai/si30RRhOn4/WrEg+02wkT7w5H1qB721SxaW+lWCNBh3kIUD3yeK8vvfjd8G/DG/8A4SHx7oGmRbtu+51S1gXf6ZkkAycU1GTWi2IlNRVpPVHrKP8AaIRIvDj+f/16+ev7D1lviAZo7SQj7d9o3YOzy/M8zOenT9eKvj9pv9m63uSV+K/hMxyemu2HH/karB/ac/ZsjfcvxY8JEN1H9u2HX1/11bxjON7ROWpyTt7x7pDKsybh+I9KpujWknmxDMZ6ivEJv2mf2bopPPg+LHhI5+8v9u2HP/kaut0P42fBnxPD5/h7x5oOqRltubXVLWYbu4+SQ889Kx9nJa8rsb+1prW6PRpoY7uNZIzz2P8AjUdtcH/UXHDjjmoYZoTGLuwlW4tpOcxkMPqCMircsMd3GskZ57H/ABrPyZpp8ivPZtGfNt+3OP8ACpoJ0uE8qX73cetQw3TwnyrnPHep5rdJh5sJw/UEd6H2kD7SKkqzWbZjJ2Gr9tcideeHHUVFFMJQbe4GG6c96rS20ts3mw8gU99HuFr6M2KgmgWWLygdo9qSKTz0zyhqLzpo32SRlx/eUVmkzO0iGWN7e18uMbiTyRTYx9mtvMP+sfpWoCGGRTGjRmDsMlelHN3HfozPkb7LbiP/AJaSdajtYlgj+0y/gKnls2luPMYgp6VVvZWaTyyMKnSrWugyqxkup/djxV+4+UJYw9W60loqxRNcv+FOj/0eNrmTmSTpQ2NiTuLaMW0X3j1NPXbZW+9v9Y1QWcZkkNzMeF5/H/61Qyu13Nhe/AHpRboK3QmtIgzG5lPC88+tSRj7RIbqfiNegNSSIHK2cf3Byxpkv7+UWkfEadce1SBIrCU/a5uI1+6P60+KNp3FxL0/hX096NgmkCD/AFUX6n/61XqTZmFNLBQS3AFOrPnZpbpLcfdHJqUgEv5tsG0cF/5VDP8A6PaLAv3pOv8AWh/398qdo/6U8YuL3PVYv8/zqtgsNmBgt0tU+9J1pLv93HHaRdW6/wCfrT4cXF485+7HwKZbf6RdPO3Ren9KYCXbCKBLZPx/z9an8vZAtsvDSdf6/wCFVYf9JvWkPQc/l0q55gXzbpug+Vfw/wATQBTvpRkW0fAXrS2MSopupeAOlUo0a4lC93PJq7fSAbLWLoOv9KBeYyJWvrlnf7g/l6Vcz9quP+mUX5E1Gw+yW4iT/WyU908qNLOM/PJ1Pt3NZjFVlkka7k/1cfC/1NV4Va7nMz/dXt/IUXz8pZw9scfyrUhiEMYjHaquKxLUU8ohjMh7U2ZxGox95jgfU1Ru/wB5PFaDp1NSMRSbe0Mp/wBZLz+dR2CbFkuH6L0/rTNRl3TCIdFH86slG+wJHGMl8frzVXJsR2AMs8k79v61nzSGSV5PU1s2sDx27K3ys+fwqKOztA21n3v6ZqSWhkI8iyeUfek6fyFOsIGTfIwwegzViecWu1AuQafPveHfAffjvWnLILr7hLeFoA7ykFnOSamMiiMyL8wHPFUrOfePLkOT2zU0SmGQwn7h5X+opuNtGTGd0miWKYTx7k4P8qYhMsTRScMOD/jVMk2dx/0zf/P6VdkU5E8XJx09RTatsRGTe/TcjhmZW8if746H1q7VWSOO6jDL17GoI7h4W8q4/OhxvsCny6S27lyZBLE0Z7iqkR+12pjf744P1FXwQRkcioxGokMi8E9fesTpKtsftFu0EvVflNV7OQwym2k9ePrU0wNvcC4H3G4b/GmX0JIFwnVOuP50GZOv7ibb/wAs5eR7H0/Gq0ym1uBcJ91utWVZb229G/kaIZBcRtBKPnHDD+tAEV9F5ka3EfVOfwqQbb2256/yIptsWhc2snI6qfUUxR9kuMf8spf0NADLCYjNs/BXp/UVdUAZgbpjj6f/AFqo3sbQyLcxevP1q7u86NZ4uo5H9RQWuxjMr2k/H8ByPcVp3cYubcSR9RyKLqEXEIkT7y8j/CodOmzmFvqKCbdCWzcXFu0T9uPwp1qcq1rL1j4+oqs4+x3Ycf6t/wDP6VYu0aMi7i6p19xQIm2+bG0MvUd/5GkglYkwS/6xP1HrSkiVVmh5I6e47imyxi4USxHDjkH+hoNBlzbsW+0QcSL+tOVor2Haw57juDT7e4EoKtxIvUVHNbuH8+DiTuOxoArRSSWMnkTcxnoanuLRZ/3kXDfoakVoryMowwR1HcGqQeexfY3zxnpQZkltdNG32e54I6E0XNs8JM9sSvqBVkrBex5H59xUMUr27CC46fwtQAWl55p8uXhux9a0qyrqy3HzYOvp/hU9rO8i7ZQQ698daCl2ZbKA5xwT3HWqcNr9lDyL8xxxUkjzxNuC+Yh9Oo/xqdGDrkKR7EYoKMu0jKs9zPxsz19e9SxvtV72Xqfuj2q/IiyKUcZBqrdWzzqqxkAL2oItYoW8RupTPL90cmo7u5M74X7g6f41buybeBYIwcHqarWMPmzbm6Jz/hQJ9iyuLK13f8tJP8/pSxhbKHzZOZX/AM//AK6cmLiY3L/6qL7v+NVMvfXOOi/yFAE1on3ryc/TP86hXfe3GW+6P0FOvZgf9Hj4VP8AP6VYRGtYAij99L/n9KA8hJVN1MLdOIo+uKlOJ2+zxcRJ94jv7VFKfs0QtoeZJKkMZijW0iPzNyx9u5oAUj7U2wcQp6d//rVeACjA4ApERY1CIMAU+g0CoJJlSJ5Bzs/nUN5K8cYWP7znFVbz93FFbJ1NAmwtR5NvJctyT0/z9aLb9xbtcv8AefpS3S8Q2a9+tLcASzRWi/dHJ/z9KCBEJt7QzH/WS9/r/nNEX+i2Zl/jfp/T/Gkuf311HbDoOv8An6Uy+YzXCwJ24/E0APs18iB7lhyen+fc06ZjbW/l/wDLSXkn69atFQZY4V+7GMn+QrGupfPnLDp0H0oB6DrS386Xn7g5NTXUpuphDH0BwPr61NIfsdqIx/rHptoi28T3Mn4f596At0JZRt22MPU/ePtT5EErC0TiNMFv6Co42MML3Uv+sk6f0pJWNrbbSf3snU/zoAimY3U4gj+4ta6qqKFXgCqdhD5cfmHq/wDKrrMFBZugoLXcdkVmQsJZZLt/uJwtOuJitru7y/yP/wBaobk+RapAOrdf6/rQDILcG5ut7fU1JIftN+E7Icfl1p9gCsUkoGT/AIU6xtpY5DJKMccUEJFfUJC0+zsgp2nxgu0zdFFTvaweYZJ5OWOcdKtN5dpETGvGapJ7E+bM63je4uvPYHbnd/hWgIWNz57ngDCinxS+fFuX5T/KqMM7pMUlJOeDntVqDdxOaVvM0w6kkKckdahS4WSRo8YK+tMkHkyiUfdbhv8AGobpGjcXMf40KKegSm1r2LSuyymOTvyp/pUG9raTa/MTdD6VKCtzEGU4I/Q0KRMpilGGHUf1FP1G9dn6ExkUbf8AaOBVMf6Nd7f4Jf50R27qzROcx9QfQ1PcwmaLA+8vI+tTotDanK61KVyrW1wLhOh61amG9VuYuqc/UelNUi7t9r/fHB9jUFnK0bm2k/D61p09Do1t5omuI1uoBJH1HI/wohdbm3MT9Rwf8aA32abaf9XJyPY02ZDBKLmMcH7wqfILdPuGWbNFI1tJ+FRSA2d0GX7rfyqzcR+Yq3MP3xz+FOkVby2DL17fWqv1C/Ulc7GE69Dwfp61Sv4cETL360+ylDIbeT+H19KsooKm3k5wOPcVPwsn4WQ2M2+Py/4k/lV/5vSudkWS3lKr9719qTzrj1rXkTNuRH//0P31iuIpvunn070ssKSgA9uhHas+aydfmgOfbvUaXdxCdsnOOx610cl9YM15esWacsQlj8tvz96p2jtE5tpPwqaO+hf73yH3qVo4p9rdSOhFRqtJAtFaRTbNnNuH+qep5lIK3MPOOvuKsSRrJGY35zVSFmt3+zSdD900731LTvr1JXUXCLLEfmHIP9KR0W7h9HH6GomzaSb1/wBU55HoasEY/ex856gdx/jU7bE7bFe0lyGt5eq+vpXhv7QHxrsPgj4LOpyxreatqBaHT7dukjqMl3xzsQYzjqSBxnNe7Tw+aFngPzjke9fjz+3n4judS+LlhozkiDStMiAj9JJnZ3P4jaPwr0sJRVaqk9up5mZYh0aDqQ32+Z83eMviV40+IWpSap4t1Wa/kc5WN3xFGPSOMYVQPYV4t8SfD9x4s8GX2k2aeZd/JLCDxmSM5xk+oyPxroVlq0ktfapW0R+ZylJy527s+BD8OvHYOP7AvP8Av0aX/hXPjztoF5/36ev0ESWrKSVtzF+2fY/PQfDbx8xUDw/e8/8ATI192/Crw5ceD/BGn6PeoI7z55pwDnEkhzjI9BgfhXTrJVlJcVVzCdRy0PT/AAV8R/GXgHUo9T8K6pNZSIctGpzFJ7SRn5WB9xX66/A34t2Xxd8J/wBsW8a2uqWTLFf2qn5Q5GRImedjjOPQgjtmvxGSWvtL9iHXLiz+KV7oyv8A6PqOnS7l9XidXQ/gNw/GvHzGhGdJ1EtUe1lOLnSrKnf3X0P1XkijuY/mBB/UUy2tjB1kyD27VKZlL+WnzN/L602SYhvKj+Z/0H1r4fXY/RrvYWYwqQ0oBPbjJqXcAu5uB71Sdo7f5m/eSn/P4VSJnu3x+nYVqoXCxdkvhnbAN5qWMzKN9ywHtUBMNkuF+aQ1RLz3D8fMatQT22KsX5L5RxGM+5pIri6lPyoMevNIltFAvmXB/Cg3Msx2WyYHrU2X2UIoeJPEmj+EdDuvEXiCf7NYWS75pAjPtBIH3VBY8nsK8Tb9qr4EOMPr7Ee9ldf/ABqvYPEfhXRvFeiXWg+JlNxY3y+XNGHMeRkHG4EN1HY18IftGfDT4M/C3wfFL4e0FjrGqytDbu91cFIggzJJtMnzEcAA8ZOTnGD9lkOBy7GVFh8RzupJ6ctrW87/AD+R+XcXZlnWXUpY3AOn7GEby5+bmvfZW010S8z6p8NfH74SeNtbsvC3hzWmub+8JEMX2a4jDbFLH5mjAHAPU17BeQ3ErgqMqvSvi39lP4P6Ppvh2w+Jt/b/AGnW73zGtGOcW0XzRcDpukGSSc4BAGOc/bUQuwf3pG39f0rz89wuEwuLlRwUm1HR81t762sloe3wrjszxuXwxeZxipT1Sjf4Wla929XvuVbo+RAtsnU9abaKsET3T/QV5b8fvGGueAvhdqnifw7IkV/bPbqjPGJFxJMqN8rZHQmuL/Zk+I3in4o+EtT1XxfPHcXFlf8Akx+XGsQCCJWxhBg8k1yQyqvPASzBNcifK+99P8+52VOIcLTzWGTyT9pKPNsrW163vfTsfRUjm2gLH/Wy8n/PtRAhggAHMsp4/wA+1Ty2nnTCVm4HbFfllrFj8ffAHxd1TxHomjatf/Zr68ktibe5urOSKcyAEeXlSPLfgA5B9CK6smyhZi6kFVUXFXV+vl/Vzg4k4jeTRo1HQlUjOVm4/ZXe1nf08j9V40WNAi9qfX5yf8L9/as/6Ep//BPd/wDxVfoHolzd3mjWF3qKeVdz28TzJgrskZQWG08jBPQ9KwzTJq+AUZVZRfN2dy8k4lw2bynHDwmuW1+aLjv2NDzgbjyV7DJqvEQJbi5btx+VFsc3FxKexx+VQytssRnrIf5814B9rYbakxxS3b9T0pYT5VlJMfvSf/qpLoeTbRW46nr/AJ+tSXSfJDaL3/pQMYP3Gn57yf1/+tQP3Gn56GT+v/1qZfnfNHbp2/rT775pIrZP89qAHWymG0Mg+9JwP5Co75hGiW69hk1cIHnRwjpEM/0FZs6Sz3DlVO0nHTj0qbk2JrRRBA9y/wCH+frTbNPMdrmXovOferF3BMyRwQD5R1NSyWzm3WCIgDuakkr27efNJdycInAp9u/+tvJfw+lP8qFbf7O0gHqQealaOGO22kF0HOPWqsK5RsVMszXD9v5mtmqttJC6kRDbjtVK4uLmKTYcD0x3pqDbsRKaSuXPKd7kSv8AcQYUe/rQluqTPcE5JoO26t8jgn+dVbSUo5gf8PrVKGjE52aXcuRpAx82MAknr3qzWc5NrNvH+rfrWgCCMipkraoqMr6PcpLM0VwYZjkPypqvdQmJ/tEX4+xq7cW4nTHQjoaitpd4ME33hxz3Fap/aRlKN/dfyHELd2/HX+RqrZzGNjbyfL6fWnLmzm2n/VPUl5beYPOi++PTvVafD0ZDv8S3RBdRGCQSx9CfyNXARdQh14Ycj2NMglW5iMcnJxz71WG+xmweY2o306oNF7y2ZcZVuoirDDj9DVa2maBvIl4Hb2q4w3Ymi5P8xTHjjukz0YfmPY1mmtnsXKLvdb/mNlR4nM8POfvL608GG7j9f5ioIZ3hbyLjj0NOmtmDebbnD+lVbuTfS6XqiErPaHK/MlWobuKXg/IfQ0yK7Q/LL8p/SmzWKPzF8h/Sm9dJijda03ddi66q6lHGQaaiBE8vqPf0rLD3Nr8rdPfpVqO+jbiQbP1qHTe6KVaL0ehWANjc/wDTKT/P6VPdRvGwu4eq9fcVaPkzrtOHHpT0QIgQdB61idC12K52XkIePgjkH0NCMt3CY5Rhhww9DVcobKXzF/1LdfapbiNwwurflh1H94UDJI/nQ20/JA/MetU4S1lceRJ/q5Ohq4jpcxiSI4I6ex9DSyRpdRGNuCP0NAD/APVyf7Lfof8A69Z13E0MguYumcn2NWYJGyba4+8Bx/tCrIwB5b8g9M96AIGCXttle/T2NRWcu5WtpR8ycYPpTQjWMhZeYG6/7NPurdnIuYP9Ynp3oAjQmyn8tv8AVSdD6VZfMDeaB+7P3h6e/wDjTUaK+gKsOe49DTbeRom+yz9f4T6igB1xbmXE0BxIOh9adbXaz/K3yyDqKMG1JxzF6f3f/rU2e1juMSxtsfswoAllgy3mxna47+v1oH75CkyY9fT8DUyBgoDHJHemvIqHaep6AdaBPQqRWPky745CF9KuSCMqfNxt96a8oQZfqegHWoGwB51z26L6f4mrUSHK2xYiKFRsGF7cYqCW8ij4X5z7VRluJZzsTgHsO9WEhjth5s3LdhWnIl8Rh7Vy0j95NEbmT5nxGvp3okvYo+F+c+1UJbmWY7RwD2FTxWfG+c4HpVOKWsiFUk9Kf3irdzytiKMGr6l9uZMA+1Uzcqv7q1XcaBbSSfPcvx6UpJehpGT6O/5E7XFuPlLg/rTvKTyykfyBvTiq/nW0PEYyfb/GojeyucRJ/WlyN7Ir2qXxP7iS4t5Ps4hg6Dr71DEv2O1aRxiRv8j/ABqxH9sJ3NgD0P8A9ar1ZNWNYvm1sYFjF5029uicn61fEikveP8AdXhf8+9WzFHsKAYDdccVBcWvnRLEjbAtSWU7X52kvZug6VfgRgpd/vvyfb0H4VG0BKRQr9wH5vfH+NXaACq88wi2L/FIcCrFZ82Gv4U9AT/n8qAHS4kvI0P/ACzG6q6/6Rfs3aL+n/16tqwWS4mPRMD8hn+tULY+TZy3B6v3/T+dAE1sRPdyznonAptm2Wmu36f5NNi/c6a793z+vFE/+j2CRd26/wAzQAWHzGW7k/z3NNsB5szXD9v5mnN+400DvJ/X/wCtT0TyrNYRw0xx+f8A9agB0knl2rzfxTHj6Hp+lU7CISzbj0j5/HtU2oLI7LFGhIUdhUscMsdlsjX95J19s/8A1qAKxze3eB9xf5D/ABqeUi4uVtV/1adfw/zipbW2kggOMCVvXtS20C2gYyONz96Beo0n7ReBB9yH+dVWP2u92fwJ/IVoW0MUSsYiW3nk02B7ZX8uNNh6VSTE5Lqy9VW5ieUJGv3Sfm+lR3Ms0fKY2nvS283nxlJOo6+4p8jtzGftFzcg+W3WaRGJ4TtSkW8shDAF09aoKWtLjB+4f5VbuUZSLmLqOvuKvk1JVS6btsXAABgVTnkeGQSdYzwRViKRZUDrTnRZEKN0NQtHqaS95e6ypcxCZBLHyR+ootZRNGYn5I4/CmQs1rJ5En3T0NLcRtC/2mL8RWtvs/cYX1518yBS1pcbT9w/yqe6gEi+dHyw/UVLIiXcQZevaoLWYo32eXj0/wAKq9/eW6J5Uvcez2JLWUTRmKTkj9RUkfeCXn09xVW4haB/Pi6VbVkuoww4I/MGpkuq2Lg38L3X4lL57Ob1Q1ckQTASxHDjof6UvEymKUfMP85FVB5lm+PvRGi9/Um3Lp0/ImW8QDEo2PnBFW1dXG5Dke1QSQw3Kq4P0IrPeC5tzuQ8eopcqe2jO6CutWaghVZDKvBPX3qpeQk/v4/vL1qKPUGHEoz7irqXUEnRsH0PFK0ou5esXcjG29t8Hr/I0y1lJzbT/eHHPerKQorb4+M9QOhqG5tzJiWPiRP1pXWw00/dGxk28vkP/q3+6f6U4p9nk3D/AFb9fY+tKCl3CVbhh19jSQSnJt5/vj9RVlEF3C0bi6i7datBvPjEsX3h/kinL+7Pltyp6H+lVtrWkm9eYm6+1TvoTvoTSQx3SqTxj/OKh/s+P++atkfxoM57dvrRl/7gpX8yb+Z//9H94o7q4hbZKM47HrV4S21yNrYz6HrQstvcja3X0PWq0tgw5iOfY11aPfRnTp10Y6SwHWM/gaqm3niOcH6j/wCtSia4hO0kj61Zjv3YhSm4n0rT3l5le+istxOnG4/jV2CW4l5ZBt9TV3qPmFDEKMk4ArBzT6GLkn0FIBGDyKaiLGNqDAqN540j8wnjt71AJWjjM0569FrNRZKTLBMcWWPG4/rX4i/t0vj9oG//AOvKz/8ARdftepwv2q56/wAI9K/D79uiZz+0Bfs/eysz+Hl17eXxtWv5Hg5zH/Z/mfKiS1aSWsRJaspLX1lz8+NtJatJLWIktWllp3FY20lqyslYqS1aSWquS0bKyV9Y/sbl5fjVZRo2C9pc/wDouvj9Jc19a/sYzsnxusynX7Hdgf8AfuscS/3MrdjvwK/2mnbuj9jGbycW1vyx6miR1tE2LzI3U0gxZxbm5leqMcclzJ656mvhUk9XsfrFrjoo5biTnn1NXJZkt18qH73c02eZYF8iDr3NRQW4b99Pwvv3pt31lsG+rGw20k53McL61ZeeOAeVbjJ9f89aa0slw3kwDCVJ+5sx/ekqHrv9xL8xq2zufOu2/CmyXiRjy7cYHrVaSWa5bb19AKsx2kcS+Zcn8O1Nq3xC9Sskc1y2eT7npXwd+3JB9nHgoZyX/tHP/kvX3y92znyrZcf59K+A/wBuKGWM+CnmbJb+0f8A23r7rhBv+2KF/wC9+TPyXxL/AOSZxX/bv/paPpv4I3zQ/BTwv5C/OmnKQffntXzZ+zf8bfil8RfiKfD/AIq1kXll9inm2C3gi+dCgBzFGp7nvX0x8DmRfgj4a8qPL/2aMn8+9fCX7HCM/wAX3CsU/wCJbc9P9+OvcwmGoVKOaVKkE3FuzaTa1e3Y+OzHHYmhicho0akoxmlzJNpS0julv13PsT9qu2MfwQ1uR5C582z/APSiOuC/YhZR4B17Jx/xM/8A2jHXf/tXwxp8EdbYsWbzbPqf+nhK86/YlW3PgLXTNjP9p8ZP/TGOuOhrwvVv/wA/P8j0MZ/yXuH/AOvT/OR5x40/aa+LPij4gXHg/wCE8KwRpcyW9qsVvHcXFx5WcyHzQygYUtwBhep717Qvin42eGvgF4l8VeOpnsfFdhMTbu0VtxATCAfLjBiPJfqM/pXx/wCJVk+H/wAe5rj4L3ra5fxXc5hiigaTZLLuEttgf60ICRuHb3Ga+tfGPiP4heJv2aPF+ofEvSI9F1VWCJDHG0QaASQFW2yPIcklh17dK+kzLBYaksHDD0YKnJxvde+7vqnrZ9T4bJc0xtaWY1cXiajqwjUsov8Adqy0aa0TT2tYv/sp/E/xx8TLDxFP401Eag+ny2yQkRRRbRIHLf6pVznA613Xh79onwH4k8cH4e2MV7b6yJp4NtxEiR+ZbhjIu4OeflOOOTXg/wCwv/yC/GH/AF2s/wD0GWvH/j3bT/Cv9oyHxhYqViuJrbV0A/j+bEyf8CaNs+zV5lbJsJis7xeCUeVqN4JaK9l0+dz28NxLmOA4ZwGZOfOnO1Ryu24tvW7d9ErdT0D4u/Fr9ovwV4u1u905Z7fwtb3O2CWTT4nt/LOAMzeVnknAJbk8V9B/s+fGqb4u+HLv+3LWODVdJkjjn8lSInSQHy5AGJIJ2sCM9sjrgb3xs+yXnwf8T3UO2e1utMkmjPUMNvmIR9DgivlX9iRWN14wYdBHYZ/OaueVLB47Iqlf2EYTpuKula+y189Xc9GFXH5XxZQwixUqlKupS5ZO6Wjat2SsrWP0VuTEgEsibsfpTmaMILnZuIHHrioYSLi2MbdRx/hSWbZV7aTqnb2r8n5bL0P6CuSxGGf96qDf79abBNHLIQyhZFqtDm1ujEfuP/kUXkbRyCdOM/zp8qvYhydrmtUUu7yz5Zw2OKZBOs6ZHUdRVisdnqXuU7ebz4yrH5xwcfzqCGZ4ZjBMc57mo5s2t15i/dbn/GrNzEtxEJI+SOnvXRZfJmN380V7yHY3mr0br9alspsjyn/CltZlnQwydQPzFU54HgcFenY01r7kiHo+eJJMjWk4lj6H/OKuMsd5Dkde3saEZLuAqevf2NZkbSWkxDfiPWjV+qB+76Mmt3a3mMcnAPB/xqe7hP8Ar4/x/wAakmiW5jEkf3h0/wAKZa3H/LGTgjgZ/lU3+0hcv2Ht0JY3S6hKv17/AONQwStbv9nm6djTJY2tH86L7vpVtlju4ty/gfSlp8hq79V+JaqtPB5hEicSL0NQwTsrfZ5+GHQ+tX6y1izZWmiqNl1EVcYI6j0NVYZmgf7PP0HQ/wCe1XXQ7vMT73f3FRXMAnj3L98dP8KtNbPYiUXutxk9uwbz7fhx1HrUiPFdxbW69x6VStboxHypen8qtywEnz7dsP8Aoapq2jIi0/ej80QKz2b7H5jPerjLu/exHn9DTI5kuFMci4bupqAiSzbcvzxHr7UPX1BaLy/Is5juVMbDBHUdxUAaS0O2T5oux9KnKx3Ch42wR0IoWQn93OuCfyNSn0La6/iJJBFcrvU8+oqjuubM4PzL+lWHgkgJktjx3Wnx3UUo2yfKfQ9KtbaaoxaTeujBLqCYbZOPY9KbJYxPzGdv8qbLYK3zRHb7dqq4ubb1A/SmkvsMUm1pUjcV7SdOQN30pvnXMXBJH1/+vUyX7jh1B/StJGLruZdvsacpNfEiYwhL+GyjDcXMp4QEdz0rRHApaYHQ5IPTrXPJ32R2Qi47u4ixRoxdRgt1pSFHz9MDr7VWWRpWLg7Yk/X/AOtTQTcMWbiJf1o5e4c/YnYRSqJG6DkHpSrIrLvIwvYmq4P2p8niJf1qTeGzM/Ea9Pf3/wAKrlJU76kplCp5knyimrIdm9xtHYd6rJ+9b7RLxGv3RUobjz3H+6P89zSceglJvUkJjjzIygMfzNJLClwgWQY9PUUscfPmSct/Kp6l2NlfqRopQYY7sdz1qSq886wrk8k9BULSvFD5kn326D0pqLZDmkNubllbyofv96AFtF3v80rVHAoiRrqbqen+fenxDObuf8K2slojmTbd3v8Akhw/cqbifmQ9B6ewqgzyXEnqT0FLJJJcS8DPoKujZZR5PLmrS5fUxb59OiACKyTJ5c1TCzXcmf8A9QpYonupC7HjuasvOI8W9sMn1o223K+Ja6Id+4sx/ef/AD+VMEc90d0h2J6U5IEgHnXBy1V57p5flThP1NJK+33jk0l733Flp4LYbIhlv89TVMvPctjk+w6VPDZEnfNwPSpHuYoR5cC5/l/9eqVl8OrJd2rzdkNjslUbpj+FON3DCNsK5/QUwW9xOd0xwP8APap0jghO1Rucfif/AK1Q2vtamsU18CsRB7yfoNgp4s3b/WylqnPnv0wg/M/4UxoY/wDlrIT9TxWfN2L5Or1HxxxQ8K35mpwQelUvKsh3T/vr/wCvR5VmTwV/76/+vSavuWm1orfeWZY/MGAxU+ooi37MSfeFPXGMA5p1RfobW1uFUUuczeW6Yfpmr1Z15GRidOo6/wBKuCTdmZVG0uZEs8yQ/IyZD/rTv3L2+QuY8ZxTZALm33J16j61BYy4JiPfkU+VctyedqVujLMfkTxbdvyr2NMWSC6co8fKf3hUUf8Ao90Yz9yTpTbhTBMtwvRj/n86rlV7E+0aV+25O8qLMIZUGOxNXao3SCaESJ25/CktLjePKfqOnvUON1dFqdpcsvkX6owzOJmglOT2NXqzr2MjEy9R1/pRCz0ZVRtLmXQSV5LefeWJjbtT7qETIJY+SP1FSKUvIOev8jVe2laBzby/hWq7rdHO7bPZle2m8l8N9w9as3kJ/wBcn4/40y6ttpMsfTuPSpbOcOvkv1HT3FNv7cSIr/l3P5D4JluUMcnXv71SZWtJgw6dvcUTRtbShk6dRV5WjvIcHr/I0fDqtmPWfuv4kE0a3EIdevUf4VFaTceTJ1HTP8qiika2lMUv3T/nNT3NuW/fw/fHPHela3uvYq7fvrfqiIhrOXcvMb1pKwdQy8g1VhlS5jKv17j+tRKzWkmx+Yj0PpUNX0e5cWo6rZ/gXJYlmXa1QwswJt5uSOnuKtAgjIqOSMOPQjofSs0+jNnHXmRRJazl9Y3qeaGO6QOh57GpGQTIY5Rz/nkVmpI9pIVbp3Fbr3tVuc0rR0fwv8C7BMT+5m4ceveopIntX86Hle4qw6R3MYdTz2PpTY52RvKuOD2PY1N+q+4trZSfox2Y7lAynBHQ9waUSc+VMOT+RqF4Xibzbf8AFalSSK6TaevpSt1WxSbvZ7/mVp4JYBvtycZzikhvz0mH4irBke34l+Zegbv+NDQQXI3oefUU7q3vHVTSSs0DQW9z8y9fUVUewkXlDu/SmtazwncvPuKal7MnDHP1rRJ/ZZ0JP7LGbbiH+8v8qlS8uM4zv/CrtvcNMf8AV4HrVvAzmolO2kkS5dGiGHzSMyqAfanvGj43jOOlDSIrBSeT0FQTTHcIIvvn9KxSbehkrt6FllV12t0qPehbyupxz/8AXqtLKwItoTmQ9T6Ux28kC2g5kfqatQKUSbzBF+6gQuR1HpR9on/54GmZ+zqIohubqaTzrj/nnRbyEf/S/eueyDfNEdp9Kri5ubc7ZBn6/wCNXWjlh+aDlf7p/pSxzJcbo2QgjqDXSpaa6o6FLTXVCRXEVwNhXn0PNTRwRxEmMYzTo4o4hhBiqstwzy/Z4Ovc+lZ76R2I3fulxmCqWboKzFJvJS78RJTbqTcwtYu3X606b91GtpFyx61pGNjSMbCqftcu9v8AVR0J/pc5lb/VR9KSb9zElpF95+tJckQQrax9T1qvQr0FH+mXGT/qo6/Dn9vGcN+0LqG3p9is8f8Afuv3K8sxRpbL96TqfbvX4U/t8siftFagidEsbIf+Qq9TAv8Ae6dj5zOv4Ct3/wAz5GSWrSS1hJLXrnwe+GWqfF/xgnhPTLuOwxC9xNPKC4jijwCQowWJJAAyK+jclFXZ8FGLk1GO5xSS1ZSWvu1f2Ergcf8ACaL/AOAR/wDj1Sr+wvcDr4zX/wAAj/8AHa5vrtH+b8zu+oYj+X8j4YSWrKS19yL+w1cD/mc1/wDAI/8Ax2vlb4r/AA21L4S+Ln8K6ncx3oMKTwzxAoJIpMgZUnIIIIIyfrXRTxFKo+WLOerhatJc01ocaktfYH7E0qf8L0sGfoLO7P8A5DNfF6S19d/sVPu+OVkB/wA+d3/6LrTEa05LyLwKviKfqj9nHL3E2e56VckZbSLyovvHqabEBaQ+a/8ArH6Co7aIzuZZeg6+9fEO3yR+ru3yEt4FC+fP93sPWkLS30u0cIP0qSfz53wEIQdOKsNHJBCI4Fyx6kUm+r3EyGWdLdfIt+vc1XhhknbI6dyakhsZGb96MCrE5nA8m3jIX1pXtpEjbRCPNDaDy4hlvWokgmuW8yYkD/PSpYrdbdfNl+Y+g5p/zTL5kx2Renr9am9tvvF6DkZE+S2Xce57fnXwP+3LaXX2fwbesC0Ub36MwHyq7iAqPxCn8q+8TcvIfKtVwPWqt/4f0rWbVrLXbSHUoHwXiuI1ljJHTKsCDXu5PmKy/G08XKN+W+nXVNfqfIcT5M83yutl6nyudtbX2af6Hy1+y78W7PxZ4as/h1aafLFdeH7FfNmcqY5B5m3gdR1718ZaNqGtfs5/GWdtVsTOLGSWF4s7PPtJfuSRuR3GGHHUYOOcfrNongrwb4YnkuvDWhWGkzyrtd7S1igdlznBMagkZ7VNr/hPwv4rgS28TaTaapHFkxi6gSbYT1K7wcH3FfTYbiTC0MViJRoN0qq95X1vrrf5s/Pcbwbj8VgMHGWJSxGHd4yUdLaWTXyWvkfml8cP2k9L+JfhVfCXhzSrizinmjluJbllyRHyI1SPP8eDknt054+sf2VPAuoeEvhXHJrduYbvWbqS9Eb5V0idFSMMO2Qu7Ho34V63o3wm+GWgXUeoaR4X062uom3pMttGZEPqjkEr+BrupLyGPjO4+1cuZZ5h6uCWX5dScIXu23dt/wBeZ6OScLY+lmss4zfEKpV5eVKKskv6v0Px18O6zrP7P/xjmvPEOltdTadLPFLFIfLMsUoIEsbYI5GGBxg9K9w+KP7VPhDx54B1jwlp+hXlpdajEkayu8ZjQiRX5wc9vSvvnV9D0XxQiRa1o9rqMaZwLuCOcDPXG8EVhr8Jfhai5l8HaJ/4LrYf+yV7dXiXL8RVp4rGYd+1jbVS00d1p6ny9LgbOcDQr4HLsZFUKnNpKN37ys9fTS58ofsL/wDIL8Yf9drP/wBBlrT/AG3PCovfCuh+MrdMyaZcNaykf88rlcgn2DJge7V9c6F4d8K+GRNH4U0a00wTkGUWdvHbhyucb/LAzjJxmtTVdI0rXrCTTNesYNQs5dpeC4jWaJthyMo4IOCARx1r5+pxBbO/7VhFpXWnW1rM+spcHy/1Y/sCtNOVn71tL3bT76Ox+WWq/tL3V/8ABW2+FiaWftotI7KW9eXI8iM4G2PGcmMBSSfU19M/sc+ANX8MeENW8Q65bPaP4hli8mKVSkhgtwwDlTyAxc49QAehFfSmnfDz4d6ZMtzpHhnS7SVCCHgsoYyCOmGVBXb105pxFh6uFng8DQ5IzlzSbd7u9/lqkcORcHY3D5hSzHNMV7WVKPJBKNklZrV9dG+l9TIjzZ3OxvuP3qW6VoZRcp+NXnjRxh1DfWgxqyeW3Ixivz7n1ufsdirdRrcQCVOoGRToXW6gKP16Gkt1eFjC3K9VNVpQ1pceYn3H7U1r7pL7lYNJaT49P1FbkbrIgdehqrPCl1EHTr2/wrPt52t5Nrfd7irfvq/Uhe67GrcQiZNvcdKzrWfyXMMvAz+RrXBDAEcg1SurXzB5iD5h196zi/ssqUftIZdW5VvtMXBHJx/OpYZY7uIo/XuP61BZ3P8Ayxk/A/0ptzC0DefDwP5VX91kf3kR4ks5c9R/MVdmhS6jDr17H+lKjR3kOD17+xqijy2cux+UP+ciq1fqTZLToNgme1cq/TPIq5cW6zqJYj8386fNCl0gkjPzdjVKCd7dzHIOO49KW/vLcVuX3ZbFy2n84GGUfOvBz3qJ0e0k8yPmM9RU08CzgSxNh+xHei3n83MMoxIOoPeov1Q2uj+THMkV1GGU/Q+lNinZX8ifh+x9aryLJZSeZFzGe1W/3N5F/nIptaeQJ3fmWqKoJM8LeVcdOzVeBzyKyasbKVzPvLXf+9j69x61VtrpoPlblP5Vt1m3VrnMkY+oraMr+7I5qkGnzwJ5Io7lRJGcN2YU2KdwfJuBhux7Gs2GdoWyp47itRWhu48H8u4olG2+wQmparcia2khbzLY/VTU0c8c4MUi4fupqAyy2pxJ88fY96nIgulyOffuKl+Zot7R+4eN8Y7sv6j/ABqKa2inG5eD6ikDy2/E3zx/3u/41I0e797A2CfyP1qdtSnZqzRnk3dr7r+Y/wDrVahvY5CEIIJ/GpFnO8RSoUY/iDUywxIxdVAJqm/5kRGLXwvQQQQht4UBqmqtcXAhGBy56CoJpGt4cE5lbvUWbNXJRuNnlaeUW8J47mkkO5xZwcAfeNJGPstuZD99ulLEPs8Bmf8A1j1r6HNvv8/QWb9462kXQfepLhizLaQ/jRH/AKNAZ25kkpLZfJja5fln6f596Ct9O/5E5UEi2i+6nLf4fjULn7VOIk/1adaWVjBDszmV+tPSMwxCJP8AWSdT6f8A6qNtRvV2/r0H8SvjpFF+pH+FTKpZvMb8B6UiIoAjX7qfzqesmzWK7hUcsgijMh7UM4TAPU8AVn38mSIV+pojG7HOfKmyG2VribzJOQOTUv8Ax93Of+WcdOYG3thCv+sk/rSTYgiFvH95+tbXvsctrKz+YZN5PtH+qj/WoLy481/LT7q/zqeUi0txGv3m60y0hUZnk+6vShaahK793q9ySJVs4vNl+8e1V4opLuQySHC9z/QUp33k3on8hVi4EgRYIUO3ucUbeorJryX4kM0+8i3txx0471P+7so+eXP+fypbaBreMuRmQ9qqm1uJpN0g256mjTboVaS962v5EWZ7qT1P6CrwWGyXc5y9SlWgj2W65J71BDZs7ebc8+1Nyv6AoOL21Is3N4f7sf6f/Xq2kcMHyoN8n6//AFqdmSU7IxsQd+/4VC1xHD+6gG5v6/1qdXoi0kvef9ehYIc/NM2xfQf1NQfaV/1dtHv/AJUq2rynfcnd/s9quqqqNqjAqG0i0m/L8yj5N5LzJJsHoKcLCLqxJq9RU876D9nDqVRaQD+D9TT/ALNB/cFEk8UX3zz6VV+2SSnEEefrVLnYn7NaWLP2WD+7UqIEG0dKjj87/lqV+gpDcxDhTvPovNS7vQtcq1tYsUhAYYPQ0xCzDLDb7UodSdoOTUF3K0EckDsnWM8g+lVbpGglW4j6Z5+v/wBetamsAwwRkVqp63MnTTVkVLlBcQCWPqORRGy3Vttbr0P1q0iKg2qMCqnlNBN5kYyj9R6UJ9BONnd/MbZyFSbaTqnSqd1GYJQ6dDyParV5CwInj4K9f8amRo7uEq3Xv7Grvb3kZuN/ce62H29wJ0z/ABDqKmZQ6lW6GsPEtpN7j9RW1FKsyb1rOUbao0pz5vdluZGZLObB5H8xV+aFLqIMh57H+lS3ECzptPXsazoJWtZDHL07+3vWl+bVbmTXJ7r2ZPa3Bz5E3DjgZ/lUV1A0DedF0z+VT3dsJR50X3x6d6W2uBMvlS/e/nSv9pA1f3JfJj0eO7hw3Xv7Gs0+dZy/55FSyxPaSebF93/PBq6DDeRYPUfmDTvb0E1zaP4kIRFew8cEfoaghleB/s8/Tsf89qrYls5f84IrRIhvYv8AOQaGreg4vmd/tEVxAyt59vw46gVNFLHdx7HHPcVDFK9u3kT9OxouYCrfaIOGHXFT5Mq/2or1QKz2jbJOYj0PpWgCCMiqcM8dyvlyAbu49abiS0OR88X6ik1f1Li7K62L9Vri3E6+jDoamR0kG5DkU+s02jZpSVjn45ZbZ/Q9xWqrQXkeD+XcUtzbLOuRw46GsYeZC/B2uK6dJ6rc4tabs9jUV5LU7Jvmj7N6fWnTW4kIlhO1+uexpILmOceW+N3p2NNdZbb54OY+6ntUdfM10a7ocjNNmC4TBxnNVntZ4G3wkke3WraSxXS46Ec+496aZJrf/WL5if3h1/GnFtaI7aT00dyCPUGXiUZ+lXNkNym/bnP4Gl2Q3CiQrn61I7LGhZuAKhtfZWo210WoqqqLtUYAqC6uBAnH3j0qGOVpM3D8Rr0FV4Qbu4Mr/dT/ADimodZDUOrHr/o0Rnk5lk6ZoQm2hM78yydKF/0u53n/AFcdKh+13O/+COtX5mr8wXNrCZn5lkoiHkRG4k+aSTp+NM/4+7n/AKZr/L/69WQyvI07fci4H17mpfmS/MaZRaKN/wAzvyab/aK/3aiih+2O8sv3e1WP7Ot/SnZddyrI/9P98UjmhYKp3x+/UVbpAMDFLntVN3KbuVrqbyY8jqeBVOEfZrdpj9+TpSSf6VdBR9xeP8aS6cyzCJOg4H1rpjH7J0xj9kS1QKGuZO3T60+2GWe8m7dKLngR2kf40XB2iO0i/Gjf5/kPf5/kJbAvI91L2pIF82ZrqXov+f0p8+UWO1i5PepGUZW0Tp1Y079f6sF+v9WDeUR7lvvPwo9u1fgt+3uzJ+0RqG7qbGyP5x1+8kuZ7kQL91P8mvwX/wCCg0oH7SOpKvQWFgP/ACFXpYHSfyPns4/3deq/U+Olkr1D4UfFPXfhJ4tj8W6BFFcSeU8EsM2fLlikwShI5ByAQR3FePpLmvef2evhVafGT4gDwtqV7JYWFvayXc8kIBldIyqhEzkAksOSDgdq+gnJKD59j4WlGTqL2e59NL+3r4qP/MpWP/gRL/hU6/t5eKj/AMynY/8AgRL/AIV6wP2GfhOP+YrrH/f+D/4zXyL+0r8DNI+Cmp6M3h/UJ7zT9Zjnwt1sMsckBXPKhQQQwxwMc15tP6tN8sUezVeNpx55S0+R7Ov7d3ik/wDMp2P/AIES/wCFfMvxN+KGufFfxXJ4q12OK3k8pIYoYc+XFFHkgAk5JySST3NePJNVtJa9KnRpwd4o8iriatRcs3obaS19lfsMMJPj7p6tyPsV4f8AyGa+I0lr7S/YQk3ftA6eP+nK8/8ARVPEv91P0Kwa/wBoh6o/ccgHkilqKRDIhUMUPqKqwTlyYJ/vjj618Go3Vz9OUbq5eBB6Um5S20HkdqyGDWVxlf8AVn+VWrn5dl1H26+4NW4Fchc3pu2EjPpSllHU4qjdoJI1nj6pz+FLIBdWwcdRz+NLl2YcpfppAIwwzWTYzBW8otwen1ouTNBLlHO1+lP2etg5NbGqiIv3VA+lPqr5pa382Pk4zj+dNtroTkqRgio5XuRZ7k8rOi5RdxquTsXzbl/oo6f/AF6s7037N3PpQ0aSDDgGhO24XMl5p7ttkYwPT/GrC28Nuu6c5NW/L8uPZBhTVFbOR2Ml0/StuZPyRdxzXcsh8u2X8aUWygebdyZ/Hil+0KD5VouT69qUokX726fe/Yf4CjbbT8xEqOzjEC7E9T/QU13gi5mfc3v/AIVRmvpJPlj+QfrTobKR/ml+UfrRy21ZNiRr/J2wp+f+FPVb2Xln8sUpntrf5IV3t7f405Vu5+ZD5S+g60aLZEljesK4lkyfelSQP90HHrjFVfMtbXhfmf8AM1Ir3MvIQRj361m49QLlRyRrKhR+hqHYE+eWQn6nA/IUfaYzwgMn0FZpPoBFFFNbtgfvIz+dF1aiYeZH9/8AnV0HjJGKdVczvcVuhi2tyYG8qT7v8q2QQRkVSurUSjenD/zqpbXTQHy5fu/yq2ubVEJ20ZbubXzMyR/e/nRbT+apil++PXvV0EEZHSqtxbeYfMjOyQd6SlfRjatqihLG9nL5kf3D/nBq/wDuryH/ADkGkjkWdWilGHHUf1qg6SWcu5Oh6e/savfTqZ7egqSS2cmx+UP+cirs0KXcYdDz2NL+5vYff9Qaz0eWzkKt09PWjfVbitbR7BDNLaybJBx3H+FaE0K3KiSI4cdDSssF5Hkfn3FVEM1k+H5jNF76rcLWVnsWYZhMDDMMOOo9apSxS2j+ZEfk/wA8Gr00KzqJYjh+xpIZxJmCYYk7g96lO2qBq+j+8WKaO7TY457ioCJrPlP3kXp6U2ezZD5lv27d/wAKdb3oPyTcH1/xqvNbE31tLRluG4imHyHn0PWrFZ81mrHzIG2N+lRpNeRHZJGX/wA+tRyp7GvO1pJE81lFLyvyH2rOaC5gfcoPHcVtoxYZII9jT6Sm1oTKkpalCG5WceXIPm9OxqvNavCfNgzgfmK1WVW6jNOpc1thundWkZ0F8knyS8H17VN5JiO6A7Qeqnp/9apGt4GO5kGTUqoqDavAobXQIxf2hRnHNNdgilm6Cn1mX0hOIE6nr/SpirsucuVXGW+ZpWuZOi/5/SmRg3dzvP3R/L0qS6YQQLbr1PWgf6NaZ/jeui/VHJbo+mrFb/S7rb1jjof/AEu52D/Vx9aB/olrn/lpJ/n9KVP9EtS5+81L0H6+rGS5ubkRD7qdf61bO15Mn/Vw/wA//rVBGptoM/8ALV+lNuCYolto+Wbr/n3qfJF7Jyf9dgh/fztcv9xOlWeR8/8AG/A9h/nk0qxhFSAduT/n3NLF+8YzHp0X6f8A16TZcVbQnVQowKUkAZNLUUqGSMoDjPesjb0KUD+a8l1J0TgVDaqZ7kzP25/wrSSFEjEWMj3qRQFGAMCtebexiqe1ytGjvO00gxjhR7etNS1Im8+R8n0q2GVuhzioknR3aIZBX1pXZfLDS4PbwyPvYZNShVUbQMAU6g81Ny7JbBRWesrW0nlTHKv0Y/1qO7iMbC5i4Pemo62M3PS9jSLAHBPWkd1UZYgfWqpIurfcvDdvYigYu7bB6/yIot3Hzdi5kYzS5zVC1bzITBJ1Tgj2qjE7WtwVbp0P0qlDdEOpaz7m7UYRAdwUA+tVLwSBRLGxGOuDTrSczR4Y/MKnl0uXze9ysu0hJAyBmqKXh87yJEwc4yKuM6JjecZ9alpoaknsV1818vL+7Qdu/wCJqnLeM58q3GB046/hWsQCMHkVGsUcZJjUAmqUl1REot6JmfFZY/eXJ/D/ABNPa8RP3dsu7+VJJbXM0mJXGz2/wp263tfkjG9/brWu++pilbbRCLbzzfNctgegqZHQfJbJn37fn3pgikkHmXT4X+6OB+NQTXoUeXAMAd/8KnfQq6jq/wDglx9qjdO/4dB+Xeq738afLEuf0FVIrea4beeh7mroW1tBk8t+Z/8ArVVktNxKUnqtENV76YcYjHrVlFaJczS5+uAKgWW5uP8AVr5a+ppSLeA7pW3v78n8qh9il3LIlDfdyffHFTVSWeab/VR4Hq1SeWxGZZD+HAqLGqlfYsEZ4NZ5tZIX823P/ATVj7TDnap3n0HNSo5cZKlfrTV0DSkRSxJcx4cYP6islGltJcEfUeorfqCeBJl2t17H0qoyto9iJ07+8tx8ciSqHQ5BqKe3SdeeCOhrLVpbOTDDjuOxrZjkSVd6HIoa5dUEZKatIzoJXgf7PPwOx/z2pbu3Knz4eD1OP51dmhSddr/gaghkeJhbz/8AAT601LqiHH7Mtgt7hLhPLk+93HrVOSN7STzIvuf54NPubYxN5sPA9u1WYJ0uU8uT73cetVtqthWv7stxytFexYP4juDWcwms5cjp69jTpo3tJBJEeP8APBq/FPHdJscc9xRtqtifi0ejFBivYv8AOQahhkeB/In6fwmongltX82Dle9WwYr2L/OQanT5Fq7eu/5la5tSp86D6kD+lPtrsSDy5evr60RyvA3kXHT+FqWezWT54uG/Q0X6SFZr3ofcEkEkLebbfitSw3kcvyt8j+hqlDdPAfKmBwPzFXZIYbob1PPqKGv5hxfWH3Fuq81vFN98c+o61RH2y24++n51oRSNIPnjKfWoatqjRSUtGjKlspouU+ce3Wp4LsqfKuOPc/1rUpCARg1XPdWYlS5XeLKj2qM/mRnYfb1qWLzsES447jvUu0AADjFOqHK+jN1orBWVdM00ot4+mefrV+aQRxl/Tp9ao2oEaPcv+FawVveN4K3vDLtgAtvH0XrTpv8AR7cQJ99+tMtVMkxmfovJ+tPi/fTtM33E5rbbTsbPTTsEv+jW4hX77daJP9FthEPvv1pYc3FwZm+6v+RRH/pNwZm/1aVO24ttxyRmCERr/rJf0/8A1U2552WkP41Ikn37p+g4UVHa5w9zJye1T5sXm/6ZOyNtEMB27OppnkXX9+nuzxgInLn5jUfmXXpUWMrH/9T9+yQBk1RlmKwtKOrcL9KluGLFYV6v1+lUbtjLMIU6Dj8a6KcbvU6KcbvUW2/cW73B6ngUlkvzNO/RRResECwL0UU+f9xbLCOr9a33Xqb7r1C1O55LmToKLflpLuXoKJgYoY7VfvP1pbn5EjtI+p61G/z/ACI326/kJbn/AFl5J+FETGOCS6b70nSluVJEdrCOnWrUlssgRM4Ve1Jtbvr+Qm11/pFS0UxwtN1ZuBX4Ff8ABQsiL9pLUYx20+w/9FV/QOqKihV4Ar+e3/gonIP+GmdS2t/zD7D/ANFV6GBlesz53OJc1G/mfGCS13PgP4geKPhx4ig8U+ELz7FqECvHuKh0eN/voynIZT6H+deapLVpJa+h30Z8OnZ3R9lr+2x8dz/y+6f/AOASf41498Rfi144+LGp2+q+Nb0XMlnGYoI4oxFFECcnaqdyepPJrx9JatJLShTpxd4o0nWqyXLKTaNlZKspLWOklWFlre5ytG0ktfa/7BL7v2hdPH/Tle/+iq+F1kr7W/YJuPL/AGhtOY8j7Fef+ijWOIV6UvQ7cGr4iC80fvNVC7t2YrNF99KuqwdQy8g06vhU7O5+lJ2dyiwF3bf7X9ajsmEsT27dv5GraxhJC6cBuo/rVSRfs92so+7Jwa2TveKNk73igtHKlrWT+HpRBm3uGgP3X5FMvA0M6zJ3/pUt0vmwiePqvNVv8yt9e5TuovJm3LwDyKvHF3bf7X9aRwLu2yv3v61StJvKl2t0finuvNBuvNEtjKUYwt36fWmTqbW4Ei9Oo/rT72IxyCdO/wDOrDhby33L94fzov8Aa6MTf2ht7GJohMnOP5U2wm3AwseRyKSxlyDA/bpVWVGtp8r25FCW8GTb7LNRrlY5RFKNueh7VZIBGDyKo3CLcwCROo5H9RRZ3HmL5bfeX+VYuOl0Z20uiz5YjQiEBTWO8N08u1wSx79q3qKUZtCTsZgS3sl3SfM9Ql7i8bavCfpViSwDyb95wetRz3Ii/cW4xjqa2TvtuP0H4t7Mf35P8/lUIa5vDgfKn6Uy3tTL++mOF6/Wp5LlnPk2g/EUbbbkD/8ARbMer/r/APWpqvd3H3f3anvQsENsvmXBy9Hm3NzxCPLX1qfMB/lW0PzTNub3/wAKctyz8W8RI9TwKZ5Ntb/PM29vf/Co3vmY7YE/P/Ci1/MC2FuCcu4X2Uf1NP8ANij4aQfiaoCC6m5lbA9/8KnWwhX72WqGl1YFlJ4ZDtRwTSS28Uw+cc+velWCFfuoKmqL22D1M1RPaHGPMi9uorQVlZdy9KdRQ3cSViCWESYYcMOhFNGJVMUw57+/uKs0UXCxiPHLZy705T1/oavgw3sX+cg1aYBhtYZBqqtpGj74iVP6VfNfcjlttsZjLNaPkfgexrQhuY7geXIME9uxq46q67WGQazZdPIO6BvwNO6e5HK47EhSS0bfF80XcelSvHDeRhgeex7ilt2uANsy/Q/40x7Z0bzbY4PcdjSuO2m2hGs81sdtwNydmFTvDBdJu9ehFWBkrh8Z70+pbLUejK1vB5K43Fv5VZqvHcJKzBOidTVaCVpJJJ3OI06Ciz6jTSskXGljVgjHlugqKe4WEhANznoKrQkHfeSfh/n9KjtQZZnun6D/AD/Kq5TJzb0RaurkwABcFzRHcP5JnmwB2ArPUNd3OT0P6Cr21Zp/LH3Ie3vTaS0M1Jt3RZhLmMGTqamoqGaQRIX/ACHvWe51bIC65JPROv1rOtQZrhp26Dmn3T+VAIv4n5P9f1ppP2exC/xyf1/+tWiWhhJ3evQiX/SrrP8AD/QVO/8ApF4I+qx9aba/ubZrg9W6f5+tLB+4tmnP3n6VT8jNefqK3+k3e3+GPrTzm5usf8s4v50yP/R7QyH70n+RSqDBafKP3kn58/8A1qn0K9fUfGfOuGlP3YuBUMGbi6edui9P6VZhtytt5ROC3WrEUKQrtSk32LUW7XIgrsrOOGf17DtU6gIoVeg4psk0cQzIcU2KZJ0LRmsjRWvYnqubiEP5ZbnpVEXEsE5Sc5B/zkV4d+1D8ZYP2ePgh4j+NcmkHXV8Oi1Jsln+ymb7XdQ2v+t8uXbt83d905xjvkXa25PO2vdPfLqSaJN0QGO/tVe1uy58uY8noa/B+P8A4LjaaqbZPg7M3v8A26v/AMg15F8bP+CvNx8UPhf4j8B+GPAF54S1LWrfybfVLfXCZbN96t5ieXaxPnAxw469aE1azJaldNH9HzKbSXzV/wBU3UelOuoiQLmL76encV/NV/wSg+LXxT8b/tUPofjPxnrWvacdA1CT7Nf6jc3MHmK8OG8uWRlyMnBxkV/SzGTA/kP9w/dP9KpPqU49Og+3nWdM9x1FWayp43tZftEPQ9RV+GZJk3L+IqWuqHGX2XuJPCJ49h69jUFsxdDBMPmTg+4q9ULIGYSDhh/nFJPSw3HW6KFsTb3Bt26HpUmfs95j+CX+dOvYztE6ffjpt0onthKv8PP+NaXvqYWtdLoE/wDo9ws4+63DUzUIsgTDtwamjIu7ba3XofrSWr+ZE0EnVOD9KV7alNJ6dxtnKJYjC/OB+lVUzZ3O1vuf0qL57Sf/AHT+YrQu4hPEJU5I5/Cr2fqZK7Xmhl/EeJ17cGplIu7bnr/WmWkizxGJ+SBj8KrwMba5MLdG/wAg0vLsXdX5ujG2kzQzeS/Q8fQ1pTTiHDMPlPcVn38G1vOXoev1q1C63VuUfr0P+NJ6+8EG1eBbV1dQy8g0gRA28AZPes20kMUhtpfXj61rVm1Y3jLmVzGukumf5vmXtjpUkVskK+ZckfStWqdxbCf5g20j8qtS6Gbp295alWS6lmbyrYY/n/8AWp6W8Vuvm3Byf8/nTneOxTagyxqlHHNdvuY8dzT9NjNvXXVlhrma4by7cYHr3/8ArVKtvBbjzJzuPvRJPFar5MAy1MS1Lfvrs/hVFde7/Ad9puJzttkwPU077MijfdSb/qeKQ3LyfurROnfsKBaov727fef0qdh7+f5DluYx8ltGW+gwKmH2h+WxGPbk1Ve+ijGyBM/oKYFvrjknYPy/+vSsLn6b+hoblj/1kn54pPtNuTjzBVRNPjHMjk/pVpbeFBwg/Hmp901Tl2JHRJF2sMiqRt5YG8y2OR3U1o0Uk7DcUyGKQSrnBU9wadJGkq7HGRUlFT6DtpZlZN8beXJyOzf0NUri2aM+bB0HOB2rWoq1KxMoJqzKFvcpcL5cn3vT1qpcWzQN5kedvr6Vfezidt4yp9qsqCBhjmq5rbEcjkrSM63vs/JPx71LJbsrGe24f07GmT2CP80Xyn07Ulut1Cdjpuj+o4pabolX2mTpJFdIUYcjqD2qvtuLQ/L+8i/lVma3Ep8xDtkHQ1LD5u397jPtSuXZvciVoLtOmcdj1FMhtRC+5XOPT/GrgAHSoGnUSiJeWP6UXeyKaWjkWKY7rGNznAqlJI8lyIEOFXlsUjD7TdbP4Iuv1o5e4OfYtSzpFH5jdO1Rm522/nMMZ6Cqbsbu6CD7if5NMvZDLMIk6Lx+NNR6GbqbtFu0nlnY7lAUenrVmV9oCr95uBUcCpDi3HXGTTBIC0k5+7HwKdru50U07ala7YtIlvH2/nReN5arAnbk0y1BkmeeTomT+NJHm4u8t0zn8BXTa2nY9C1vkSyZt7URj78nWiXNvbrEPvydaX/j5vf9iP8Ap/8AXpU/0i7Mh+7HS9fUj19RJf3EAgX779aSYeVFHaJ95+tLCftFy87fcj6UsCmW4a4YHHap23FtuMuzjy7WPtVsJ8yQjpGMn69qVLdBKZidzVYZlUZY4FZSlokjFy0SRFHGQ7SHq38qm5qob6AHGc+9H26D1pWl2FaXY//V/etZOJbs/RarWa75TK/ReafeERRR269uTQP3VjnvLXatvU71tp1IoR9putx6ZzVj/j4vvaP+n/16SwVgkkqjJ6CrVrbGEEscu3WplKzZE5JNkMX7+7eXtHwKmS3/AHxnkO5uw9KsqoUbVGBQ27advXtmsXLsYOfYUkAZPFRs58svGN3pVeKUTAwzDDjqPWoVLWb7W5ibofShRKUOnUW3vd77JsDPSv57v+Ci+2H9pzVFXgf2fYH/AMhV/Qjd2okHmw9e+O9fzt/8FFpmP7TWo7jyNOsB/wCQq9XBW9pzRPGzdJ4dSj3R8XpLVlZaw0lq2ktfQ3Pg7G2ktW0lrDSWrSSEUyTaSWraTViJLVlJKq4rG4stfbf7AQWb9onT4272F7/6Kr4SSWvuH/gn87yftG6cIz8wsL0j/v1WVd/u5eh2YNf7RD1R+8scj2knly/cP+citVWDDcvINVVaK7Qo4ww6juKrKZbN8PzEa+Oa5vU/TZLm9TVqvcRebEVHXqKlVldQynINPrBOzME7Mo4+1WmD94fzFR2EgKmBu1XwoDEjv1rMnBt7gTL0J/8A11vF3vE3i73iLbsbe4aBvuk8VDew+XJvHR/51Pfx5CzL9KmGLu1wfvf1q72tMu+0xIXF1bmN+o4P+NfJ37QH7Y/wY/ZX1XR9J+LN3e28uvRzS2otLRrgFLcqrEkEY5YfWvp+CVoJQx+hr+fb/guAB/wm/wAKnHfT9T/9GwUp+7ddyJrl07n7U/A/49fD39orwV/wsz4Wz3E+jC8lsi1zAbeTz4QpYbDzjDDmtX46/GrwH8BvhvdfFD4hyzwaJZSwQyNbxGaTfcSCNBtHPU818G/8Edwkv7IlxE3/AEMeo/8AoqCt/wD4KuF4v2MvE1u3/QS0r/0qWpTur9UK915o92/Zv/bY+B37TPiLVPCPwtu764vtKtPtswurRrdBEZBHwSTk5YcV4f8AF7/gqH+zX8GvHuu+ANYtdf1HWfDt3LZ3UdjZRFFniOHCvNPCCM96/Nb/AIIskr8bPHjL28Pp/wClcVfol8Rv+CT/AMAfi98Q/FHxR8VeJ/EseqeKb+4vpobO4sooIpJ23FVElpK2B2y1K7+IWvxGx8Nv+Cs/7I/xB1q20G/vNV8HT3bqkc2t2kcVt5jHADTW01wsYz1eTao6kiv0viliuIkngcSRyAMrKcgg8ggjqDX8bn7cX7LFr+yZ8YYfAmj6tLrOi6rp8epWM1wqi4SN5JIWim2AKXV4idygAqRwDkV/SB/wTX8Zar43/Yu+HWo61O9zeWMN3ppkcknyrG7mt4Bk/wB2FEX8KyatoZtWPZPjh+1R8Bf2c4rZvi/4ut9Fur4boLJVkubyVMkeYttbrJKI8gjeQFyMZzXgHw5/4KU/srfF34g6L8NfCGoanca1r1ytraebp8kUbSHJGXJ4HHcV/OF+3V4o1/xb+138VLvxJNLJNY69eafAJST5dpYym3t1Udk8pAQB656k1+8X7Nv/AAS4+CXwl8R+DvixH4m1rWfFOgNBfrJHcWq6bLOU/hiFuZDFzx++yRzmhX3RJ9GftFfty/Aj9mvxrafD/wCKF7f22p3thFqUa2lm1wht5ZZYlJYEc7oX4+nrXuvwe+MHgn41fDXR/ij8O5JrjQ9dE5t3uIjDK32aeS2k3RnkfvImx7c1/O3/AMFpGB/ap8OY7eD7Ef8Ak/qFfsD/AMEvraM/sOfDKY8nGscf9xe8q1Loyr9w+OX/AAUR/Zw/Z98fan8OfiBc6rdeJNIEBuraxsTKsf2iGOeP95I0UZzHIp4JxnB5yK8Fl/4LQfsuNP8AZ4fD/i5I/wDnr9gscfl9uz+ldf8AHz/gmJ8OP2jfjf4h+MfjDxZrFhca/wDZA1lYJBGkQtbWK1H7yVJSciLcflHJxXnOpf8ABFH9naTT3j0jxp4ptr4j5ZZ5bGeIN6mJbSIke28fWlJtasGfX3wG/bg/Zo/aJ1ePw54H8WiDxBPkx6ZqMT2d3NgZIi8z93KcZO2J2YAEkY5r7TjijiGEGK/iY+Pvwf8AGv7Ivx+v/ATavv1fwtcW17p2q2mYDIjBbi2uYxkmNxxkZO1wQCwAY/1UWvx51XUf2ID+0DC4k15vAsmuMYUG0ahFp5lk2pyAFnU8dAB6Um3Ikw/jv/wUJ/Zh/Z81y48I+L/EUuq+IrMkXGm6RAbueA/3ZXykKP6o0oYdwBXy/D/wWk/Zeln8p/Dfi23jJ4keysWH1IS+J/LNfgz+zN8Ij+1H+0VoHw18VeIn0x/Flzdz3moy/v7iR44ZbqTHmH5ppihALHqcnPQ/uVf/APBGH9mr7IIdO8X+LFux1le4sJIyf+uYs0P/AI9+NTFN7AfpH8Af2gfh5+0j4Eb4j/DW7nudIjupLKT7TA1vIlxEqMyFW64Ei8gkc9a7L4i/FPwJ8KPCV545+Iut23h7QbDAlu7o4Xc33UjQZaR2/hRQWPYGvGP2Tv2YdF/ZT+Gd18ONI1q41yzm1K41ITXUaxyIZ44o9hCHBx5Wc8delfjD/wAFp/iNrt98W/BXwtW4mTQtN0UauIDxFJd3dzPb+aR/EUjg2qTnG5wMZatGB9ya/wD8Fj/2TdDvpLPSrDxP4gRCQLi0sLeOJ/cfarqCQD6xiu7+Ef8AwVN/Zj+MXjTRvAmlpr+kavr13FZWceoWMaxvPO4SNC1tPOBknGWwK/Oj9i//AIJk/CD4/wDwL0P4veP/ABbrButekudlno7W0MdsLed7fy5XmhnLSHy95wFwCBz1P2l8PP8Agkl8I/hT8TvCvxS8M+NdcaXwvqdrqUdrfLazrKbaQSBGeKOEjOMZA4qbPcD9QPFPjTwx4K0OfxN4y1iz8O6LbY8291C4jtoEz0zJKQoJPAyee1fEHjH/AIKj/sYeD5jZQ+M5vENxHkMNMsbiZeP+mrxpE2f9ljXqv7Z3wc039oD9njxV4N1fUJ9KtrKB9UjmgVHPn6erTRq4ccoxGCBg+9fyZfs1/C/R/jV8dvBfwr165nsrDxLqCWk81qUE8aMCcxmRWXPHcGh6CR/Qw3/BZz9lNL0Wn9jeK5Ij1nGn2gjH4G93/wDjtfYPwD/bT/Z1/aQkfT/hv4pjbWkDOdKvVNpf7EGSyRSf60AcsYi4XvivhjU/+CLv7Naaa9vp/i/xZHqJU+XLJcWEkYfHBMQs4yRnsHBPrX4L+N9A8cfsn/tDapoWiauYfEnw81gi0v4F27jA26KXac8SRkFkORglTkdVYZ/bk91DDBJczuIoYwWaSQhVCjkkk9AB3NfF3xC/4KK/sc/DeaWz1X4jWeqXcRx5OkRy6nkjqPNtkeEH6yCvpewuNO+KPw0t76Z2g03xZpKSfIQHWK/gzkEgjIWTjIPPXNfxbftE/C7T/gr8bvGXwr0m9l1Gz8NahJaRXE6qkskagEFwnGcHnH5ChiR/Q/f/APBZz9lOzuvIttF8WX0ecedDYWgTHriW9Rv/AB2vor4Hf8FEf2XPj5r0PhTwv4jk0fXrtlS2sdZi+xSXLscBIX3NDJITwED7z2Br468Bf8Ec/wBmvxH4G0HxDqvifxZ9t1bT7a6k8m7sEjSSeJZCEU2LHAJ4yx4r8Wv2u/2fbr9lD4+aj8NdO1eXULazS3v9NvSPKuPImG6MvtwBLGylSy4BK7hjOBIz+0maYRxGQc+lfK/7Rv7Xvwe/ZZXQIPi1d3sE3idbl7QWls1xkWnlCXdtI2481cevNa37KPxG1L4u/s4fDXx1rU/2vUtV0e3a9mYAGW5tx5NxIQMAF5UY8cc1+Q3/AAXFk36z8H0/uw67/wChWVXsiN2fsV8A/wBof4bftH+ALnx38Lbi4uNKt76XTpHuYTbyfaIo4pXAQ5JGyVea+b/C3/BTD9lzxf440j4WaNf6pHr2s6lBpMMc+nyRp9rnlEKK7k4H7wgZrxX/AIIyqZP2XtZQ9B4svz/5JWVfiH+0BbP8Ef23fF91bqYk8NeM5NUt1HVIvtgvIQPpGy1TZCje5/Xl8UfiD4Z+EngHWfH3jC4Ntonh+2a6u3VN7+WnZFHVmPAHckCvmT4Gft8fs6/tD+Lx8NvhrqN6+uNay3ax3dm1ujxwlfMCsSQWAbOPQE9q+ZP+CwfxWTw3+zjp/gXT7gef471SGMgH71jYYuZSPUecIPwNfhb+yX44vvgb+0/8NfGmsq+n2o1C1Fw0g2g6bqi+RLLz1XyJiw+lF7WQlG92j+sj4+ftF/DT9l7wRY+OfijdT21hqt8lhB9lhNxIZ5IpJR8o52hYmJPrgd6qfs3ftP8Awq/ae0PV9a+FM15PaaJPHb3Ul3bNbfvZVLgJuJzhRz6ZFflV/wAFvvFfl6P8K/BETcT3GqahKvp5KQRRn8fNfH0NfSv/AAR58If8I7+yQ2vyJh/FOvX96rHvHAIrMD6BoG/Ems2zSMUtj9V6psfNuAn8MXJ+varLuEQuegGazwTFaNK335f61SQpM8S+NP7QXwg+A2jp4m+LviW30CynYrbxvuluLgpyRDBEHlk9yFwMjJFfAOuf8Fk/2WIL/wCzWWjeKtQgQ486GxtEjb3AlvI5PzUV+JP7eHxX174w/tT+Or/ULiSe00LUrjRNNhySkVrp8rQARjt5rq0p9Wc1+r/wn/4Iw/DW68HWE3xe8X65/wAJLcW6S3UWkPa29tbSuATEDNBcNL5Z4LZUNjIAqr9jPlVrS6n0lZ/8FaP2OdU8Nz6rLrGraZcWv3dOuNMlN3N6eWYTLB/31MtcZ8CP+CnFp+0v+0t4a+C/gXwY+keGtTW+eW+1KcPfSC1tJZ02QQ5ii5jAOXlyCcYPNfi7+3R+x1d/sf8AxE03QrPVX13w54ktpLrTbqZBHcDypNksMyqcF48od4ADBhwDkD9m/wDgk38OfgfrvwJ0f4vaP4IsbHx5o95e6Td6rmSe4kkUAmWMzO/kmSCZVcR4B5wADiovI15Yn6K/Gn44fCf4DeG4/GHxe8RweHtNdzHAJA8k1xKBkrDDEGllIHXapwOTgc1+eup/8FnP2U7C8a2s9D8WalGpx50FjZpGR6gTXsbfmor8rf8AgrL8Q9f8Wftf674T1C5mfS/BdpY2VjbucRx/abWG7mdV9ZHl5bqQq84Ax9qfs8/8Ej/gb8QPg/4R8f8Ajzxprl3qHirS7TUx/ZEtpb2sX2yJZREPOtp2Yx79pYsMkH5R0o3DRan3x+z9/wAFG/2dv2kPHNl8N/A/9sWHiHUEmkgt9RsljDiCNpZP3kMs0Ywik8sM19zG8aObZKm1f881+aPwB/4Jj/Dn9mn4z6P8ZfBXi/VtSbR47qL7FqEdu4cXUDwE+bEsWNofP3e1e/ft1fFfVPg5+yl49+IHhuc22sRWkdnYzJxJDPqE0dqJUPZohKZAfVRQvMUrvRHG/Hj/AIKF/sr/AAN1q68M+IfEj6z4hsmKXFho0JvJIXHVJZMpArjoVMm4HggV826X/wAFk/2XZb0RT6H4rso2IHmy2VoUx6kRXsjfkDX4c/sgfsz6r+1r8Z4vh0mqnR7GG1m1LVNQKefJFbRMiMUQsu+SSWVEGTxkuchSD+zfi/8A4IpfBmXwzcJ4D8b6/aa+sRMMuom1ubN5O2+KG3hkAPTiQkdcHoWpPYlwTdz1T4pf8Fd/2U/C+iRXHgd9S8c6pPEHS3trWSyjic/wTzXaoV9/KSWvTf2YPi7o37f/AOz14kuvi/4Qs4fDt/rUumvpSzSyRtBZra3URllBjZnEpySoQcDjrn+XPwVp2jeAvjdpWhfFjQk1jTND1tLLWtNkmkiWSOG48m5j82F1YEYOCGxkDORkH+vnxp4W8D/syfs2+PNR+DWgWvhq08N6Lq2sQQWUQCtdwWjOsr5yWbMa5Zs8DngUJ9GVKPVbn5yfH2x/4JJfs/a5ceFPFPg+11PxHZnFxpmk/bLueE/3ZZPPSFH9UaUMO4FfNdn+0b/wSHmmEN18Cdetx08wwoU+pCaqT+QNfnX+zP8ACMftQftE6B8NfFfiN9LbxVcXc15qMv764keOGW6kwXI3TTFCAWPU5Oeh/dPUf+CK37ORsQum+L/FcdyBy8txYSIf+ACzQ/huqd9B7an0B+x14H/Y08R6efjx+y94TTSGR7jSnu3W5inQgRSSxGOaRl6FDkZB7HrX6DQypdRlX69x/UV8w/sk/s1aD+yz8MLv4XaDrNxrtpcanPqXnXUaRyAzpFHsxGcEDys5469K+j5Y5LSQOnTsf6Gr30MNveWxpIxz5MvJxwf7w/z1qk8clnJ5sXMZq4jR3kXoR+YNJHIWbyJ/vfowpLQ0aTsTxSpMm9KlrMeGS1fzYOU7irsMyTLuX8RUtdUaRl0e5IVDAg9DVO2GzfbP/D0z3Bq9TSoJBPUU7ja1uZcBNvdGJujcf4U6f/RrkTjo3Wn30RZBMvVP5U+Qfa7XI69fxFVfqYctrxI72ISRidOdv8qbp83WFvqKdZSiSMwPzt/lVCVGtpsDtyKpL7JDdmqiJ5VNpciROh5H9RVm7jWeITx8kDP4VI4W7tsjr2+tV7GYgmB/w/wpXe5dl8PRk8EguoWjk6jg/wCNUYWa0uNr9Oh/xqWQGzuA6/cf/OKmvIRLGJU+YgfmKslpv1Qy/hyBMv0NT2lx5ybW+8v60yzkE0ZifkgY/CqDB7Sfjt09xU2v7oXs+ddTfpO9MikWVA69DUlYnURuiSLtYZFV5klSEJbDH86j8x47zyy3ytzir2Rnbnmq2M9JXM5Uis18yXlz0/8ArU1ElvG3y/JGOgq5NbRTEM45HpVO8eYEQxoQp9O9UnczlG3oLJdpCPKtgOO/aoEgnum3yHj1P9KtW9iq/PNyfTtWjT5rbCUHL4itFbRQ/dGT6mrBIAyajklSFdzms0tPettX5I6mzerNW1HRFiS+UNsiHmGpI/tL8ykIPQdahL21n8qjc/60xFnvDulO2L0HeqsRd3syz9oDNthHmH17D8aXiMgyvuc9AP6Cow+f3VooAHVuw/xpsk0VsCF+eQ9f/r1Nug79WTnew3SnYvoD/M/4VH9oMh2W65x/EegqukUlx+9ujhBzjpTjcl2EFoMe9VYObqWtwjOHYu57D/Cn7yo3SkKPSqxZLYbE/eSt+Z+tLhYR51y2W7D0+lTYdy0rFhkjA96akySNhMkDv2qovmXX7yX5IvT1qZSZeIfljHf1+n+NFhqVycOpbYDyOtSVTVgw2QcKOrf4etWwMDFJlp3Fpu4c8/d61FcS+VEXHXtVLJjsiTy0v9f/AK1JIlysSxTMyyXMh+QfdFQ2p2rLdydaLr91bxwjv1/D/wCvSXOY7eK3HU9f8/WrMnpv0FtyY4JLpurf5/nSofIszIfvSf1ouhhYrVO9Mv2AKQL0AqtxPT5C2oEMEk7fh/n60yzQFmuJOi/zp92fKt44R+P4f/Xpbj/R7VYB1fr/AFp7/MVrfIajsVkuD9+Q7Vouj5MUduv1NXkgCpEh/g5/Gspybm6wOhOPwrSGrPSoRstSc/uLIDvLRb/ubeSfueBTL1t0wjXooxVuW2d4o4E4A6mqb016mzeiv1IYf3Fo03d+lTQwEW21eC/WraxoqquPudKkrCU7nO6l9iCGFYY9g59akLKpCkgE9KhnkliAdV3KOvrTJI47uMSRnnsam19WK19ZCXU8kIBRcg96EeK8i2t17j0pIZfNBgnHzjqPWqUsUlpKJE6dj/Q1sktuptGK+HqQTQmB9sgyOxqH916VvRtFdRgkZx29Kf8AZoP+eYqvaNdC/avsf//W/d+YNcXBCDPOK1Hto5NgbonaplRUG1RgVBczNCu5Vz71u5N2UToc3JpRJwEjXsoFMjnilJEZzioVeC7Taevp3FZssMtpIGHTsaIwvo9wjC909zeoqrb3STjB4b0q1WTVtGYNNOzK08Hmjcpw46Go4pRMDDMMOOo9au1XngEoyOGHQ00+jNFLoysrNZtsfmI9D6V/Oz/wUnHlftRaiw4Emm6ew9/3WP6V/RWku/ME4w/8/pX4Sf8ABVT4calo3xI8NfE2GJn0vWbH+z3k7Jc2jM4U+haOQbfXafSvTwjtV13PJzWLlQ80z8vElq0kuaxElzVlJK+gufCEHiXW5dI07zLY4nlbap9O5NeTrqmoed9o+0y+Z13bzmvSvEGnNrGn+TEcSxndHnoT6fjXmS6Rq3neR9jl3/7h/n0raLO2lax7b4T1uXV9N33PzTwN5bH17g116S1wfhjTH0bT/JlO6WU7pMdB7fhXVJLRc4ZpXdjcSUGvuj/gntKR+0dp8mMhNPvSfp5eP618CpJX6jf8ExvAl3qnxC8R/EK5jI0/SrE2EbHo9zdOrEA9ykcZz6bh61z4hpU5XO3BR5sRD1P2smh8zE9u2G9u9ENwsw8qUYf0PehUe2PyfNEeo7ikuLZZwJYj8386+TutmfpOmzEMUlsxeH5o+61cjlSVdyHNZ8N28beVcDp3qy0OT5tucMfyNEl/MKS/mLdV7iETRlO/aiKYP8jja46j/CrFYapmGsWUokLwGCUYK8f4GqFs7QTmN+AeDW5WVfwE/vVH1reErtp9TeErtp9Rl9DtfzV6Hr9a/ni/4LZSF/GHwqQ/wafqn/o2Cv6JoXW6gMb9Rwf8a/Ab/gtj4Q1ER/C3xtFA72Vu2qabcShf3ccsnkTQKT0BkCykeoU1T+FxfQp/C4vofTv/AAR9laH9lCRx0/4SHUfy8uCu5/4K0Rq/7GHiGdf+gjpX5falr8wf+Cen/BQb4Y/s1/DHWPhV8WNO1E276lLqdhe6fElwP38UUckMsbPGRgxBlYZzuIOMAnE/bp/4KUad+0r4E/4U/wDDXw5Ppfhee4huby91TYL2drdt0cccUTukSBgGJLszcDCgHdm2rJoybVrna/8ABE6NZfjb8QEbofDif+lcNf0eQyNaTmOToev+Nfzd/wDBFSUw/G/x4w/6F9M/+BcVf0m3UQniE0fzED8xTjtZ7MqPZ9T+a7/gtgqj9oDwOR38Mqf/ACduK/Tv/gk/MP8Ahi3wlC3/AD+asR/4HS1+XX/BaSRn+PPgYN/B4YQf+TtxX6af8ErQ6fsXeD5embzVcH6X0tSo6tMhR1sz8jv+CrPij9n3xH+0HqNt8M9Nu/8AhONPkW28SajFMq6dNcQp5flCDYXa4jAVJJQ6rlSpRmyw+h/2Kv2Y/wDgoH4L+I3w48R+LtQ1nQ/h1Z3MU9zpNxrzJH9iKHCtp6zkAdP3TKCO6g1+XX7UHh/xJ8Nf2pviHZ61AyahaeJb6+iNwn+vimumuYJiD1WWNlb0INfvV4W/4LH/ALM2seH7O68XaVr2iayEQ3FvHaRXMKy/xCKVZgWTPQsin1FQt7Mlb2Z+e/8AwWjXb+1V4d9/B9if/J+/r9hv+CX7qv7C/wAMdxxkawP/ACr3lfgD/wAFGv2jvhx+1B8cNG+IHwwN42lWXh+202T7bALeT7RFdXczYXc2V2zLznrmv36/4JiqJf2EfhtGOoGsfn/a94aFruSfjV8Z/wDgpD+2bp/x58ceDfhz42aPSrTxJqOnaTZRaPptxJ5Ed3JDbRKXtHlkYqFAySxPqa+5P2HfjN/wUV8a/H2w0H9pDTPEFt4JexvHmfUfDMWl2/nomYc3KWcJB3dBv59DX4wftG6Rr3wS/a88aedb+XeaH4pn1S0VwQHie6+2WrfR42Q8etf0GeHP+Cun7IGreHodV1vUNW0PUnjDS6fNp0s0iSY+ZFlh3xMM9CWGRjIHQSwPyM/4K84/4bI1DH/QF0v/ANAav3F/Yr8JaV4y/YR8CeFvEKl9M1zw5PY3CK2CYLkyxSYbnB2scV/NJ+2V8e7D9pv9ofxF8UvD9lNZaTffZ7TToJwPtH2a2iWJTIEJAeRgX2gnG7GTjJ/q5/Zl8Fat8N/2dfhv4E1uI2+oaRoNhFcxEENHcGIPMhB7pISPwrWPkUj+an4y/wDBN/8Aal+D3i26HhDw3d+MdFgmaSw1PRf38zRo+YjJBH++imAwSApUN912xmvKtR+Kv7cfwNmtJfEfiTx74ODtiCPVJtStopCnYRXWI2x6bTX7saF/wV7/AGUZppItcs/EWkXEDmN1msYpUBU4JBhnfI9OAfavif8A4KFf8FD/AIK/tC/B3/hU3wwsNQ1G4u762u5L69txaw28dsSf3QLNI0rH5T8qgKTyelDS6En29/wTH/bK8a/tN+H/ABH4L+Lc8d94o8ILbzx36RrCb2zuCy5ljjAjEsTqASAAwZeMhic//gpd+xL4w/aeTQfiN8JViuPFnh23exlsJ5RAL2yLtLGIpHwqyxyM2A5VWDH5gVAb5K/4IqeCtWbxD8SPiLLDLHpsdpZ6TFMQRFLNJIbiVQehaJUQn0Dj1r9Yv2mv2wPhl+yH/wAItcfE7TtUvYfFjXiW8mmQwzGA2YhLeass0RwfOGCuTweKXS7A/mOg+B/7dHwSmmj0Hwn478LAnfJJpEOoRxFhxky2eYycd91d/wDBP/got+1D8IPGdhP4t8W6l4x0K3nCajpmtSm7kkiDYlCTT5milAztO7Ab7wIyK/Zu4/4K6/sjvaSXzXOuvKgyLYab+8PsCZRHn6sK/nf+OPjl/wBon9oTxN438HaFLbSeNNWzp+mxr5lw7zMsUSlU4aaU4LBc/OxxnrSemzA/sZ+I2sWWu/BfxJqWhv5tlf8Ah+9uInHG+KW0Z0PPPINfyR/sFsyfth/Cll6jWY//AEB6/rK1LwnP4W/Z5u/AsANxe2Phh9NUZ3F3hsjCOe+SPxr+PL9mn4n6L8F/j14H+KfiG2nvNL8N6lFdXUVqFMxhXIfyw7KpcA5ALAE8ZFDA/twhhEC+fPy56Dvn/Gv47P8AgokWP7aXxSLjB/tCDj/t0hr+qn9n/wDaE+H/AO0n8Pz8Ufh6t2NKF3NZAXsQglEsAUv8gZxj5xzmv5U/+Ch7mT9s/wCKTt1OoQf+kkND11Eux/WJ8AY3m+B/w6kn6Dw5pG1f+3SLmv5Jv2+f+Tx/ix/2Gpf/AEBa/rl+Af8AyQr4cf8AYt6P/wCkcVfyS/8ABQK0ubP9sv4rQ3MZR21cygH+5LDHIh/FSDSbuNI/rq+FUpHwy8FQr30bTyT7fZkr+aX/AILFNu/a6i9vDmnD/wAi3FftN+xJ+2F8LP2jtDtPBPgiDULfWfCWh6f/AGhHeQJHGpVFhYRSJI+4b1OOBxz7V+QH/BZfwrqGn/tFeG/GJgf+ztc8PxQxzEfIbizuZ/NjB6ZVJYiR/tCm0Tc/ZT/gm6C37Gfwyc9FsbgD/wADJ6/Mr/gt0+/VvhC/rFrp/wDH7Kl/Yi/4Kc/B34Ifs9aX8I/itpurLqfhg3KWk+n28dxHdW88zzoDuljKSIZCuCNpAB3ZJA+Af23/ANsjUf2vPG+l30GjLonhrwutzFpcDnfdOLkxmWW5cHbufykwi8IBjLHLEvoK2p+0X/BGHj9ljxBMx4XxXff+kVkTX5Vf8FY/CR8Ofth6vrGzYPFOl6dqY9DtjNkT+dqc+9fqj/wRsbZ+yV4g9T4uvx/5JWNfK/8AwWz8HfZfEHwp8exx5+32Wo6bKw/h+zSxTxA/Xz5MfQ0ugfaPjn9t34v6h+0F4s+Dfg/QXN7PpnhDQYPJByTq2sQRTzL9SGgU+4r2T/gqp+z/AGHwhvfhFq2gRAaavhuLw5I6DAafRAoSR/8AalimH12V86/8E5fhu/xQ/a98D293GZ7Lw5I+uXBPOxdMTfbn6faPJX6Gv3Q/4KrfDFfHv7Huq6/bReZfeCb+01iPA+fytxtJx9BHMZD/ALntT8xbNI/ED9vH47t8ebn4O+IjcfaZYvA9gb05z/xM2nnivP8Ax+EV/Sd+wv4Q/wCEG/ZD+FGhbPLaTQ7e/ZfR9TzfNn3zMc+9fxlaXp99rupWOiWamW4u5Y7aBPV5Xwqj6s361/eX4b0O08MeHdL8N2AxbaTaQWkX/XO3jEa/oKgtKxfvG+QQjrKcVVvslo7eMZwOgq+8W6ZH7Jn8zUoVQxYDk9TVJ2Icb3P4dvifd22nftG+Lb7UP9RbeK7+WXjPyJfuW478Cv1k8ff8FsPGQ1u8g+FHw80220eOUrbzaxLNNcSxjo8kcDxLGW67Q746ZPWvya+K9gmrftG+MdKmYql74r1CFivUCS/dSR781/Wb8Nf2Jv2T/hzoVp4f0j4ZaLqEltEsZvNXsodRvJ2/ikkmuVY7mPJC7VHRQBgCStD8pP8AgtLqh1rQfgFrEyolxe2uuTSBOimRNMfAzzgEnHNfTX/BFUn/AIZc8Vg9vGN7/wCm/T6+d/8Agt7Y29hH8E4LRBFCi+IVRFGFUJ/ZoAAHQAdK+gf+CLEyJ+zF4qifjPjG8IP/AHD9PqvQE+555/wUs/4J7fEv4x+P2+PXwQtU1q/vLSKDV9KMqRXDvaKI4p7bzNqPmIBXjLBsqCm7cQv5Hx/Dz9uz4H2MsGm6H8QPB+m2W6V3sY9UtrOPuz+Zb4h9yc/Wv6Vv2lP2+fg3+yv8QdL+HvxO07WZbjVtOTUo7nTreGeBY3mlh2SB54pA2YieFYYNeHaz/wAFgv2SLDRp7/S/7d1S9VCY7OOw8p3fsDJLIEUZ6nJwOx6VJR+Xf7GX/BSH49+D/i34Y8IfFXxRdeMfBuv3tvp92NTP2i6tPtMgiW5iuSDMfLJBZGZgyggANgj9af8AgrFAYv2MfE7xnCPqGlbh/wBvcdfze/CbQ9S+Of7T/hzTdE00wT+LfE8U5trQErbQTXXnTFcAYSCLcxOBhVJ4xX9IP/BWDzY/2LvEsMnzj+0NK2t/29pwapCZ+Df7EP7VGh/sk+I/Gnjm/wBEl8Qalqmjrp+n2kcghjac3EcpaaUhikaqhJwrEnAwOSP1/wD2H/8AgpB8Sv2ofjs/wv8AEvhnSNF0X+zLq9R7UzvciSBowqmSSTYVO85/dg1+Zf8AwS+/Z4+Gn7QPxu1q1+KOnHW9L8MaX/aMVg0hSC4nM0cS+dswzooYnbkAnG7Iyp/pq8FfAv4JfD+ZNS+HfgPQvDV4kbRC407Tba2uNjY3KZYoxIQcDIJ5wKkT303P45f2rgF/al+MQUbQvjLxDjHb/iYz1/Zzr2iaZ4w8J6v4M19Gk0zXrK4sboKcN5F1EYpMHnkqx7V/GH+1apT9qL4wq3JXxj4gH/lQnr+2eezygkhHYZFWuxnNPRo/kx+NH/BNT9qz4OeK7oeEPDV3400OGZpdP1XRP38zRo2Yi9vH+/imAwSApXd9xmxmvI9Q+Ln7cnwQktv+Ei8T+PvBwdsQxapcanbROU7CK6IjbHptNfuzoX/BYL9ld3e01q08Q6TJE5jcTWMUoDKcEgwzyZH4A+1fFf8AwUM/4KG/Az9oP4OD4TfCvT9Q1G6u762u5r+9txaw28dsSf3QLNI0rH5fuqApPJ6VBabZ9o/8Ey/2x/HP7S3h7xJ4O+J8sd94t8Ii3nW/jjSI3tncFlzJHGBGJYmXDFQAwZeMhif1ct7qO5Xy3Hz9x61/Pd/wRL8H6mnib4k/EeeCWPTY7O00mKYgiKSaSQzyqD90tEiIW7gOPWv6D7m0En7+Dh+vHer9SGrO8SGSGWzk8+HlO4q2RFeQhlOD29QaggvP+WdxwR3/AMama3Mb+bb8HuvY0N9xJLpsRR3TxP5F1wezVLJbkN51scN6djTpI47uPaeCPzBqikk1k3ly/PH2/wDrUehT00exowziX5SNrDqDViqpWG5USIeR0I6ihZWQ7J+D2bsf8KgpPuWCoYEHoaqW0bwO0TcqeQau0VVxtdTDnDWt0HXoeR/UVcu4xPCJY+SOR9Klu4fPiwPvDkVVsZCubd+3T+oqr9TK1m4vZkFjceXL5bdH/nT76IxSCdO5/WoLqDypePuNyK0oXW7gKSdeh/oabfUhK65GHy3tt7/yNQWM5DG3k4K9P8Kgtna1nMcnQ8H/ABqe+iIYXMfBHX+ho8ir/aIpla0uBLH9w/5xVyaNbqASR9eo/wAKUbL2354P8jVK0lNvIYJOAT+RovILW06MZZ3Jhk8t+Ff9DW7WPf2+D56dD1qzYzeYnlt95P5VL11HC6fKxl8ChjuFH3DzS3+RGkqfwn+dXnRZFKN0NVXiLWpibqox+XShMco7ksUweASt6c/h1qZSGGQcg1mac52tEe3IqO3Jt7owk/ITjH8qLFKWiNmq9xOkCbm5PYetTZAIBPJqCa3iuAN/buKheZTvbQzYo5byTzZDhP8APAp9xdrGvk2/ygd/8KkvGkijEUQ2x+v9KrWlp5p8yT/Vj9a182c7TXurcda23mfvpuFH61Y3tdv5cXyxL1PrTJXa7k+zw8RjqaS4mW3j+zw8Y6mlqx2SQXF0sI8i34x1NJbQAL9on4A5ANRWlsH/AH0v3B696S5me5cRp93sPWn5IX95jpZ5bqTyounYf1NWXZbKPy4+ZWoVVsYsn5pXpkCBAby55Pai5ST67kihbRTPOcyvUMEbXDG4uPuj/P5UiRNeSmabhB/nFXOJuekK/rj+lFxpX9BD+++d/lhHb19z7UwFrs7U+WEfrUZL3smxeIl61pKqooVRgCp2LSuKqhQFUYAqC5m8mPcBkngfWp2cIu5qo3PzXEMY9cmkhyemhFfk7YoRyxP/ANapZVBnt4R0Xn8ulRyDzL9F/uf/AK6nTL3sjdkUD8+aoz3bK0/76/WPsmM/zpT++1ADqIx/L/69JaANdSy9uf1NLZkFprhv896CVqOQ+dqBPaMVX/1+o47Kf5VNY5CyzP8A571FpylpmkPYfzoDew+b99qCx9kx+nNOl/fX6R9k/wD10ln81xLN/nk0tmQZZrhqVxpX+ZcuZBHAzfhVCwhbzPNYcAcVpbA6r5gzjn8amqlKysjtU7RsisltGrmQjcxOcmpJJo4hlziqz3vly7JEIHrSXFstwvmRnn+dO2vvj5dVzlxWV1DKcg0+sKCd7VyjjjuK2kkSRd6HIpThyinDlH1nyRvbv5sIyh+8taFFQnYzjKxTkjS6USxHDDoaSKUTAwzDDjqPWkaN4GMsAyD95f8ACnOiXaCSM4YdD6Vsb6W8vyKMsM1s2YiSG7iovNu/Vq0o7nbmO4+Rh+tS/arf/noKrml2NOefY//X/ey6iuM+ZE5IHakgvQ3yT/KfXtTUnmtz5dyMjsanlt4bldy9T3FdG2kjr0StL7yGWzIPmWxwfSpIp1mBhnXa3cHvVYNcWRw/zx1cIgu1yOv6im/MH5/eUprN4j5kHIH5ipra9DfJNwfWniSe24l/eR/3h1/GnSQwXS70PPqP60N3XvA3dWn95dorKDXFrw43x1fimjmGUP4Vi421MZQa1CSJZRzwR0PcV5j8V/hX4Q+NHgfUPh34/tPtWnX4BV14khmT/VzRNzsdT07HkHIJB9UooUmjJ2a5ZbH85Xxc/wCCanx78B6lcT+AoYvG2iAkxS28kcF2E7CWCVhyP+mbMD7dK+Y5/wBmn9o20kMUvww8SuR3i0i7lT/vuOIg/nX9aNUmieFjLBz6r/hXqQxsrWaPGlldGT0bR/JwP2eP2gwdrfDDxSD6f2Jff/Gatr+zt+0OP+aX+Kf/AASX3/xmv6visF4nPUfmKgEk1ods3zR9jWqxsui1J/seD0Unc/lMX9n74/jg/DPxN/4Jr7/41WtYfs3/ALQt9IIoPhn4kBfoZNKuo0/77kjA/Wv6opIYLpd6Hn1H9apD7RZNzyn6Vaxzey1KWTU3tN3PwF+FX/BPL44eLtTt28fQR+C9HyDLJcOk9yU7+XDE55P/AE0K49+lft98NvhP4S+Engyx8E+Brf7Pp1kMksd0k8h+/LI2Bl3PXt0AwABXpQaC8THf9RVbbPZHK/PHXHUxE6mj08j08Lg6WH1p/F5hDeMh8u47d+9Xtv8Ay0i7847GoStvepnv+oqsq3Fm2fvx1yNJ7bnoNJ7aMuPHDdLhuGH5iqYS5szlfnjq0RHcqHjOGHQjqPrToWuM7ZlHHcVKdlYlO2n4CK0F2vuPzFSxiVSQ5DDse9L5Ue/fsGfWpahvojJvogoqqUuS+7eAvpVqk1YTVir9nCSebD8p7jsa80+Lvwi8B/G3wPf+APiRpMetaLfAGSFiyEMhykkcilWjdTyGUg/gcV6rRTUnuNSe5+JN9/wRa+CF5qqvpXjvxBY2TknyZUtZ5PoJBFGB+Kmvpfw9/wAEyP2XfBfw28QfDrT9LvLmTxPbC0u9bupYpdVRBIso8iR4vJhwyA/JCM4G7dgV+hF3bFD5sXTuPSrMZW7tyrde/wBfWt9PiWxvoveWx8QfsufsE/B39lXxHrHi/wCHOsa9qN9rNkLGZdWuLWWJIxIsuUFvawEHKjqSMdq+17OYo5t349PrUMEhtZyr9Ohqe9hIIuE/H/Gnb7PRias+U+G/2pf2BvhB+1V4y0vxt8QdX13TrvSbH+z4U0q4tYYjEJZJcsLi2nJbMh5BAxjjvXv/AOz78CPB/wCzz8KNN+Evga8vr3SNLkuJY5NRkilud9zK0z7mhihQgFiBhBx1ya9sjZLuDa/Udfr61Qike0mKt06Gotf1QrX9T5i+Pf7IfwE/aRMEvxX8NifVLVFih1O1kNrfxxgkiPzo/voCSQsgZRkkAE5r5BuP+CLn7Ks8zTReI/GECNyI476wKD6b7Bj+ZNfrRdwCVPOj5YD8xUdjcZHkufpUyXMuZEyXMuZH5Jt/wRW/Zb2kr4p8ZZxx/p2nf/K6v0N/Z8+D3hj9n34XaL8HvBt1eXmjaCLj7PLfyRyXLfarmW5fe0UcUZw0pAwg4Azk8n3OsKZWt7rf2zkUoK90KKvdHyZ+0r+xR8B/2n7q3vfiRps9trNpH5MOrabKLe9SDJIjJZZI5FBJIDo2DnGMnPwbqX/BE34URTJLZfEXW0tyeVkt7Z39vnAUf+O1+19+geNZ15x/I1JH/pVnt7jj8RTdnaTDzPzk+AX/AAS8/Zn+CPiLT/HMkd/4x13TXWe2l1iSJ7e3mU5SWO2hjjTcpGVMnmbTyMEAj9J2RHHzAGs6wlzmFvqP606FmguTbsfkPSk47k2Pxt8Sf8EVvgxqOoTXmheO/EFmlw7SFbhbS4Klzk8rFDkVBoH/AARf+BWk38c3ijxrr+uRRkEwwi2s0b2Y+XK2D32kH3r9qN67tmefSoZraKYfMOfUVKa6kHl/wn+FfgT4P+DLDwN8O9Ji0PQNKB8mCPJyzHLSSSOS0jseWZiST3rwD9rX9j7wD+2HZ+HrHxtq+p6PJ4Ye6azbTnhAY3YiEnmpNE+7HlLjBXHOc9vsS9jdYVihX92OuKbbItrCbiT7zdBV6PUD8TLr/gib8K4ZEKfEnWdp6qbW2J/Pj+VfYH7N/wDwTm/Z2/Zt1228faTb3viPxNY7ja32rypIbZnBUtBDFHFErEHAZlZh2YV92wRtdTF5OnU/4VOSbufy1/1UdFlsAkKmVjd3HCjoK/Mz4j/8Emf2UviR4n1Dxin9ueEjqUzzy22j3lvHa+ZIcuyx3NvceWCSTtQhR0UAYFfprJ/pMwgj4ij64qK5czSi2h6Dj/P0qWrgeBfs1/s5eC/2afh9/wAKz8B3uo3+ji8nvvN1OWKW48y4ChxuhhhTHyjHy596+ZfjR/wSw/Z8+OXxP1/4r+LPEHiez1bxFMk1xDY3djHbIyRrEBGstlKwGEHVzzX6VwxLDGI16CpamTuJI5jwj4ZsPBfhTRfB+lySy2WhWVtYQNMQZWitYliRpCoUFyFGSABnoBXxz+0X+wD+z5+1J4qfxn47ttQ0rxAkSQSahpFwlvNPHHxGJUlimiYoOA2zdjAJIAA+5Ek3SyA9EwKpWHEUsh/zimkM+Mf2Vv2GfhJ+yXrOv+J/hzq+uajca9bJaTLq1xayoscT+YCggtYCDnrkkY7V658dP2dvhX+0n4Am8E/FTTDe20UjTWlxC/lXdnPs2+bbyjODzyGBVujKRXuUZ2aazeuf54oBK6aT6/40zM/GMf8ABFT4IxXy303j3xDJphIP2cJaCfHp53lFf/IVfSPjP/gmP+yz4k+FGifC/TdNv/Ddppd79vN9ps8X9o3k7RGNvtNxdQz+YpByFAAUj5ABkH9C7sYtIk+n8qkuhzbR9sgfligGz5v/AGdP2Z/Av7KXw+uPhp8O7/UtR0y+1KbVHk1SWGWdZ5YoYSAYIYF27YRgbc5J5PGKP7Vn7Knw4/as8J6J4R+Il7qen2+i3hvbebS5YYZt5iMRVjPDOvlkNkgKDkDnsfpm8+a8iQ9OP1NM1JiZUUen86a6Et7s+KP2ZP2Cvgz+ybrmseNPh7qGs6pqmt2SWMj6vPbyiKHzVlKxeRbQEbmRd2SfujGK+r/iH4P0b4geANa+HviNWbS/EdjcaddiMgP5F1E0UhUkEBgGyDg4ODXZtA01tFFnGMZ/KrhRGIYjJHSpuVa5+VHgn/gkH+zR4F8aaB410/xB4qvLrw/f2uoRQXV3YPbyyWkqyrHKqWKMY2K4YBgSM4IPNfq1RWbLetDNsePC/qfpUWLbtuXHniiIV2AJplwkskeImwf51G0dtepuHJ9R1FVx9psev7yL+VAm++x+WOq/8EmP2ctX8f3vj/U/EPiyPUb7UpNUkjjvLAQCeWczEAGxLbNx4G4nHfNfqtLbRXK74zgnuKd/o95H6/zFUjBcWhLwHencf/WrQz9dUfI/7U/7Gfww/a6PhaL4qarrOl/8Il9t+xtpE9tB5n2/yPM837RbT5x5C7du3GTnPGOw/Zr/AGWPAP7KvgO++H/w11DUtR0/UdSk1SSTVZoZZhNLDDCVVoIIFC7YVIBUnJPOMAfScVxBdLtYc+h/pTfLmt+Yv3kf909R9KzHbSx8A/tW/sC/DL9rTxbpfjPxt4g1nRNV0iwGmxfYWgMBhSWSYF45YWYtulPIcDGOO9fJ8P8AwRH+E/2gSS/ErWpLb+4ttbB8f7/I/wDHa/bL/R7tcY5H4EVV8m5tMtCd6+lAK6Pkr9mj9hX4A/ss3cuufD/T7q/8RTwm3k1bVJRcXflMQWSMIscUQJHOyMEjgkivV/2hvgL4P/aU+GF98J/Hd3fWGkahNbzyS6dJFFch7aQSphpopkwSOcoePSvaIbuOb5fut6GrdBqfDH7Lv7BPwh/ZI8W6v4x+HOra7qVzrVkLCZdUuLWaNI/NWXKiC2gOcqOSSMdu9fbckLK3nW/U9R2NXKKBWPyr8e/8Ek/2bfif488S/EbXPEfiu31TxRqd5ql3Fb3lgkMdxfTPPIsavYuwQM5ChmJx1JPNfqFFI9pthn5QcBqsyw5PmRna47+v1pqyLMDDOuG9D3+lBLufjT4j/wCCK3wS1S9uL3QvHviCyFwzSbZ1tLnBc56pDDxVDwx/wRh+Bml6jHceMPGOv6zBGQTBD9ms1f2ZtkrYP+yQfQ1+zxSa1O6L95H3X0qYNb3qev8AMUEu7PPvhj8LPh58JfA+n/D74aaPFomg6aCIYIsk73OXeR2Jd3Y8szEk+tdsrTWLYf54zUcltcWreZAcj/PUVcguorhfLkwGbse9Ab77iyRQ3aeZGefX/GqqTz2jeXKMr/npUr20sDebaH6rUsc8V2vlSDDdwf6UBb7yZWjmXzIm59f8aVikg8qUcnt6/Ss9rWa3bzbc7h6d/wD69W45YrtNrDDDqvcUFJ9GV2tZoG8y3OfarEVyk37qUbX7g0KbiJwh/eR+vcfWrDxxv99QfrQJK2wxEdDhTlfQ9RU9FV5VnYgRuFH0zQaFiq8kCSEMPlYdCKmXdj5uT7U6gLXK8sfnRbX4P9ayIZGtZvn47EVv1Ru7Xzl3J98frTTM5R6ojvoQ6Cde3X6UWcwkQwSc4H5im2U+QbeTqOmf5VVnja0nDp06j/Cq8iHp7yJQTZ3O1v8AVn+VTX0O4ecnbrUkyLd24kj69R/hUVhcbx5EnUdPp6Ux2+ySWs4mjMUnJA/MVRlR7WcMvK9QaLiN7ScPH06j/CtIiO8g46/yNArXVnuWIpFlQSL3qSsK1na3mMUvAJwfY1u1LNIu6MND9nvMdgcfganv0wyzDvxTdSiORMOnQ1YH+lWX+1j9RT8zO28RJz51qJV6r835dals5fOi+Y5YcGqunS7laJvrUUObS8MR+4/H+FQNPaRsfKwI6jpVa5hd4fLgIHt61WuS9vOk6n5G4YVos6qAWOM0F76GcxFlb4H+sf8Az+lUbeFriXB6dSa3pI0lXa4yKrGE28DLbDLGruS4fcU7yYf6iLhU61LCi20fnzffPQVBZW53mWZcCP19aZLI15cBE+70H+NMn+8yWBWupTLN90fl9Ke269l2rxElFw2wJZQdT1p0x8hEtIfvv1NA7EnE7+RFxEn3iO/tUE0puJBbwfcHp/npRcuLWIW8X3j1NWrS38iPLffbr/hWYWvoWIolhQItS0VXkkImjjHRsk/hQbbFacl7yKLsOad9/UP9xf8AP86hX5tSP+wP6VNBzdTt6YFBmRQfPfSn0z/hUtucG4lP94/pUNgfMklk9f60tvn7DKx77j+laEobZ/LbSyj/ADgUIfL09m/vf14pE+TTSw7/AOOKW5+WxiA77f5UAloKmI9Pdv7+f14pbDiOR/8APFNuDs0+NR/Fj/GnWSN9kkA4L5xn6UDS1QlsfLs5JPXNPtY91mQv/LTP+FWooFSAQt8wH+OasVNxqI1gSMA4PrWQ7XNq25jvB/I1duTOSBCDkc5/pTYbpJP3co2P0welaR0Vzshor7jlkgu02sOfTvVfZNZtuT5ou9LNY877c7T6URXjIfKuhg+tWv7pa293VdidkgvE3Dr69xVDE9m+e36GrrW4z5ts2w/oaVbgE+VcrsJ9ehpp222BO2i1RLDPHOMr17irFZstng+ZbnB9KWO7ZD5dyNh9aycb6xMnBPWBo1VeFlfzYeD3HY1YUhhkHIp1QnYzTsV9sVwB5iZI7HqKT7Jb/wDPJasYBowKd0Pm8z//0P3vjuYrkeXIME9jUTW0sDeZanjutLLZRyDfEdufyqNJri2OJwWT1rpX937jrVvs/cTR3sUnySjYffpQ9mpPmW7bD+lOKW12u4dfUdareTd25zEd6en/ANakvLQS/uuxMtzJEdt0uP8AaFSeTG372Ftp9R0/Ko0vY3+WYbD79KcbYf6y2bYT6dKb030B6b6Egklj4lXI/vD/AAphtoJf3kR2n1Wm/aJoTi4Tj+8KlCwT/PGcH1HBqNtSdVqRh7mH/WDzF9R1qeKeKThTz6HrTA06feHmD1HB/KmF7WY4cAH34NDVxWv0+4u0VCiBOVcsPTOakZlQbmOBWduxlbsGBnOOaUgEYNVo7kSvtjUkDqamDqW2jnHX2pNNDaa3K32Xa++FzH7dRVrBIw2DSCRC3lg5NDSIrBSeT0FU23uDbe5TksRnfAdhqeJp8bZl/EVOzKg3McCoo5kl+5kgd6fM2tSnJtakEtmpbzIj5b/pVqMOFw5yakoqXJvRkuTejI1jRCWUAE1JUckscQy5xUSzgoZmG1e2etFm9RWb1JnkSNdznApvmp5fmtwPeqMebhzPNxGnQVCzyXswReEH+c1sqfc1VPoy5DO8zllAEY7nrT0maVzsX92O57/Soioc/Z4uI0+8f6VE8huH+zwcKOtPlT2K5U9i0LgPJ5cQ3ep7VK0saMEY8ntVNpBF/o9uMv3NGEtPmb95K9RyojlRo1UFsI5fNhOM9R2qIbk/0i6bB7AVLFNIwMsgCJ29aVmthWa2GXlt5q+Yn31/Wm2kgmiMEnVePwq8jB1DDvSbE3b8DPrRzacrDm05WYnzWVx7fzFX7mJbiISx8nt71YngSdNrdexqG2glgJXIKmrcr69Sua+vUrWNxtPkP07f4Uy6gMT+dF0z+Rqe6tST5sXXuKfbTGRfJnHze/cU7/aQX+0ia2nE0e7uOtLPAs6YPUdDWeyvYzb15jP+cVqq6yKGXkGs2raomStqinADJA0EvVOP8KrWTmKcwv34/EVqFBvEg69DWXfRlJVmXv8AzFUne6EnfQLlTb3ImXoTn/GprxchLhP4afIBdW25eo5/Gm2ciyxGFv4f5Ur9R+Yl4BLAk6dufwNWrabzoQ/fofrUFsMCS0k52dPcGqtu5tbkwP0PH+FLl0sI2arz28c6gPnjpirFRSyeUhkxnHWoXkZlR4Xht/KgGSepqKQi0txEp/eP1rSjdZEDr0NIURsFgDjpTv3AzXP2K2wP9ZJ/n9KlsIPLj81ur/yqaa1SaQSOx47dqt0NgFQ+aPNEPfGTUhOMe9UkUjUHbsV/wpIBynC3L+5/QVWteLKU/wC9/KpkyYrnH95/5Uy3RxYuu05OeKoTQxxt00D1x/OiUbdPVfXH+NTPA8lmsI4PHWpGtvMt44HONmM49hSuKxDfjIiT3qWZGe4hIHC5NWTGjEFhnb0qSlcdim9v5lwJieBjAqzsXdvxz60+oJfO4aHHHUHv+NSFh0s8cIzIcVFDdwzHapwfQ00SRT5hlGG/un+lUp7B1+aHkeneglt9C20U8TmSB94bqrH+Rp+6G5Gxxhh2PUVmQ3s0Xyv8wHY9a0klguhgdfToRQNFGS0mt28y3JYfrU9vqCsdk/B9e1XR5icH5h+tQS2sE/zDhvUf1qrkWtsMltAT51s3lv7dDTUvmjby7pdh9ahC3dn9395H/n8qtpNb3i7WHPoetSP0FktoLkeYvB/vCohJdW3Eo81fUdaY1lNC2+1f8DTkvWQ7Lpdh9aA9ScC3uhvQ8juOCKUedF1/ej8j/wDXpjQQT/vIzhv7y03fdQf6xfNT1HX8qAJGjtrnqPmX8CKYEuoPuN5q+h6/nT1kt7rp1X8CKdtnT7p8weh4P50GgJdRt8rfu29G4qzVRpYiNk67fZhx+fSnRxJjMTkD2ORQBZoxmiqrXKb/AC4h5je3+NUlfYlyS3LVVZbWOR94yr+oqcsAQD1PahnVSAx5PSpG7dRIw4XDtuPrjFV57KKb5h8j+oq0zKg3McCnUBpsUoVu4/klxIvr3qSe2jn5PDdiKeJ4mbYpyfapqp3RKsyvAksa7ZX3+nrUhRC28gZHepKaSFGScCpLHUVBHMsrEJyB3qs7tcyeVGfkHU1ai+pm5pLQtpKsmdnIHeq7XDPL5UAB9SelQXEvS2g6dDj+VSqnkKIYuZG6n096vltqYubbsidpTv8ALjGT39BRJOsZCAbmPYVWeQQYgh5kPU0oC2i7m+aV6fKVzvXUuNIsa7pDinggjI71RVMfv7o89h2FOHmT/O3yRjnHc1PKUpvsOmtUlYSKdkg7inzQieLy36+vvTUmaSTEQ+QdSf6VOrq2dvas2mi009jLtJGglNtLxnp9f/r1HeQNBJ9oj4BOfoa2HVWGGAP1oZVdSrDINO4culiqrR3tvhuvf2NZ0Ej2U5STp3/xq4lm8EvmRPkHqD6VPdWwuF44cdDUis3r1IL22Ey+dFy4/UUWFz5i+TIfmHT3FR2kssB8mcEDsT2ovIGjb7VD25OP50B/eRpuqupRhkGqFsjW8xgb7j8qfpVq3nWePeOvcVKyB8Z7HIoL31MaX/RLzeOh5/A9asahFvQTL26/SpL+HzId46x8/h3ptlIJrdon7cfgarzIt0Hf8fll/tf1FJCPtNn5Z6gY/LpUFoxt7h7d+/T6/wD16sgfZ7r/AGJv51ILUZYTFkML9U/lWlWLcg210J06Hn/GtdWDqGXkGqY49gdFkQo/Q1VitRbh3i+ZiOM1dqvDMswOBgrwQakqxUhU2yPc3H+samW2Qr3svJ7f5/StRgGGCMioJrZJoxHnaB0xVXFYoWkbTzG5l/hP6/8A1q2KjjjWJAi9BTi2AT6VI0rEcsojC56sQB+NRNzdqPRSf1qO6UmS3IHRqk/5fv8Atn/7NQMq2/N/L9D/ADFS2oxJcN/tfyzTbRWFzMxHGT/OpLeN1E2RguxxVMyRXsBiCV/88CnR8aaT7H+dTW9u8cDxORl89PcVPHAiRCH7y+9SUkUijHTgiDJPp9anmtfOjRM4C1cAAGBwKWquVYj8tNqqRkL0zSuyou5jgChwxUhTg+tVhNg+XcDaT3/hNSMQX1uz7M49z0p0sDuwkikIb9KrXGnq3zwcH07VRSa4tG2nj2PSgzb7mk108YAlTDZ59CPapGSC8TcOvr3FRx3EN2vlSDDen+FRPZSxNvgP+Nbxt6M66dmt9Rd9xacSfvI/WrIe2u12nn2PWoor3ny7gbGolso3+eI7D+lN/wB7Rlv+9oxv2ee3Obc7l9DUq3EMw8uYbT6Gq4murfiUb19f/r1YEltdDa3X0PWm11YNPd/eO8mSLmBuP7p6fhQXRx5c67Sex6fgaj8m4hH7ht4/utSrdRt+7uF2H0PSotfUm19dxfsrRHdbNt9j0pRctHxOhX3HIp3lFRut22+3UUecy8Tx4HqORT331DffUnR1cZU5FPqkUs5PmUgfQ4pPItf7/wD49U8sSOWJ/9H99FMcg3xNj6f1FKZCBiRePUcistra4gO+Pn3FTxX5Hyzj8RXQ4dtTqcOsdSwbWF/3kR2H1Wk3XMXDDzV9R1pwWGb95GcH1Xg/jQWuY+oEo9uDU3voTe+j/ETzLaf5ZOvo3BpPsrxHNvIV9jyKXzbef5JBg+jcGj7PInNvJj2PIo20DbTYPtDJxcJj3HIpDb2837yI4PqtKLh04njK+45FL5EEo3x8Z7rxRsG3kAF1HwSJR+RqfAlX51/A0IpRcMxPuaZJOkcXm9R296jfYy32EnnS3XJ69hWciTXj75DhB/nimxRtdyGWU/KOv+FWg32k+VFxCvU+vtW1uXY6rcu25KpDjy4fljXq3+H+NRiQyHybbhR1aoJJWncW8HyrTppBAotrfr3NHKSojzKIz5FqMt3NDyJaD/npKeppvy2MPq71Db27XD+ZJ93v71Vlu9h2W72/MfFFLdt5kx+StRVVF2qMAU4AAYHSlz2rnlK5zynzBVdZt0rIo4TqahaYokk5+iiq8p+z2oj/AI5OtWoFRgR83lz/ALH9KdcMZ5hbJwg4p0H+j2rzHq3Slth5EL3LdT0rZ90dDdtV02G3cgAFtF0HWplU28YiT/Wyfp/+qq9ogy1zL0X+dTo+xHu5Or/dHt2pP+VCenur+mMuHEKC2i5Penn/AESIIv8ArZKhtV3M13N0H86kg/eSNdy9E6U3poJ6aDhts49zcyvREBEDdT/fPSmRL9olNxJ90V8tX/7XvwzsP2n7D9lbUrDVofFWpQfaLa5MEP8AZkifZZLv/W+f5uSsbKP3P3xjpzSfn/XkJ9n/AF5H1Rt8w/aLrhV6Cps7h5svC/wrXzT+0v8AtSfDb9ljwfp3jv4nRX93ZalfJp9ta6bFFNcPKY5JS+2WWFdiiP5ju4JUY5r1r4c/Ejw18Uvh74e+KHhZ3bSPEtlDfWomAWWOOZQ2yUKWAkQ5VwGIDAgE9ah72Ie9jvGBJ82dtqDov+NeJftDX3xsj+EWuz/s52dveePUa1/s6O8aFYG/0mLz8+eyR/6jeRlhzjHNed/sx/ta/Dj9rW38Sal8PLHVrWz8LTwQTy6lBDAkr3AkI8nyppiQAmW3bT8y++PKf2iP+ClX7O37PHiu5+H+qy6j4i8QWBC3Vpo9vHJ9kcgMEmlmlhjBweVQsy9GANOyJaR83/sjf8FKdXv/ABP43+HH7Z+q6N4Q1jwvN5MFyR9l3XMErw3VtIEaSNmjZQQyYHXrwa/UD4ZfHr4Q/GhdSl+E3iqy8VR6N5IvTZSb/s/2jd5W7gfe8tsfQ1+KPw5+MX/BMT9o74uWnh/V/grrMHjDx5qrb7u6Zjby3t7KXaSRodQyu52JOIsDNfphrVj+y5/wTv8Ahlr3xQ8PeE5vD+i6pc2Vvfppnm3U9xKpkS3+S5n2gL5j8hh15zWFramdup9rw3cUx2rkH3qcuoIUnBPSvxfvv+C0f7O6XynTfBnil7fPzO8VjG/4Ri7Yf+PV91/s4/tk/Av9q22u7f4Z6pNFrWmxie50rUIvs97FHuA80IGdJE3EKWjdgpI3YyM21HoNpH1syqw2sMikRFQYUYFfKf7T/wC1x8Nf2UPDuieIPiZYarfQa7dSWsA0uCGaRJYk3kuJp4QBjpgmvpvTryPVdMttRjUpHeRJKoPB2yAEZx3walq2jFboalQzxiaMp+X1r5K+KH7YPwx+Dfx38Gfs9+KLLV7vxH48+xfYJrWGGSzj+3XT2kXnSSTo64kQltsbfLgjJ4r0z9oP45+FP2cfhZq3xe8a2l7f6Ro72ySw6ckUlyWuZkgTYJZIk4ZwTlxxnr0pbPQW2x6xYylJDC3f+dNlzaXW9eh5/DvXnfwi+J2gfHP4ZeHvi54Qtrmy07xFB9pt4b1I0uAoZkxII3kQHKno54ryHwJ+118M/if8efF37OGj6dqtj4t8FxXE9095DDHaSx20sUTfZ5I53ds+crLujXK5PGMVpdXua3u7n1bcfKUuo+cdfcGob6ESRi4Tnb/KvkL9pb9tv4P/ALJbeHrD4nWuqahceJRctbxaXBDO8cdsUDNKJp4cAmQBcZzg+lfRXiP4heHPB3w81j4k6lKbjQNF0u41l5YAHMllBAbkmNSQCTGPlBIB9RS2I2O7s5/Pj5+8vBq0VDAg9DXzJ+zh+0X4M/aW8Cv8Tfh9p+pafo63s9iqarFFFPI8Cxl2UQyzLs+fAO7OQePX5y+K/wDwVU/ZS+FHi2/8GTXOr+J7/S5Xt7ltGtI5beOaMkPH5s80CuVIwTHuXPQnmpkuqE11Ob/aM/4KS23wH+N158APCvw01L4geIdOigecWlz5Db7iAXQjiijguJJMQsrMcDHPpmvdv2Rv2pvGH7R7+KF8W/C/VPhqNANmIBqckshvPtXnZ8vzbW3/ANV5Qzjd94dO/n8Xj/8AZMt/h7N/wU3i8Fait7cW4Ml7t/4mxi84aNj7N9r+y9FA+/8AcGc7uK+qfg18YPC/7QHwq0H4yeCILy10fXhObeK/jjjugLe4ktm8xInlQfPESMMeCOnShaknsk10IHCyKcHoRU8ciSrvQ5FVHC3lsHX73UfX0qnYTGOXym6P/Oi2hVjZUg9DmnVi3SPbXHmxcB6vpIt3DlSUPt1BpWJLdFZcFw8Mn2e5P0JqxJvhPmp80Z+8PT3FFgJnnhjOHcA1JnK7l59KpyQw3ib1PPYj+tUklnsX2SDKf56UWFcvx3cbsY5B5bjsauVSeOG8jyD+PcVTE1zZnZKN6dv/ANdSM2aKrQ3UM/3G59D1qzQBHJFHKMOM1XAnhP8Az1T/AMeH+NXKKAKbxW92Ce47jgisyaxmhO5PmHqOtbhRSdxHPr3p9VcTVzDh1CSP5ZfnH61qRywz/Mh5/WkltoZuWHPqOtZsmnyod0Jz+hqSdUa2XXr8w9utQNBb3GT/AB+o4Iqil9PCdlwufrwavpJb3XI6/kRQVe43ZdRfcIlX0PB/Oj7TC37uYbCezDinMtxHzGRIPRuD+dN+0xH93Ohjz2Ycfn0oGBtEzvhYxn26UvmXEX+tTzB6r/hR9mQfPbuY8+nI/KjzLmL/AFsfmD1X/CgAK2l1yME+3BoEU8X+rk3j0b/GnbYLn5sZI/AipI4zHxuLD3oFYVWdgfMXb+tKTHChPCgU7cvPPTrWVIz3koRPuD/OauMbmc58q03FaWW7fy4+E/z1q0irF+6hG5u59Pr/AIU0kRYt4PvHqfT3pksogXyYeWPU9/8A9dbb6I517vvSev8AWiJWlWNvKi+eU9f/AK9NZltuW+eVqYNtnFvbmRqSFAim6nPJ5FKy3/pju726/kScR/vrk5fsPT6VX3z3j7V+VO9R/vLuX0H8hWtHGsS7V6VTfL6iivabbfmJFEkK7UFS0VCWJkxnAUZNc+516LRCPJtdI1GS36CqV7IXcQp/k1Kj8SXTd+B9Khs13yNK3b+ZreKtr2OScnK0e/5DpyLeEQR9T1pWP2SAIP8AWNTYB9ouDO3Ren9KjA+1XJP8A/kKq3R/Mm/VddES20awx/aJOvapGfyIzI/+tk/z+lPGJZc/8s4v5/8A1qqjN5P/ALA/lU7u7K+FJR/rzHwKIUNzL1PT/PvTohnN3P8AhSSf6ROIl/1cfWibNzMIE+4nWjfcW23/AA7CMG5fzpeI06DtUnzXbYHEQ/Wlb9432ePiNPvH+lIT5zfZ4uI16kfypFeT/wCH/wCAPGJBtj4jHUjv9KXDScL8kY9Op/wFSHYqc8ItUN0t6+1fkjHWpSvqaSdtOpaE6FhHEpbH5D8at1n79n7i1GSOpqREEX76aTJ+vFJxQ4yf9bFliwGVGT6VWW7iLbGBQ9OalinSYkJnimz2yzDI4b1pJJaSHJtrmgydiFGScCnVTgYuphmHzLwfcUsBKlreTnHT3FJxKU72J0jjQ5RQM+lSVFGrJlew6VGIWWTzFkOPQ80rDu+xZrAGbO8x/B/Q1v1XuIEuE2twexqSmihqMRBW4TqOD/SrIP2u2DDh+v0YUsaNJAYJuq8f4GqNlKYJzA/AJx+NBBdIF5bY/i/kwqtp8xBNtJwR0/qKnY/Zrnd/yzm6+xqvfRGNxcR8c8/Wgb7mxWeUaC680f6uXg+xqxbzLPGHHXuPepmUMNrcg0Fmfcu9vMkoJ8tuoq1NOIUEmNy98UlzD50LJ36j61Ws5FnhMEnVOPwoAsw3MVxnZ1HY1YyM4rn1L2dzz26+4q9fxb0W4j+8vcelBCZp0Vn2d2J18uT74/Wonkks5vnJeJ/XnFBVzVqN5I0++wH1qJw0iiW3bn9DTQ0N2hRxyOoPUUDJ0dJF3I24e1VzdCOXy5l2A9D2NZ7xT2L+ZGcp/nrV+OaG8TYw57g0CuXAQRkcilrGaO4sjvjO+P8Az1q3DfQy8N8h96AuXqayqw2sMinUUDKgikh5gOV/un+hoPkzjy5VwfQ9fw/+tVumsqsMMM0AZ6WsVrJvZ/3bjGD61c2uvKNkeh/xqK5gM0QRT0Oeazwbu0+n5itoxutGbQhdaM0nMUnyTDaff+hqL7K8ZzbybfY8impexSjbKNufXpU3lFRut22+3UUarRlax0Y37Q8fE8ZHuORSGG1uBlMZ9qX7RIg/fx8eq8ijy7a4+ZOvqODRtqG2uwm25h+63mr6HrS+fDL+7mG0+jUm26i5VvNHoeDSiaKT93KpBPZhR5hvqJ9mKc28hT26inq1wDtkUH3U/wBDQLZV5iYr7A8VOWVcAn73Sk3chyv5iGOMnLKM0nlRf3RVW6uzCQqcnvVT+0ZfShRbVwUJNXP/0v38qJ4Y5PvqDT9y5xnmnUbFbGc1gA26FylWolmXiRg386noq3Nvcbm3oyJ4o5Bh1BpkcAib5WbHp2pzTxo2wnLHsKc8iRrukOKNdg1tYkoqh9qklO23jz7npVgOYk3TsPwocWgcGtwmhEwwxIHoKr3VtLMVCEBB2qdJXduIzt9Tx+lTMyryxxVJuLKTcWZ0+V2WcHGetR3UiwoLaL8TWtgZzWabJvtAcnKk5NXGS6mkJLqNXFnb7z/rJKbaIFD3UvbpTJg91cYUHCnGe1W7iCVkWKLAUetW+z6mr7N7lFQ97Pk9P5CttVCKFXgCoLeAQR7e56mrNYzlfRHPUld2WwVQjkZo5Zv75wv8hVx1DqVPemLCioqDopzUppERaRVkUNNFbj7qDJqjdMZrjavY7RWwIlEpl7niq8dkscgk3k4rSM0jaM0tWQXfJitk7f8A6qS76x20farQtibkzs2R2FMS3kN2ZpOnaqUkrFKSVvIbIgzHZp06t9Kr3TmacQR9Bx+NWV3xia4cYJ6VXs1C+ZcP0WqWmpS01/q4t2wRVtIvxqSVCqRWkfU8mobRTNOZn7c1YRwFkvG78L9Kp6af1cHpp/VxXUMRaR/dHLGvw/8A26Vj+H3/AAUY/Z0+KSfuLXVX0/TJ5BwCIr9oZm/CG8APsBX7eMxgt8n/AFktfjJ/wWZ8P3Nh8M/hf8TrD5b3wx4gkt45B1Q3kPng/TdZr+NZS2uZS2uc/wDt2aGf2sP23Phj+yjZ3LRaPoGl3mpalLGeIZbmJpjvx/0yggCn/ptx1q5+wh8Zb7w/+wf8XfDXiGQ2+t/BeHXY/IY/PHHJbzXMCn3+1CdAP9kVP/wTfll/aB/ac+Ov7XOowNHaXs6aVpfm8lLeZg4jJ7PFbW9upP8AtH1r4k/bH13UP2ZP2gv2j/h9psckejfGfSrS8tVXhDNd3cFzLKf9lT9uiHuR0qL21RF7ao/SP/gjl4LbRv2W9R8S3C7P+Ek8QXk4bpvhtoobZR9BJHL+dfAv7KfxV+Dv7O37Ynxjl/amt49P1u61G8Wy1K9sZLkW07XcsspCLHLJH9oVo2SUDG0dcNz+yX7BXhZ/B37HXws0NU2faNITUiO5OqSve5P4TV6v8TP2YPgF8ZrhdQ+KvgbTPEOoqvlrdSxeXdhB0T7REVlwOw3YHarask2XayTZyXw4+O/7KHxn8QWkXgrxZ4b8Qa/GfNtbcGIahmPndFFMFmyvX5RkV7J8SPEfwr8PaPBL8XtV0XSNGnnCQ/25PbQW8k6AsAv2ohC4AJAHOMmv55f+Cln7Nnwk/ZP8UfDLxv8As8xy+Fdf1G6uZjYw3c1w0cti0D291B5zySxkOxB+baTjaBg5+nv+C0y65c/B74aX1zH5Vt/bE4mReUSdrXKDP0EmPWk5N3bM229T9UvDPxP/AGbfHF2ngbwd4r8J6/c3auI9Msb2wunlCIWk2wROxcBQScKcAEnivxm1vwRoHwE/4LBeD9O+G1lDoej+JUinexs0EVvGL+znt50WMfKFaSMy7QMAn5QMDH6P/s6/sS/sm/DnUfCnxy+EOgPHqv2IXFjfjUru5jaO+tjGzhJJnjIaOU9uM8c18C/Fu/svGX/BZb4e6doMyXcuhQWsN15R3+XJbWl1dSK2OhVGGR271gZnWf8ABbz/AJJd8NP+wzef+kwr9nfCH/Ip6L/15W3/AKKWvxd/4LczI/wx+GsaHJXWLzP/AIDCv1i+Dnjjwx8T/hn4c8WeB9Xt9Y0i7soBHPbvld6RgOjDqrqeGVgGU8EA1aj3Gkfj7+3bIg/4Kg/s4NnIUeHM4/7DlzX2P/wVRn839iHxxtQ4+0aRyf8AsIwV8Vftnz2eq/8ABU/4BaPpUou7nSR4eN0ikExFdUuLkqw7HySHwexB719o/wDBVG5ab9iXxuETEf2nSOf+4hBVW3sO3Y9V/wCCev8AyZf8Kv8AsFN/6US18CXyf8Kw/wCC0lnMT5Fn8Q9KBPZT5mltGPruuLMfia+9P+CegMf7GXwsd5ODpbcHoP8ASJa/Pj/gp9rMPwa/ax/Z7/aMeJ5bbTn8q68r78lvpV5HPLGD6tHduBUWJPF/2tfBOoftifti/FzQNEkkl074NeDbsWgj+7Lf2aeb5HH8TXU8ie4i54Fe6J8ex4q/4I6al4gkud+r6Ppsfg+4G7nK3UNlGpPcmzljc59TXo//AASQ8Gahr3w8+JP7QXixPM1n4m+IZmeRhnzIrYvI7jPZrm4mBHfYM1+PPxz17VfgFpXxq/Y18uRbCTxrZ6lYjoiWVvHcEEj1mieyYf7p9qL9Sr9T+gv/AIJ4eBJ9B/YY8B6VbP8AZNQ1ezvb/wA7HIe/uZpYn/CJk/Kvyk/YM8bfA39jzx38Q/h9+2Foa+GPGRmt1s77UtMkvUEEPmpJHCyQysiSk7xKg2TLjLfKtfvD4U0fUPgx+z9pOhaXa/aLnwh4YgghgP8AHPp9iFVT06tHg885r8af+Canwj+F/wC1cPiR8ZP2gYIviJ49GqRRyRatIZxDbSxeYsogzsxJJuRcqVVYtkYUZBoo+4/23vHHgD4j/wDBOPxx40+Fl1De+FtStrJrKa3ga3idY9YgjfbG6oy4kVhyo55ruf8AgmQob9hn4ZK3Qxar/wCnW7rkf29fC/hXwH/wT8+IXgvwZpVvoej6db2AtrO0jEUEQfVbaRgiLgDLMWPuTXYf8Exv+TGfhj/1z1T/ANOt3UtWJasfb0Ba0uDBJ9x+hqO/gMcnnp0P6GtWWFJk2OKaIy8Ril57Z9fenfqFyBSLy1wfvf1rJhlktpcjtwRViFms7ho5PuH/ACDU1/b/APLdPx/xphYszRR3kIeM89j/AEqva3Jjb7PccY4BP8qp2ty0D+qnqK07i3S6jEsZ+bHB9azJI5oZLdvPtundamjmhu02sOe4P9KqW14Yz5FxxjjJ7fWpbmzyfNg4frj/AAoArvbz2beZAcr/AJ61chuobpfLkABPY9/pUMF6VPlXQ2kd/wDGpZ7KOb54jtP6GquBWm091O+A59jUUd9cQNsmGcdj1qQXNzat5c43D/Perqy2t4u04J9D1qRWFivYJeM7T6GrlY8+mn70B/A/41SEt3aEKSV9j0oC50tFVrZ5ZI98wAJ6VLJKkS7pDgUDuSUVFHIko3J0+lSZxRYSd9UNZVcbWGR71Rk0+J+YyYz+laNFA7FSKKePhpd49xVllVhtYZHvTqjkkSIbnOBQLYgFsindCSnsOn5GrdMDAruPA96qtdgttgUyH9KaTZLkluXaYy7lxkj6VHGZgMzlR9KTz9xxEhb36D86dg5l1GyQHyPKiOPrUB/0O3z/AMtGrRpOGHqKak+onBbozs/ZYd7f62SmWqAA3MvQdP8AGpru2aYhkPTjFRXeQq28SlgBk4/Stk7/ADOZqzu1otiOINdzb3+6v+cUlxMZ5BFFyAcCrawvHbbE++3Wi1tfJJZiCfajmW4ezbXL33LEUQhQIPxNTUUVg3fVnWlZWRV37rnYOkYyfqajmb9wSvWU4H4//WqdYUQsRnL9TStErFD/AHOgp3Rm4toz7xhGiQL2GaeT5Fj7yf1/+tU81msz79xBpZ7bz9gzgL2rVSVkjJwd2ysT5Fl7yf1/+tSxgwWu4f6yXp+PSprm3eZ48fdHWnsjPcKSPkQfrRzaD5Gnp6FW5YW8KW69T1pc/ZbbP/LST/P6VEB9ovc9h/IUTH7TdiMdF4/xp+TMm/tL0RLF+4tTJ/E/T+lPVTbxBF/1sn+f0qTAlnA/hh/nTEYMXu3+6OF+n/16V7mqjbRf13EkzEq20X+sfqf61KiCMLBH25Y/59aghO1GupOWfpUhDhRCD+8k5Y+n+egqX2BdyJ913JsTiJOpqUnP7i34UdT6U7H/AC72/GPvH0/+vVe4uFhXyIOD3Pp/9eqWuiE7K7f9eQ6S4itR5UQye9QxQzXTeZKTt/z0pba0H+tn4HYVoOyqu+XhfShu2wKLlrPbsMAyvlw/Ivr/AIf409Zo94i3Zaqm+e7OI/3cXr3NXYoY4V2oKzfmbRd/h2HNGrMHPUU+iq81xFAPnPPoKnVltpassVE8scY+dgtZ32i6uG2wjaP896lW1iiG+4bcffpV8ttzL2jfwolF0rnESM/uOlWhyM9KoG7yfLto9/8AKpY47gsHmfGOwocSoyv5lysjUYcEXC/Q1ppIjHAYEj0pWVXUqwyDWRpuU0K3trhuv9aLZ/OiME3304NRLC9nNuXLxPwfan3UbRuLuLqv3h6igZQRnsZyrcjv7j1rdVldQynINU5Y472IMh57H+hqna3D20hguOB/L/61K4lobdZE6vbXP2lB8h6/1rXprAMNpGQaYzPvIRPEJo+SBn6im2EwkjMD87f5VahiMBMa8xnke3tWbcxtaTiZOhPH+FAvMrzRvaz4U9OQa1YZI7yIq689x/UUk8a3duJI+vUf4VjRyvC+5OCKVydi8jyWMvlycxn/ADmrk8AmAngOHHII704GG/g/zkGs9JZbGTy5BlD/AJyKZZchuw/7m4G1+nPQ1FcWJU+bbcH0/wAKsTQRXkYkQ89j/jVNLia0byp1ynY/4UATW99z5dxwfX/Gln09JPnhO0+napnht7tN6nn1HWqJN3Yn+9H+n/1qAIhLd2h2t09D0rQhv4ZOH+Q/pSx3lvMu2T5c9j0qOXTo3+aE7D6dqANFSGGQcinVzjJdWpzyvuOlaVnPcTcyAbR3pXFc0aKKapB6HNMZXktIZO2D6ioUtJojmKXC+mK0KKtTexqpvYYu7Hz4z7VC1tCx3Y2n1HFWCccmokmSQ4j5x37VKb3RKvuhyIUGCxb61JVaW6ih4Y5PoKjjkupTuCCNffrVcrerDlb1ZdqukCrIZckk+tDToh2fef0FPjZyMum38c0WaQWaRQFk7yM0rfe54qT+z0/vGr29c4zRvX1q/aSL9rM//9P98obWOH5vvN6mpmkRSFJ5PQd6q3U7JiKL/WNRDD5XvK/U+la2vrI2tdc0iyzHO1ev8qqvKwbyIPmkPUntTZZm3fZ4OXPU05VEI8iDlz1PpTSsUo23G5S1+VP3kz0eT/y2vH/DtRuS2OyMb5mpSip+9u2y3Ydqou5IskkgxCuxPU/0FNY28B3Od7+/J/8ArVWe7nnby4Btz+dSx2sceGmO5j2p2tuHLbceJbif/VL5aeppwSKJvmzLJ+Z/+tU213+98o9B1/OpVVUGFGBWbl2MnLsRKZWOWAUenU1PSEgDJqp9oMjbYBn1Y9BWdrkWvsXKKpM6QtzmSQ/5/ChgSvmXT4H90dP/AK9XylcpP5gPCDd9On508sFGWOKy5L0/cgGBQlpPMd85x9etacnV6F+ztrLQtvewqcLlz7U+KSZzlo9i+55qt5trajEY3N/nvTA91dHC/IlLlXYfIraL7y5LcxRcMefQUsUrS/8ALMqPU1V221oMv8z09TPccn91H+ppcqtoLlVtCy0qIdpPPoOTU1Zxmhh/dWyb29v8aXyZZBuuWwv90UuTuTydy+CDyOaayK6lWGQarru27LdQg9T/AIU4EQf62XJPrU27EW7C/Z41iaKP5Q1Mkt9/loP9WvUU37ZETtjBkPsKtIxZckEexqrtble8tWUjG8t3lx8idK+af2tv2brP9qz4OXnwpudb/wCEdluby0u7e++zfbPIe2fJ/c+bDnchZfvjGc89K+pqTA61LlcHK58n/sh/sx6Z+yj8Ik+E2naz/wAJDK9/c6je6h9m+x/aJrjag/c+bNt2xRxp985254zgeCftu/sAaX+2N4r8M+KrXxf/AMIhqGg2c1hK407+0PtUBk82If8AHzb+X5TGX+9nf2xz+kLwMITHCeT1J71EkZtY8gb5X4rRWsUrWOb8F+F7LwN4S0Pwfp/72LRLG2sYTjH7u2iWJTjtwtfmd8b/ANgn49eMfip4l+Jnwy/aJ1rwaviK6+0rpdqL23itvlC7RLb3ygjIz/qh1r9VGcWo/vzSVJbW2w+bLzIf0pu27G7bs/JH4P8A/BK+10r4m6b8Xv2ifiVqHxU1nSZIbi3trqOTynlgO5PtMtzNcSzopwRGPLGR825SVP6CftE/s++A/wBpn4YX3wt+IKSrZXMkdxb3NuQLi0uoc+XPEWDLuAZlIIIKsw717vUDyEv5Sde59BWO5jufiZo//BML9pnwBZHwv8Lf2ntY0Pw0jN5VpAL6zSMOcnEUF75YJJ5I25619F/sk/8ABPnwf+zJ4vvvibrXia58d+OtQjli/tG4i8iOAXBzM8UZeaQyynIaZnJIJAAy2f0Yu7kn9zH07n1p8Ucdonmy/ePQVtGNtWaKNldnxJ+2j+xin7X3hjwz4fufF/8AwiK+Hr2W7MgsPt5nEsYj2Y8+DYR1zlvpXzT46/4Jc2+neKL3xN+yz8U9c+EhvyXk0+0lnktt54IilhuIJo48dmMuO2BgD9bVjmvG8yQ7E7f/AFqsKyRfubYb37n/ABqml11YPzPzF/ZW/wCCa2g/Af4lN8b/AIn+Nbn4h+NU8xreaaExQwTTIUkmcyyzSzzbSQrllABPyk4I+0P2ifglo37SHwc8QfB7X7mXS7HXUhxdwqGkgltpknikVTwQHjGQcZXIyM5HtbGKD5528yT/AD0HahHnueR+6j/U1nbQVj8+/wBjr9h7xH+yZr+pXl/8V73xvot1YmztdIlspLS2s2MyzGWNDeXCZOCDiNfvE57V2H7bH7G0H7ZfhLw54dl8S/8ACIXPh2+ku47s2X28yRzReXJF5fnwbckK2dx+7jHOR9pNcwW/yxDc3f8A+uahD3l1935E9elHLoTY8p/Z/wDhBpH7PfwY8KfB7S70X0Phq08lrry/I+0TSSNLNN5W99nmSuzbd7YzjJ618S/tJf8ABNbw5+0Z+0PY/HlfGn9gqq6d/aOmf2Z9q+2vYPgv5/2mHZ5kKpF/qmxtzznaP02FrbwDfO24+9SLOXG22jyPU8ClyroKxYkijmQxyjcrdQa/JL4g/wDBJzwfdePb/wCIPwF+JGs/Ca+1FpJHhsYzNDE0rbmW3MU1rLHET/yz8xgO2BgD9aVV0PmTS/h0FRvewL0Jb6VNn0JPxi8Qf8Eqvjb4v0i68PeLf2rfEOt6Xe7RPaXtld3NvLsYOPMil1dlbDAEZHBANfpb+zH8ET+zj8DfDHwX/tr/AISH/hG1u1+3fZvsnn/abqa6/wBT5s23b5u375zjPGcD2sX0jnEURNSCS9P/ACzA+v8A+ujkfULl6ioIvP8A+WpH4VPUMCpd2/nx8feHSq1nPvU28v3l457j0rUqpNaJKd6/I/qKAMq6tjbtuX7p6U22uzbtg8oeoraUM6GOcZ/kaxbm1aBsjlT0NVcrc05oIryMSIeex/xqjFcTWTeVKMj0/wAKrQXMls2U5B6itkG3v4sf/rFSSKUt7xNw59+4qgRdWJyPmj/T/wCtVeWGezbep47MK0Le+jmGyb5D+hoKsSxz290uxhyex/pVafTT96A/gafcaeD88HB9KjgkvlfyihYD+9/jQSRR3F1bNslBPsf6Gtlf3iAuuO+DUlZ9xdhD5cXzP0qkr7CcktWPurkQjanLn9Kgjg/5eLs/gf8AP6U6ONLVfOuDmQ0xY5r1t8nyx9hWi02Od3b1+4cbqSVvKtlx71NHaKDvmPmN79KtJGkS7UGBUc8ywxlz+FRzdIl8vWRKzKg3McCkLADPr2qjAjNie4OSfuipp5xAMn5pG6Ci3Qrm0uxZJfJ5PzO3QCosLF/pFycydh6ewpI0MI82b5pX6D+lOOyH9/cnLdh6fSmR5sb5c1z80/7uP+7/AI1IjqBstUz79vz70zY8w33J2x/3f8ahlvQP3dsPbP8AgKrfQm6Wr/4JaZEUb7hs/Xp+Apn2p5Tttkz7npUMdoznzbo/hV4A/djG0ev/ANap0KV35EPkgfNcMZD6dvwFTAu33V2j3/wp4RR9fXvT6hs0UbBRVZ51VvLUb39B/WkYhB5lw34Dp/8AXp2K5kWqjaRVO3qfQVCDLNz/AKqP9T/hVaS7iiGyAZPr2/8Ar00iHNLVmiDxkjFQSXUEfBbJ9uaoLHdXXLnC/p+VWAltajLnLe/X8qrliRzt7EqTySnKR4T1JxU7ypEMyHFZ5up5zst1wPWnrbxRDzblt59/880W7iUn0LEdwJT+7UkevapmdUGXOKprNJP8sA2p/eP9KVnhtuXJkf8AM/8A1qmxSloXQQwyKXPaqIF1Ny37pfQdakQJENsK7iep/wATSsWpXLVQpDEjb1XBNIFZfnlk/DoKja7gBwG3H0FGvQG11FaFhEyRNy5zk+9Q3EL7I4Ih8ueTVyNy4yVK/WpKd2hOKaK+1cj+7H/OmMzKML/rZP0//VVuovLG9pB94jHNK42uxRmmFunkRffPU/5702G3WJfPn+92H+e9SRW7RFp5/nI5GOaeDgfabnj+6vp/9etL9Ec/Ld3kPdxGPOm49F/z3qtHE92/nT8J2FOiia5fz7gcfwrWlSvbY2S5t9hoAUYHAFOqKR9g4GSegqtcXBgTGcuf0qErlOSQl1diL93Hy/8AKqtvaPL+9lJwefc0ttAGBuJ/u9ee/vT3kmu28uHiMdTWi00Rzv3vel9w6S6jiHlW6gn9P/r0iWrynzbsn6VIqQWmP4pD09akYDb5l0Rj+72H+NF7bFct/iEVxjZapn36D/69DQj71zJu9ugpguHnOy3GAP4j2pzPBb/NId8n6/8A1qkrRkoZ8bYo8D1PA/LrUgPlrmVh/IVnfabm4O2BMD1/+vUi2a58y4fP+fWlbuClf4S2txC7bEcE1PVFZol/d2y7z7dPxNSBJ25kfaPRf8TSsaKQ6O3SJyY8gHqO1E9vHcLhxz2NNe6gj6tk+3NVzf7jtijLUWBzSLVvE0KeWW3AdParFUBLdt92IL9amX7Vu/ebce2aLApXLNRyxrKhjfoakoqSzEglaznNvL909/60+/tM5miH+8P61ozW8U67ZB+PemQLLD+7c717Hv8AjQBz0MzwPvT/APXW8rQX8OD+I7g1SvrHGZYRx3FZscjxOHjODWV7bgXCtxYSZHKn8jWlHNBeJsYc+h/pTILqK6XypANx6g9/pVO6snhPmwZIH5iq9AHSWk9q3m2pLD07/wD16sQX8Uo2T/If0NV7bUiPkuOff/Grc1pDdL5kZALdx0NHoAyfTkk+aE7D6dqog3tke+z8xToxfWziNQSPTqK2k3lB5gAPcDmjcCK2maePeybf60+WWO3j549AKZcXMcAweW7CqcUTTn7Tcn5R0H+e1apdzOUuiFjimu28yYkR9hWkkaRLtQYFVIbkzSHaMRqOvvULNJeSlEbEQ61aTenQ2pq6tfQvrIjkhTnHU9qjZgRuY4jH6/8A1qb8ip6Rr+v+f1qsN14+9vlhX9aEupoo9R/z3fJ+WEfrSGR5f3NqNqDgtTyPtA/uwr+uP6Ugkeb91bDbGOC3+FWbAqW9sf8AnpL+ZqXbLIMzHy19B/U1A0tvaAqnzSd//r1Aq3N4cscJ+lO19WKzfvMtG5gh/dwLvPoKBHPKN07eWvoKfFHHD8sQ3N3NS+VuOZTu9u35VDaWxDaWxEhRBiCMuPUf4nrT/Ml/54n8xVmip5jPmP/U/euBGX/SJeZJOgpJ5jCPKQ5lbqamaVVU3DdOi/596rWy9byf8K6Vr7zOta+8yWJPsyBRzLJSSP5I8qL5pX6mleQwIZX/ANY/QelMjAtYjcTcyPRvqw31YvyWSbm+eV6qxwzXb73PHr/hT4YWuWM85+Wri5m+WP5Yh39fp7VTdvUtvl9R0YVB5duv1b/PWp1jC89T6mnKqoNqjAFUri6KnyYeZDx9KwV5OyOVXk7IlluVQ+Wg3yHsKa8ggXfOcsegFQjZZR7m5leo4ofMJubs8ehrRRRtyrfoOVZrs75Tti9KVpyxEFoMe9QyzyXT+TFwv+etSySJZp5UfLnqauxdun4Di0VkuPvSGqQ8+8k9f5Co445LiTaOSepq9NMlqnkwff7mrtbbc0tbRbjv9Gsxz80n+fyqpJcz3DbB0PYVCiPM+1eSa0iYrJMD5pDRa3myWlHzYyK2SFfNuT+FNe6lmPl2wwP1/wDrVAqzXkvJ/wABVt5YrRfLi5buaTWuurE1rrqxVhhtR5k53PTN1xeHC/JHTY7dpP390cD3qwGef5Yv3cQ79z9KlvqS31HII4f3UC7n7n/E0SNFD8053t2H+AqtLdJEvlWw/GmxWckh8yc4H61PL1kLl6yGvd3Ex2Rcew61JFZf8tLg49v8TVqMxp+7tkz6nt+dJIYo/nuG3HsP8BQ5dIg5dIqwK4A2WseR69B/9eneXO/Msm0ei/41Tk1BzxEMfWo1hubjls496OR7vQOR7vQu77WI7i2T65Jo+3RE4UEmmx2ES8yfOf0q6iIgwgA+lS3H1M24+o2KRnGShT61LRTWIUZJwKwMmN8qPzPM2/N61JVdJ0lbamTjqe1JJMd3lRDc/wCg+tXZ7MdnsyzRVVpWjAj+/Ie1MLi3G+aQlm7f4Cnyj5S7SEA9az0NxdfNnyo/bqae85z5Nt8zevUCjlDlLpAIwelMSNEzsULn0qsZRbLiRjI57U6FrlzukARfTvSs7CsJ9jhL7zk/Wi4imkXbEQF9KeJ1L+XGN5746CpTIisFJ5PaqvId2UIrRIl8yfkjt1qOS8lkPlwDH8616btXO7HPrRz9WLm7malqiDzbptx9DQ927ny7VfxqzLaLLJvdiR6VYRFjG1BgU+ZbsVzMWylkO6d/6mrkdrBGOFz9eafLMkC5bv0ApFlYJ5k2EHpUuTZJY4FICD0rP+a6+d/lhHb1ppke4PlW3yIOpo5QLZuIw3lr8z+gp0syQjc5/Cqbyw2a+XENzd//AK9QwwSXLedOfk/nT5VuBowTLMm9QR9anqg2bj91F8sQ6kd/YVIspLiKEbgvUmpaAt0xlV1KsMg03zU3+WDk1JkZxUAYkunSAkxYYdvWq4hu4H3qhBHpXSUUFXKFvcrcAxTJtbuD0NVZtNYtmAgA9j2rYJAGTwKarKw3Kcj1oC5BbwvAu1pC/wDSrVZkt4XcQ23J6ZpbiY28flqcyHqarlMuZDby6x+6jP1P9KIYkto/Pm+92FMtIFVftM3AHT/GrccbSP58w/3V9P8A69Xe2hmk2+ZkUcDzP59x+C1dkkSJdznAqSsU7r254+4P5VO+5T93bcuRSNMTK3yRL09/rUSYuZTNJ/qk6Zptw/mMLSHp0NXEVVxEv3U6/X/PNVsRvoJLMIU81+p6Cq0C9bu46np/n+VRqDeXBY/6tf8AP61d3Bv3rfcTp7+/+FLbQe7uRvIsK+fL95uAPT2/xpiDaPtd117D0pkQM7m6m4VOgqImS9mwvEY/SqsS31GO815JtToO3YfWr0UMVthVG6Q/5/AUqkJ+4tx93qfT/E1YSMRjA/EnqaTZUYa3e4Kh+9Jyf0FJLMkI3OfoKZcXCQLlup6Cq0SHm8uevYelQl1LbtoicOdvmS/u19P8f8Kr+bLdtsh+SPuaaBJevluIhRPdKg8m3+mR/SrsZt99iRpI7UeTAN8h/wA80qoIh9oujl/5fSmIiWcfnS8yGs+SSSeTLck9BTSuS3bcmluJbpvLToegFW47eG3XzLggmhQljHufmRqzZJHmfLHJPSq30RD01lqy3NfSP8sfyD9aWGzZ/wB5OcDrjvUkUMdqnnT9ew/z3qrLPJdOEXoegoXZDa6zLUl2kY8q2X2ojtyf312fwNOVIbJN8nMh/wA8VCqTXrbnOIxU+hXr9xK1xJMfKtRgetSJHFbkFvnlP50qsF/cWo5Xqew/xNNklitQf45D1/8Ar0vJF+bJmIC77hgB6dv/AK9Upb9j8kAx7/8A1qjWG4uzvc4Hqf6CrscdvB8qDfJ+v/1qWi3FrLbQqx2s053zkge/WraeVD8kC7m9v6mnuBjdO2F9O3/16qSahGg2wJn9BTu2OyiXMXL/AHiIx7cmmnyYz+8kyR6n+lZ4a7uvu5x+QqxFp6jmU59hRa24Jt7Ima9gAwCW+g/xqWKYydY2X609Yo4/uKBUtRoaJPqwqN40fG8ZxUlV/tMW/wAtTuf0FSU7dSxRUMsqxDnknoB1NMEjRrunwCegH8vc0WC5ZoqmGcHzp28tB0X/ABqL7RNcNttxtUdWNVYnmNGiqbSJbrsyZHPQZyT/AIUqs8amW5fGew6D/GixVycRxht4UZ9ahltY5zufOfY1Ek08zbo0Cx+rd6nknSM7fvOew60ak6NA0bLHst8LVKKxYuWnO4e3etIuFXc/FOHIouDgnuZct8sP7qJMY9Rj9KSO2ln/AHtyxA9P89K1GAPUZqGeATgKWKj0FFyHHuU3vIox5Vsm8+3T/wCvUYgvLj5pm2D0/wDrVoxQRQjEa49+9SMyopZjgCnfsHLf4itHZQJyRvPvVlVVRhRge1QxTNN8wXavqe9RtK9wxitzgDq3+FQWrLYu1BLPHEQHPJ7VVaRYf9HtRl+9G2K1HmzHfKf88UA5F3eoTe3yj3qGG5SdiqA8d6zcz3smOij8hV35YR9nth83c+nuaBKVy/RVLcLdfJjzJIeef5mpzKEAD/ePYUF3JqybnTt7boMDPUGtbOKKTVxnMtaXUfPln8Of5VoW146kRXQIJ6Ej+da1FTy22AzLqwWX54flb07GnWlnJAdzSfgOlXldGJCkHHpVS5u1h+ROX/lVWE3YvVUurkQLgfePSog7QxGec5Y9BVOCJ7uUySdO5/pTM5N7IdbQ+aTPP90everBD3jf3YR+tSFftB2j5YV9O+P6VcACgAcCquNR6FS4RhCIYRjccfhTljVF8pOFH3jTXnP2gxJztH6moLpyii1i5J6/jWkbvQ6oarlQxma9m8tOI0q1gSfu14ij6+/tTVj8pBbx/efkn0/z2qKYmVxaQcKOtXvsa76IUlrt/LTiJOvvUc1yFHkW/AHGRTriQRKLaD8adFClsokkGZD0AqtFqx6LV/IjgtFUebccD0/xq8A8n+wvp3P+FCIzHzJuvYdh/wDXqdmVFLMcAVhKVzGU22Hyxr6AVVEzznbCMAdWP9KrFnvZNi8RDrRNN0trYe3FaKHfctQ77kkl4kJ2J+8buaj/ALSP/POnhLezUCXljS/arOnZFWXc/9X95Z83FwLdPur/AJNW/lZ8dI4f5/8A1qrWymKJrg8s/A/z9aWcFI1tI+WfrXS10R2ta8q/ruEX+kTG4k/1cf3aYA19PubiNKmmikES20A47mpvs5EAgQ4z1NHMlqTzJajRi4O1eIV4/wB7/wCtVwAAYFNRBGoRegp9YN3OeTvsU7qZ0XZEpZz6dqhtbdolMzjMh6CtKmO6L94gfWrUtOVFKenKihHaySSmW4/Knz280zcuAg6CrKTRSHajgmmvdQxv5bHmnzTuXzSvsRwW3kRkKfnPeqrWEjHcZASa0JZUhAZ+h4qQsAQD3pKUlqSpzWpVS3aCIrDjzD3NUDZXJOThs981t1Gzohw7AZ9aam0Eak1sUmAs4sRKXY98Vmokk8m0ck9TXR0Y70KpYqNW3TUyZpVtk+zwfe7miGBIE+0XHXsKvC1hWTzAvNRNbNLNvlOVHQVfMtiudWsRBXuT5s3yxDkCo5JpLhvItxhaWUz3UnlKpRR609nWH/R7YZc9TVlAFgsxlvmen7HmHmXJ2R/3f8aYFitP3kx3ytVN5J7t9o/LtSSvr+I0r6/iTzXoA8u2GAO9QxW0053twD3NXoLJI8NJ87fpV+pc1HSJLqKOkCrDawxcgZPqatUVRe6LSeTAMn17VjrI50nJl6vkr4pftGav8JfinpPhPxJosH/CM6uYympiVg6IcLKWTGMxMQWAP3SD1OK+o7id1xbxnMh6mvBf2i/hNbfFH4aXejW8YfXLD/S9Pbv58YOY8+kq5X0zgnpXRSir+/1JqU5ct47n0C90kaBiQxIyMV8m+BP2gtY+KXxl1PwH4W0iGbw3o5kM+pmVv9XH8mVUDad8vCc8rluxFfLGn/tP3Nh+znc+EbieRPGlqRo8WciQWhQj7Qc87o4wYvUNtJ619f8A7MPwmf4ZfDi3tryLy9a1rZeagSPnQkfuoT/1yU8j+8W9a6PZKCbe5lCp7SSVJ+b/AMjK+KH7ROqfCf4oaR4Q1/R4Y/C2sGPy9UWR96I2FlJTGMxMctg/dIPU19UrIgAhtMMTyW6j614N+0Z8KLf4r/Di70DT4g+tafm709u/noOY8+kq5X0Bwe1fFmm/tTXOl/s33PgySSSPxrbt/Y8ZORILQqR55zzujjBi9Q21u9SqfNFcq/ruKVX2Ump7PVH1B4H/AGitU+IPxh1XwD4O0aG48P6QZPP1VpWJKR/JvRQNp8yXiMZ5X5uxFR/Ev9oDVvhN8U9G8NeL9Ei/4RjWvLaPUxI+9EJ2SFlxjMTEFhn7hB6nFdD+y/8ACFPhX8N7eXVovL1rWdl5e5HzISP3UR/65KeR/eLVq/tEfCk/GL4c3unW6AappwN3ppPUzIOY8+kq5X0zg9qd4KVuhf7z2fNfXf8A4B7uskt7gxHbD6+tfLXgT9obVviN8YtU+HvgnRYJ/D2kGTz9VeViSsfyb1UDafMl4Tnlfm7Yr5Zsf2qL+w/Zwn8FSyyR+MrQ/wBjxk5Ev2QggTeoaOMGL1DbSetfX/7M3wuX4SfDWCC9g2eINc23V+SPmjJH7qE/9clPI/vFqbp8qd16f5kKq6soxhtuz6QxDaDzJDukP51x3jnVvE+neEtU1vwtp6ajf2MJmitHYp5/l8sgIBO4rnbxycCutitSx8+5P4VcdlRd8vyqO1cl7S7nY+y3Pnz9nj45Wfxu8NXd6LRNL1TS5vLurZH8zCScxSKSAcMARz3U+1Wvj38bdO+CXhKPWo7dNR1S+mENrbM+0SEcyOxGTtRfTuQO9fIXjWCX9mf9oq08d6dG0Pg3xi7rcqoOyMSMDOuBx+6kxMoHY7R3qTSrVf2p/wBpOTUD/pPgbwVjbnmOcRv8g9P9IlBb3iXHUV1eyjfnex5jqSUeR/Ft/wAE+xbLxd8StR+D/wDwnz6FCviCS0N9FpQkkGY/vCPfjd5hi5Ax947fes39nn452fxw8NXl/JaJp2q6ZN5VxbLIZAsb8xSAnBw2CPqp9q+h+lfmR4yjb9l/9pC08d6apTwb4vZxdog+SMSMPtCAD/nk+JkA7HaO9YQSqJxtr0NakpRtLp1/zPr34/fGux+CPg+LXPs632pX06wWdqz7BJjmRiRkhVXuB1KjvXU+DvE3jPxB8N7XxXq+lwadruoWr3MFiZG8tS4LQLK5G4Fhgtx8ucYyK+G7JR+1X+0pLqkv+keBfBO3bnmOdI3O0eh+0SgsfWJcdQK/SCLN1MZpOI4+lEoKKSe4Um5ty6HzL8BP2hT8V9Z17w54p0tdB8Q6Ic/Zg5bfGj+XJwwBDRSYDD3HvXp3xa+JNh8MfAmpeOdVQSi1AjtrcnZ9ouZOI48+meWPZQT2r41/aS0LUfhD8WdF/aG8IQH7Hc3CRalEvAMuMNv7ATxAjPZhnqRWX8R/Ea/tY/Gfw38N/B07P4Q0iJLy7nXjIdVaaQjsVUiFc9HJ7Gt/ZptS6fkYurKKcH8R9m/BPx74q+K3gqDxf4j0iLRIb12NrFE7uXgXgSHcBjcc4HoAe4r1ua6WNfJt+AO9U4oLLStPt9G0mFbe0s4khijThEjjGFUewAxU9nbiT97J/qx6965nbc7Emkkz49+Ifxo+OWi+ONR8M+AvhzLrFlp7IFvZILmSCXfGrk7kEcYwTj7x6VzOn/tg+K/DviCy0P42+CZvDdrekD7TGsqYGQC/lyj541z821iR6E8V93h2vpdi8RJ196+C/wBvPXvDs3gnQvDkcsMmsLqSzRxAgzJAIZVkOOoUuUHOMke1dEGptRaOOqpQTmpH3eb62lszepOiWCR+aZsjZ5YGchum3HOfSvha+/a78beLtavdG+BngSbXbOyO03ciStuGSA5jiAEatj5dzZPoDxX0RJo/iCX9nA+HkRhq48KfZimPnN39h2bfrv4+tfPv7CmsaPL8OtW8N2ksUerpqUk88WQJTC8UQjbHXbwR7HPrUQiknJq9ipybmop2uGiftfeJ/DniOz8M/GjwVJ4XS+YIl2PMREycGQxyj5oxn5mVjj0Nfd6LDFGbqRwRjcXJ4A65z6V+fv7eV9oDeF/DPhuCRJtebUDMkS4acQeUVfIHIDMY8euOM44+ifiveap4f/Z01u2n/wCP+Hw+YJz3DtAIpPx5NE0pKLjpcISaclJ3seKa5+2F4g8Q+Jbvw38DvBk/isWWRJdlZHQ4ONwjiGRGezMwz6Cs60/a/wDGfhTWbTTPjd4GufD1ndHH2qBJU6HkiOXPmKP4tsmQOx6V1n7FOm2lj8F0ubRALrVb+4kmfHJEZEagn0AX8Mn1rq/2wdKsb74C64Jolkl02S1uYmIyY5PtEcZI9CUkYfQ1doKXJYy/eOn7TmPpK0vLbWreC9sZVmspkWWOSM5WRHGQQR2I5FfEvjz9sORvFEvgj4PeGpPFl1buUaZfMaOQx/e8qKJS7KD/AB5A44yMGrvgnxjf6f8AsTrrEDmO7ttH1CCOQHBQpNNBGQfUAA15t+y743+Efwh+GC69401aDTtT8QXM8pGySa4eG3byox5cSuwQOGIJABJPNKNO121ewTqN2Sdr6nr/AMLviz+0HrHjXTtK8efD0aPot753m3iwXCeVsiZ48lmYDcwC8gda+tLeNruUyydByff2ryTwh8d/hX8TtTXSPCHiCK4vCPlt5Ukt5W9dqyqm7HfbnivbFRVC20fQfeP+fWsaj12sbU1frdCqPOYOf9Wv3R6+/wDhU7yBELt0AzTwMcCqVyfMmjth0+830Fcp07EU0jx2vzn95L1/z9KRT9ltd38b1HMftN4sP8Kdf6/4Uy+cy3Kwr24/E1r5GLfUms02RtO3U8D/AD9adeO0cYhXl5OtWgoEkcS9Ixk/yFUof3908x+5H0/pU36jtZcqJ0i8uNLZfvNyx9u/+FRTfv5Rapwidce1SGQJC90esn3fp2/xpIo5ILclRmV6YW6EVyxmcWkPAHX/AD7VOFCYtbfjH3m9P/rmltbdooyzfff9Knhh8lTk7iTkmk2Uo9WSIixrsQYFI7+WhbGfQCpKKg0MiCCWaXz7kdOx/wA9KmmgmuZBv+WIdu9aBIAyeBUXnwEgCQEn3qrmfKrWZFNC7RiKAiNaitrFYH8xzvPb2q1LPHCAZDjNKJVMfmjkYzReQ+VXKU9nJO+9pPoMdKfb2a25Lk727VaWVHj80dOtS0XkCgr3Maa0uZXMjYP0NT29sLZPMdd0noOcVfZlRcscD1NKpDDIORRcSgk7nPTvNPL8457CryKlhFvbmV61agktoZW3OuTVcxKp216mbBbtcMbi4Pyfz/8ArVOXe5PlQfJEOCf8KnngaYBA21O4FQ3DPGBb26EZ4yKVyeWwyWZYR9mtR8/+f1pI7WKEeddNuPv/AJ5p4Edim5vmkNKsRP7+8P0HYUXHbuODT3H3P3UXr3NRyXMVsvlwDc3+etQTXbzny4eAfzNTQWA+9N+VHqF7/CUhHc3jZPPuegrRisIY+X+c+/SrygKMAYFOpOQ400tWFFVLi6WEhANzHtTZLhoId8uPMPQUWNeZEs1xHDgNyT0A60vmlY98+F9qpQoIVN3c/fPSoEWS9l3scRj/ADgUWI5pErSz3jeXF8kfc1LujtQILdd0h/zzUclwI8W1oMnpkU/5bJNzfNK9UA/K2/zP88z/AOePalJWAefcHLnoPT2FMGLdGuZ+ZX7f0qpFHJeSmST7o6/4Cgl9kSpHLev5kpxGOgqYzEnyLReB37Ch2a5byIOIx1P9Ka8yxf6LaDL/AMqzC1iTEVp/00lf8zSiIf6+8IyO3YVH8lmvmSnfK1QpFLet5kpxH2/+tQHkTG4luG8u3GB3arEUKwDCcsepNPUIiYT5UHf/AD/OqUl3JK3lWo/GgvbVk8s0UHMh3P8A5/Kow11c8r+6j9e9OgskT55fnf8ASr9AWb3IkjEa7ck/U08kKCTwBVeS4RXES/NIe3+NMmzM4tx06ufb0/Ggq/YlSYOC44Qdz3qspN2/mPxCvQHvUUrfaJltIuI1649qS4k3EWVv9D/n+dBDY9pXu5PKh4jHU0ryHP2S069z6Uj/AOjotpBzI3U0juljF5cfMh6mgPUV5IrFNifNIetVIIZLpy8hOO5qOCF7qXBPuTV6aXkWdr9Dj/P51Vyd9yXfk/ZrXjHVvT/69KWEZ+zWwy/c+nuab/qFFrbcyHqfT3pyr5I8iH5pG5Zj29z/AEFSaWHKvlfuovmkPUn+Z/wpkkkdscn95K35/wD1qimuBB+4g+aQ9T7/AONT21qIv3knMh7+lAvJCxwO7ebcnJ7L2FXMjOKr3M4t0yBljwBVV5DbRGSU5mk/T/8AVRcrYmnlYuLeA/Oep9BTJGbItICc/wATHnAqNc2sPmNzNLQzCyh9ZX70EDZp0tU8iDr3P+e9Q2kIcmeX7q+veqkUbzyhB1Pert5KsaraxdB1pXJ8yOR2vbgKvTt7D1rQ2KB9mi4UfeP9PqaZBEbaIDH72T/P6VdjQRrtH5+tMtIcFCgBeAKpiXmWdj8i8L/WpLqXy4vl+83A/GqN2fJgjtk/H/P1pXKYWfyrJdyc061GS95N2pbhfLiitV6n/P8AOrHljdHbj7kYyf6VvHSJ0Q0gRySGCIyN/rZf0/8A1Uwf6Hb7j/rHpYx9quTKfuR9KURST3HmyjEa9AavbRmui0f9eQyFFgT7TLyx6D61cijOfNl5kP6e1BgLTCVzkL0FWaylK5jKdwrIuDLdSeWgPljv2+ta9FKMrakRly6lF4pI4hFbjr1NLDbGCMlcGQ9zU7TQpwzgY96cJEKeYDkVXM7Fc07WM42MrOXeQEmj7A/98VeiuYpSQh6VNuX1queS0NOeof/W/fcQoAg/559KftXO7HPrUDT7JliYcN0NQTTyQTqWP7s1ootmii2aFQG4iEnlFvmqCceVIt0nTo30qO+h3KJ17dfpRGK6lxina5NdXL2+MLkHvRO7tb+bC2O/4U0Yu7XB+9/WobGQ/Pbv/D/k1pbS/VF8tle2qJoH+0QbWPzDv/I0sifarcg8MP5iqak2l1tP3W/lWi37uVW/hfg/XtRJWd0KSs7oxIZDDKHPbrV+/jDIJ17dfpUN9D5cnmL0f+dWbNxNAYn7cfhWkntNG0ntUQsRF1a7D1HH+FOhJmt9n8acfiOlVLZjb3Jifvx/hVo/6Pdbv4Jf51LXRepnJWbS9Sx5gKCX8/8APtSXEInj29+1A+SUoej8j696bG2x/IbtyvuP/rVltqjHbVEVrLvUwS/fTiofOltJtkpLRnoTU1zC2RcQ/fXr704GO+gweD/I1ppv0NdPi6FkuNm9RuHXioo7qCThWwfQ8VSgme2k8ibpS3dr/wAt4vxH9aXIr2YuRJ2Zq1XSFI9zRDDN61WtLreBHIfm7H1q3JKIuXHy+oqGmnYzcXF8pm/Y7iSUmZuPWtOKJIl2oMU5HVxuQ5FPolJvRhKbejCq1xN5IUKMu/AFPbeXCgfL1J/pVUMC73T/AHU4Wpiu4Rj1Y25maKPys5dup9KjGLOHcf8AWyfpTLZfOle4m6LzTUDXdzubp/Sum1tDpslo/mT26iCM3M3U9KxNY1jTfD+jX/inxBMLew06F55nPZIxk/X0A7nitxx9qm2D/VR9a+Av2u/Huq+MNf0X9njwK3m3urTwNehTxlzmGJ/RR/rX9AFPTNOCcnY561Xki5dT421KfxHq/iK//aSttAiGgR+IUkMBH7vzC/nBWA6g4AduhdvU4r9ovC/i3RvFnhjTPEnhyXz7PVYFnjbuA45B9GU5BHYgiuKtPhF4S0r4Qr8HTEJdNkszbTPgK7yP8zT+z+b+8HofpXyZ+yj4t1H4b+PNc/Z88bybJbWaWXTmfoZEG51TP8MseJox9e5rpk1ON0tjipRdFrm2f5n3nrmt6X4Q0C+8Q63MILeyheeaQ/wpGMn6/TueK/FS9k8Tapr95+0tDoER8PxeIY5DCw/dmUt521wOoOAHbpvb1OK+wf2uPHer+MvEWjfADwWfN1DV5oHvQp4G85hic9gP9c/oAp6Zr6o074Q+F4fhSnwaSPfo4szbSyYAd5G+Zp/+unm/vB6HHpRH3Fd7v8grQdabiun5nc+FPEumePPD+neKtFk8zS9QhWaI98MOQfRlOVYdiCKseI9f0zQdIvda1SYW2m6ZC9xPKegjjGSff2Hc18G/st+L9Z+G3jfX/wBnDxnJsmt7iV9PJ6GQDfIiZ/hmjxMg/wB7u1Xv2uvG+p+JNZ0X9nfwSfP1HV5oH1Dae7EGCFj2A/1z+gCn1rP2fv2NViEqXP12t5nxrfzeI9T8Q3n7SFroMQ0CLxAknkEfuzIX84Kw7jAAduhdvU4r9pvB3iHRvFnhnTPF+jS/aLPVYVmh9Rv6qR2ZTkMOxBFcRpnwb8Jab8JF+El1F5umyWZtHOBveR+TMPR/N+cHscV8ofsq+MNV+GPjvXv2d/G5xc208kmnE9DIBvkVM/wzJiZPx7tWlSXtE+XoY006MkntL8z9DpJBEvmzct2X0/z61ElvJcP5tzwOy1LDAxbzp+WPQelYHjTxZpHgTwrqni7XpPLstLhaaT1bHCov+07EKo9SK8+9tI7nY5cp8Vftq+KYtcTw58EfD9nHqGv6zdxXG0Dc0AJMUQH91pS5yeyg54INZ/7GuvjwN4g8U/AfxTbR2WvWt3JcxyDrcGMCORM8bgABJH6qWPQVB+yp4Y1f4mePvEP7SHjePfJJNJDpynlVkI2sY8/wwxYhjPue4qf9rXwhrXhTxBon7RngseTf6RPBFelRxwcQyPjqp/1MnqCo6Zrusrey/q55NpP9/wD1Y+/b+YlhAn418Gftn+JY9Yg8OfBDw/aLqPiHWbuK5Ixl4ckxRAHs0hY5PZQc8NmvpjSfi94UvfhUfjNPLs0mO0N06ZBZJR8hg/66eb+7HqcV8q/sreGdW+Jfj7xB+0j43j3yyzSQ6cp5VZGG1jHn+GGLEMZ9z3FRBcur6fmddaXMlTh1/IZ+x9rz+Cde8UfAXxLbR2WvW95JcK463BjAjkj3/wAQUASJ6qWPQV+g1yRFGlpF1PWvgL9rLwbrXhDXtD/aM8GDytQ0m4iiviF4ODiGV8dVP+pf1BUV9g+BfiF4e8ZeBbf4mR3C2+mTWxuJmc8W/lg+cjn/AKZEEH6ZpVVe01/TKovkvSl0/I8A/bK8d6X4X+Fx8DCFL3V/FTJFFERvMccLKzTY9QQqp7nI6Gvn79mG71L4G/FvUvhX49sI7HUfEtvamGc8lJNhljiD9MSBipx/y1UDrW38Jbe8/aQ/aB1T4xa/E/8AwjfhaRBp8L9N6E/ZY8eo5nkx0bHY16X+2B8NrvxH4Xt/iX4fDJrvhM+c8kXEhtAd5II5zC3zj0G6to2X7t9d/U5GnNusun5dT7Mt4DO+3sOpqxcyGZhawdBxXjvwN+Ktp8VPhpp3iGIhdSQfZ9RQf8s7mMDecdg4IZfQHHUV7LCotITO4+dugrildPU9BSUlzI8/+Kvw8tPif4Ku/AE17Jp8d60UjzwgF08qQSdD64xX5xfFP9nHWv2dobT4qeE9Zh1230q5i82K9s428ppDhHIcurDdgZwrKSCOeR9ra7+1N8IPB/iTUvCXiLULiy1TTpfJnZrWSSPfjPBiDEjn0r5q/aQ/aQ8EfEXwI/ww+GRuNdv9cnt/NlW3ljTEUglCIsgWRnaRFAAXGM854rqpe0TStocNf2TTd9T6oT41Wt18CF+L/wBkCgaabprcHj7Sn7sxA9dvnDbnrjmviT4U/s26p+0PZ3fxc8XavHoUOrXMvkw6faRp5nlttaTAKoo3gjozMQSTnk/XMPwY1mH9lh/hT5a/22+ln5N/H2sv9p8vf0/1vGen4V4F+zT+0t4E+HHgSP4Z/Ex7jQb3Q57hY3kt5ZEKSymUo4jVpFkWR2BBXGMc5yARbUX7Pe5M7OcVV2t+JwPxL+BGs/st3ekfFzwnqcHiG2s7yNJItQtIyY5HyVfksDnGNy7XU4IPcfZHxW8RW3iz9mHXPF8ClE1vREulU9VEyq20/TOD9K+Xv2mP2gvCnxe8P2Xww+FgudcutQvIneRYJIw+zO2NEkCyFi5H8IAA/L65g+G93cfAuH4TysiXg0IacWzujFybfaWz/dEvP0ok3aMpbigleUae36nD/sWhYfgTY3L9ru8A/wC/prpP2p1x+zz4unl+/LHaf+lcNfKP7PHx10X4LaZqHwj+LkFxocunXssqymBpAm/AeNljBbqCysqkEH6Z1/2k/wBpHwj8T/CY+F/wrFxrl1rM0CySLbyxjZHIJAsaSBXZi6r/AA4xnmhwl7W9tLgqkVRtfWxpeHv+TE5f+vK9/wDThLR+yd8D/h3rXwyj8b+LNHg1nUdUuZ1i+1DzI4oYX8vAjOVyWBJJGe31950T4RajB+zhL8Km2nU/7HmiwCNv2yYNLjPTHmnGfxr5h/Zr/aD8GfDXwtL8N/ic8+i3Gl3c+12t5ZAEkbLRssYZ1kWTdn5cYPrTu5KXJ3I5VGcefsL+1n8KPDHwt07w18T/AIeWg8P6hHqKQkWvyR+YEM0MoXorKYj0GDnnpX6SeGNRGs+HdL1rvqNrBcn/ALaxh/61+Z37Rvxc0j9orUfDPwr+Ecc2qs14JmmaJ4ozIVMaYDgOFUMxdmUAD8a/TvRdNi0fRrDR4f8AV2MEUC/SJQo/lWFW/LFS3N6NueTjsatZ0LD99dn6D6Crk24xkR9TxUHkL9mEDnAHX+dciOxlSwGPNuH7d/1NR2KGW5Mz9ufxNascKRR+WOR71KAAMCi5KjsVVR9spJwznj2HQUsNssUJiJznrU7yJGu9zgCop5vIUPjK559qkqxNtXjjp0p1UrySWOISxHgHn6UPi5hEkXDDkfUdqAuTSzxQ48w4z0pJZvLh81BuH9KhkVb22469vYiorCXfGYJOqevpQTfoWLeY3MJYfI3T6VDZ3EjO0M5+darQ5s7sxN9x/wDIp16jQzLcR8Z/nQTd7l9R9+BuR2+h/wAKwpo2glKnt0NbhYSRrPHyRz+HcVWvohLEJk52/wAqaY5K6JGAu7PP8WM/iKg06Xgwn6io9Om2uYj0bkfWm3Cm1uxKvRjn/Gn5E32kXbb9zNJbnp95fpViPIDR916fTtVe64Ed3Hzs/UGpmONsw6d/of8ACpNESnbIhB6Hg1n27NazG2k+4fumrbN5Um4/cbg+xoubdZ02ngjoaBvuVrlp7d/PQlkPUGrsMqTIHSqltN5ga3nHzrwc9xVVlewm3rzG3+fzoIvbU0PtUIcxsdrD1qyCCMiqNxCl3EHj+92P9Kp2l00DeRNwP5UDvbc1TBG0omI+YVQura5mlHIKdvatJm2rkDP0pkc0UozGc+3egbSehHb20cA45buatUUyQuF+QZNBWwksixIZG6CqpuGjgM8oxnotLKvmyrB1ReW/oKoSN9tuhGv3E/l3NBDZJbL969ufw/z/ACpYFa6nNxL9xelR3TmaYWsPROPx/wDrVYmG1VsoOrdT7UEWIm330+BxEneluZ8YtLb6cfypLmZbWMW0HXuf896dDGlnF58v3j0FA7DlWOwi3tzI9NgXOb25P0/z/Kq0SSXs+6Tp3+npU1wxuZhbQ/dT8v8AIoGRKr38248IP0FWpWLsLO24A+8fSkmk8hVtLf757/5705ilhDtXmRqq4rDZpBAotbX756/59aX93YRZ+9K3+fypsCC3ja7n5Y9P8+9NhiM7G7uT8nYf57VIxIIDKTc3R+Xrz3/+tV7IYb3+WMdvX6/4VHu80efN8sScgHv7n+lNVHu2EkvEQ+6vr7mgpKww+bfHj5IR+taEcSRLsjGBTwABgUtA0hCQBk1TvJ/Ji+X7z8CoTKbm58hf9WnJ98VBIDd3vl/wJ/TrQJvsPtVEEJuZOp6f596fI5tbfLf62Xr/AJ9qd/x8XYQf6uH+dRKPtl4WPMcdArW2FjAsrYyH/WPRABbwtdScs/T/AD71Gx+2XQQf6tf5f/Xq0R51xz/qoP8A0L/61A7DFP2WI3E3Msn+cVlDzLiTHVnqW6nNxLuH3B0q5Aq2cJuJB87dBQTa4s0i2UIhi++eppYk+xxb2GZZOAKitYzK5u5+g5/H/wCtViNt269m4UfdHtQVYcAbZf79xL/n8hUU8v2SLyozmVuSf609G8pHvJ/vP0HoOwqOzhaWQ3U34UD8iaztfKHmyf6w/pV8nHJpaoXbsxW3j+9J1+lLYNiNGE0rXcn+rj4X/GoIQby5Mr/cT/IovZAgS0i6DrTpSLW0WEffk6/1/wAKVyCWJhPcNcN9yLhf8azLiYzymQ/h9Kv3J+z2iwDq/X+tZ8MfmSJH6mpb6FMv2oFrbNcP1PSorKLzZTcSdF5z706+fdIkEfRe3vVl18uOKyTrJ1+nelcLFiL94xnPfhfp/wDXq1SAADApa1KKLfvb0L2iGfxNU1/0m/z2Q/yq9BDIvmPJw8h+uKW2tooctGc571HvCsVlIlv2J/5Zjj8K0BGoLH+91pQoUHaKghlNxG235GHH0rRJ2KSdiwoCjAGBQzBVLN0FUbWdpN0U3LCnwfunNs3Tqv0q3G25o4Wvcninjmz5Zziq0d4Wn8p129vxqt/x53X+wf5f/Wp99EQVuE/H+lbcqvbubKCvbuPuJpoLgMTmNu1WGIVhMOh4P07GopALq13D7w5/GmWUokjMD/w/yqWtL9hNaX7EV/DtYSr0PBp2ny8mI9+RVpR5iPBJ1HH4djWOC9vN7oa0j7ycWaR96Lgx86GCUqDj0+lReY/96tieEXSK8Z//AFVV+wS+tCqaAqjsf//X/eyYefbLKn3l5/xpXAvLXI+9/WraoqZ28Z7VSX/Rbjy/+WcnT2NbJ9jpTvt0Es5RJGYJO38qlhOwm1k5x09xVW6jaCYTx9Cf1q1KPPiWeH768j/CtHZ69ymk9ejK6A2lxtP+rfvS3UZhlFzH+NWAY72DB6/yNNgbzFNvP95ePqKL9X8w5ur+Y27QTwiVOo5/Ci1kFxCYn6jj8KS2LQSG2k6HlTUEim0uVdfuH/OKEvs/cCV/c+4uFftETRP95ePx9azIJGt5/m47GtZyFxOnIxz9PX8KqX0GR56fj/jRB9H1CEuj6i30XSde3WpCPtdrn+IfzFFo6zwmN+ccfhVe2LW9wYG6H/Io1tbqh62t1Raif7RBycMP5inOvnx/LxIv6Gq8gNrcecPuP1qy52Hz05H8XuPWs33Rm+6HwTeauDw46iqs0Lwv9og/EU+eJsi4g++P1FTQTpOm5evcUbe8g295ETLFeRZHB/lUME7QN9nuOB2NSSQvE/nQfitPZYryLjr+oqrq3kVdWt0/Ihnss/vIeD6U62ud/wC4n+/0571WSaazby5RlP8APSrkkUV3HvQ89j/jVPtLYb2tLbuVLiBrdvNiJC/yq1aXQmGxvvj9abFMyHyLnr2PY1FPZMh8y37dqW+kg392f3mrUMsKTJsfp7U2IvLH++TYajzcxttx5q+vQ1ilqc6Wu4yaF0tvJgGfWosG1twg/wBbLWmCSMkYprKpIYjJHSqU+jLU+jM2dvs0It0+8eprmLXwT4M07V38YR6Dp8euSEn7atrELklxsJMwXfkjg89OK65rRXn81myPSqd6ZWkywIQcCtou/uo2VpWiV1V55sd3PNYep+CfBuqa7BrtzoFhdavbFCl7LaxPcxmP7hEpXeNvbB47V09uBbwNcN1PAp4P2SEyN/rZKty10HJ3Zyj+DPBdprv/AAkVloGnx605Ja+W0iF2S42HMwXzMkcHnkcV1bEWUAUf6x6itIwM3EvRen1qH57u4+v6Ci3R9BqK26dTn28EeDb3WI/FupaFYXOrWxQxXktrE9yhj+6VlKlwVPTB47U+28E+DbfXpPGv9hWEWsyEt9tS1iFyS42k+bt8wkjjryK6x1E0gtk4jj+9/hUJP2u4Ea/6qOocmzKyepKjcG7m/wCAiucm8DeENR1yLxXqmhWFzrUJQxXkltE9xH5f3CsrKXBXtg8V06ATy+Z/yzj4X3PrV2sXK2xnJ9ArC13QdA8Rac2m+JdOttUsSQzQXcKTxEr0OyQMMjtxW7WdLma7SL+FOTUxWpEY33Mu10zSfD+mQaJoVjBpljDny7e2jWKKME7iERAAMk54HXNLrOmabqmlnRNVtIr60uhslgnQSRyL6MrggjPqKvn9/f8AtH/T/wCvSx/v7x5P4Y61WhtayscfJ8PvAcOhf8IhD4b01dJllE0lmLOH7MZeP3hi2bC3A5xnityz0jStBsLbQNAsobCyt+I4LeNIok3Ek4RAAMkknA6nNakBEs8lw3ROlNtcyzSXDdB/n+VF+5PKkUNc0/TdW099D1O1ivrO4TbJBPGJI5F9GVgQR7EVm2vgfwdp2hy+EtP0Kxt9KvSWns4raJLeTONxaIKEOcAcjsK3bYG5uzM3Qc/4Va8zaklz68L9BQ7rRCcTmdO8P+HPDFs2leF9MtNHsjIZDDZwx28ZkIALlIwBnAAzjPFbCWtu9rMbuMSxSqY2RhkMp4IIPBB6VHDGZ5QnryasXj73W3i6LxgetD7Bbojm/C3g3wp4bef/AIRjRLLRo7ghplsraK3EhTO3eIwM4ycZrrEIuJjK3+ri6UyUeTEtpF/rJOtPkUAR2Ufflj7f/XqW76k27HA638LPhn4nuLjWPEvhXTL+ec8yy2kRlf3Mm3cSfrT/AAh8M/AXha6/tHwz4csNKmAKiW3to45MHt5gG4j8a7S7YyzLaxdBx+P/ANatWKNYkEa9BScnaxHKt7Elee+LPhv8O/FbPf8Ainw3p2q3W3aJrm2jeXA6DzCN2B9a7qWQrhE+85wP6n8Kp3GJbqK3H3U5P+fpUrTUGr7nFeHfh54D8DwfaPC3h+x0q6mXaZba3jjlKnsZANxH412FkBFFJct24FR3zmWfy1528VbMLtZJCg5OM5/OqbvuCVtji9X8AeCfGrmfxdoFjrDxrsVru3jldATk7XcEj8CKyfDvw98B+EJzc+FvD1jpU5BXzbe3jjkKHsZANxH1Nen29qY4Gic8v1xUUUdkrhFGW96E3sjJpbjIkaOxOwEvJ6e//wBauH1n4TfDzxbM194t8Nafqd23Hmz28by4HTMmN361391M9vt2AbadKPtFvuiJ9R/hQrrUG09DlvCngHwZ4Hjl/wCEV0Sy0kzDErWtvHEzgdAxUZOPcmuv80NF5kXz+lZ9hPgmBvwq0g8iUp/BJyPr6U5R1dwjK6Vh8EwnQ9j3pE/eI0E3JHB9x61UlDWs3mJ9w/5xVyT94oliPzDp7+1DVtURGTej3RXjlaB/InPH8LVo1UIju48Hgj8waqrLNZt5c3MfY03Hm23BS5d9jRkjDxmM9xiqcP76B7eXh0+U/wBDV1JEkXchyKNi79/fGKwN99SlanfE1tL1Tg/Sq9q5tp2tn6MePr/9erNyphlW7X6N9KZewiWITR8lRn6igglP+jz7v+WcvX2b/wCvVe5jaCUXUQ/3h/n1qaF1u7Yo/Xof8aLaUtutp/vJx9RQaCXcQuYFki5I5H0pYWW7ttr9eh+vrSQ5tZvs7f6tvuH+lNZfstx5o/1UnB9jQBFYyGJ2tpPXj61fTCuYuzcj+oqlfQkEXMfUdf6GrSP9pgDrww/QigS7GRPE1rP8v1WtOZReWwdOvUf4U6eMXUOV+8On19KqafMVYwP36fWgm1iWwkEsLQNzj+Rp9qdjPaSc7OnuDVeZTa3IuF+63X+tWLpCyrcwn5o+fqKBE4AZTbyc8ce4qOCRo3+zynkfdPqKduFxEssfDDkfX0odUu4uOGHT1U0GgXNt5uJI+JE6GmwyrcqYpR8w6iiC4JPkzcSj9adPb+YRJGdki9D/AI0C8yiPMsJOfmiY/wCfxq5NbxXaiRTz2NEci3AMUyYYdVP8xVJ0msX3x8xn/PNBA+CeS0fyLj7nY1LdWvmfv4OH68d6lSWC9j2kfUdxUKtJZNsf5oT0PpQVYZaXh3eVcH6E1rVnXFmk482EgMfyNPtGuAPLnU8dDQNdi4V3AqehqrHai3VzByx6ZpZBcI2+H5x3U/0NTIWZcsuw+nFAzPtYTbiS4uBgilRjDC93J9+ToP5VpMqsNrDI96q3NsLgD5sY/KgVuxRtIvMY3U3Qc8+tVriZriTPboBV69WRIlihU7B1IqvYQh5DK33Y/wCdBFuhYb/RLcRL/rZKDixt8DmR/wDP6U6Nlkdr2X7qcLVOJWvbne/3e/sPSi4Fi2QQRG7m6np/n3qCBWvLgyScgcn+govZvOk8lPurxx61c2G3hS2i/wBZJ/kmlcqwhH22bH/LCP8AU04EXT8cQxfqf8KimIjCWNv1PWpygwlpGeAMsfb/AOvTKEVftb+Y3+qX7o9fetCmgBRgcAU6gAqrLOqwNMv0FQ37uI1ijPMhxUN5x5Vqn+ewpXALf/R7N5z1fp/IUkP+jWZmP35On9P8aW6AMkNmvTvTpwJ7qO2H3U5NMBh/0ax/2pf6/wD1qP8Aj1svR5P6/wD1qSb/AEm9WHqqdf6/4U26JuLtYF6Dj/GpuBLaqbe2MuPnk6D+VNumFtALdW+ZuSf5/nVvaDME/ghGfx7fkKxZ5GuJiw+bJwBQ3YCazh86Te33V5NOmdry4Ea/c6D/ABqa4YWlqsCfffr/AFogAs7Y3D/fbpU+QrEsoDutlDwg5b6U9lE8oiX/AFUXX3PpUSbrW2Mjcyyn9TTblvstqsK/ek6n+dK4xjE31yFX/Vp/n9a2QABgdBVOxg8iEZ+83JqzJIsSF26CrXdgOLAAk9qzYHDebeydOg+lJdSMlsFP+sl6/wCf0qO8Pk20duvfr+H/ANepbCxDaKZ7nzH5x8xp+77TfD0U/oKmsUdIJHwQzdM+wp9lZyQOZJCOmMCklsFinfvvuCB/AMVNpqYLzHsMVLJFZxSEy5LE5/OrUreRDvgUYoUXe7FeJRtreV7jz5kwOvPrV4Qf6QbhmzxgD0psEv2mEgnDdDis+KR7W4KydOh/xqkkiXLY11lR2ZFPKdagiui8zwyDaR0pJh5UguV6dG+nrUN5CRi4j6r1/wAasTb3LAdo5ijnKvyp9/SoHLWj715ic8j0qaN0vIOeD39jRG+/NvOPmH6j1oAlM6YRgchjjNVm/wBGug/8EvX60RWhjkZDzEw/WrE8ImiMZ69j71cWupvCXcpXiNDKLiP/ACasyDz4hNF99eR/hTYSJ4TDL94cH/Gq9q7QTG3k7/z/APr1v080dHTzRYkC3duGXr2+vpSWriaJoJeo4x7U1ybWbf8A8s5OvsafcRlWF1F1HX3FT5fcT0t9xDalrec279D0qKdWtrkSp0PP+Iq3PGLiJZYvvDkUcXttg/K/8jVc32vvKUteZ/MkdhhbhOcdfpVW+h3ATJ260WUpUm3k/D/CraAAmBunb6en4VPwsn4GVbCbKmNu3IrQ3J61gzRNbyFQMjsfaot7+la8qep0ckXrc//Q/fCG8hl4+6ferLxpIu1xkVRmsFb5oTt9u1UhJc2xxyPY9K6ORPWLOnkUtYM2mjV08t+RWfbM1tMbeToehpY9QU8Srj3FWg9vONuQfr1qbOOkkKzjdSWhUmVrSXz4/ut1FTzL5ipcwffXp7j0q0yK6bG5BqlEHtpPKbmNuh9Kad9eoKV9epKQl3EHQ4I6H0NBUXMJjkGGHX2NRyo1tJ58Qyp++P61OcOBPFyf5j0pegeaK1pI0bG2l6jpVlQIz5TfdPT/AAqOWJbhQ6HDjofT2NLFJ5ymKUYkTr/iKHrqEtdSi6NZziRfuN/nFW7mITxLLHyRyPpU+0SKYpB/9f3qvEJLd/KbmM9D6VXNfXqPmvr1QsLrdwGOTqOD/jUdszQObWX/AICaWeJ4ZPtMH4ipXRLuEMvBHT2NGnyDT5P8AH+jvtP+qbp7GmTwOj/aLfr3HrToZfMDQTj5hwfelTfCRG2WjPQ9x7Gp1TFqn/Wo63uVnHo46ileD5vNiO1u/ofrSPaxvIJRlW9qskgDJqG0tYkNpO8SEoJ48Srj2pkNqkBypJpRP5rbYecdT2pjzO7eVBye7dhVa7D97YkklRGAxuY9AOtOaVY03SkJVKSaO1BSP55D1J/rVSOOa7kyT9TVqCerLVNNXexaa8lmbZbL+NTLm3XfcSkn0qB5orUeVAMt3NU0jmuXyOT3Jq1G67I1UU12Rbk1BjxEMe5p8H22Tkvge4oEdvaDdIdzUnmXN2cR/u4/WjToidLe6tC608cQxI/NRJdLKcKjEeuKg8m1t+Zjub/PamvqB6RJj61Chf4UQoJ/Ci+8McgUMOF5AqndWs0z7lYY7Cola9nG5SQPyq1FDOh/eS59uv8AOizj1DWGtyveBo4khQHYOppIAIITO3334FaRkjHVgPxoKxyYY4OORU8+lmLn0szOmb7PB5f/AC0k5NPjjMMKxLxJL/n9BVh7VJJRKxOR27Uqx5nMpYHjAHpRzaBzKxMihFCr0FPopM84rE5yt5xa58leiDJqCJtpuLg+pA/Ci34muJW7Go5j5dkq93//AF1tbodCXQbbZigknPU8Clj/AHNiW7yUXY8uGKAU65TJhth+NVuXvqMf9xYhR1kpX/cWAA6yf1/+tTbw+bcpCO3H5068XzZo7degoE+gQKYbTj70pwPxqO/YLsgToozV4LmdFAwkY/XpWfLbTz3BcpgE9fapW92Zre7JbYC3tmuG6v0pLNAoa6l6DpVi6tpZgiRkBF9akkthJEkSthR196VxXKtsd7SXsvbpS27FY5byTq/SpGezSLyGbIHbmrB2LADEgYAZAoaZLkijp8Zd3uH/AMnvWvVS2uVnBGNpHaqV09zFJjccHoafI27GcpdS6Y9s32iVgABgD0pY44QxuI/mJzzTFKXlvg9f5Gq1pIYZTDJ/Ef1pqOj7kuRegkSVSyDHPIqxWbOGtZvtCfcf7wq+rq6hl5BrOS6oE+jKW9reYo/+rfkH0pt3Bj9/H16n/GrksKzJtb8DVa2kZD9nl6jpWql9pGTX2WPRku4MN17/AFqnaytBKYJeAT+tSMps5/MX/VP1qa5txOokj+9/Oq026Ml3evVEF3CUYXEfrz/jVpGW6iyeCP0PrUVrOJF8iXqOOe9ROr2cvmJyh/zilv7r3C9veWzLeBNGYphhh1/xFU4na0kMcv3T/nNXeJlEkZwex/oaQiO5Qo4wR1HcVKdtHsW43s1uNmibPnwH5/0NLHLFdKY3HPcGoI3ks28ubmM9DUk9ss2JYjtb1Henbv8AeK/VfNFd7aa3bzLckj0qaG+R+JfkP6UyK8aNvKuRgjvU8trDcDepwT3FN9pmce9N/Is/K47EGhUWNdq8CsZo7m1O5Tx6jpViPUD0lT8RUOm94mirLaWgyRDY3AmT/VPwR6VPdQlwLmD76c8dxU63MEoxuHPY1MqKi7U4FZNNbm6aexVVkvrb0P8AI0kEnnK0E4+deCPX3qN4nt5fPgBKN95R/MVLcQs4WeDiROnuPSkMdGNubeTkY4J7j/61UxmxuMH/AFUnf0q5FIlyn9116juppzKs6GGUc9/8RQA5v3beYPunr/jVG9typ+0xcFeT/jUsDPA32ac5H8LevtVtfk47dvb2oAro0d7bc9+vsahs5WjY2svBHSlMD2snm24zGfvKP6VLdW3nhZI+JE6GgCBv9Cn3D/UydfY1YkBjb7RHyP4gO49fqKbDKtzG0My4deGB/nUcLtaP5ExzGfut/SgCWeBLpFkjOGHKsKZb3WW8m4+WQcfWpGVoGMsIyp5Zf6ilmt4rpAWGD2PQ0ASSwrLgnhh0I6ihA7KUlAPv2NPRdqhclsdz1pjTKG8tfmb0H9apK4m0tyBbKFJRKpIx2zVqSRIxueo5JvLwv3nPQComKwDzZjvc9B/hTUSHK2xZV8ruYbR71UlvgDthG81Sd5rt9o/LtVsCGyXLfNIa15Etzn9o5bbdx8azf6y4kwPTpUct+q8RDPuapvJLdPjk+gFW47WKFfMuCPp2ptJayIUpPSG3cZHLeTNmM4H04rQ3eWuZmH16VTNxLKfLtlwPWlFrGn726bcffpUNdzWLttr+RL9sjJ2oGf6Cp2RZEKsMButUmvokG2FMj8hUYuLyX/VD8h/jRyFe1S03LFzatJCIojtA7etQrFJaWrbRukb05qWOG6zueXHt1q6WVfvGs2uxrF31aMOwhzIZn4WP+dXFlCpJeyd+FHt2/Or3ySKRwwPWoZ7VJ0VSSAvTFRaxaKFqNiyX03Oc4rSgRkTL/ebk/WmPCG8tQcLGc49cdKtUIAqrcy7DHGOshx+HerVZ8oL30QxwgJoYDnHmXqKeka7vxPFV4f31/JKekfH9KsA7GuJ/TgfgKqQfubCSXvJ/+qkwH2rCWea5boOB9P8A9VJZnCzXj98/401f3Gmk95P6/wD1qLr9xZR2/d+v8z+tRcBbDhJbqT3/AMTTdPXJkupO3f8AU0soMOnJGOsn9eamETpaxwoDmQjd7A9aYWGTvssix+/Mc/8AfX/1uKradFukMrdI/wCdWL+CaeRVjXKKP51MttIlp5KYDt1zU9QKUam9uy7fcX+XYVO3+l3Yj/5ZxVZhtfJgMQbDN1NNjW3sgUL8mqUWDsRKftV7u/5Zw9PrVZT9svs/wJ/If41p2wt9h8gcHrUUd0ol8l08vtT5e4cyRoVVuIfO2gnCKcn3qC8M6DfGx298dqLOfzUMUnJ9+4qmRza2JikFxIH3bmj9DxTlljaYxkYYeves1g1lPkdP5irl0nmItxD95ec+1MXNIv1Qui8LrcJyOhFTwTrOm4dR1FSsiupVuQaC3qtCpNEl1EJI/vdv8Kjsptym3k6r/KmpusZdrcxP39KddQlSLqLqOTQR5lV99ncZX7h/UVduoVuYhJHyR096f8l7B6H+RqpbSNbSGGbgGgVradCSynDr9nk6jpnuKsJ+6PkScqfuk/yqtdQFW+0Q9RycfzqxFKt1Ftbr3/xFBS7FKSN7KbzI+UP+cVeZY7uMOhwR0PoaFY/6ifknofUf41VaOWzfzIuYz1FZitYeLxov3c6/OPT0q7HNHKMxnNRYgu0DHn+YqjLZSxndEcj9a6YqDVrnXCMWrN6mnsTf5gGD/Oq95b+au9PviqMd7PH8r/Nj161djvoW+98pq+WUXdFckou6CJlu4Nj9R1/xqO1laNzbS9ulXEELnzEIJ9RTLm3Ey5HDjoam62YuZfC9iEf6LLj/AJZSfoakdTDJ5yfdP3h/WkjPnxGKcYYcH/GmQu0L/Z5en8JqgGXUB4uIuo5OP51Oji5hDqcMP0NPH7k4/wCWZ6e3/wBaq7xtbyefF9w/eFTe+gJ3VvuJ9qXCDzF5HUehpPsdv/cp4AkxLGeo607Y/rS+ZGnc/9H94Q9zaNtbp79KuJeQSjbKMfXpRFeRTDZIME+vSmy6ejcxHHseldLs/iVmdrafxqzFexhkG6I4/UVTexnX7uG+lMKXNsc8j3HSrEN3cu2xQGq/eWzL95ap3K4F1FwAw/Or9t9rPzSthfcc1fGcc9aZJIkY3OcCsXO+ljnlU5tLElNVVXhRioJbgRReYRyegqvveBPNm+aVug9KhRbM1FstPJHEf9puw6mmyyJGQcZc8Ad6rA/Z0M83MrdKWMGIefLzK/QVpymnKWWdlATgyHt2pkkzKRFH80h/SoZJDbLj70z0Iv2ZQB80z0lESj1LG9hiMHc/c9hSmXL+XGNxHX0FRbWX9zGfmPLNVmONYl2rSdkS7IbJDHIQzDlehHWpQMDHWlrOluGlk8iDv1NSk5aExTloXiygFieB1rKLSX020cRinXTcraQ/jSyH7PGLeL5pH61tFW9TohHl1W45mLEWttwB1NNnmW3TyIOvc05ytlDsX77dTVO3ga4f27mrSW72LSW72Fgt2uGyeFHU1PPcrGvk23AHUikubhVX7PBwBwSKWG3SFfPuPwFD11kNu/vSGW9mXG+bhale5P8AqbRPxpuZr58D5IxUjzQWi+XCMt3/APr03q9dxPV66sRbeOIebdncf8/nUU16zfLF8q/rUAE90/8AeP6CrqwwWi75Tvah2Xxasp2XxasqxWs0x3Hgepq3stbX73zNUTXNxcnZAMD2/wAakS0SIb52pSb+0/kTJv7T+Q03c8p2wrj9TSraXEhzM2P1qyrnG2CPA9TwKGiz808vHp0FTzW0WhnzW20Ivs9pF/rDk+5qVJ7SMYVwKjzYJx8v86Tz7EdAv/fP/wBahq+9xO73uWlmic4VwTUc9ssvzr8jjvUIlsWPZT9MVaE0J6OPzrGzWqMrNaokUkqC3Bpku/YTH97tUtFZmZRtblpiVkxkVHJdOkvlyKMA/pUU6m2uRMv3T/k1LeRCRBOn8P8AKupKN0+jNrK9ye5k8tBKFD0rS/uftEYBOKhtWE8Biftx+FNs3KM1tJ1HSo5bfIixPbzCdS2AGBpkNyzSGKUAHtiq6/6Jc4P3X/lTr6IgidPxq+VXt3GalRSKzxkKdp7EVDa3AnTDfeHWrdc7TTMzPtZfOjMMvJHr3FQRM1pOYn+4f85ouQ1tcCVOh5/xq1Ki3cIdOvb/AAro036MCtfW/PnJ0PWixn2nyX6HpUlrP/ywl6jgZ/lVa6tjAd6fcP6VS19yRD7okuYvIcSxcAn8jVpWjvIeev8AI0kMi3UJR/vd/wDGs4+ZZz8dv1FK19HuiXpqSRM9pPtfp3/xq3dweYvnR8kfqKe6pdxB16/54qK1mMR+zzcY6Ur395bi8nsSW0q3ERjk5Pf3qGN3s5fKk5jPQ0txA0L/AGmDt1FWFaK7i/zwaWm/QWu3Ut1XngEy+jDoarQyvA/kTdOxrRrFpxehompIqI3nIYpR8w4I/rVVJHs5fJk5jPSr7pkhl4YdD/SmTRCdMdGHSrUl12JlF7rcjmgEoWaE/OvIPrTopROpilGG7is+C4e3by3HGeR6VoSxLOBLEcN2IqmraMzTvrH7iuVks23L80Z61aIWZRJGcEdD/jTIp9x8mcYf9DUTxSWzebByncUb77jWi02/InVxLmGYYbuOx+lQFZLQ7k+aLuPSp1aG7TPdfzBpVZ4/ll5HZv8AGp20G9dfxGlYLtM9f5iqDRXFqS0Zyvt/UValtmDebbHY3p60kV8M7LgbCO9Wm/s6ozkk372j7iRagjcSjB9R0qZre2nG5fzWmyWkEw3rwT3HSqL29xCcpkj1WmrP4XYUnNL3ldEz2Eg+4Qf0qEQ3UXQMPp/9anJd3AOz7x9xWtGXKjzAFPoKJSlHcmMKc/huijAb1zydo9xWlSEgDJ4FRiVCpcH5R3rBu/Q6ox5dGx+0Z3Y5prlEG9+Md6rI5kzPIdsY6D+ppqEzH7RLxGv3R/Wq5e5PP2LLPH5fmSDA680CQ7d7jGeg71VQ+e32iTiNeg/rUhkCr9ok4H8I/wA9zRy9BKd9f69SRpfKTc/U9AKVXcLmTq3QCqyck3c3/ARUuWH71xl34VfT/PehoFJvUlaTZgNyx6AUrxrKmyUZB7URx7Pmblj1NS1DsbK/UjjQIu1c4HTNSVVuLgQ/KvzMe1QSyNbw5Y5lf/P6U1Eh1ErjbmZ5JPs8P0NP+W0URR/NK9RwgW0XnSfffoKfGBEhup/vHpW2lrI5le93v+SFJFopdzulaqCrLcyepPekzLdS8ck/kKvO6WSeXHzIa0+H1M/i16IVnjs02R8uaqxQy3D72PHc0sMDTHzpThepPrUskzykQWowPWs9th/FrLboiR5orUeVENz/AOetNW3klPm3JwPT/PSnKsNku5uXNUpJ5rptoHHYChLsVJpaS+4tS3iRDy7cDjv2qosc902fve56Vcis1jHmXJH07Uj3bMfLtU/z9KE/5Qab1m/kPW2t7dd8pz9f8KY99zsgT/P0oSzdzvuX/wA/WrSeWg2wJn3HT86Ta66lpPZafmVBFey8yttH+ewqQWVtGMyHP1OKslXcfO+0f7P+NQlbJCSzAn3OajmL5Et/xHLJaRH5CB9KmE8B6OPzqt5tiOgH/fP/ANajzbInkL/3z/8AWqWilK3VFqWJJl2uKSFGjjCMd2O9IssAG1XGPrUwIIyKXkWrXuLWclzItx5EuPTP8q0az76EsolTqnX6UIU72uh9zcPARhQQakSQSw+Yozx096j4u7X/AGv6iq1lLtkMTd/507aC5nzeTL0EqzJnGMdqjhuvMlaJlwRUGfst1/sSU27QxSLcp+P1qBcztcnlunhnCSAeWe9XqpXCC5twycnqKr2Vz/yxc/T/AAoKTs7M1azYpXiuGglJIPQmtKs+/iyomXqnX6UDl3RFcK1rOJ4+h6ipp41uoRJH97t/hSwyLdQmOTr3/wAaqwyNaTGKX7p/zmi5OnyZXtpjBJnseDV68gEqefHzgc+4pt5a7v3sf4j+tNsLnI8h/wAP8KVyUre6yS0uBMvkS8nHfuKqzxPaSiSPpnj/AAourcwSeZH909PY1dhkS7iMcnXv/jUDtfR7jnSO8gBHXt7Gq1nMYm+zS8emfX0pqGSym2tyhqzc26zqJY/vfzqrleZDNG1pL58Q+Q9RWjHIsqB06GqltcCVfKl+90571CQ1lJuXmJqV+o1oaMkayqUcZBqtCWhbyJOR/Cf6VaVldQynINDosi7WqyzLlV7SXzYvuN2/pVxlivIsj8D3FPC70MUvP9feso+bZTcdP5is27EbFyCZ4W8ifj0NNntnifzrb8RU4MN7Fz1/UVEk0ls3lXHK9moKsSRyR3abSOe49PcU4SNCdkx4PRv8ajnttx8+3O1+vHelhnScGGVcN3B7079GMiuLQ/6y3474H9KiivpYzsmGcfnVh2e0AP3oycYPUVJ/o92vqfyIrpg9NVodEHaPvLQTdaXQ5xn34NV5NO7xN+BpktjIvMR3D071AJrmA7SSPY1ql/IzaK/kYrWlyhyFz9KcjXobau7Pv/8AXq9bTXE3LgBfWr1KVRrRoiVRrSSIYRMF/fEE+1SMqtwwzUZmTd5Y5f0FQSyvJJ5EJwf4j6VhZtmNm2XCARg9KiSVHYovIXqe1U3Yu32W34A+8aSRuRaW/HqatQGoE4lJJjtlGF6ntS7rv+6Kbll/c2wB2dc0f6b6LRYu3kf/0v3tltYpxvjO0nuOhqp/pdof9j8xV94Wz5tu2Ce3Y06GWRyVlj2Fe/auhSaXc6lJpd0R210Z8jbjHftVpERc7QBn0pVVVGFGKz3ma4m8iI4UdTUWu9DK3M9NEXnkVEMhPArNizcSG5m+4nQU25czSi2i6Din3HGyzh/GtIxsbRjb5/kLFm4lNzLxHH0oh/fym5k+6nSkuOAlnD+NF02xUtIvxqt9v6Q99v6QRf6VOZ5P9XH0qUSA7ruToOFH+fWgx7VW0Tvyx9qim/0mYW8fCp1qdxb+n6CwD715P+FTRhgfNf8A1snQegoIV3x0ih/Uj/CrEYJ+dup6ewpSkTKQsaBB6k8k+tS0VAJQ0pRf4Op/pWOrMNWVr6UogjU8t1+lQWwFvC1w3U8CoTm7uuOh/lVqRRPOIF/1cXWum1lynZay5fvGQfuY2u5eXfpToP3aveTdT0qJz9ruVjX/AFafypt5N5j+Un3V4p2voVa7t3IVEl1N7n9Ktzyrbx/Z4fxNPVWtYPlGZX/So7a2YuZZgeOgPc0Np6vZCck9XsghhS3T7RP17CmIsl9LufhBUk1vdTybmGB256VYkgkWJYIOB3NLm89ROXW+pWuLoIPJt+AO4qG3tWm+duF9anhsCDmXoOwqW4jupf3cYAj+tPmS0iHMl7sWRyXKRjyrUfj/AJ60kdoW/e3RxU6QC2TcF3yUeWceddduijoKi/8AKRzfyj0Z2Gy3XYn94/0FMZoIW3Od8n5//qqLzp7ptkPyJ61bitYouep9TSdluS1y7kG+7n+4PLHvQtiCd0rlzWhTWZVHzHFRzvoZ872RXWzt1525+tSCGEfwD8qeWVV3McD3qlLfxrxGN5/Shc0gXNIueWn90flTTBCf4B+VU0N5Oc/6tasbltx++lyfeizXUGmupZAAGB0papi4eT/UR5HqeBU5cIP3pANQ4tbmbT6iyRrIhRuhqKCJo4/LkwR2qVG3djj3qSi7SsO/QydptLgH+E/yqS7jZWFzF/D1rQIBGDzSbV27ccdMVpz6plcxUmUXMAkTqOR/hSW0q3ERifqBg/SnwRPA5Qcxnke1VLlGt5hPH0NUrP3UBXdZLSbjt09xWzDKsyB1qB1jvIQy9e3sazY5ZLaXBHTgira515ks2ZolmQo34Vl28r2shjk6d/8AGtdHWRQ6HINVrq385dy/eH61lCVvdkSR3Vv5g86H749O9LbXCzr5cv3v51XtrgxN5UvA/kaddwFW+0Q/U4/nV2+yyPNEckb2kodPudv8Kuusd5Dkde3saSCZLqMo457j+tUiJLKXI5Q/qKN990Lb0I43ltZsH8R61oyRx3aCROvY/wBDQ6Q3sW5evr6VQjkltJCG/EVXxarcT00exbtrhg3kT8OOmabNC9u/2i36dxU8kcV5GHU89jTIJ3Vvs9xw/Y+tRfqhNdGSq0N5F/nIqGOV4H8mfp/C1RTQtbv58HA7j/ParMcsV2m1hz3FFtPIfXzLlFZ+6S1O2T5oux9Kuqyuu5TkGsWrGidypdWvmjen3x+tZ0Fw9u2B07it+s+7tPNHmR/f/nWkZfZZz1IfajuTEQ3kf+cio0lkgby5+R2b/GspJZIW3DgiteG4jul2MOe4qpRt6CjPm9RJLb5vMgOxv0pUuOfLuBsf9DULCa0O5Pni9D2qwksF0u08+xqX5lLfTRkm0p9zken+FMkihuF56jv3FRYltvu5kj9O4qQqk4EsZwexH9aXmVvpYotb3Vsd0JyPb/CpoL15GEbR5PtVhJZ1cRypnP8AEOlWNozuxyabl3JjD+VibF3bsDPrT6p3M5jIij5kaobiT7PEIgfmfqahRbKc0rjZHN3MIoz+7HU0sh86YWsfCJ1o/wCPO3/6aP8A5/Sgf6Jb5P8ArHrX0MP8Xz/yFkHnyi3ThI+tJKTPKLWLhV60D/RbbP8Ay0f/AD+lEC/Z4fMx+8k6D+VA99H8/wDInO138pfuR9fc9hVcZvbj/plH+tLMfKiFsnLydfx/xqXy/LRbZOrcsfbvU7FPV2/r0HA+a/mt/q06e59f8KnVTnzG6n9BTVA6Lwq8D61PUNm8V1CoJ5fJjZ/y+tK8iqwUcs3Qf1rOvpN8ghXt/M0RjdkVJ8qY2zQyymaTovOfepE/0qczv/q4+lSOpjhW1j+/J1/rUdwfLVLSHqetbXuc1uVWf9MVM3U/mt/q4+lVrmZp5dqdBwPerFywt4Ft06nrSWkW1WuXGfQUJ294bTb5fvHjbYxZPMrVXggMzGaY/L1J9acsM1zPvmUoPf09KsXEc8gEUS4jHv1ovbQLX1toivJK904gi+VKneSOyj8uPlzUsFu0EZ24MhqqLGV33SuOevrSuvkPlkterK8cUt05OfqTV0vDZrsQZep5I5Uj8u2AX3qGCzCfvJvmf0ock9ylBx0W/chWGe6YSTHC/wCelW08uL93brk9z2/E0YlnYhxsjHbuahe4YN5NslS23oCSjqTSCNBvuHz7dvyqP7RPLxbpgepp6Wig75z5je/SrtRc2UW/IzvsTyczyE/Sp1s7cD7mfrVqkBBGRS5mNU4roReTCP4B+VO8tP7o/KoJbyGLjO4+gqus13P/AKpQo9aLSDmS0ReMUR6oD+FOVFQYQYHtUKK8Q3Ty5/ICm/ag5KwqZD+Q/OpHdFuiolLhcyYH0oWQMcLk+/agshhgaCVip/dt29KrXkTI4uYvxrUoqrkuCtYoyqLq3Dp16j/CiBxcQGOTqOD/AI1cCqvQYzVRoWjm8+Hv94VIrdSG0kMMhtpPXioL2AxP5qdD+hq1fQFl85Pvp/KlgmS7jKSfeHUf1oIt9ljrW585djfeH61bKhgQehrBliktZQQfoa17edZ0z3HUUrlRfRmXIj2c4ZOnb3HpWg6RXkOV69vY1PNEsyFGrJR5bOXaw47+9TsFrehPbXDQt9nn4x09qS7tip8+LjucdverFxCtzGJI+vb3qG0uefIm+90Gf5UN9GFujJoJUuoyj9e4/rWdLFJaygqfoasXNu0D+fDwP5VYimivI2jcc9x/UVO+jHa4qvFeRbX6jr7e9V43ksn8qXmM9DVaWOWzkDL07GtGKWK8iKOOe4/qKV7+pYlzbCQedF9/rx3ot7hJ18mXh+hB71CjyWL+XLzEeh9KfdWwlHnwff68d6L9UAEPZtuXmI9R6VfR1kUOhyDWfa3gl/cz/f6fWleKS1bzYOU7rVJ9UBpVXuIFnTY3B7GlinjnXch+o71PV6MDmf3trL6MK2IbiK7TYw57j/Cpbm3S4TB4I6GsF0eB9rcEVztuD8gNXEtkeMyQ/qKmkhhu18xDz2YVWtb8P+7n4Pr61JLbyQky2vHqvY1V01psA6LzQfJugGB6N61DLYMDugP4VLDcx3QMMq4PpSkXEH3P3qeh6iuulLT3WbQbWzKq3VxAdso3fXrWmpWeMF169jSriVAzrjvg0ssixIXbtTk77LUJNPZajuAPSqd3c+SuxPvn9KjjkZlN3N90fdFQ2ymaVrmXovNWoW1ZcYW1fQd/x6Qf9NZP0px/0S3/AOmslJD/AKRMZ3+6lLCftFw1w33Y+lX6mr8wP+h2+P8Alo9LGptoc9ZZelRxj7XdGRvuJ/kVYDqS10/3V4X/AD71L7Ml6aMjlmFmBGg3MeSai/tGX+5UltD5xaefnd0q39mt/wC7VaFe6vi3P//T/fJYWjYeU2EPUH+lWqQAAYFGRnFU3cpu5TvJvKi+Xq1V1/0W23j/AFknSo/+Pq6/2B/IUlwxuLkRr0HArpUbe6dkY2tH7x9oBDE1y/0FOtvkSS7l6npRc/O8dpH0FFz87x2cXQdae/z/ACDf5/kFrwHvJfwpLUZL3k3alufmaO0i7dapaxqelaHYXWp6zdxWGl6XC9zdXFw4jhihiBd5JJGwFVQCWJOAOaTf9eQm+vf8jQaQxQmdv9ZL09qLdTFCCP8AWS9K+JdL/wCCif7GPiPxbD4TsvibZi6klEKST215b2rOTj/j6lgSAAn+IuF9DX3AZBh5xzj5V/z9am+hm3pZCqqlhEv3U6+5q3UMMeyMKevU/WpqwkzGT1Kt1KYoiw6ngVTP7i0x/HLV+WBJiN/IHapsDrirUkki1JJJGbaRPHC8gHzt0zU8dsUgKZwzdTVl3VF3McCm+YGj8yP5vShyb1Byb1I4bdIAQvOe5qRYYk+6oFR29ws6kjgjqKs1LbvqRJu+oUhIAyelMljWVCjd6pW8zI/2afqOhoUbq4KN1dF1JI5PuMGx6UeYhfZn5h2rLmRrSYSx/dP+cVauPmjW6i6pz+FXyLQ15FpbqWGmjRxGxwTTnljjxvOM1VuUFxAJY+o5FBxd2v8Atf1FLlWjJ5Voy2jq43KcinAg9KxrGby5PLbo/wDOlvIjFL5icB/51fs/f5SvZe9ymzRVRHae33xnD/1FRWt00j+XJ17VHI9WRyPVlqXzdv7kDPvVZtsA82Y+ZJ2/+tVhp40bYxwfepflYeoNSnbdEp23Ri/vr1vb9BVoLb2Yy3zPV1o8psjOz6VRSyVCZJ23Y5rbmTNuZMZ511cn90Nq/wCe9SCG3t/nmO9v89qPPkm/d2owB3p2IbX5nPmSn86PIH2JQZpRk/ul/X/61QtcW0H3fnb1/wDr1SluJp22jp6CrEViAPMnOB6U+VL4iXG24n2y5mO2JMfTmpVtZ3+aeUj2FBu0X91ark0ohkkG+7kwPToKHp5Bt5EyywRfu0YufQcmpld2PK4HvVP7TDH+6tl3n2qRVu5OZGCD0HWs3HuZtF2mOiupVxkGqpNrCcudzj15NOFw7/6qIkep4qOV7oViNLZ4G3QnI7g1Jc2wnXPRx0qypYj5hg06jnd7kmFDO9rIUccdxW0rK6hlOQagubZZ1yOHHQ1nQzS2jbJAcen+Fatc+q3Av3Nqs4yOGqK1nYHyJ+HHTNXkdXUMhyDUM8CzjPRh0NQn0kLzKNxA1u/nRcL/ACq3HJHdx7G69xRDKWJguB8/8xVKaB7aTzYj8n8q130e5O2o0iWxlyOQf1q+yw3seR17HuKI5IryMo/XuKzmE1nLkdD+Rpb+pG3oKGls5MEdfyNaDpFeRblPPY+lCSQXke1hz6dxVQxTWb74/mj7/wD16Td/UdrehYgnYN5E/wB8dD61XuLZoG86Hp/KrbpFeRBlPPY9xTYp2RvIueG7HsaE+qE10YlvdJMPLk+8fyNMeGa3bzLble60XFiG+eD5T6VHFdvEfKuQfr3o84kX6S+8tw3cUvB+R/Q1bqlLbQ3I8xDgnuKrol7AdqfOP0qLJ7F8zW5dmtopuWHPqKzXsp42zH83uPlNa6b8fOAD7U+pUmipU1LUow3EmNlwhU+pHFQ3Fkc+Zb8H0/wrUoo5rO6BwurSMqG9KnZcdu/+NW2iVj50DbWPcdD9anKKx+YA0qqq8KMUOXVAovZijOOetMkkESF27VJWZfOZHW2T+LrUxV2OcuVXG2wyWu5u1Mt1NxcmZ+g5/wAKddsIo1t0/Glb/RbUJ/HJXT+py26Pp+YJ/pd0XP8Aq4+lKubq63f8s46H/wBFtQg+89K3+iWu0ffep9Cr9/VjCPtd1j/lnH/n9atBg0jTN9yLgfXuahCm2hEa/wCtlP8An8qbdDaI7SLvU76D2V2Lb/vHa7k6DpVjnp/y0k/Qf/W/nSqqjbCv3UGT/T/GnQ/OTKf4un0pN31NIxtoTgADA7UhbaCx6CnVG6CRCh6H0rI1fkULds+Zdy/hTLONpJjPIPf8TWkkaIoRRwKkrXn3sYqntcqxxN5rTSdTwPYUR2qJJ5pJZvepUljkzsOcdaiS4BmMLjYR096V2XaOhKYoy24qCfWpaKQgEYNZmlhajEke7aGGfTNUixs5cH/VN+lJeQ5Anj6jrj+dXYxc9C8zqhAY4zwKJJEiG5zgVVRheWxHf+tLEwurcxyfeHB+tFu4+a+xa3qF3k8etIkkb8IwP0qpaNlXtpOqcfhVAFrO59h+op8pLqWszeorOvIvMjE8fVf5UtjMZEMbHlP5VNtLl8/v8rNCkOccdazhdSxzeVLggnGauySpFgvwD3osNSTINrkGS5PA/hHT/wCvVKS4mum8uFSB/nrWsjo4yhBHtShVGcDGaLicb7MzktYYF8y4IJ/T/wCvSNeSynZap+NPayLybpJCw/Whp1iPkWy7nqSLW02AWyj97dvu/lUquz8QLhPU9PwFReUEHm3jZPp2qrPfSSfLD8g/WquPSJdkkghP71t7/mfy6Cqz38jHbCn9ajgspJPmk+QfrVkz21sNkS729v8AGpHd+g0RXsvMshQe3/1qsL5Nt8rSEn3Of0qNUup+ZD5S+g60nmWttwnzN7cn86AWmpbWRnPEZA9TxU1UVa8m5CiJffk05kgj5nfcf9o/0pXNLlyqDWYV/NgO1v0p4uA3EEZb9BU8ZkIy67D9c0bhuMaMTJslGD/npWQVktJsj8D2IrfqKWJJkKN0oauDQ2GZJ03L+I9KWaFJk2v+dYxWeyl3DkevY1rwTpOm5evcelSnfRh6lCJ5LKXypf8AVnoakvLXzB50XXvjvV6WJJU2OMiqcbPaHypTujPRvSk1bRhYba3YkHkzdex9agubZ7Z/PhPH8qkvLTOZYuvUj+tPtbwSDyZuvTPrUX+zIZJDNHeRmOQfN3H9RWfNby2b+ZGeOx/xqS5tmt28+H7vt2q1b3aTjypeGP5Gle/uy3AdDNHeRlJF57j+oqFGeyk8qTmI9D6Uk1m8TedbHp2qxDNHdxmOQc9x/hT12e4EV3aCUedF1649aitb0j91P+f+NSK0lk2yT5oj0PpUs1rDdL5kZwT3Helre8dwEmtc/v7Ztj9eOhpsV9hvKuRscd6qpLcWTbZBlPT/AAq/i2vU9T+opJ3+HcC2pDDIORTZYo5l2yDIrL+zXVu2YDkf57VoQNcEfvlA+laqV9GgM2bT3XmI7h6HrT7ea4g/dzqSnrjpWvRU+zs7xAqtbwTHzR1PcU+JZUyJG3Dt61MQD1pa2T0sVfSwVk3DNcXAgToP8mrtxMIoi469BVK2xBA1w3U8Ct4K3vG1NWXMMu33OlvF0Xj8afcfuYktY+rdajs0y73EnRf51LbfvZHupOgrZ6fI2emnb8wuD5MKWsfU9aS4/cQrbJ95+tFt++me5k6JSwfvpmupPup0qdtw236fmSeWYo0tl+9J1Pt3qOf97KtpFwE609JNqPdv1fhR7Uy2Bjja5bln4H+frRtr/VxLTV/0yy0QlPlL8qJ6etJ9iX+8aR/MXbBAeQMk0zF761lqZW8z/9T9+iwUEnoKoTzFIC/RpensKmnO+RIB35b6CqFyxuLkRL0HH+Nbwj3OinHuSQ/6PatN/E/SkslCK9w/QdKbfPl1gTolPuR5UEdsvVuv+frW269TfdeoWvAku5Pwpbb5RJdy/hS3ClUitE6t1oueTHaR1O/z/Ijf5/kJAfLSS8k6v0r5p/a/+G3iz4tfsv8AxB+H/gfnX9bsQLVC4j894pY5jDvPA85YzGMkD5uSBzX5v/t++Of2+rf49v4N/Zvt/FEng6HTLOUHRtJMtuLqTzPNzdrAx3dMqZOPQV8Ga94l/wCCr3gyxk8Ta9J8QbeytV82SVoZ54YkXktIgR1VQOpYADvWTmnuZOaZmXnwd+NHjj4IeDv2atC/Zf1TR/HWjavLcXni2TTpbeS8hkM+I5rmS2jVYv3qgs9w0eIU2jkbf6mfh94b1Dwr4E8MeF9VuBd3miabZ2c8wyRNNbwrG0mTg/Myk9O9fhx+wH/wU5+JPjX4n6P8Ff2hbuDV4vEbC00vWI7eO3uI718CGCdYAsTpKfkVggYORuJBJXX/AG3/ABR/wUUn/aK8T6F+z+PFS+BLWGw+xNpVlstS72kTT7LkRgufOL5+c4ORxjFZ69DON+h+9FIWABJ7V/JL4T/4KBftt/s//ED+x/iRrup6o2mzIupaF4kg/evGQDt3SoJ4WKnKsrYOQSHXg/1OeAPGml+OfB+heNNIJOl+IrG21G1Lfe8i8iWaPP8AwFhmmo3KjC60Oziu4pX2DI9M1VvDOjZ3HYemK/mh/Zo/be/am8dftc+Evh94q8e3OoeHtR16S0ntDa2iCSEGTC7o4FcdByCDX9MsMiXURjk6jr/jWqsveSNVZe8loNtZxMnky8n+YpI91pL5Tf6tuh9K/mc/Zj/be/am8cftbeEPh74q8fXOoeHtQ12S0ntGtrRBJCPMwu9YAw6DkEGv0t/4KQeMf2ttF0nwDYfsrQa3NcajLqI1f+xdO+3lUjFt9mMsnkymEZaTacpu5644G1q1sJtatbH6aXMbQSC5i/Gr8MqzJvWv5LvGPxo/4Ke/BaFfFvxA1jxroNkXA+0albvJZB36I3nRvACeykfhX61f8E4f28Ne/aVj1b4d/FEQDxtoUC3kdxbx+VHqFlvEckjRr8qSxSMobbhWDAhRhqXxK3UXxqz3P1sqndW/nLvT746V+GX/AAVL/ax/aA+Avxc8I+H/AIQeMZvDmm6joX2ueGK3tpg8/wBqmj3kzRSEHaoGAccV+oP7H3jfxV8Sf2ZPh3468b37anrus6Wk93cuiIZZC7DcVjCqOB2ArJNpmKbiz6LXF3blH++OD7GobJvleCTt/k1+HH/BU79q39oD4BfGLwp4f+EPjCbw5p2paCLu4hjt7aUST/apo95M0UhztUDg44r9NP2RvG3in4g/s2/Dj4g+NL5tT1zW9Ljnvbp1RDLKWYFysYVRwOwArRO94m0Xe8T6UtWMUr2z/hXmfxkTxenwm8d2/wAPfOHiebQdUGj/AGcgS/2gbWX7L5ZPAfzdu3PGcV/PfF+3B+1PJ+3FH8MH8e3B8L/8LEGjfYvslnt/s/8Atf7N5O7yPMx5Xy53bvfPNf0DfHL4x+D/AIFfDTUPir46S7/sPSngW4azh8+SP7RKsKEpkceYygntkVV09e5XMnr3P555NB/4LFRndI/i8Z/6ebb/AOLqUaN/wWPuFwJPF7gf9Pdr/wDHK/dD9nL9rf4OftXWevn4V3V3LL4cNuLyO8t/s7j7V5nlMoycg+UwJ7Yr+drWP24f+Cknwnmt73xvrmtaHHckqi614ftreOYjkgfaLNcn/dOajpuZ9N9T9nf+Cc9t+1tp+leN4v2rjqxupLiy/sv+1ZY5CECzed5flk4Gduc+1fo3cxmCbzV4BOR9a+Cf2Cf2vrz9rr4Z6nq3iayg07xd4WuYrXU47QMtvKk6Fre5jDFivmbXUruOChPQgV+Zv/BQv9tL9pv4RftQ+IvAPw28cz6JoFla6dJDapbWkgR5rWOSQ7pYXfliTye9ap2tItO1pI/oxuFE8AlTqOf8ah0+bBMTd+RXH/DHVr/V/AXhvUtUl8+8vtMs55ZCApeWSFXc4GBySTxxX4B/8FDP2yf2mfgx+1V4l8A/DPxvPoegWNvp0sFrHbWkgR57SKRzulhduWJPJpN2TiwbsnFn9GktyYZdki/I3Qirtef+A9QvPEPw78NaxqEv2i9vdMs555CApeWSFWc4GAMkk8DFdbY3GR5D9R0qHG6uiHG6ui+6koQh2k96xzZXBkwec/xVuUVMZuOxCk0ZheCzG1Pmk71AqXF625zhP0/CrrWcLSb+nqKqXU8inykHlqP1reLv8O5qnfYlaaC0+SIZbuaiSK4vDvlO1P8APSlt7ZVTz7jgelDzTXTeXCMLR6feHoSNPBbDy4RuehYrqfmdtqHtS4t7MZPzyf5/Kmhbm65c+XHU36r7zMfvtLXhfmf8zT/NuZf9WgjHq1M3Wdpwvzv+ZqA3NzOdsAx9P8aVr6gXfL2jdNKfzwKT7VbRjAbP05qsljI53Tt/WraWkCj7ufrUu3VmYkd1DK2xSQferDxpKu1xkUqqq8KMU6s2+wGd5E1u26D507qavI25d2CPY07IzigkDrQ3fcCKSJZRhuo6HuKRdzDy5hn37Gp6KLgY89u9s/mw9P5Vbiliu4yjjnuP8Ku1W+ywbt6rg+oq+a+5FrbGVNBLbNvXp2Iq7b3gf5JuD69jV8gEYPNUZrBWGYjs9u1PmUtJCs1rEV4Hhbzbf8Vp48i8jx6fmKLdJ4hskIYdvUUsttubzYzsk9aV+4W7EA+02nbzY/1FWmRLhAXXr68EVMoIADHJpxOOtS2NRK8NvHCPkzzViqkNz5pdsYRe9V7dt5ku36DOKLN7i5krJFxp0VxF1c9hUM9wUkWGIBnP6VDCdiSXknVulMtBkyXcvb/JqrIjmb0Jru5aLEcZ+buaEmljt/OmOSegqnCjXVwWfp1P+FXU/wBIuC3/ACzi4H1ptJaEJtu5ZhEgjUSnLd6moqCd/LjyPvHgfU1nudOyE8wfPIfux/z71RtAZJXuZO1F2wihWBfqf8/WiXNvaLGPvSda0WxzSeuvQjhBurvzD0U5/wAKmH+kXmf4I/8AP86SD9xZtKer9P6UR/6PZmToz9P6f402SvP1HL/pF4W/hjpU/wBIujIfuRdKb/x62eOjP/Wn+XJFaiOMZZ+v40yl5+oQuJppLhvux8CmWoM07XDdun+fpVqK3C24hbv1xU6RpGu1BgVDl2LUHpci2FkbPBk6/wCfpU4AAwOgqvNdQw8Mcn0FJBcJOpxwfSotI0ur2LVU3u4kk8o5z3NUy81pN+8Yup/Wrc8KXUYkjPPY07W3J5217u4t2ZxHuhbGOtVLS7Iby5WyD0Jp9pOVP2eXgjgZ/lUV5a+WfMjHynr7VaX2WYSb+OJZmRoH+0xDj+IU65hE8Yli+8ORjvUVnchx5UnXt71Mv+ivt/5ZN09j/hS2NVZryHWtyJl2t98dat1mXULRv9ph4I6/41at51nTI4I6ipa6ouMvsyJJYlmQo1VrYsmbWbqvT3FXqjZAxDdx0NK/QbjrczYR9lujEfuv0/pUkjfZ7oP/AAydalvY98fmL96Pmo5x9otRKvUDP+NO5ly20QtyDDKlyv0am3sQkjE6c7f5U+2cXNuY36jg/wBKS0fKtbSdU/lTHZPTuNsJtymFu3T6VWINndZH3P6VDIr2tx8vbkfStOdFuoBInUcj/CghXat1RFfRb0E6c7f5VLAwurcxv1HB/oaispRJGYH5x/KoVJs7nYfuH+VBfXm7kVu5trjD9OhrVuJmgAkAyveqd/D/AMtl+hqW1kFxAYpOo4P0qWOOnulyORZUDp0NPxzmseCQ2s5if7pP+TU+p6hb6Tpt3qt4SLeyhkmkIGTsjBZsDvwKk0i7kNxaXDyb878/pUqQwWi+ZMct2/8ArV/Of+0f/wAFj/HXig3Xhz9nHR/+EU058p/bGopHPqMg9Yofngg/4F5x7gqa/LO8/aR/aHvrqW8vPif4nkmmYszHWb3kk5PSXH5UC5eqP7dmluLxvLj4T/PWpgkFku5/nevlL9iHX9a1z9kj4Y63rl5Pqeo3ukh57u6keeWV/NkGZJJCWY+5Nfnl/wAFHP8AgoZ4v+EXimb4FfBC6jsfEFvDG+sauUWWS0M6iSO3tlbKiUxkNI7KdoYBMNkgEftp5lxeNtThO/p+NWP9FswM/M/6/wD1q/hf8S/Fn4tePL83XizxhrOvXcx63d9PcMST0Adjx7DipvCvxi+L3gHUIr/wh4z1nQ7m2PBtb6eIjHUFQ4BHqCMHoaVirH9y4a7uuU/dx04xWlv80p3t78/pX45f8E3f+Cgni3496s3wN+MtxDN4shtmn0vVFQRPqMUIJmimRAF8+NfnDKAHUNkBly/3f+1z+0d4c/ZQ+DeofEvVLcapqssiWWlWLtgXN/MGMYbuI0Cs8hHO1SByRUDsfUAuZpuIIuPVulSCOYjM8uPZeP1r+LT4vftmftLfGzVrnUfGvjvUktJ2bbp1hcSWWnxITwiW0DKpCjgNJucj7zE814RD4s8b6ZIuoWus6jaSTciZLiaMtjuGDDNXYZ/eF59tH0fP4k00X9uTjJ/Kv5OP2Vv+Ckvxu+CnizTbD4ja3d+OfA8rxw3lrqUr3V3bQEgGW1nkJk3Rr0idjGw+XCnDL/V3oGr6R4h0XT/EOgTx3em6pbxXdtPF9yWCdA8br7MpBFK0gNj5XX1BqhJZFG821Oxh27Vo0hIHWm0nuBDDI7r+8QqwqRlV1KsMg1+RP/BRz/goXq/7Ol3H8HPg75LeOby3W4vdQmRZU0qCUfugkT5R55B8w3gqi4JVt4x/Ox4x+NPxp+KeqNdeNfGWteJLy4Y4W4vJ5xl+0cW7ao9FVQB2FJLuB/csivCdv3o+3qP/AK1VbqzZv3kHXuP8K/hb0nxv8VfhvqiyaHr+teF9Rg5Btru5sp0/74ZGFftZ/wAE/P8Agpt4517x1o/wP/aJ1AazDr0qWela5IipcxXchCQ290UAEqyt8qyEbw5G8sDlE4JqzA/fe1uw/wC5m69AT39jUV1ZbMyQDI7j0rSktYJTudea/Iz/AIKM/wDBQnVv2cbqL4NfBwwt45vLdbi91CdRMmlQSj90EjfKPPIPmG8FUXBKtvG3PkbVpFXP1ft75kwk3zD17ir00CzYngOJOxHev4a/GHxm+M/xS1Vrzxp4x1nxHe3TMQtxdzSjLdo4t21R6KqgDsKyNJ8bfFX4caoJdD1/WfC+owcg293c2U6f98MjCmoO1pMLn91cU6zZgnXD9we9Qtbz27b7U5Xupr8Af2A/+Cl3jfxJ450f4HftF6gNYj12VLPSdekREuoruQhIbe6KgCVJT8qykbw5G8sDlP6C4EkRMStuNLlb0f3juMilFwhWSMj1BHFNjs4Y38xc57c1cqmbkm4EEa59T6VTsrcwvQuVBNPHAA0h69KouTc3YjH+rj6/hSr/AKTdlj/q4v51LqX0Q+XuWZ7oQxByPmPQGo2uXjthJJgSN0FUgftl5z9wfyFNupDPceWnOOBXPKq7Nr0RpyluxluJWZpDlRx+NXJWOAg6vx/jUUJSJxap/AuSaYJQRJdH7o4X/P1ruorTUlK7uVrpjNOtunQcUl8wG2BOiilsx87zv0UUy3Uz3O9u3Jrv2+R17fIln/cW624+8/WifMMKWqfefrSp/pF6X/gT+lOh/f3LXDfcTpUbbk7b+o2ceVElpH95+tLONojs4+/Wi3Pnzvct0TpUltFI0z3EoxnpRe2/9MV7b/0yG7O+SO1j6Croj+dFA+SMfrTlgjRzJjLnuafJIkS7nOBWTleyRg5XskJHHsLHOSxzUtZzajGDhVJHrSf2in900uWfYOSfY//V/epJCsct0ercCoLFRvaVuiCnXrBFSBegGaG/c2IHeSu1bep3rb1I7ZTPc72/3jUyfv70v2j/AKU6xjYQs44L8CrVvbrCpGck9aznJK5E5pNle3UyzvcEcdFqxHbqkhlJyxqzTWBKkKcH1rFybMHNs/PP9rX/AIKHeAv2R/iDpfw88UeFdT1y61LS49UWaykhSNI5J5oAhEhByDCT6YIrv/2Q/wBsvwp+2FpPibVPB+gXugL4ZmtoZVvnicyG5WRlKeUT02HOfWvBP+CrXhDwjefsneK/GWpaDYTeJtPfSre21R7WJ76K3OoRZjjuCvmqh8xsqGA+Y8cmvgv/AIJLfHv4QfBHwZ8ULj4qeLtO8Ni7udOlhivJ1SeZIYp95hi5klxkDCqeSB3o5bOxPLZ2PhTxnYQ+BP8AgoFqNp4dX7HHo3xH3WqKNoh8vVQ8YAHQLwB7Cv7Fbu13DzYvxFfxw6RqyftAft42niHwpbym28aePkvrVHGJFtbjUfOBkAzgpD8z9cYNf2O2lwUPkzfL6Z7e1XC/xI1hfWUT+YD/AILI2tvb/tSaDNCgR7nwlYvIR/G4vr6PJ/4CoH4V+9n7HcRuf2SvhDLnc6+FtKH4C2UAfhX4S/8ABaVBH+1P4ZC8Z8HWR/8AKhqNfuj+xXcmH9lT4SK33D4Z0v8AD/R1qldtyiCvKblE/mT/AGMiB+3j4AJ4/wCKmk/nLX9g9zA0LfaIOMdR6V/Gd8G/Fuk/BL9svRfE/jaQ22n+GPFcqahIFLeTGlw8Msm0ckJksQATgcAniv6YviN/wUL/AGUfhp4Rn8RTePtN8TzpD5lvYaLcxX95cMfux7ImKxknqZSgA60ou2pMNPeP5xv2MEEv7d3gFT/F4kl/9q1/X8yy2kue46H1r+PL9iC/Oofts/DfVI08v7Tr5mCnnG8SNj8M1/Xz4q8a+C/B2gv4h8c65YeHtLidY3u9RuorS3SSQ7UBlmZVBY8AE8ninBta9CqcrK/Q4b4/6JpPjD4D/ELRNXgW4tbvQNSSRHAOD9mkIIz3BAIPYgEciv5pP+CSV7PbftlaNaRtiPUNK1SCYf3kEPmgf99xqfwr9tv2o/2zP2ePAfwV8Yppvj/RfEGt6lpV5Zafp+l38N/PPcXULRRblt3kMcYLZZmwAAcEnAP4x/8ABITwtfa7+1vHrFuGEXh7Q9Qu5HA+UebstlBPTkzcDvg+lRJWejJmknoz0r/gtVCYPjz4HU8j/hG8j/wNnr9o/wBgM5/Y3+E//YGj/wDRj1+N3/Ba+wvF+Mfw91iVNsNxoM1up9ZLe6Z3/SVa+6f2EP2wP2d/D37KHgzRPFvj7R/Duq+GLR7K+sNQvI7a5V4pX2PHFIQ0qupVgYg3XBwQQC127g1du+58F/8ABbL/AJL74G/7Flf/AEtuK/Zn9gyIS/safClf+oLHj/vt6/nj/wCCl/7S3w5/aY+OOnaz8MJJ7rRvDWljSxezR+Ul3Ks8srSQqfm8r94ACwUnBOMYz/RH+wN/yZx8J/8AsCxf+htUJ2M07H8ztirN/wAFHbdO5+K6D/yvV/Vj8afhzb/GD4M+NvhTdgZ8R6Vd2kJfpHcPGfJk/wC2coVh9K/lCvta0rw1/wAFC7jxFr93HYabpXxRa7u7iY7Y4YINb8yWRz2VVBJPoK/rp8LeOvBPj/Tx4n+HviHTvE2lea0Ju9Luob2381AC0fmwsy7gCCRnIzWsNbxNoO94n8yX/BJv4l3Hwy/a3j8DauzW1t40srvSJo5PlEd5b/6TCWH97MLRD3kxX7I/8FVNKs7n9irxzeXEKyPZz6TNCzDJjlOo28RdfQlJGX6E1+Fv7Y2g6h+y9+3xrXinw9F5Mdrrdn4s00D5VdbmRb1kH+wJvMix0wMdK/Sz/gpD+2p8A/H37LV78NPh14stPEuu+L59PYwWTeb9mt7aeO7aSdgCqHMSpsLbst0wGxmnZEJ2R5d/wQ9dm1n4w228iOS20MlOxKveAH8Mn86+Mf8Agqwhi/bV8Woe1npX/pFFX3b/AMESfC+o2Wj/ABS8dzREWN7caXp0EmOGktVnlnGfYTxfnXxX/wAFa9NuLL9szXb2Yfu9T0vSriE+sYtxD/6FE1DTSJaaR/Tr8Moivwu8F3Cf9AbTs/X7NHX8uf8AwVYkE37avi6T1stI/wDSGGv3e+DP7cn7K/8AwobwnrfiD4k6NpM1rpFnDd2Fxcot/BPDCqSxm0GZ2KspAKoQ3BBIIr+bn9tf42eFP2hv2jvE/wAT/BMVxDol6La3tTdKI5ZEtIEh80oCdocruAJyARnByBcnpZlyelmf16fB+XZ8NfCMTdG0fT/z+zx13d5EYZhKnAPP41wvw2g2/DDwdOnU6Pp+fr9mSvRlK3dtg/e/rWt9po1v9pE1vMJk3dx1qxWBFK9vL83bgit1WDKGXoawqRs9DGcbACQMt2prIj43AHHIp5GRis2yZleSBj06UktLkpdSSe2lnkGX/d1FLcLCPItRz61oLIjsVB5HUUzyIg/mBRvq1LpIpPoykkKW6+fcnL+lV5bmac7I+Aewpzw3E0x8wY9+wFacMEcK4T86ptLVg2UobD+Kf8hWkqqg2qMCnVQubsRfJHy/8qyu5MjcsyzRwjLn8KpLc3Nw2IgAvrUcdsX/AH90cDrzSyXmf3VqMdh/9YVqo9ESWflgXfPIXP8AntShpphkfuo/1P8AhUKQpAvn3Ry1SYaUeZcfJH/d/wAalgPRgflt1z6sen/16a7xQndK29/89B2qtJdPIfJthgdKkWOOzHmzHdIaLdxXJl86bl/3Senf/wCtTlk3fJAMgfxHp/8AXqqglvDvl+SIdvWn+a87eVbfLGOrf4UrDLPmbT5a5dv89fSlaVYl/ekZPYVVeZYB9ntly9KqLB+9mbzJW6f/AFqLCuWlkJUtINg96cjh13YIHvVVjtAmuevZR2/xNTIJHO+Tgdl/xqWhlikJxyaWs69ckpbqeXPNJK4m7E884S3Mi9+lVZ2MNqIyfnk6/wBf8KklXfPDAv3U5P4dKgm/fXoj7J/+s1aMpMWb9xarD/FJ1p1yPLhjtV6t/n+dB/f34HaP+n/16emZr1m7R8U7kvyIb1giRwL0AzTrj9xaLD3fr/Woh/pF77A/oKfMPPvRH2HH9TQiX1aHf8etpkffertvF5UQU9ep+tU5v316kXZOv861KiTNILUKp58y69oh+pqxI+xGc9hms8kw2W4/fl/r/wDWoRUmV1P2q8z2z+gouWM1z5a9vlFS2QEaPO3YYptihkmMjdufxNa36mFrpLuS3Y3PFbL0qSZDNPHEF/dx8n0+lTpbgTNOxyT09qs1lc15b3uV3gSV1d+dnQdqsUVSaR4Jf3hzG/Q+lLc10WpYSWOQkIc461nyXNxBPiXlParE0LK32i3+/wBx60v7q9h9P5g01Zambu9Ook0Md3GGQ89j/jWQDJBJno6VZjkks5PLk+6ev+Iq9cQLcJ5kf3ux9au9tDJx5tVuKDHewY6H+RqhDLJaSmKT7vf/ABFV4Znt5cj6EVrSxpdxB0PPY/0qbWBe9qt0Jc2yzr5kf3v5022uBIPJm+90571Ut7lrZ/Jl4Gefarl1beaPNh+91+tPyY1r70SldWrQtvT7n8qu21wtwnly8t/OktbpZl8mb73TnvVO5tXtm82H7v8AKjfRitb3o7GijmNhFJyD90/0PvVSeB7d/tFv0HUf57VYgmju4yj/AHu4/qKVZWhfypj1+63r9aRo7NElvOlwm5eD3FWazZrV438+14PcVZgnWcY6MOoqX5FpvZlmqVuphd7dvu9V+lXaTGakbXUx482t3s/hf+XaproGCdLle/BqS+h3xeYOqfypf+Pu0/2v6irv1ItvES7jE0IlT+Hn8KrWE+1vJboen1qSwmyDC31FU7mJrebC9OopeRL6SRPcI1vOJo+h5/xq1Oq3VuJI+o5H9RTgVvbf/a/kaqWcxilMEnGT+tTcdvuZYtJRPCYn6gY/CqQ3Wdzz0/mKluFa2nE6dD/kirVzGLmESx8leRQO1/VEV/EJIxMnO3+VYWu29zrXhbWNEtsG5u7O4gj3HALSRlBk/U1u2EwZPIfqvT6VRnja1nyv1BpXH/eR+Nv7OX/BHHwB4VNt4i/aK1g+L9STD/2Rp7SW+mRn+7JN8s8+Pbyh2IYV+Cfx60jTNB+OnxF0LQ7WOy07TvEer29tBCAscUEV5KkcaAcBVUAAdgK/uXt5VnjDj8frX8Ov7SP/ACcT8Uv+xq1z/wBLpqZof1mf8E/wD+xn8KAeR/Y4/wDRslfyg/tP69deKP2j/ihrt2/mPc+JdW2+0aXUiRqPZUAA9hX9Vv7ALNH+yJ8J+flk0dOP+2sgr+Vn9qfw1eeEP2lPij4dv4zHJa+JdVKg94pbmSSJ/o0bKw9jSTA/pr/4Jw/BzwP8K/2W/BfibStKgTxL4vsU1S/vjGn2mb7UTJFGZcbvKjiKhVzjqepJrmP+CnXwT8I/EP8AZc8WfEHU9Lg/4SfwfFBfaffCNRcJGJo0miMmNxiaJ2/d5xuCt1Arr/8Agm78Y/A/xR/Za8E+HNN1OCbX/CFiml6hYGRPtMH2YmOJzHnd5ckYVlbGDyOoIHK/8FSPjN4R8AfsweKPA1/qsCeIfGEcFjYWCyKbiRGmjeaUxZ3CJIlbLYxuKDOTUu4H86v7GHia98I/tX/CfWNPnNvJJ4j0+zZx/wA8r+UWko+hjlYH2NfqR/wW11u/S6+FHhlnKW5TV72RP78mbaNCfoN2Pqa/Ij9mf/k474Vf9jXof/pfDX7F/wDBcLw1eGX4T+MI4ybRRq1hK/ZJD9nliB/3gJMf7pqra3A8A/4I+/BbwZ8S/jV4n8Y+NNLg1iPwXp0EtlBcxrNCl5dykJMUYEF40ibZnoTuHIBH9L3iPwz4Y8V6FdeG/Ful2mr6PeIYprS8hSa3kjPG145AVI/Cv5nv+CQHxr8GfDH4z+KfCHjLUodITxpp8EVlLcyLFDJeWkpKQmRiAGkWVtnqRgckA/0m694i0Lw/o1z4o8Xara6No1khlmu7uVILeOMclmkkIUD3JqZStoirH8V37Svw+0v4U/H74gfDvQ1dNM0HWby3s1c5ZbXzC0ILdyIyoz3r+p//AIJyeI73xX+xX8MNW1S6MslrZXNgMnGI9PvZ7WJT9IolA9q/lh/aW+IOl/Fb4/8AxB+ImhFn0vXdZvJ7NnG1ntvMKwkr2JjCkjtX9M//AASwt/M/Yl8DSzn92s+r4H/cSuKJbAj9Elmeb5bYYUfxHp+FL8kb4GZZf8/lTA8lx8kHyRDjd6/SoZbqKBfLthk+v+etYuVtWUfxR/ta+Lb/AMc/tO/FHxLqL+ZJP4h1GGM5ziC2maCBc/7MUaj8K/o+/wCCX3wN8JfDr9mXwz470/S4U8UeNYZL++1J4lNyYpJSIYEkxuEKxIp25wWJbqa/mH+NmT8ZfHpbr/b+qf8ApVJX9d37EMs8/wCyP8JbeH5Qvh6yyf8AgFazdkQkd1+0Z8DfBH7QHwq174deLNMi1Ge6tJ/sNw8avPZXnlnyp4ZCMoytjpjcMqcgkV/Ena3VzYXcN7aStDPbuskbqcMjocgg9iDyK/vdaRbfFtaDMh/zzX8D9z/x9S/75/nRB9AaP7ufh34nm8X/AA98M+Mrvaja5pdlfEL0zcwrKcf99cV/GP8AtbeML3x5+058UfE9/IZHuPEOoxREnOLe2maCBf8AgMUaj8K/r9/Z4i3/AAB+Glxdn5R4Z0bA/wC3KKv4yfjcR/wufx8R0Ov6r/6Vy0ou4NH9Pv8AwS7+Bvgv4cfsyeGfHdlpcR8UeNYJL++1Fol+0GKSUiCBZPvCJYlVtoOCxLdTX1l+0d8C/BX7Qvwo174feL9MhvZLi0n+wXLxK89lebD5U8DkZV1bGcEbhlTkEiuG/Ye8yX9kT4SqPlQeHrLJ7n5O1fWgAUYFWncbP4ELW6ubC7hvbSVoZ7d1kjdThkdDkEHsQeRX93Hw58UHxl8PfDXi+bAk1nS7K/fb0BuYElOP++q/hEuf+PqX/fP86/t8/Z9Bi/Z1+GajrL4a0b9bKL+lTOXKrglc9ihlYQyXknJP3f8AP1qK1Jiglu36twP8/WlvcRwxWw/H8K+Xf2sv2qPBn7JXgrRPFXjXSr/VrXVr77DHFpwiMiSeVJLufzZIxtwh6HOa49b2XT82bH1FCTBZNP8AxSdKUf6Pp+f45f6//WrivAHjfTvif8PfCfj3RYJbXT/FOmWeqQQz7PNjivYVljWTaWXcA+DgkZ7mvLv2pf2jPC37MPw7X4leL9NvdU05byCy8mxWMy+ZcBiD+9dFwAvPOal6XS6afNgu59CWv+j2sk56ngUlioRXuX6L0rwfwh+0D4X8efs7Wv7Q2mafeW+hSaTeav8AZJlj+1+TYiXeuEYx7j5Rx82ORkivzIv/APgth8LFdLXTfhxrMlp/FJLdW0cn/fsbx/49Qou9l0/MG/xP2wi3mKSY/fmbaKdesI1S2XoBk184/sv/ALWHwi/av8KXOv8Aw1uLiG60Z447/Tb5BFeWjyA+WWCM6NHJhtjqxBwQcEEDP/ao/ag8Hfsq+BrD4jeN9LvtXsNT1SLS1i04RGUSSwzTBz5skY2hYCOuckcda9fDx5YK/Q1g09ex9PSfuLRY+8nJpYf3Fo0vduBX5tfFj/gqT+zP8PfDmgavBcXniPWNf0yz1JdJ01IpJrNL2FZ4472UyCGKQBgGjDO6nqmCDXj3gX/gsx8B/EutWmieN/C2seErGeTyzfZivYIl7SSrFtlA9diOR6GtOZWsxcyskz9h4gYbQsB878CrUVvi2EROCetV9L1HTtX02z1bSLhLuxvoY57eeJg0csUihkdGHBVlIII6itSs3O5jKd9iKKJIk2J0oaaNGCMcFulR3HnAB4j93qPWmERXkWRwR+YNTa+rElfVjbtriNQ0R+Xv60QTpdRmOQc9xRDKyt9muOvY+tVLi3e3fzoen8q2SXws2SXwvchubdoX6blPQ1Wx/s1vW863Cckbh1FT7RVc8l0H7SS6H//W/eFo5Lqcso+TPX2rVaGNyCwzt6VJwMDpVe5eaNN0Qz61s5OVkjZycmkid5EiXc5wKrw3UUzFV4Pv3pkM8Vyuxx83p/hVK4tmt28xPu+vpTjBbPcqMF8Mtzboqha3YkwknD/zq/WTi1ozGUXF2Z83/tW/s/8A/DTvwS1r4OHXf+EbOry2kovvsv2zy/stxHPjyfNhzu2bfvjGc89K/JC1/wCCHtstz5d/8ZmZPRPDwQn6E6g38q/f+oZoUmXa34H0oVuo011Pz5/Za/4J2/Bf9lPxAvjvTJrzxV4rWJ4Y9Rv9irarINsn2aCMBULjgsxdsEgMASG+/Z7dbhfNiPP86dHKyN5M/foexphR7Vi8fMR6j0rVabbmq023PzA/bK/4J0N+2B8VNL+IsvxD/wCERbTNGg0gWp0n7d5nkXNzP5vm/a4MZ8/G3afu5zzgfdPwj+GLfB/4T+Efhmuof2uPC2mWmmm78ryPP+zRiPzPK3SbN2M43Nj1Nesywx3aCSM89jTYLg58i44fpz3qk7e8i07Pmj80fkJ+1P8A8ErPB/x5+IOofFDwF4qPgvWtaczajbzWn2qyuLggAyrtkiaF3IzJ98MxzgEnPmHww/4Ip+F9G1W01f4t+PZfENnAwaXTNMszZJLjna908skmw9GCRo2Ojg81+4F1aGP95F9z09KLW7Mf7uX7nY+lU4p+9EcoqXvxPyN+FP8AwSs0P4V/tH6b8cPD/wAQPL0rRtZn1Oz0P+yOI7eRn8u1+1m8YnykYLvMXOM4Ga+2/wBr/wDZ2uv2l/grqnwp0/W08Pvf3FpcC5e3NyF+zSiTBjDxnDYxnPHoa+n7i0WYebF94/kait7poz5U/bjJ7VPnEVusPuP55tH/AOCJHjK6vxHqnxV063tM8tDpkssuPURvNGP/AB6v1w/ZW/ZF+Hf7IPhS80LwO8+p3+sSRy6lqd1s8+5aMERrhAAkUe5tijOMkkknNfVVxaEHzrb64H9Kkt7xX/dz8H17GlZfFESivijsfLn7Wf7Jnw//AGvPAFt4W8Vzy6XqWlSvcaXqduqPLaSuu11ZG4kik43plc7QQwIBr8ktN/4Ik64+sPBq/wAWbaHTlPyyRaQ7Tv7GNrkKv13t9K/oU8loG3wcg9V/wpJYY7pdy8N6/wBDUq3UzXL12Pxj+IX/AARg+Fms+GfDWjfDfxld+Gr7ShcnU7+9s/7Tm1R5vK8s7VntUgEOxgqqDkNzyCW/UP8AZ/8AhgPgn8G/CfwlGqf2yfC1ktmbswfZjNtJO/yvMl2dem8/WvT0mmtW8qYZX/PSrrRxzgSxHDdiP60ONtxuFt/vPx9/aF/4JC+C/jL8UvEHxO8KeP7jwhL4mu5L+8s5dOXUYvtdwxeaSJvtFuyiRyXKndgk4OMAfbH7H37L6/so/CCX4Ut4l/4SoS6ncaj9s+x/YsfaEiXy/K86fp5fXfznoK+q0mYHy5htbsexq1WeqMrNM/NP9tP/AIJ4ad+2D4s8OeMU8Z/8IdqWhWUmnzSf2b/aH2uAy+bCP+Pm38vymeX+9nd2xz8qeEf+CKPgDTNUhbx78S9Q1q0jcGSGx0+LT2kQHpvkmucZ9QM1+69Z17bmTEiDJHWtItN+8aRab9485+Hfwl8A/BbwTp3gH4ZaRFoug6aCI4IyzEs5y0kkjku7seWZySa+Vv2wv2F/AP7YNjpl5qOqy+GPFuhxPDZapDEtwjwO24w3MJMZljBy0eJFKlmOSCQfvC1kE8TQSdRx+FZro9vNjuDkVuldOLN0rpxZ+Beh/wDBErU4tV/4rD4pxDTkcHFjpZM0sfcbpZwsR/4DIB717H8U/wDgjD8NPFF9pFz8KvG8/g3TLDTYrWeC5086rPeXKSSNJdyT/a7cBpFdVMaxhRt+XAOB+0kird24Zeo/n6VXsZ9jeS3Q9PrWXKmvQy5U16GN4M0hdA8KaT4Wkn+0nSbK3s/N27PMEEYj37cnGcZxk49a1kZrKba3T+lPnRrWcTR9D/nFWJ41uoBLH94cj/Cr0XoytF6MjvYRIonj545+lMsJ8HyG79KdZT/8sH/D/Cq1zAYJNyfdPI9qP7jEl9hm7WawMN6H7SVZtpxNHk/eHWnzReYmB1HI+tc60dmYrR2Zm3X7q5WUd8GtN5UjUO3Q96p367oVk9P60QH7RaGM9Rx/hVvVJsp6pM0AQRkUtZWnykFoT9RWiJELlAeR2qJRs7ENWKF3dFSYYuvc0yGBLdfPuOvYVoGCNpBKR8wrJuxOXzIOO2OlaxaeiKGTTyXD47dhVxESyTzH5c9BSRIlonmy/ePQUyFDOxubj7oob+4zJY1z/pd0foPSqks0l3IEXp2FNuLhrh+Og6CraKtjFvfmRu1PbUBT5djH6yH/AD+VVYYpLqUyyn5e5/pSRRyXUpLHjuasTy9LS3HscUvzAJHa6cW9vxGOppZ5hEv2a2+90J/z3pZGFnEI4+ZH6n/P6UsMS26ebKMyHoKAFjjW1UMw3StwBTmZbf8AeyfPK3T/AOt7UrsLdDLLzK/b+n0pltA0jfaZuSegqPNkeSJYYXZvPn5fsPSrtFRGQCQRDqefwqG7lkMkjG4SFenU1W/1t/8A7Kf0/wDr1JDh7uWT+7x/n8qjsTuklmP+c81exnuTQ4eeaU9B8v5dar2WDJLcN2/rzTo2IsZJT1fJ/PimR/u9PeT+/wD/AKqQuwtkflluG/z3p9oSkEk56n+lRt+608Du/wDXn+VLJ+605F/v4/Xmh6k7CaeoBeU9hinWHzPJO3+c80kX7vT5H/v5/wAKWP8AdacW/v8A9eKbBaWHWQ3vJOf4v/11p1QtV2W8fYuc/wCfwFX6h7mkdijdtkJAB/rT+gqveh5ZVhiGdo/nWg0W6VZc/cBwPrUvTmlewnG97laK3C24hk59anAVBxgAUjlghKDJ9KpQ3mW8u4XYf0p7j0WhKL23Mnlhvx7VcrKurEHLwj6j/CmW12UPlTdOx9KduqIUmnaRsUxlV1KsMg0+ioNjPVmtDsk5iPQ+nsafLCyv59v9/uOxq2yq6lWGQap/NanB5h9e6/8A1qq5m1YcRDexe/6g1Uhkeyk8mf8A1Z6GrckRLefbn5/0NKpivIyrLgjqD1BqhNa+ZDd2gmHmxff/AJ1n207274P3T1FXo3ktG8qbmPsafdWomHmxfe/nSv0ZLjf3luOuLdLuMSRnnsao21w9q/kzA7f5Uy3uHt3wencVpyRxXkYdTz2NF+jEve95bkdzarKvnRfe68d6S2ut/wC5n4fpz3qtHLNZv5coyn+elW5oI7lPMiIz6+v1plLuiKa0aJ/Pt+3arCPFeQ7W/EelVYbp4T5Vz27+lW3iV2E8Jw/qOh+tZgvIrJNJat5M/K9j7VZkhSfEsRw/ZhTiFmQxyjB7j+oqgwnsW3L88ZoK232L0U5J8uYbZP5/SrVVFeC7TH6dxSB3h+WX5l7N/j/jQWmWyM8GqkMLW8hVeY2/Q1bBBGRS0BYxLlDBcCVO5yPr3q5Mi3duJI+vUf4VNcw+dEU79R9ao2UrxSG3m4z0z60GfLrYq2k/lS/N9x+DVvUIdpE6fjUF9B5Um9fuP/OrlpKtxCYpOSBg/SlcSX2WOiZby22v16H6+tQWcpikNtLxzx9arRu9nclW6dD9PWrd/CHQXEfVeuPSlcvzILuJreYTxcBj+tXXVL633L17expIXW8tyj9eh/xqhbytZzmJ+hOD/jRcRHaytbzYfoeCK/iP/aR/5OI+KRH/AENWuf8ApdNX9vl/bZHnp+P+Nfw//tF/8nB/E7/saNb/APS6akuxaVj+sD9g5GP7GfwlnTrHpA/9GyV8g/8ABRr/AIJ3a18ftaHxw+Chg/4TBoI4NT02aRYU1JIV2wyxSvhVnVQIyHIVlC8qV+f7O/YAAb9jP4Uq3Q6Ov/o2Svqi9v8ATbBI7G/vIbeWfcIVldUMmzH3QSM4yM49aHpqhn8VurfsoftS+GNS+yXnwq8UxXMbYWS30m7nQt/0zmhjZG/4CxrrR+xL+0yvgLxP8VfFvg+78L+H/DFm97d3GtBrOWTb/BFDIPOd2J/uBR/Ewr+yfT7qJI38xwI8bsk8fnX5L/8ABUD9qX4Z+GPgL4j+DPhzxBZ6t4t8XGCza0s5kuHtLZJllnln8skR5VPKVWIYlsgEKxCUr2A/n8/Zggkuf2lPhNBEMvJ4t0JQPc38Nf15ftWfs+eE/wBpz4Pan8K/FEps5ZmW6069VN7WV/CCIpgmRuGGZWXI3IzAEHBH8s3/AAT58FXfjz9sb4X6bbDCadqiatK3ZI9LVrvn6mIKPciv7ILyS0htpLm+dIoYFLs8hCqigZJJPAAHU1TvbQD+On4rf8E+f2sfhRqlxZ3HgG/8SWCORHqGgwPqVvKn97bCpljHtLGpFcL4V/ZC/at8dXdppWkfDHxHsZvLie9sZrK1jyeczXQiiQep3Cv7PnvYNRtxNps0dzbf3oXDj9K828f/ABd+Ffwg0K48U/FDxPYeH9PtUMmLmZRLJs7RQjMkreiopYnoKyc3flSKsfxY/FP4a+IPg/4/1v4a+LXgfWfD8wgufsrmSISbQxCuQucZwTjqOMjmv6m/+CWtrcN+xF4AM/ywtLrDD3H9p3Q/mK/l7+O3xIHxf+M/jf4npE8EPifVry+hifG+OCWUmFGxxlY9oOO4r+tX9iXwjd/D39kb4XeErtStwujx3sy4wUfUWe+MZ9187B9xTqNJaglc+r7m7DDyoOFHGR3qWCBLZPtNx17D/PeucbxH4W0u4eLWNYs7SeLGY5riNHGRkEqSDyDkVfh1GDW447vTp47m3l+40Th0I6ZBGQa5G7e9LfoaW6I/h/8Aja2fjN49b11/VD/5Ny1/Xb+xJP5X7Ifwkhtx+8k8P2WfxSv5Tf2t/Bt/4C/ac+KPhjUIzG0HiHUJowRjdb3UzXEDY/2opFP41/RP/wAEvv2gvh/46/Zu8OfD3+1reHxj4MiksLjTZZlFw8CSkwzxRnDNEY2VSQDtYEHtnrqXsTHc/TQlNPi/vyvX8EF1/wAfM3+8386/tS/aS+P/AIF/Z9+F+veO/GmrW1tfx2k39mWLTItzf3nlnyYoY87jlsZIBCjLHgV/FlZ2l1qV3Bp9jE09zcyJFFGgyzyOcKoHcknApUr2v0FLsf2+/s8qT8AfhnPc8Rr4Z0bav/bjFyfev4xvjcd3xm8en11/VP8A0rlr+2H4c+GpvDfgXw14SuGBGgaZZWJ29CbaFYuPrtr+Nv8Aa58H33gP9p/4peGb+MxNB4h1GaIEYJt7qZri3bH+1DIh/Gim73a2CStof1hfsN/8mg/CP/sXrL/0CvqC8maGL5PvOcCvzL/4JgftFeA/H/7NXhn4aDV7eLxh4Mjk06402WZRcSQLKTBPFGcM8RjdVJAO1gQe2fqT9qH9oXwF+zz8NdY8X+LNWt7a/hs5zptkZVFze3hQ+TFCmdxy+MkAhRljwKqpLRpbhFdz+Ki5/wCPqX/fP86/uA/Z9Af4FfCyPsnhjRW/8kYv8K/iDsrO71K8g0+xiae5uZEiijQZZ5HOFUDuSTgV/dd8N/DcnhDwb4e8JyMrtoOl2Wnkr0zbQpEce3y0VOi8xx6s6mT99qIXqEx+nNfjR/wWtfd8EfBR9PEoH5WU9fsvZAPcSzH3/Wvxv/4LPWVxN+zx4P1QLmKLxVFGx9DJY3ZH57TXHB3afds2fws/Qz9kD97+zL8IGP8Ayz8H6F/6QQivjP8A4K/vv/ZQkb/qYNO/9Amr7E/Yzu4Lr9lL4UXlud6p4V0eLP8AtwWkcbj8GBFfF3/BXy6gtv2TII5jte68SadDGPV/KuZMf98xk1KesV3bYraNnv3/AAT6tLbU/wBjH4YWF9EtxbS6ZcRyxSAPHJGbmfcjKeCCDgg8EV9Uah8MvhxrNpP4Z1DwtpdxpMsZiltGs4fJeMjBBj2Yx2r5x/4J4WM9h+x58MEuk2P/AGUZR/uTXEsin8VINfYtiwLT3Ldv/wBdC3S7t/gI/nc/4Jh2UXgL9uz4v/DrRGKaTY6frdnFFkkYsNWt4oSc5JKoWAJOeTX1R/wWcgkT9l7wtI4xnxjZAf8Agv1Gvmn/AIJ1j/jZh8ac9RF4p/8AT1b19Uf8Fqjn9lzwt/2OVl/6btRr1lL3bEKdlyo7P/gnd+x38CvCHwJ8G/Fq68PW/iDxf4t06DUpr/U4o7k23njcIbVJFKwqoOCyje3O5sYUcp/wVr+DPw0vP2Zrz4k22h2Vl4m8NahYmG9t4I4p2guZhbyQyOoBeM+YGAPQqCO+fsP9ii6lg/ZK+EQdf3f/AAjen/8AooV4p/wVY8mb9iXxjOnUXekc/wDb/DRy21YcttWdf/wTQ8QXniL9iX4a3eoStLNaw31kCxyfLs7+4hiXnssSKAOwFfeVfm7/AMEtppIP2JvADDoZdX49f+JpdV+jkMyTLuT8qHBpXFKDSuTVSmhdH8+Dr3HrV2iknYiMrFMiK8iz0I/MGmxysD5Fz17HsadLCyv58PDdx60furyPB4I/MGtdLeRvpby/Ipz2jxtugBIPYdqh8q6/uNV5bhoP3dz26N60/wC3W3rWnNPuXzVO5//X/ey6tmlO+NufQ/0qGK8eM+XcA8d+9ODXFocON8dWSILxM9f5iurZWlqjrvZWlqiOa2jmHmxHD9cjvRFcsp8m6GD69jUBiuLRt0fzpVlJYLpdj9fQ/wBKHt3QNaa6oguLHPzw/lSQXbIfKuO3f/GpgLi2+5+9j9O4qT9xeL7j8xRfS0tUHNpaWqLQIIyORS1l+Vc2pzF+8T0q1FdRzcfdb0NZOPVGLh1RNJGki7XGRUSeZH8knzL2P+NWaKi/QhPoUWieBvNg5B6r/hSukN5HuXr69xV2qrwEN5sJ2v39DVqRqpX33IEneFvJuvwaknslk/eQ8H07GrAKTr5cyYPof6VX2z2Zyv7yL07irT1uty09dNGVYLiS3bY447ir7xQ3ab1PPr/jS/6PeJ7/AKiqLQ3Fq3mR/MP89RWmjfZl6SfZjklms28uQZT/AD0qxLbxXA8yEgFv1p0VxDdLsccnsf6VE1vNbt5lucjuKm+vZk317MhiuJrZvLmBI/z0rRG2QeZEef5/WoVlguk2OMH0/wAKg+zz2zeZCd49KHZ+TB2e+jLZMcw8qUYb0P8ASqptp7dt9udw9KsK0N2noR+Yp0K3CErI4Zex71mnYhPl0/AbHPFOPKlGG7g1NGrJkFsr2z1qXAznvS1DfYyb7BRVUwPv8zzTn9KtVLRLRA0KlxKnDD9frUd3b+cmV++OlW6KpSa1KUmtTEsp/Kk8tujfzp97BsfzV6H+dS3dqWzLF17inwSLdQmOT7w6/wCNb8320b8320LEy3cJjfqP85qvaStBKYJOhP61Cpe0uMN+PuKt30O9VnTt1+lNq2nRhbp0ZBeQGJ/OToT+Rq5E6XcBV+vf/GmQSrcwmOTlh1/xqiDJZz8//rFK19OqDfTqgRmtZ8N24PuK3FYMAy9DVK4iW5iEsfLDp/hUFjPtPkv0PSpl7yuZy95XNGVPMjZPUVlWEm2Voz/H/MVtVh3KNBceYvQnIqYapxFHaw6YfZ7reOmc/n1qa+QjZMn0/wAKdeqJIVmXt/I06Ai4tTGeo4/wqr7MPMsxSh4RKfTmpVZXXcvIrMsZCrGB/wAKdH/o12Y/4ZOlQ46szaJbi1Mzq+/j0/wqnfS4xboMKtarSojCNjgt0pZIo5V2yDNSpW3EZVnEqKbqbgDpUBaS8m479PYVoXcMrxqkQ+UdqiiUWUHmN99+grW/UAmkW1i8iH73c0QqLSA3Eg+Y9BUVrEZnM0nIHJ9zUoH2ybc3+qjo8gEgTaDeXHU8ipVbAN3Px/dH+fWmBvttxgf6qP8AWoZna7uBFH9wf5JrMB8KNdSmeX7o/wA4rXqNEWNAi9BUlS3cSQVmWp8y6ml9OP8AP5VZR2M0uei4AqnYfLFLJ/ninYGSWrfuZph1JJ/So7b5bKVvXP8AKlQ7NNLjv/jikHGmfX/GmQE2E09F9cf40TjbYxIvfFF6NtpEPp/KpLtf3lsg6bv8KBMi1D5UiiXtS6kdsccQ6f4Ul5817Ev0/nSX4eSZI0XPHamugn1HSDZpyr64/nmluwy28UA5PoPYVZNv5sEcTHGMZ/KrlTcrlIRFjyx2T/DFTUgIPSsye6uIJclR5fb3/GluW3YtS3UULBHzk0TRLcxfI/0x0piyW16m08n0PUVX8i4tTvgO9e4qSH+BEs01m3lyjKdv/rVeZLe8TcOffuKIp4Ltdh691NV5LSWFvMtT+FaCtbzQqSS2h2TfNH2I7VLNax3I8yNsE9x0NNhvEk/dTrsfoQelPNu8JL2x47qelZjt9xSjmms28uYZT/PStaORJV3Iciq6yxTfupRtY/wt/SoGtJYW8y0b/gJoErrY06Kox3ik+XOPLf36VeoNE7lUI0Lfu+Yz/D6fT/CiWHeRLEdjjv6/WrVFAWKaOlwDFKuGHVT/ADFQDzbI4b54fXuKuSwpKAfusOhHUU1Hc/up159exoFYZLDFdpvU89iKzAbiyk57/kavPbSQt5tqceqnpUsc8VyPKlGG7qaCWr+oqyQ3ke09e47iqTRzWTb4/njPX/69E1lJE3m2x6du9TQXob93P8j+tBPqS/6PfR+4/MVQ/f2LeqH8j/hVyWzIbzrY7H9O1Ed0rnyLkbX9+hoKa7k0U0V0uVOCPzFPLgfJL0PGexqnJZMjebanaR2qaKcS/ubhdr+h70Du9mQy2RVvMtjsI7VJFdkHy7pfLb17GnLFNE6iNgY/Ruo+lXcZoBLsV1i8s5jbC9x2/D0qxRVeWFpCMSFAPSgssVBLCkw+bqOhHUVIoIGCc+9PoAhkiEsZjk5z3rDUyWdx83br7iuiqpdWy3CejjoaTQmiC8hE8Inj5IGfqKisJ+PIf8P8KWzmaNzbTcHtmoLuFreYSx8KxyPY1DfUnzHMGsbncP8AVn+X/wBarN7AJoxPH8xUfmKe4W9tdy9e31qvYXG0/Z5Pw/wo8mVYksLjevkSdR09xX8eXx//AGY/2j9U+OvxG1bSfhP4svNPvfEmsTW1xDoV/JFNFLeSukkbpCVZWUgggkEHIr+wK8gNvIJY+ATkexrQRo7632t17+xqYy6DPlv9hzQte8Lfsn/DTw74m0250fVrDSxHc2d5C9vcQyebIdskUgDqcHOCBX50/wDBZz4a/EX4gQfCK48B+FdV8SR6Wde+1tptlPeLb+f9g8vzTCrbN+xtu7Gdpx0NftTDI1lOVfp0P+NbwIIyKuMrgfwnT/CH4u2zfZ7nwVrsRJ+4+m3SnP0Mdel+CP2Pf2oviFfx2Phn4X68xkxia7spLG2GfW4uhFCPxav7UNThJAnXtwaliP2uy2nqOPxHSo53doq3U/NH/gn9+wXB+yz4f1Dxv42uYNU+IPiCBIZTAuYdNtlO5raKQ8yM7AGV8AEqoUYG5/r/APaK0/VNf/Zr+K2haJaTajqV94U123trW3jaWeeaawmSOKONQWZ2YhVUAknAFe1abJy0J+tQqfsl5tP3D/I1nz7THbofw8XnwN+OGkylL/4f+IrOROok0q7jI/OMVNo3wA+O3iKVYdB+HPiPUXc4At9Iu5Of+AxGv7iL4GCaO6T6GtB5URBIx+U9/rWynq0xWP5of2R/+CVfxQ1/xdpnjf8AaN0weGfC+mzRXI0iZ45bzUth3CKVI2IghOMSeYQ5HyhRncP6PrCzRikSIEijAGBwAB0AroiElXnDqaryW5S3aK1+UmsZ023zPYtO2h/LZ/wUa+Anxz8c/tlfEDxR4J+HHiTX9FvRpQt73TtHvbq2m8rS7SJ/LliiZG2upU4PBBHUV+5f7BPhrxB4D/ZC+Hfh7xfpN3omt2dpcpPZX0EltcwlrydwJIpQrpkEHkDgivrm0tTExmuRgR9M1CfMvbn6/oKzlUdlda9C1HU/KX/goP8A8E+NS/aVkT4vfCmSCDx5YwC3ubS4cRRarDH/AKsCU/LHPEMqpb5WXCkrtBr+erxn+zn8e/h1fSWPjP4fa7pUkTFfMksJjAxXqY5kUxSD3RiPev7ebg73Syg6DrSznGyxt/xpxqcqtvb8yXG5/Dd4f+Dfxm8c3ot/DPgnXdcupT0ttOurhz7kqh4HcngV+0X7Af8AwTL8ZeGvHWk/Gn9oS0j0x9DlS60vQtyyz/aUw0VzdNGSqCI/NHECWLgF9oXa/wC9l3IIkFpD+NXrS3EEeD949arnc5ci+YrJK5PHGsSBEGAK/Jj/AIKJ/wDBPS+/aVnh+LXwkeC38fWFuLe6s52EMOq28f8AqsSn5Y54xlVL/K64VmXaDX611UldvtEUQ6HJP4V0NqKISufw9+Nf2cvj58N9Sk0zxt8Ptd0maJiN8lhM0L46mOZFMUg91Yj3rH8P/Bv4zeONQFp4Z8E69rt5Mc4tdOurhz7nah49SeBX9x6fPqTH+7/hip7Y7ru4b04rCNa7tbrYtwPwS/4J+/8ABMzxh4W8e6V8bP2iLOPTZNAkW60nQt6yz/a4yDFc3TRkqgiPzJECWLgFtoXa/wC9Vs2EuZvUn9Kj045aWQ0QfLp8reuawVRytJ+Zry2uvQS1O21mf8P0r5c/bC/Z4h/aZ/Z51z4ZxTLa6wzx3+lTykiOPULbPleZgE7HUtE5wSAxIBIFfUa/LphPqf6026+WwhHrg/pWSfIk10X5mjV3bzP5yPhD8ef2/v2IvCsvwc8Q/CG88TeGdJmk+xyy2N3PDAJXMjpbX9puhkiZmLAHcVJxkdBkeO/Dv7eX/BR/xboWheK/A03gTwbo0nnCS6s7nT9Pg8zCyXLPdfvbuYLwqxZwCcBQXY/0n3Py2ESDvj+VTWcLi1kRxtaTPX3FdCneotNbGLjaO5xXw68F6N8NPhxongLw6jJpfh6xt9OtvMOX8m2jWJSx7sQMk9zXa2sLGzK9C571eihSKIRDkD1qTcM4zz6VcaOzl2E572Pwf/YU+D/xX8I/8FCvi9408WeCtb0Pw9qkfiQWmo32nXVtZ3Bn1eCWLyriWNY38xAWXax3KCRxX0J/wVs+Gvj/AOIX7O3h3Rvh74b1PxVfw+KrS4kt9Ls5r2eOFLG+UytHAjsEDMoLEYywHUiv1RuUnlIEeAByD70yK7ZT5dyNh9a9CN2nYUU7aHzj+x7pWq+H/wBl34Y+GfE2n3Glapp+g2UFxaXcTwTxSJGAUkjkAZWB6ggEV4x/wUr8D+L/ABv+yN4t8N+A9EvvEOqXNzpZjsdOtpbu5kEd7C7FIoUZyFUEnA4AyeK+9prOOUbo/kP6VElxNbHy7gZHrVpae6aJXXufcfD/APwTe8IeJfBv7HHgjwp440a90HWbKXVTNZahby2lzF5mpXEiFopVR13KQwyOQQehr7aeCe0bzIzkev8AjV1oop/3sJw/qP60CeSE7bkcf3h0oi7bCi7aL7h1vdpN8p4f0q3VCW1imHmRHafUdKYs89sdtyuV9RUuKfwkOKfwmlVeSDc3mRna47+v1qSORJBuQ5FSVnqjPVECkSDEq4I9ad5cPoKloouFz//Q/eqG+Rvln49+1OktCG8y2Ow+lPktoJxuXg+o/qKrgXNn/tx10q32TrVvs6eRJHeFD5dwMH1qR7aG4/eRnB9RQsltdLtYc+h61A1pLEd1s/4UtPRi09GSCS4t+JR5i+o61Ji3ufmU/N6jg1Cl48Z2XCFfepTBbzjzIjg+q0PTVg1bV6Dx58XX94P1ppS3uOv3vyNR7ruD7481fUdakWS3ueD19+DU26k26/kNCXMP+rPmJ6HrUq3UZO2T923oaTZPH/q23j0br+dIZ0I2zRlfqMijcnctAg9KWoo4o1+aMYzSySpEu5zis7a2RnboiSiqcU8kzZVNsfqe9TrIHbC8gd6HFobi0RPaxM/mDKt6irCggcnNRrMruVXJx1PagzIG8sct6Cm7vRg7vRkE1pFIdy/I/tUkKzp8sjBx696lkljiGXOKjim83lVIHqaq7aKvJrUbLaxSnd0b1FTIhRcEl/rUlFZuTehDk2rMTAHNLUE1xHCPn6+lRi4KxefLwD0FVyvcfK9yaWZIV3PTGnCReZKNvoO9U4fnJu5+g6CoBvvZstwg/QVqoLqaqC6luCWWVjM52RDtUkckkjGUnbEOnvUfE3yjiGPr74qIs95L5acRCnZMLJllLh5pMRL+7HUmpGnjEgjHzH27VWZyW+y23GOpozHajy4RulNJxRLijQyM4qubdRL5qfIe+O9VyFt/3053ynp/9apY3lUGWc4B6LUWa2ItbYddW4nTI+8OlQWjnabaYYK9M+lXlbKgsNuexp9TzaWYc2lmYTxvZT7l+72+npV+VEu4Q6de3+FWpIklTY/SoIbYwN8r5U9jWjlfXqac19epQtJzC/kycA/oakvbYg+fH+P+NT3Vr5v7yP7/APOnWzTAeVMp9jT5vtIV/tIdaXHnJhvvr1qaWJZkKNWbNE9rL58X3a04pFlQOvQ1lJdUQ+6Ktsp2NbS9V/kap2rG3uTE/fj/AArXKgsG7isvUYirCde/Bpxd9ATuJeI0NwJ06Hn8RVi7XzIluI+qc/hS8Xlp/tf1FR2EoZDA/wDD/KncY65AnthKv8PP+NTWk3nQgnqODTLceW0lsenUfQ1UjP2S6KM3yH/Io8jM2ajkijlGJBmpKhmdo4y6DcRziskBBLA4t/Kg49c1WuM28K20Q5fqa0YpVljEo4BqXg1VwMmci1tlgX7z9f61ZsoPJiy33261LJbRSOJHXJFWKTYBVfzgbjyR2GTUxJ4wKqLGwvWkxwV600AiHCXL+5/QVWteLGU/738qnRH8q4AU5Yvj3pIYZBZNERhjniqMyJxt00D1x/OiUBdOjHrt/wAastbtJapATgjGakNsjwpFJyEx+lK5VitfjIiT1NTyxs9xE4HC5yatYHX0paVx2KrW6tOJ2JyOgq1RUEqO2GjfaR+R+tSMSe4WBdzgn6VXhv4ZOH/dn36VKJhnyrgbCfXofxqtPp4PzQfL7UEO/Qma22t5ts2wnt2NSLIr/up12k9j0P0rHSe4tW2dMdjWnFeQTjbJwT2PSgEyvPYMp8y2P4f4UkF86Hy7kdO/f8a0grJ9w5Hof8aZJFDONsi8/rVXDl7EUttDcjzYztbswqAXNxanZdJvHZhSfZbi2O+3bePSp47uKX93KNj9welSIkIt7xezfzFQiO6t/wDVnzU9D1pJbAZ327eWaQXF1b8XKb19RQP1JxJb3I8txz6NwacI5Y/9W28ejf0NN/0a8XsT+opnl3UHMT+avo3X86BEhMMv7uZMH0b+n/1qZ9mli/49n4/utyKUXMMn7uZdh9GqTynT/Utj2PI/xoL3Gi52cToY/fqPzqyrKw3Kcj2qv5rLxLGR7jkf405EgceZEB9RxQCLFFNYhRknAFVBcmV9kA3Y6k9KpK4nJLcu1BLbxTffHI796kL4O0cmmtKqsE6sewosNtCxxmNcFi31qOa3imHzjn17095Fj+8evQd6eWAG5uB71IabFSGCeE7fMDL6GrEsMcy7ZBmo0uElfbGCcd+1WapruCaa0K8MPkLt3lh71YopjyJGu5zgVI9h9NZgoLMcAVBFP5uXxiMdzVXJvZdvSJOvvVWM3PsXI5hIC+ML6mqwuJLiXZDwo6moJ5jO4t4fu9Pr/wDWqxs8vFtD1PLH0FO1iOZvQlLtJJ5cXQfeb+lNe5+fyoBvbv6Cq8spBFpbdehNPJFooijG6V6grmLUk6QqPM6nsKl3DGTx9aoKq248+4bfIf8APFLseT99dfKo6L/jQXcsS28c2CwwR0I606SJZY/LfnPeoIpJJn8wfJEv61Yjk8wFgOOx9aVhp3My28y0mMUo+V+/ai+tyrfaI/x9j61sUhAIwehqHHSwyjDKl3AY5Bz0P+NZ4L2Nxg8j+YrQWyEcnmwuUPp1FTXFus6bW4I6GocW15lXILqBbqISxctjj3FQWFyc/ZpOo6Z/lRbC6tW2SISh9OcU+9tC/wC/h++OuO9Tr8SH5M0iAwweQaz4Yza3Jj/5ZydPqKntLkTphvvr1qyyhhg1rpK0kTtoYdyDa3YlXoTn/GrN/GJoFnTnH8jU99D5sGR1Tn/GoNPlEkRgfnb/ACrma95wfU1W1x8X+lWW08sOPxHSktSLi1aB+qcc/pVe2Y2t00D9Dxn+VW2XyLsSD7s3B+tEXezfowZBp8pVmt36jkf1rXrFvEaC4E8f8XP41rRSLKgkXoa1pO14PoKS+0hWRXXa4yD61XW2WFXMHDHpmrRz2qrbXBm3K42unBFaS5bq+5mr2K0cZs4XmfmQ/jTLf9xC13Jyz9K1VIPQ5qKWCOZQrjgdMVi6VtY9NjTm7mbYxGRjcS888fWtmmIixqEXoKGJCkgZPpWlOHJCxMndkFzP5IVR1c4FMbm+U+iH+dMu0d5ISoztbn26VJtP23OONnX8ahtuTXmi0tCpa86hN+P86faH5rl/9o/1pbWF1uppGBCsTj86fbwOiTB+DITiuenF6adWaSa1+RVsOLaZvb+lLHxpjf571ct7QQwtGxzu64qeOFI4/LUce9XCjKyT7MUpq7sUAkj6cscYyT/jVmW1EyRoTgJ6VcordUY2s/L8DNzfQYqKoCjt0pJXWNC7ZwPSiRDIu0MV9xVTz5YDtuRlP74/qKcpcuhKVyJdTjL4ZCF9alktoLn99E21/wC8KZNZQ3C+ZCQC3cdDWUy3Nm/dT69jXnzqVIaVFddzqUU/gdmaj3FzbgCVQefvetTLJb3i7W6+neoLe8FxmKZR0zntSy2IzvgO0+lerQlGUU0yLJaS0Y0x3FpzEd8fpU8d1BONknBPY1Gl1LCdlyp+tSvb29yN6HB9RXU/733jf977xrWjRtvtn2n0PShbnafLul2H17GohHd233P3i+lSpdQzDZIMH0PSm1ffUGm99STyV/1kDbM+nQ/hS+cyD9+mB6jkVGbUod9s2z27UC6ki+W5THuOlRa+2pFr7a/mKbaJ/wB5Adh9R0pRJcRf65N49V/wpQkUv7yFsH1X+opd08f318weo6/lSvfRk3vox63ELjKuKf5sf98VXaW1c/vBz/tDmk3WP91fypcvkVbyZ//R/fJJIJ+UOG/I1JmROo3D261nSWEindEc/oaRLu4hO2YZ+vWujkv8J08kX8LLhitp+nX24NJ5dzF/q38wejdfzpVe3uunX8jSlLmPmJt6+jdfzqfJi1Wj/Eb9oT7k6Fc+vIo+zRN+8gbYfUdKPtKj5bhDH9eRR9njb95btsJ7jpT28g28hfMuYv8AWJ5g9V6/lSf6Jc9cbvyNLvuYuJF8xfVev5VIUinXc6fnwaT01Ftr+QwRTR/6qTI9G5/WrC7iPnxn2pgCQpycAeppstwscXmevSo1ZDvIZc3KwDA5c9qpwwtMfPuD8vvSQxecTPMfkHXPerAf7SS7cQr+tdHwqyN/hVkPBEq5+5Cv4Z/+tUYY3B2x/LEOvvULO13KIk4jFPnk6WkHToaOXoHKOMpkPkWnAHU0kkyWq+VFy3c0OVtIvKT77dTUdrbb/wB7LyOw9aNLXewaWu9h1vbtMfNn+YdvetQAAYFLSZGcVzyk5HPKTkLVVZy0j44SPqaheQpG0/eQ4X6f55qC4P2eBIB1fk1agWodBiA3dzub7vX8KfITd3IiX7iUsf8Ao9oZP45OlLB/o9qZT95+lbPyNm+qGXUhkcW0XQcfjU+zykW2j+833jUVqgjRrqTt0qQOYYTO/wB+TpUvsiX2RHcv0tIeg60+Q+RGLaLmR+tNtVCqbuT8KWH+O8m7dP8AP6Vb007fmJ6Csy2cexfmkbrT0C2sfmycyP8AnUUC+Yxu5ug5FSKQc3c/QfdFZvsSwVRGftFycseg9KlG7iWUZY/dX0qKFWkb7VN/wEVJPMIRk8u3T2qXq7CYOET97cHJ7D0+lPikllO7bsj9+pqrHFwbi7P4Gn/vrv8A6ZxfqabQmXwyt0OcVFK0yjMYDeoqv5ltaDanJ74q1FIZI1cjbntWTVtSNivDdrK+xhtNWWkRCFY43dKrXNt5n7yLiQfrSqRcwlX4cdfY1TSeqJLZIHXvRwB6VWiLSRFJhgjg/wCNShCU2SYb196hqwEtRyxiWMxnvUcNukBJQnB7VYofkBi2bmGcxPxnj8aW5Bt7oSp0PP8AjV+4txMNy/LIOhqOeJprbOMSLz+PervfUu4T8olzFyU5/DvUd5ELiETx8kDP4VHp8oIMD/UVNCfImNs3Q8r/AIVOxAWNx5sflsfnX+VaFYc6NZ3Cyp909P8ACtiORZUDr0NJrqUyrAjW8jwn7h5X/Cq8Z+zXZhb7knT8f84rVIB61Qv4S8YlXqn8qafckdc3T27jKblNWIJ0nTelVxtvbX3/AKis+ylME/lvwDwfrSsBsrLG5KowJHapaxr6NoZhcR8Z/nVuGWO9hKOOe4/rRYC9SAg9Kyo5ns5PIm5j7GrTq6HzoOfVfX/69SA6W6gibY7c+mKmVxIm+M5z0qv/AKPfR/T8xWcRPYPuHMZ/I0AXlvCj+XcjYfXtV4EEZFU1aC+jwfy7iqRW5sTlDuj/AE/+tQLY2qKow3sMvB+Q+/8AjV6gYxlVxtYZFV/Klh/1Dbl/un+hq3RQBUPkTDy5V59D1/D/AOtVCbT3X5ojuHoetbBAIweadRcTVznorme3Ow8gdjWpFdwT4U8H0P8ASrDxRyjEgBrOl00HmF9vsaCbNGjtcfd5HoaifyJfkkHPoeD+H/1qzVlu7XhwSg9eR+dXY7u2nG1+PY9KCrjhbyR/6iTj+63IpftLx/8AHxGV9xyKUxSLzA+PY8j/ABFJ9peP/XxkD+8ORQMQw2s/zx4z6qcGlAuYhwfNHvwaPJt5/wB5GcH1Xg0YuouhEo9+DQAebbzfu5VwfRhigWxj5gkKj0PIqVSs6kPGRjswoSJIvuDHtk4oFYdH5uP3mPwollSJdz0olQqWB4Hesn572X0QfoK0jG+5nOdtI7kg869fn5YxVtcD91BwB1P+e9Rltx+zW/AH3j6f/XqKabbi1th7cVb10RgrR1ZK0uW+z23Xu3pSPIsH7qL55W6//XprstlFsTmRqIUFvE0833z60rDu9v6Q4lbVfMmPmSn/ADxVdEmvX3SHCj/PFMije8lLP07n+lbKqqKFUYAqm+X1FFc/oIiLGNqDAp9ISB1qux/eksfkjH6n/AVznXsLJKfNWJOp5J9BVG7czTCBO386kRykUl23WTp/SorFOXuG6D/JrZK2pzSfNaPf8h903loltF+NEzC1hECfefqaS2/eSPct0H+f0FRwqbu6MjfdHP8AhUivfVdSa3QW8XmuPnbgCnSv9li65lfqaepEkhuG/wBXHwP6mqkQN3cGR/uL2/kKXqVsrRJYVFrCZ3+8/QUsQ8lDdT8u3SjP2u6x/wAs4/1prg3lzt/5Zx1A15DoQXJu7joOlOCm5PnS/LEOg9fc04gXD7BxCnX3NMybuTA4hT9aGaEwYTDceIR29f8A61DDzBulO2MdvX6/4U9nSNPMfhB0FUlWW8fzJPljFA32LCXBkO23T5R3PAq5uGcZ59Kz/MeT9zaDCjq1SBLe1+eQ5f1PWpuCZbffj93jPvVD7cUfy5k2VYgn8/JCEAdDTp4EnXDdexpPXVFkryKib26UBlK7geOuapWzMubWccjp7inwLJDI0JBMfVT/AEo5gLY2n5h+dKCD0qKOMx5UH5ew9KjFrEJvOXIPt0ou+wFqufkVrO7DD7nb6V0FRTQpMmx+lRVhzLTcuLtuZ2oRbkWdPofp2qaMi7tcH7w4/EdDT4Ym8k283OOAfUVnW8htblo34BOD/jXLJ8sk3s9zVaqy6F9f9LtjG/3xwfZhVOxmaGRraXjJ49jVqb/R5xOPuScN/jUGoQEf6TH+P+NE7r3luvyBa6dzYrPkjaC5Fwv3H4b296faXIuI+fvr1/xq4QCMGurSok0ZaxdmZF4Gt50uk6HrVy4maOETRgOO/wBDUlxCJoTF+VUbCUOjW0o5Xt7Vg7xm4rr+ZqtVfsWbW7S4JXG1hzU7TxK3llwG9DWA6vZXHH8JyPcVoXsa3FuLiPsM/hWUK8uV33RUqauuzNWkBB6Vk2V3vHkTcnoCe/tTZVksZvNi5jfqK3+sLlU0tOvkZ+z15Wa+4Zxnn0qGW4igGZDjPtUTBblRPA2JB0P9DTY5knBt7hcSdwe/0qnU6LrsJRJ4biKcZjPTt3qvLdS28mJUzGehFUZ7OW2bzbckgfmKuW95Fcr5UoAY9uxrnVWTfJLSX4M05EveWqL0ciSrujORUlYs1rNbt5tqTj07/wD16kg1NW+WcYPqOlaRxFny1VZ/gJ07q8dTWpCM8GmqyuNynI9qfXac5Ta1KNvt28snqOxo81WHl3Kbc+vKn8auUhAIwax9nb4f+AXzdzPEMFnIJgSFb5cfr/SrShSMwv8A1FMmtllj8sfLg5rPNvdWx3RfN9P8K6qVOKVo6G6tLrqaTOANsycevUVEbaInzIG2H1HSoY78Z2zDHuKnEcUn7yA7T6r/AFFVZxJs476BvuYv9YvmD1Xr+VBe1uPlfGfQ8GjfdRfeUSj1HB/Kk8y1uflb73oeDT8/yDz/ACAW8kXNu/H909KX7QV+WeMr79RSfZ5Y/wDj3k49G5FPSWXdsliI9xyKT1G9fMZ9ngk/eRNtPqpqRRcIcFhIPfg0ptod28DB9uKkLorCPPJ7Um7mblckorOubpkby4uo61W+13HrQoN6hyNn/9L9/KYyqwwwyPemCaIts3AmpqrYrYovYQk5XK/Sp4oWi4MhYe9T0ZFPmb0Y3NtWY1gGGCMioUt4ozlFx9CaHuFD+WoLN7dqWWeOFcyHn0os9gs9ieiqAluJ/wDVL5a+pqXzFhGHcux7d/yocQcSWSGOXG8ZxUNxbGdg27GO1fiX/wAFVv2ofj38A/HXgTTPhF4sn8M2mr6bdTXKRQ28vmyRzBVY+dE5GAccYr9EP2KPiB4q+Jv7LXw+8d+PdTbVvEGsWcsl3cuqI0rrcyxglYwqj5VA4AoTaegJtPQ+nbhHZktoxtT1qO6kAC28f3R1rWqj9kAnEoPHUg1rGa6msZrqQnFpb7B/rJKS2RYIzcyfhTZIZ7ifdghM4/CrU9s021FOxUq21s3uW2tm99ylDGbqYs/Tqa2QABgVFDCsKbF/OpqwnK7MZyu9BpIUEnoKoxMzRSTHrKcD+Qq6yh1Kt0NII0CqoHC9KSaRKdkVHUNcxxD7qDNUZ2M91tHrgVsiNFYuByetQJZxRuJFzkVpGaRpGaRUu/nljtk7UXWWljto+gq4LZfP84nJ9KRLYi4M7HPpVKSQ1JIidQ8sdsv3U5NV5mNzc+WvQcf41aVJY1ll25kbpioLZPJWSeQbccDNUnbUE7aiXT/MlrF0FSzJuMdonQcmoLRd8jTydF5z71OrGOKS6b70nT+lD00QnpoOYCaQQJxHH97/AApv/H3LzxFH+tRykwQCL/lpL1r5l/aS/a2+EH7KUPh2P4ry30Q8T/a/spsrb7QT9j8rzd/zDH+uTHrz6VOwtj6jM2FM7fdHCj196gjjAzd3H1xX5hN/wV3/AGO5HG+61vYnQf2Yf/jlfAf7SH/BXL4kT/Eln/Zs1GCPwaLWDYup6YhuPtPPmk72Jx0xUcyQrn9HmDL+/uOIx0X/ABqtLdyTHZFwO2Oprzz4WeJtX8cfDDwb4o1gq2oazo2n3tx5Y2IZ7i2jlkIA4A3E4HavToYUt/lX5pD+la6LViIobVYgHl5c9BVhuP3s7bQvQD/PNMmuEg4HzSmmR2zyt5t0cnstQ9fekK5ahm84EqpAHQnvUgRQxcDk04AAYFBIAyaxfkQLTWIUZJwKz5r8KdsI3e9Rpb3Fwd85IH+e1UodZAWnvYVOF+Y+1Ojknc8x7V9zzUJktrXhBl/1/OkD3Vxyn7tfWtOVdEBo0VSRYrX5pJCWb1P9Ksq+8ZwR9eKwaAxriNrWcSp0JyP8KvTr9ohWeL7y8irckSTJskGRVS3jktmMR+eM9D6fWquVccNl9beh/kaoWkzW8pil4Hf2NWXU2k3npzG/3h6U+6t1uEEsf3u3vTJNCkIBGDWTZ3Pln7NPxjgZ/lWvWYGOgaxuMN/qpO9Lf2+D56d+tajosilHGQajSMhDG/zDp+FVcCtCy3lsUfr0P9DWSpe3m9GU1aG6wuef9Wf5f/WqxfW4kT7QnOBz7ipFYnIivoPQ/wAjVKCd7WT7PcdOx9P/AK1VIJ3gbevTuPWteWOK9h3Keex9KBjLi3Yn7TbHD9eO9EF2lx+6lGH9D0NVYJ5LRvInHyfy/wDrVauLOK5XzYyAx79jQBBPZSRN5tqenbv+FS29+kn7u4+R+nsagiu5rZvKugSPXv8A/Xq3LBb3aeYp5P8AEP60ARz6cj/NCdh9O1UhJdWh2t09DyKkLXliefnj/T/61W4r63mG2T5c9j0oAItQifiT5D+lXlZXG5Tke1UZtPjcbojsP6VmtDc2rZAI9xQB0dFVrYTiP9+ctSzXEUI+Y8+g60JXJbS1ZYoqGKTzV3bSv1pWljQ7WYA+lVboO63JaqSWdvLyVwfUcVboqRlSG18o/JI230NW6KhlmSLAbknoB1osLRDTbQlt4TB9Rx/KrFRmRVTe/wAo96qG5kmOLZMj1PSqUbkuSRfpjIrqVbkGoVLRLumlz+Qpd8r/AHEwPVv8KLBzdxJLdXh8lTtFQOjWtvtiBLHqRV1nVBlyBTgQwyKakxOKe25muws7cKv32ptqqwxG5k/CrFzaichgcHpUN1HI+2KJPlWtU09DBxad7bbEVsjXE5nk5Apk0jXU4jj6dB/jV8W7C3EKnBPU0ttarbgnOSe9HOtxezbSj95PFGsSBF6CpKKK5zsStoimG8y6P92IfqaZMSYAo6zH+dW1jRc4H3utBjQsrEcr0qrmfLoZt6wXZAvQCnSfubIL3k/rVqS1hlbe4OTSzW6zlSxPy9qrm2RDg7tlOT/R7MR9C/WnhTDbCNf9ZL/Wpp7bz5EYn5V7U8xM1wHP3UHH1qbhy6lK7cRRrbJ+NLIfstssY++/WkjikluzJIhUA559ulRt/pV3t/gH8hUk+ZMgMFpx/rJen41IVMES28X+sk6n+Zp4xLOz/wAMPH496iSTCyXj9+FHtQaWCUfds4P+BH2qdQv+pThI/vf4f41Xg3xwtO3Mkp4/pUhjJAtlPXlz/n1oKXcj2m9l3txEnT3qQ5uP3cfywr1Pr9KUjzT9ni4iThj/AEqpcXII8iD7o44qW7DsPlu1jHlW/AHemw2pk/e3JwPfqakt7VYgJZuvYVZllWEeZN17KKzt1YJdwKlxt/1cQ/An/AUR3Mbv5cQJA79qrKk94d0p2xdgO9aKRpGuxBgCqWuqKBkViCRyOlPoqlcXscJ2L8z+lW2o6sC7VSW8t4uC2T6Dms8fa7w9cJ+Q/wDr1YEVraDMjbm9/wDCuf2jeqLsSLdTTcwxcepq8M4561mfarm4O22TA9TT1txHia5lJI98CnGfbUGjRrI1KDOLhe3BrQSdJeEBI9ccVKQGGDyDVTiqkbBF8ruZ9s63dsYn6jg/0NJZyFlezn+8nH1FH2ZraXzrcZU9V749qdeQsdt1B/rE/UVzLmSu1qvxRro9DOYPY3OR07e4reilWZBInQ1wfjjx74F8B+F7jxf8QdctPDuj2hHm3d7MkMaOeihmIyzdlGSewzXyDbf8FI/2LbTVzo5+Jtq7nqwsb/yPr532fyv/AB6op3py93WLHK0lruff1Y93E8Mwu4Rx1asPwP4/8FfEzw5b+Lfh9rln4i0a7/1d3ZTLNESOqkoThl7qcEHggV2ldlSnzqxjGXKzNuYlvLcSxcsOR/hUGnTZzbP9R/UVfih8lyI/uN29DXhfxh+PHwa+BYtbz4peL9P8NNe7mghuJf8ASJAvVo4Yw0rKO5C4B4zyK5KkZRaqpa9TeLTXIz1i6hNtMVHTqDWpa3CXURim5bHPuK+K9D/4KIfsW+M7pdM034o2NvdFwim9t7yxj3Hj/W3UEUePfdjvX1jaXcFzDFfWM6zxSqJIpYyHR0cZDqRwQR0I4Nck26E7paM2X7xeZrkS6dNkcxn9f/r1elijvYxLEcMOh/oarSahZCwnudQlS3ggRpJZJGCoiKMlyx4AA5JPSvibX/8Agof+xv4M1Z9Lv/ihY3EiuYybKC7v4sg4/wBbawyx4992PetkrLRXg/wI330aPtuC9eJvIuxgjvTriwSUebbkAnn2NeRfCz4/fBH492s8vwo8X2HiR7MAzR28mLiBW6GSFwsqqegJXBPGc16oGutPba3zxn8v/rUTXKuWqrx79UEdXeGjJIb2SE+TdA8d+9WZbOC6HmRHBPcdKcGtr9Md/wBRVB7e5sz5kJLL7f1FDuo2l70fxEtXpoyJorqzbIyB6jpVuHUx0nH4inQ6mjfLMNvuOlSvaW1yu+I4z3HT8qiEXvh5fIqT6VEW454phmNg1TVzctncQHcBkDuK0LFrpxvkb932z1NdNLEScuScdTOdNJcyZqUUxnRBlyBQkiSDKHNegcthjwxS/fQGqy2KKd0bshq/RVqTWxak1sMUFRhjn3prwxyffUGnMyqNzHAqOKbzfuqdvqaSvuJX3HxoqDavT65qSqcl2gOyP943tSIty53ytsHoKfK92Xyvdl2oVhjRi6jBPeo/tAPywgyEfl+dSoZAMy4/CizRNmiqtkN5Z23ZqT7HF6VMksbkqhzj0qSq55Fc8j//0/32ihjhGEH400ypv8tfmb0H9ar3Urswt4fvHrUkUQiXy4/vfxNWttLs1tpdkzMWOxPxPpVTzDIfItuAOrU2SRp2+zwcL3NSgYH2a24x95vT/wCvTSsWlYZvEX7i1G9+5/xoEMUB8yc75DRvEZ+z2oy3c0HyrX55T5kpqgMfxH4m0Xwnod54n8W6lb6Ho2nRma5u7qVYooox/HJI5AUf1r88vFP/AAVj/Y08L30thpus6n4hMZKmbTtOk8okdcNcmHcPcAg9s18ef8Fp/i54hgs/Afwb0+8NvpWpLc6vqEC8ee0DrFahj3VD5px0LYPVRXKfsRf8EvvhV8Y/gnovxg+MerapJc+JvNmsrDTZY7aOG2jleJWldo5GdnKbhgqACByah3vYh3vY958YfGT/AIJs/t7eM/D8HxM16803XNPjez06LUHudKRhO4JXzkzb7i+MbpQT0Ar9HTN8Hv2NPgErM02leBfA8CpvYS3kscdxcBFyVDSSEyzAcA4z6Cv5v/8Agol+w/4e/ZF1jwxrPgLVbvUvDPisXMSRX5SS5tLm08sspljWNXR1kyvyAjBBzwa/Xr9jqxs/2zf+CeOn/DP4s397Jbln0S8u7aVEu3i0u6jntsSSLIMiJYkYlSSAT1Oam5Nyyf8Agr1+yAt8Lc3utvF/z2XTD5X45kEn/jtfd3we+OXwq+PvhdfGnwk8RQeINLD+VK0YaOWCUDPlzQyhZYmxyA6jI5GQQa/In9p3/glF8APAfwG8Z/EH4canrVjrvhHS7nVU+13MVzBcJZRmaWOSPyoyC0akKUYYODgjg/MH/BF/xTrFh+0T4p8HwXDLp2teHJriaLnaZ7O6g8qTHTKrLKB/vGluLc/o68ffETwP8K/C9540+IuuWugaHYAGa6u5BGiljhVHdnY8Kigsx4AJr899c/4K7fsc6TeNa2OpazrMaHAmtNMdI29x9paF8fVa+Kv+C2/iPX11n4X+EUklXQjb6jelQ58ua8DxRZdehaFPunqBK2MZOfIP2Sv2av8Agnd8Q/hRpGvfGX4sfYvGt8JPtum3Oq22jx2jiRlSONbiMGT5ADu8xgc8AdKLdAt0P11+E3/BSv8AZX+MnjLSvAHhjWNQtNd1udbWzt73T5oxNM/RA8QlRc+rso96+9p7iC2jaW4kEaKMkk4wB3r8lvg9/wAE3P2YfDfxH8L/ABm+CvjTVNTk8M38d5HGt/ZajZymPkIWhhRhn13mvZP+CmPinxH4G/Y18bah4fmltrrUnstOkmhOGjt7q5jSbJ9JI90R9nrXlsveNOSy94d8Rf8AgqB+x98O9WuNCfxZJ4hvLbiT+x7aS8gz6LcDEL/8Bcj3qj8Pf+Co37JXxA1/S/DVrr99pepaxdQ2dtBd6Zc/PPcMI40LQiVFyxAyTgdyBX4hf8E9P2XfgL+0rrPiuD4yeKZtLuNEW0+waZbXcFnLeCfzfNlLTI7OkWxQREAQWBYgEA/rx4e/4JH/ALN/h/xdoXjrwzrPiOxudDvrXULeI3ltPbyPbSrKgYPa7ypKjOHHFQlpcVtLn6nzX9vArMTkIMk9AAPU18B/ED/gp9+yB8PNXuNEufFr6/d23D/2LbSXsOfRbgbYG+quR70//gpl411nwJ+xr44m8LTy213qZstNluIDtaO3u7lI5wxHaWPdEfZ6/Db/AIJ3fsrfAT9pnWvFUHxm8WzaRPoi2hsdMtruCzmvBP5vmy7pkYukWxQRGMgsCxAIBbstEiXbZI/bzwD/AMFR/wBkT4ga9pfhmw13UtO1TWrqCztobzTLgbri4cRxoWhEqjLEDJOB3OK+3fiL8QfC3wp8E6x8RPG901loWhQG4u5ljeUpGCBkRxgs3J6AE1+bOif8El/2Z/D/AIy0Lxx4O1nxLbXmg39pqEEbXlrPbO9rKsqhg9rvKkqAcSDivpP9veHb+x18VpJ5N7f2NJgdv9YlHLbcOW250XwJ/bM/Z+/aT8RX/hX4Ra/NqupaXa/bZ0lsrm2Cwb1jzumjQH5nAwDmvcPiP8QPCvwq8Eax8Q/HFy1noOhQG5vJkjeVkjBAyI4wzNyegBr+dn/gigrt8evHQVtv/FNHJ/7fbev2U/b6aFP2OPiuu/cx0d++f+WkdZpCsb/wK/bI/Z7/AGlNf1Hwn8Iddm1W/wBNtfttxHJZXNqFg8xY926aNAfmYDA5rQ+P/wC1Z8Df2abnQbb4xa5No7a6tw9ksVnc3XmC2MYkyYEfbjzF69c8V+Hv/BFFpF+PHjvy13E+Gvp/y+QV6X/wXFLHWfg9uGD9n1z/ANDsqq7WoXe5+3fwk+Kngn45+C9M+KXw6vX1Hw5q3ni1neGSAubaZ4JMxyhXGJI2HI5xkcV8J/t+6v8AsM6hr/hHwr+13fahb6lYW1ze6WllHe4FveSJFKWa1RgSTbjAbkY967r/AIJZMv8Aww38PFzz5msf+nW7r8rv+C2f/Je/An/YtD/0snocmFz7w+HP/BNn9gj4r+DdI+IXgjStVvPD+tQC4tZ31C7iaSMkjJjkwy9O4BrwT47/ALNH/BLb9nLxLYeFviuNZ0m/1K1+2QRxz6jch4PMaPcWhVgPmQ8E5r9IP2CojL+xn8KY1O3OjR/+jHr8Y/8AgtXCIPj14FUc/wDFMrn/AMDbiqTSVx3P6BPgnrngPxF8JfCWqfCmeS78Ky6bbppk0ySI5tYFEUW8SgSA4X+IZ715B8Yv23/2XvgTrcvhP4geO7e216AfvrO1iuL+4iJ7Si1jlETY52yFTjnHSsP9iC4u7P8AYo+GR0iIT3w0ANEh/ikBkKg/U8V/L3+zp4B8PfH39prQPBHxs8Rz6NZ+KNQum1XUZZUiunuPLlm2mWcMomnmATLg/M3QnAob6gz+sH4H/tTfA74+6B4h8U/C/W5dVsvC4U6jJLZ3FuYt0bSDAmjUt8sbH5Qa4v4Rft+fsv8Axz8fab8M/hr4nn1HxBqqztbwSadd24cW8TzSfvJYlQYSMnk89OtO+Fn7KXwi/Za+F3xA034TC9+z+IbGWa6N5c/aSWgt5RHtIVcDDnPrX88P/BK0Fv24PAYzj9xrH/psuahu7uyD+m/49ftL/B/9mfSNL1z4v6tLpNnrM7W9s8drNdF5I03sCIVcjjuan+Dfx6+HP7RfhF/HHwm1GTVdDS7ksjLJby2z+fEqM42TKrYAcc4xX5Y/8Ft3Zvhh8N1KkKNZusZ7/wCjV6//AMEdWEX7JF5KqFmPiXUBx/1xtaqOjA+2/jn+0b8Hf2ZNI0vXfjDq8ml22szvbWrRWs11vkjTewxCjkYHc4rW+DHx3+H37RnhB/Hfwo1CTUtDS6kszLJBLbHz4gjOCkyK3AYc4xX5Uf8ABbFJz8MfhtLN/FrF5gf9uwr2f/gjq7n9kq5ijGD/AMJJqJLHt+5t6q+oH6qrDBb4L/M3Yf4Cpf8ASJv+mS/rUTzQWuQPnk7+v4mhVmmG6dtkfoOKPNgPQQxNiMb5O/c/ial2zPy52D0HX86qyXscY8uBd2Pypghu7n/XNtH+e1FurFctG5t4ht35x+NSxTLMNygj6iq22ztfvct78mniSeb/AFa+Wnqev5Uml0C5aYBhtIyDTY40iGEGBVf9zAd8khLe5/pUT36DiNC36VPK+gc1tyxNbRTffHPqOtTIu1QuScetZ4lvZPuRgD3/APr1KEvW+9IE+gzRy92HMXqKhiWRR+8ff+GKmqBla5gW4j2Hr2NUrKco32Wbgjpn+Va1V5raKYfOOfUdaAMu9tPKPmxj5D1HpVe3uHgfcvIPUVuxo4Xy5fn9/X61kXtoYf3sfK/yoA0WWC+iyPz7is4NcWL7Typ/I1TinkhfdGcVtw3EF6nluOe4P9KLgOSS3vU2kZ9j1FUXt57RvMgJK9//AK4qK5s5LY+bCSV9R1FT22o9En/76/xpXAngv4Zhtl+Qn16Gmz6aknzQnYfTtT5rKG4HmRnaT3HQ1XtoL6N9m7CD15H4UwIkW/tWCoCQfxFba7yoL8N3xTs4HNZk92zt5VtyTxn/AAqkrkSko7ktxckHyYOXPp2qNIIrZfNuTlqcAljHub55DTY7eS4bzbnp2FadDB3b13/Ib5tzdHEPyJ6//Xq5Daxw8j5m9TU4CouBwBUFzOIUz/EelQ3fRGvKl70h7ypH948noO9P3HAyOT2qlBCY/wB7L80rdM06eYxfu4/mlai3RD5tLsdJL5Z8uP5pWpny2/zN+8mf/P5UIn2cYHzzSf5/KlJS3+Zvnlb8/wD9VV5Geu7/AK/4I3yC/wC+uzwO3YVKrvINsA2J/eP9BUfl8ebeN9F7D/Gq8l3LM3l24x/P/wCtT3FdR/rUtM0MHzOdze/J/wDrU0S3E/8Aql8tPU0yK0WP95Od59P89au4ZuD8o9utK6NEm99CBYoojk5kk9+T/wDWqYiVup2D25NSKqoMLwKdUXKUbBSEgcniqpuN7bLcbz69hTWaOHBkJkkbp6/gO1Fg5ol2oPNBPyfOfbp+dRkSMN9wdi/3R/U1UlvcfJAMD1/wFJITnbc0ywUZkIFVHvoQdqZc+1VY7Wac77hiB79f/rVOZbS1+WMZb2/xqrC5nvsTI11IckCNffk06W6ih4Y5PoKpB7q7+5+7jqUJbWYy3zP+tMSb6E8UksrZ8vYvqetStKiHbnJ9Byaqqbi45H7qP9TSGaGD93ANzH0rMtMvKSwyRj2NNSSNyVUgkdcVT8mWUb7p8L/dHA/Gp1BC7YFCD1P+FBSZZpgRA24AZ9arny4TvlkJPuf6Cm/bVY7YVLmgLkj24MLRRnZu71DcW7yCOKP/AFY61ajMjDMihfxzT2IHU4oCxDgBsgcIMAe9RPuGIEP7yTlj6D/PAq7UXlAFmXhm70rDM26mCKtrb/Q4/lToYUtVDuN0rdBUsNr9n3Sn943ak3eQpuJ+ZH6D09qy82Kwskot182X5pD0HpTILZ5m8+55J6Cn29uzv9pueXPQelaFUlfcYUVBKzrgRjLHgeg9zVW4eaOPyolZmPVsU3KxViO7vMZiiPPc0y3swF8+54HXB/rS2tr5S+fMDkdBTWW5vX+b93GPWuV3eslr2KHS3zOfJtR7Z/wpUtEjHm3b/h/nrUgaG2PlW6+ZKf8APJpXMduPNuW3v2Hp9BRa+sn/AJAPDzSjbAvlp/eP9BTDFbRHMpMsnvyfypiS3V4fk/dR+vehri2tBshXc/f/AOuaOZW5n/XoirPYtZuZOABEPfk/4U0yQ22fMkJJ9Tn9KoBry7+78ifkKnFta243TvuPv/hQpt6xXzYWWzLMV0kzbUDfXHFW6oLcvJ8trHwO54FK0QX95dS59ugrWNR27/ghOJ/Nz8bNN8Q/t5/8FILr4D6vq0um+DfCFzd6fttW5htdMUm8kjBDp9onmBTeVOAUBBCYP6kf8Os/2I/7D/sb/hApPO24+2f2rqH2nfjHmZ8/y899uzZn+GvzW/YdnSP/AIKn/GGXG7/TPGGPx1QV/Q79su5f9TFxSlVjD3RKDep/OJ8F9P8AEX7An/BR+0+BWh6xNf8Ag3xlc2enFLk83FpqgH2OSQKFT7RBOQm8KMgOAAJCB/SnX85f7dX2g/8ABUj4O+ZhZTc+Eef+4q2K/oojhuQwaSbPtited6WQreZzPxB8W2/gPwF4k8c3aB4PDmm3mpSKTgFLOFpiCe3C1/OL+w1+zXaft/8AxS8f/Hj9pDULrV7C0u4zLaQTNB9rvLrdJ5RkT54reCMAKkbKeVAICkH95P2uuP2VfjF/2J+vf+kE1fnD/wAESgP+FF+PT3/4SQf+kcNaEHrfxO/4JU/sneJvDF7o3g/w9N4P1loSLPUrW9u5/LkA/dmWK5lmSSPOPM4DEZwwODXyt/wSE+KPjS317x9+zN4ouPtEHhhJNSso2Ys1s8VwtreRRk/8sjI0bAcANuPVzX74SRJKu2QZFfzqf8E4B5f/AAUk+MsajgW/icfh/bNtXF7G6cJu6/E6OfZpancf8Fefiz4xn1jwJ+zT4UuDb2/iVU1G+jVirXLyTm2tInI/5ZCRHYjkFgp/hFfW3wo/4JV/si+GPB9lpHjjw7N4x8QCEC9v7u+u4PMlI/eeTFbSwxogOdnylwOrE818Hf8ABSmNf+HjXwcUD79n4ayPrrV1X9AYLKdy8EVyzm8NyxWxsoqrdn84P7cv7NFv+wF8T/APx4/Zx1C50mwu7yTyraad5/sl5a7ZPK3t80lvPESGSRmJwwJIYAf0V/DfxxafEPwD4b8aRxrFH4j0yz1FFByuy8hWYAH6NX5If8Fpbk3HwF8CrIvzr4l6+32Oev0N/ZLsWb9lT4QSxck+EtEJH/blF0reVRump09UZqKT5Zn0XPYMn722JyO3+FeJfG39pb4Wfs4+H9P8S/GLU5dJ0/Urr7FBLFbTXJafy2kwVhRiPlUnJGK9mtr6SD5JPmT9RX48/wDBa54pvgJ4FmjIJ/4SUD3/AOPK4rGg4SlzUnbui53StNXP1v8ACXiLw38RvCOi+PPCs5n0jxDZW9/ZzFGjMlvdRiWJijgMpKuDggEd685+NXxo8Bfs6eDv+Fg/E/UX0zRPtUVp58UEtwfNlDFR5cSs3O084xXNfsk292n7L/wfeH+PwjoRyDx/x4w9a+TP+CwYf/hj8CQgn/hINN6f7k1NUo1ZO8WmiedwWjufevg/40+A/GfwhT446RfvL4QexuNSF2YZUf7La+YZXMJXzOPLbjbk44HSvh6//wCCu37HNrdfZ7XUtYvFP/LaPS5BGPr5jK//AI7Xo/7CFnpOvfsJ/Dzw3q9ut3Y6po95aXMLZ2yQTXE8ciHGD8ykjiuuuP2Dv2Q7zQbjSb74W6LBb3EZj3w2/lXKZGMrOpEob0Iauj2sU/Zp3tu+xnyN+8z1n4KfGv4WftB+Gj43+F3iGHxBpyP5MuwNHPBL18uaGQLJEccgMoyORkc1J8dP2gPhb+zf4Rs/G/xa1OTSNHvb6PTopY7aa5JuZIpZlTZArsBshc5IxxjuK/Dr/glCt38O/wBsz4tfCCzupG0e107UoXRjnzJdI1OG3hkfGASEllGcfxGvqX/gtFI8/wCzF4Xl6RjxjZAf+C/UK66VPljZPQUm5as+1/iL+3D+zH8K/Cuh+L/GXjSC3h8TWFvqem2kMcs9/cWl3GJYZfssamWNXU8NKEXORnINeOeAv+CpP7Hnj/XbfQD4nufD9xcyeVC+rWclrbs3YvOC8UYPYysoHc18y/sJ/wDBOr4Iat8I/DXxu+NdqfHeteKbC3vLW1vGk+xWVqUAhiEQYec4jABMmUAwFUYyeZ/4Kb/safAvwX+z/cfGX4aeFLPwjq3h++s45V09PJguba7kFuUeFTs3K7qwYAHgg5B41t1It1P3HjZbtFu5HHkEblwcgg9DTsy3fyx/JF6+tfFv/BPDxlqvj79jX4aa94iuXubi2s7iwLyHczJp93NaRZbviKJR6+tfaYMt39393F+prVPqap9RytFD+7tl8x/89TTymRvun4HboP8A69V3uooB5duAfeo47ea5PmTkqKdurHbqyc3WT5dtHu/lS+Rkb7uTPt2qaMKF2W44/vdv/r1Ksag7jyfU1DlbYhtLYjDOBiGMAe/y/pS77j+4v51PkUZFZ38jO/kf/9T97II2hXc3Msv6Uy5lI/0aHlz1NSyS+XGZz1fhR7f55qC1Ty4zcy8s3T8f8a6V/Mzo82TJGIVEEX335J9Pf/Co5H27bW26nqafNIbeP1lkpgAsodx5lahdwXcHdLNPLj5kPU1BDavOfNlOFPOfWnQQBgbi46dee9XArTnc42x9h6/WqbtsPmtsfzV/8FrTH/wvfwIIh8o8Nf8At5PXkPwx/ba/beuPhx4Z+Ev7M+h3cOmeELCKxaTR9F/tm7mk5YyStJBOqZJO1VQYHcnmvYv+C2fHx68Cgf8AQtD/ANLJ6/Xv/gn9Y6dpv7HPwwtdFs4rU3emefP5KCPzJpZGMkjY6s3djya50uZ6GKXM9D8uf+CnGs+N9f8A2Sf2d9V+Jy3Efi+7j87V1u7cWk4vXsYjOJYAsYibfnKbFweMCvsX/gj5OkH7Isp6yHxFqOB/2zgrxT/gttFHB8NPhjGvLf2tek/+A617X/wR6SJP2SJbiXt4i1EAf9s4KpWuUrXPtD9q6GWX9lv4xTXJxjwd4gwP+4fPX8+P/BHNJJP2sr9Iztz4Z1DJ9vPta/oH/axkmuv2YfjDjhE8HeIDj/uHzV/Pr/wR4keP9q/UCnBPhnUB/wCR7WrkndFu90frp/wUl8UfsueHfhn4f0b9pbwzq+vWeq3k0em3GhJB9usbmOMFpEkmmhADKQCp3q2BuXgV8A/Cf/gll8Ff2kPhdpPxe+D3xB8RaBoev/afssOuafaXV1H9muZbZvNFrNEh+aIkbX5GOh4Hqf8AwWtyfht8NT/1F73/ANELX59fAz/gpz8fvgD8JtE+DXgfQ/DdzpGhC5FvPe2l5LeH7Xcy3T7mjvIozh5SBiMcAZyckzLR2ZMtHZnk2tw/Fv8A4J9/tR3ei6ProOueD7m2aSWzdktdRs540uFiljPVJYnAdGB2tnByA1f1gfFb4a+Ff2jfhLrHw58VpI+ieKrNBvjOJIiSs0M0fbdE4V1zkEjBBGRX8sngT4NftJft6/H1/Fes6TeTN4kvIpNX1trVrfT7O1jCxHEhXy/3cKBYowSzYA55Nf1GftGeN9W+Df7Pfjfxj4H8qPVfC+i3FzZmVPMjSS3jym5O446U4O19Ajpc/BH4gf8ABGT9oPQdQnPgTxNoHiPTdx8gzzTWN4y/7cTRSRL+Exr4k1J/2lf2GPi4uhSaldeEvEml+Vd+TbXfm2d3BJyhZI2MU0MmCCrD1BAI4+yLL/gsv+03DF5eoeG/Cl5JjiVrS9Qk+pC3mPyAr5ZuYf2jv+Chvx3GuLpR1TWdSa2tJp7O2kj0zSrRTtUu/wA/lRRglvnZnYk43MQKnTpuRp0P6lNe8KeCf2rf2ZrXRvGFsyaR8SdBsL0pE37y2e7iju4ZI2PG6GXa65GCV5BGRX4R+Nf+CMX7Q+l39w/gLxJoPiHSwx8hriWaxu3TsXiMUsQ/CY1+5fxbvNU/Z1/ZP8Qat4Mki/tH4f8Ahjbp7TR749+n2wjiLx55GFGRmvwptP8AgtB+09HAIdQ8NeE7tlHD/ZL6Mk+rhb3B+gApysVKx8ZajJ+0t+wr8X10I6ndeEvEukmG78q2u/Ns7uB+ULrGxinhkwQVceoIBHH9Jv7V3jW1+IH/AAT18W+PYY/J/wCEn8I2upiPO7yxexwzBc+27Ffzq3UP7R//AAUQ+PA10aUdU1jU2trOW4tLaSPS9KtE4XzGG7yokBLfMxdiTjcxAr+jT9rzwdaeBv2CfHPhG0bdb6B4WisIeMZS2EUSHHOOF6UlbW5Ktqfkd/wRYSST48+OEj7+Gjn/AMDIK/Zf9ve1jg/Y4+KzSsN39jsB6Z8xK/mB/Zi0n9qDRb3XPjV+zLb6jLdeBBa/2m2nATt9nvDIVWW15+0QnyWMi7H24DEDG4eufHf/AIKR/tJ/Hf4aXnwh8bJpGm6ZemNdQfT7OWC7uhBIJBHK0s0qqN6gkRKmcYPBIIpO1gUtLH0r/wAEUPMPx38diLAP/CNdT/1+QV6R/wAFw0ZNZ+D25ixNvrn/AKHZV3//AAR5+AXjrwPpXi74y+LtMn0eDxNDbafpUVxE8U09vGTNLOAwB8piYwh/iwSOACav/BaD4YeN9f0L4bfEDRNJuNR0nQ21S1v5YI2l+zG6+zNC0u3JVG8qQbjwCACcsBS5bK7C2h9m/wDBLe5t4f2Hvh8CMv5msZwP+ord1+WP/BaycTfHjwMQMAeGsf8Ak5PXW/8ABKX9rb4lTeNvCP7Jc+naVJ4Rii1e4S6ME39oo22a92iQTeTt80nrCTg4z0r23/gsf+z1438b6R4R+NXgzTJtXtvDMFzYavFbRNLLBbSETRXJCAnyYyJBI2PkypPBJCbVhOx+gn7ARJ/Y3+FPTH9jIBg/9NHr8Zv+C2X/ACX3wN/2LK/+ltxXzX8Cf+Ck37SnwG+GVp8H/BK6Rqel2RkXT5NQs5bi7tFmkMhjiMc0asN7EgSK+M4HAAHjf7TGlftOa5faJ8a/2lbbUYrvx4Lk6Y+pL5Dm3szHuWK14+zwjzlMa7UBBLAEHcYJP6gv2INV0/Qf2I/hrr+qOILPTvDwuJ5MZ2RQ+Y7njngAmv5yrnSLr/goZ+19Npnww8NaX8Px4omuZ28vzNiwQK80t3dAEhriQD5vKRFZyMjJaQ/0VfsVaLa+Kv2Gfh74Y1BD9j1bw21nMf8ApncCSNsD6Gv5vNb+Gn7UH7Avxwi8Vafpl1Zah4dnuBY6ulo1xpt/akGJyHwYyksTfMhIkjzztYA1VgP39/ZZ/Yuuv2N/hJ8UdKu/FqeK28T2Zn3JZGyEH2a1mXHM027O/r8uMdK/Dj/glZ/yfD4B/wCuGsf+my6r1nU/+CyH7T2r6FeaDe+G/CJiv7eS3lcWV+JNkqFSR/p+0HB44x7V5D/wSylEP7bvgSQjOINY/wDTZc1IH6Z/8Fu/+SV/DX/sNXf/AKTV6/8A8Eb/APk0i7/7GbUf/RNrXi3/AAWz89vhZ8NpJuAdZu8D/t2r8y/gN8SP20v2SvhxYfGn4aWd0fht4uM7EzwG/wBIeW2ma2dpo0ObaXdEQHzGZFGAWAwG0B+nX/Bbwj/hV/wzXPP9sXn/AKTCvZf+COH/ACaNc/8AYy6j/wCibavwg/aI/ay+O37Z+v8Ah3TfGFpbzSaa0kWmaVolrMFe4uigcrG0k80sr7VAG44x8oGTn+lv/gnz8EPEvwC/Zf8ADXhHxpF9i129afVL62Iw1vJePuWKT/pokQRXHZgRzinYD7Z+zwBw4QZFR3Fu04wHwPShZzK+IhlB1Y9PwqUyLv2Dk98dvrT1QFeG1S3XeRvf/PSqsk11M/lqCnt/9etckDrS0KXVisZqwwWi+ZKct/npUZnurg4gGxPX/wCvV5raF38xhk1OAAMCq5uoWM2OwA+aZt59qvJFHH9xQKjmmEWFA3OegpDKYU33BAJ7CpbbBWRYZlUbmOBSBlYbgeKpbTL+/ufljHRf8aaTLenC/LEP1p8oXLC3IdykQLY79qWe5SEc8t6VTluUgXyrYfjSW9ru/f3PTrz/AFp2W7M7vZF6CYyxeY42VYqgR9p5b5YR+Gf/AK1OWRpGAg+WJe/r7Cs2iky7SEAjBqJZldyigkDqe1O8xN2zIz6Ui7mXNpgJLRNj2P8AjVY2N1G2UGcdwa6GiiwFG2mnb93cRkEd8cGoptOjkfdGdnqK0HdUXc5wKQSJs8zPHqaLARW9sluu1ST9as1kvdSXMnk2/A9aLmZYI/s8Z57n/PrWnKZua3GXdyZG8mLkfzNTRotnFvYZlfoP6U22iWBPPl6noO//AOs1bihJbz5fvnoPSm30M1Ft8z3I4bdi/nz8ue3pU006QLuf8B3qYsACT261jRqby4Lt9wfy7CpWurKfu6RLkTNJm4m4QfdH9aZCPOc3Un3R90VHNJ9pmFtH9wdcVd+Ue0cX8/8A61Mlakc83kpvb779B6VFBH5S+fJzI/QfWo4VN3OZ5PuJ0q0ZFCm5k6D7o/z60baDWuo2ST7OuW+eV+3+e1MVRbobi45kb/OKZCMg3lx+FQosl7KZG4jH+cUEtjQJr19x4A/IVoRokQ8uEZbuf8f8KQHf+6g+SMcFh/T/ABq0qKi7VGBSbLjC2oiptGScn1qKa4SHC43OegFMuroQDavzSHoKgjUWyG6ueZDUpdWU5dETFjEvm3J+ij/PJqEedenJ+SL+dRRxPeN9ouDiMdBTbi6aY+RbDjpx3qzJvqyw8wQi2tBk+vpS/u7NfMlO+U0393Yxf35W/wA/lWafNnk9WanYbdvUlZ5ryXaOfbsKvBYLIbn5c0jFLGLYnzSGs3DzP/fc0r3J+Hfcmlupp22DgHsKsxWaxr5lyfwqRUisY978uapF5buUL19uwpX7Fbb7lmS7kkPlW4x29/8A61PSCKAedcnJ/wA/nSlorJNq/NIahit5LhvPuT8v+f0qCvXceZZ7w7Ivkj7mrCCKA+VCu9+//wBc0gdpf3Vt8sY4Lf4VFLcJbr5UPLdz70D21ZM7xw4ed9z9h/gP61RlvLiZtkIxn0606K0mnPmXBwD+dXEMcf7u2Xce57fiaB6sqx2J/wBZctgen+Jq2r4G22j49TwP/r0SNFF89w2T2H+AqhLqMjcRDaPU9aTY9EaBic/NNKceg4FQmayiPYn8/wBapJa3Nwd0jED1ar8VhDHy/wA59+lQUhn28OcQxF/8/jVmJ53P7yMIPrzU6qqjCjAp1Wk+rGFNKq3UZxSkgDJ4FVEullfZCpbHU9BQ2luBcoqrLMEIRBvc9h/WmeY0Qw58yV+ij/PT3qXJFWLtFZ5CRfv7t8t2HYfQVGr3F4fl/dRevc1Dn06hY1KKzvMjg/cWq75P89aMrajzbhy8jdv8BR7QrlNDAzmoJLaGU7pFyarR/a5m8xz5Sdh3/WpXuRu8qEeY/wCn4mk5Ra95Cs+hJLCXi8qM+WPaqkOnqjbpTv8AQVcaUIoEnLHsOamByMnim4Rk7sLtIyLm5uQfLjjMYPGcUsVmoHn3h/A/1rWBBGRUE1tFPjzM8e9ZSo395u5an0KD3jv+6s0/SkWwlkO+4fn8zWqkaRrtQYFMlmSBN8h4qfY396q7/kHP0gfzr/sQpHYf8FWPi7Z3g8uSS98XpGrdSf7SDjH/AAEE/Sv6Lq/np/bE+Dfx1/ZX/au/4bb+CWiTa34fvJjqF+qRtPHazSxmG7hukixILedCWEuMIzYJDKpbt5v+C3HhCbRAx+F2oLqu3mAalF9nLY/57eTvxn/pl0rp5tLxRFtbM8w/bikj1H/gqn8H7awPnSRXfhBHVecP/ajPj/vkg/Sv6IprxInESgu57Cv56v2Pvg38c/2sP2sk/bM+MejzaBoFlMuoaeGjMUdxNBGIrOG1SX5zBCAGabBDMuASzEr+qH7av7TV5+yL8I7L4k6PoUPiS8u9Wt9NNtPO1uoSaKaUyb1VjkeUBjHOaxc5P3Y/f/kWordnpH7WiSTfssfF6FVzLJ4R10Ko5JP2GbgV+bX/AARKuo2+C3j+yBzJH4gR29g9pEF/Pafyr9GPg94sH7TXwA0Pxl4l08ada+OtHc3VpFJ5ixx3aNG8aSFRngnkrX4NeCPE3x9/4JQ/FrxRpPiDwtN4n+HHiSdYkuwzQ297Hbs/2aeC4VZEhuBG5EsLDJzjoEkpQqSlfT08wcUj+ngMrDKnP0r+dX/gmw327/goz8Zr+1/eW7WniV946bZNZttpz79q7Xxx/wAFmZNf8My+Gfgf8NryHxXqieRbT3s63AgnkGA0dvCpadwfuglRnGQR8p93/wCCWn7J3j34I6R4k+L3xetLjTfFvjNUgg0+4x9ogslbznlueSVlnlIOxsMoUbhlsDfmsrzItd6Hyn/wUvb7F/wUT+DOo3f7u2Wy8ONvP3cR61dFvy71/Q3c2CzNvjOwnr6GvyU/4KofsleOfjXoPhv4vfCS2m1LxX4NEkE1hbkfaLiydvNWS35DNLBKCRGuSwY7eVAbwn4f/wDBZy58M+HYfDfxt+G97L4r0qP7PdT2c624nnjG0tLbzoGhckfOAWAOcADgTOEai5ZBGTjqjvP+C06C1+CPgO3lceZL4iLKB1YJaTAn8Nw/Ov0c/ZE+3WX7L3wit7qFgB4T0TjHIzZREV+E/jvxR8f/APgrJ8XPDOkeF/Cc/hf4b+G52jkutzT29klwyfabie4YRxzXBjQCKFBkdBwWev6VPDehad4V8O6Z4X0hSlho1rBZwAnJENvGI0BPHIUCs1RUUowdrFud3do0bizjn+dflf19frX4z/8ABabTpIP2fvBN0AWRfE6Iz9gz2V0QPxwfyr9oI545cmM5A79q+Hv+CgXwG1b9pP8AZ01fwJ4UHm+ItKuItX0yIlQtxd2iyL9ny2ADLFJIqkkAMRk4zUSVCLVRlJ1GuQ9Y/ZBuIbj9lT4PNE4cf8Iloi8f3ksolYfgQRXxj/wWJvIIv2SorVnCyS+IdOAHqRHO2PyBP4V8E/s3f8FJvGn7I3gyP9n747fDu/urrwoz29s5kNnfW8BYuIZoLiPDBM4jcMvyYGDgGuA+PP7RHxt/4Ka+JfD/AMIvg/4DuLHQdLuxeSp5huAJ3BiF1fXARYoIokZgo/2m5clQNpOpdJIhJWuftb/wTxsWtf2NPhdNeJsH9myOAe4e5mIP4ggivs9Y5L5/Nm4iHQetef8Awi+HNl8L/hj4S+GlhMbmx8K6ZaadHKy7HuDbRCMysBwDIQWx716plQQPXpXNGkpa/Z/P/gdjVza9T+dL/gnvG0n/AAUv+NMcfAKeKfy/tqCvqj/gtLgfsueFY4x8i+MbIfj/AGfqNfLv/BPJiP8Agpj8awvUx+KQP/B1BX1B/wAFppAP2YvCsCdF8YWWfr/Z+oV6a2sYfZPtD9iRHuv2TfhKH/1cfhzT/wD0UK8V/wCCq5Mn7E3jJl+VFu9IA9/9Phr3T9iUBv2R/hJCnfw5YFj9Yh/OvBf+CrEpf9izxjHH/q47vSP/AEvhq3qi3qi//wAEtInn/Yi+H+84ijl1j8f+JpdV+gFxctMfIgHydOO9fn1/wS7ld/2H/h9bRj/lrrGf/BpdV+h8ca2oCqN0r/5/KrWiTZa0SbGRW0cAEk3L9hVsK0nMnA/u/wCNJHEVPmSHLnv6ewqWSRYkLv0FZuTbM3Jtiu6xruY4Aqokklxyv7uId+5qBQ97JufiJO1Nllad/s9vwo/z+VWo2LUbD5LzafLt03Ad+tM+23H/ADy/Spw0NmPLUbm70fbl/uVVl/KPTsf/1f3mk/0q68v+BP8AJq1uVnLn/VxdPrVa3Ux25kH+sk4FOnQ4jtIvxNdL7HQ+wkH7x2u5eg6UyMG6lM8vCJVie3kdEgiwEHWpjbqYhECQo9O9LmFzLcZH/pDeY3+rH3R6+9XKaqhVCjoKdWLdzJu5TuTMV2QrnPU022tmgQtx5jVdJA61HJLHCMucZpqTtyoak7WRWhtCshmlO96WW2Mz7nk47DFSx3UMrbEPNMlu0hk8tgfrV3lcq87jo7dYkKIcE9+9Vzp0Z/jNWZpxEgfGQakLgYPY8ZpKUlqF5bkQg2Q+VEdpPeqJ0588OK16ikmjix5hxmhTn0EpPoVpEeGPy7ZM56ms6O1lmfY4IHfNb2eM0tCqNDU2jznU/AfgC9mHn+GtMuZQc75LOF3z9SpOa6qxsLDRbVYreFIEH3UjUIg+gHFawhiVt6oAfWo/swMxmc7vQHtT5lsPmWxWEfmDz7v7vZe1cZeeAPA+t3X2i78NaZOQc+ZLZwu+fXJXOa7KSK4uZsSjZGKc8pJ+zWgx6n0qiivaW2naRAljplvHCB0jiUIo/AcCrXl4/fXjZ9B2FMLw2S7V+aQ9aqBZ7yTP69hTS6gl1JJ7x5Pkj+QfqaxH8GeH9Q1GPWtR0q0lvoxhZ5II3mA9BIRuH511cFrHCMjlvWrVQ520iQ5W0iRRQRwjEYxUtFZxuXnl8qDgd2qEmyNzRqj9qMknlQLux1J6VDcSM7C1h59T/n9aJXW0QQxfePU1SiNIyY9C8NaVqEmq2OlWkOpTDElwkEaSt/vSAAn861o4Xm/fXJ+X0psNusY8+4/AGjMt6+PuxCr22K9CXe902yL5Yh1PrTgxc+RbfKo6t/hTGbeRa23AHU1HPOtuvkQde5oEOmnWBfJt+vc/570RQpbjz7nl+3+fWmwQpbJ9on69hTwnmn7Tc8KOgoMxQkt0d8vyxdhTg5l/c2owg4Lf4VFmW+bC/JCOvvSS3IjAtrUe2RQBlWPh3wr4euZr3SdKtLS7uDmWWGCOOSQnu7KAT+NbCQy3J8y5OE7LSw2yxYlm5kPQe9WZZUhG+U89hUX7APwAv/PNB+H/AOqqT3gB8m0XcaaEnvDuk+SPsK0IoY4V2oMUtFuBUS0eQ77pt59O1XlAUYAwBQzKg3McAVVjuDM/7rhF6k1OrAllmWIAnktwAO9RyzGCPc3LnoKjV1YtdSfdThf8fxqC3BmdrufovT/PtTSFclXFshuJ+ZX/AM4qOJS/+lXR4HQUyMNezmR+I0qTm9lx0gj/AFNMgAGvG8yT5YV6D1qG4uwf3UXCimXV0HPlR8IP1qW0gVQbqbgDp/jVbakvsh0MCwjz7jjHQVKhNx++l+SIcgHv7moU3Xsu9+Ik7VN/x9N6W6/rj+lJvuUvIXJufmb5YR/49/8AWqXmUcfJEPwz/gKZkSLub5YV6D1/+tVVnlvpPLT5Ih1pCZN5zTN5FoMIOren0q3DCsIwvJPUnqafHGkShEGBVOeSSWUW0Jx/ePpUb6IrbVl0Opzg/d61RD/aXLtxCn61FO29lsrfgdzUkgDutlHwijLH2qrCbuKv+kt5snES9B6+5qndXLTttXhRTr24H/HtFwq9f8KSyh3N5z/dj/nVeZk9fdRZUCyt97f6xqr2sPmsbiX7o557mo2Zr25Cr07ewrUCK2IUH7tOvufT/Gk9CkrvyHKplfzW6D7o/rUssgijMh7VJVKU+bcJAOifMf6VmavRFedmitBGT+8k6/1/wob/AES0CD/WPTGP2i/CfwR/0/8Ar026Yz3XlL24H9a0MH3JrKPy4jLj524FJdkhEtk5Ldff/wDWatqB5ixjpGM/0H6VTtyJp5Lk/dXp/n6Ur9S2tOVFkRhVS1XpjLfT/wCvUEgN3ceV/wAso+tSM7RwGUL+8l6Dv7fkKVIJIrfZH99up9KYNX0IJS11MLePiNetWMBj9ni4jT7xH8v8afb2/kxFc/MepFTRxLCm1f1qblKPVj1UKAqjAFNkZlQlBk9hUlFSaGZa2kgkMtxye1SSWrTyh5j8q9AKuFlC7yeBzmqwvbdiFV+vHQ1VzPlS0HzQecBGG2KOwpsNpHAdy8n3p89wsADMCQfSlSYSQ+agzx0o1HZXIZLJJHLsxyafDbJBkryT3NPjmEsPmqPwqYEEZHepKSW5lyWDuxcybifUVYit/s0ZZBvc1ad1jUu/QUI6yLuQ5BqriUUncw5YrqSTLocn8qtOyWEWxeZXrVqJ4YpDl1BNFyOW2xmwW4INzdHjrzUgMl6f7kI/WrU1uJyu8navb1qvdLcPiCFcIe9SVaxDLcFz9mtBx0yKkWOGyQPL80n+elBKWS+VEN0r0qoluPtN0d0h/wA8UCHBJrgbpzsj/u+v1qvNepGvlWw4Hf8AwqCWae7fYg49B/Wr1vYJH80vzt+lRe+w99ihDazXDb24B7mtaG0hh5AyfU1aoqkrFJWCiqFzdmNxDCN7mmzTtaxBWO+VqlyQyWe7ETCJB5kh7ClabyI985+Y9hVWNVs4jNNzI/8An/8AXUMML3Tm4uDhf8/pUOTGkPXzr9st8kQqVpQp+y2Y57n0qKWdpmFtaDA9f89qkZlskEMPzytWd+v4ljwVtv3UX7yZ+p/xpHkS0Xcx8yZ/8/lTSVskLP8APNJVe2gM7G4nPydee9Jyd7Lf8hpDoYGnJubk/L7/AOelSmSS7PlW3yxDgmkO+9favy26/wDj1I8zSH7LZDAHU1GiX9alkm+O2/cWw3yn/PNOCR2v7+4bdI3+eKiZ47FNkfzynqaZDbNMftF2ePf/AD0ob15UtfwQW6jg9xen5f3cVXY41jHlwjA7tQWRY9zfIg7dP8/SqTTT3p8uAbY+5qm1DV6tk7+hJLdQwEiIb5D1P/16asF1dfNcPsX0FWYLSKDn7zepq5VKm5fH9wc1tiKKGOFdsYwKc7rGhduAKpveBpBBb/O579hSSf6RMIescfLH1PpT9okrQFyveQ9ZyyGeT5Ix0Hc1Xj/fsbu44jX7o7VC7G+uBEn+qSi5driYWkP3U/p/hXJKpfXf9X/kbKNtBQ0l/L/dhT/P51jSeHvD91qv9o22lWgvF4N35Efm4/66Y3frW5Lxiwtv+BGmXEyWkf2W3+93NZt2Tcn6v9EWtbWCa4S0T7Pbff7n/Peq9ramcmWU4QdT/eplrbG4k5+6Opq3NK1w4tLbiMdSP89KwXv2nNadEXa3ur5sl3m5byLb5Ik6t/QU2QLcK1jAo8vGHJGRjuPenNkYsrTj+83pUqqAPstvwB95v8967Fd7/wBeS/Uy2/r8TH0vw9oGiPKnhzTbaweU5mkghjjLn3KAZP1rTeeO3Jgth5krdT1596hluM4tbMcdMjvWha2qW4z1c9TRFub5Y9OvbyQnaKvL+vUZDbEN5053y/y+lZ+qaD4d1uSL+2tNtb+SE7o/PhSUpjuNwOK0Ly4aFVSLmR+BVWRvscW3O6aXqa1dSNK8V03/AK7kcrlqxzkMUsLYBEUc7eAAOwpX/fMLO34jT7xpmGtLcRr/AK+WiZhZQiGP/WP1Ncspbyn8/wBF/mbJbKP9eZHc3KIv2WDhRwTTbGFUU3Uv3U6VWhhM8oj9ev0qzdygkW0f3V4+prijO96s+myNmre5EydT0TSvFB+za3YwX0HXy7iJJUA+jgity1sbO0hXTtNgjtrSDjy40CJ9ABgfWpo4zboIo/8AWydT6D/61XkRY0CL0FelQovXm3e/+X+Zy1J9h3AHoBWcsuFlvD06L/n61NeyMsYjT78hwKpXpCLFap2q8RUte3T83sFON/mFoPJikum69BUtqNiNdyck9KLhceTaJ+NWSoMiRj7kIyfr2ruw0VCnyL5lSlfXuQzO0MW0f62XrTXItLfYv+sbrToVaeY3LjgfdFOS2kefz5sewrqulozO6W5HEn2WPewzLJwBV2KLZ8zHcx6mkMKmbzWJJHT0FWKzlK5lKVwrKmiuLqUcbIx0zWrSZGcd6IytqhxlbVFSWBjEIYSEXvTorcQxFIzhj1ND3UEbFWPI9qlSZZI/MTkU7uwruxU+wA/fkJNH9np/fNSRXkchYdMetT+dF61fNM0vM//W/fgIoAGPu9Kkqq87R3CRsvyP0PvVe4d4J1lySh7Vai2Wotl/cpbaDyO1V3ukSYQsDn17U2YY23UXOOvuKju4hNEsqc4/lTSXUaS6jruaaHBjxg/zpZiZrbzIiQevH6ikiYXduUfqOD/Q1DZSFHa3b8PrV2080XbTzRNayC4gMT9RxUjL9ogMTfeHH4iqDZtLnI+4f5GtFsI4lH3Twf6Gk11QmuqMRWaGUHuhrSvkEsIlTnH8jUV/Dtbzh0PX61LYyCSJoW5x/I1be0kW3tJDrZhcWxjbqOP8KW3JkgaF+GTj/CqkJNrdeW3Q8f4Vbk/cXIl/hk4P1pNdhNdiwHJjEncdR/OiWNZ49vr0NH+rl9A/86YreVL5TdG5X/CsvNGXmiC1kIzbS9R0qJzJYyZXmM9qs3UBkHmR8SLRFIl3EY5PvdxV36l36ljzA8fmRfN6VAl5Ex2tlD71TRnsptknMZ/zmp7q2Ey+bFy386OVdQ5V1NGohGqg+WApPcVQtbvH7qX8DV2WRoxvxuXvjqKhxadiGmtCitg3mZkfI/U1pKqou1RgCmRzRyjKH8Kmok29wk29wqpcysu2OL/WP0qZgzOOflHX61U3bPMupBz0UGhIERXUpRRbIcu3U0jt9ji8tf8AWv1PpTbUZLXUvRf502BWubgySdByf6CtTUliAtITPJ99ulEEYAN3c/UZpwAu5jK/+qj6e9VpZGvZhHH9wdP8aSMxw8y+m9EH6U+acKPstt9CRSTyrax/ZoOvc0lpGsUZupe3Sn5j8yZmFjDsXmR6jtoFRftM/QcjNEMZuHNxN90UZe9m2jiJKBD4wbp/Pl4jToKaS17NtHESUlxKZWFtB0HFPmYW6C2h/wBY/WpuAy4nyRaW304qaGFLUAY3Sv8A5/KmxxraIABvmfp/n0p7N9n4H7yeT/P5Un2RmOklFuOfnlf/AD+VJFal2865+Zj29Kkgt/L/AHkh3yHqf8Kt1N+wBTGdVIU9T0FJI4ijMh/hFZ0Dtte8l9MCpSAZfStJKLdOcfzqZk8tEs4ur8sfbvUFmoAe8l7Zx/WpYXKQyXkn3n6f0qwGXB82RLSLgDr/AJ9qLo/cs4PxotQIYXu5OS3T/PuaW0H+svJP8+tBmPlUoi2UPVup9qhvJhCgtIuw5qdX8iF7uT/WSdB/IVlIjzy46ljTRTJ7S3859zfcXrU00jXcwgi+6P8AOaddSC3iFpD6c/596ei/Y4emZZOAKV+pNuhI4DFbOHhB94+3p+NOwJW+zx8RR/e9/b/GmENbxrBGczS9/wCZqK4YW8QtIeWfr+P+NZgNndruUQRfdH+c1qxRLCgjToKhtbcQJg/ePWrVNspLqQXEwgiLnr2HvVEn7JBubmWX/P6VIrfaLot/BD/OqRJvLrH8H9BSBk9sBb27XL/efpTlP2W1Mzf6yXn86bKRPdLbr/q4+v4f5xUOoS75vLHRP51oTsUlDOwUckmtK6YW8C2yd+v+feo9PjBkMzdEFNTN3d7j0zn8BQQlZFqBPs9v5m3534A+vSr8aCNQvX1PqarIwmumP8MPA+pq9Us2SCs2KTEU94f4zx9BwKuzKzxlUO0njNQmGJLcRSH5E60IGUrEBElnbt/+uixikMxmkBH19TWpGiRoFjGBUlFyVHYrLGSJA55cnp6dKWKBIo/KHI7570+WQRIZGyQPSormVoYxIgBGRn6VJZaphZVIDEDPSqd2XMIlicjHPHpTsreW2V4P8iKBX6ElxcpbgFwTn0omlcQebBg8Z59KjwLu2Kvw/Q+xFV7GUjNtJ1HT+ooFcntpjcxEMcMODj3qCzldJXt5myc8Z9ahH+h3eP8Alm38j/hUmoRlWW5T8f6UE67l9cKxiPQ8j6dxWFcw+RKU7dvpWyr+fCksf3hz+PcVFdxC4gEsfVeR9KaYSV0OUi7s8fxYx+Iqvp0u1jA3fkVFp8xSTy26P/Oi7Rre4E8fQnP496QdmXIP3NxJB2f5lqzGcBo/Tp9D0qvc/PElzH1j+YfTvUzMGVJ16D+R60FrQmBDgg/QisxCbKfym/1T9D6Vbkbym87+E8N/Q1JNCs8ZRvwNANFO6SSJvtMHH94Vat51uE3Lwe4qvbSsjfZJ+o6H1FVpoXs5ftEP3O4/pQMuNeJHJ5cylD69RVtWV1DKcg1VdIr6AMvXsfQ1nwyyWkhilHy9/wDEUAbPlpu8zaN3rVC4spJZN/mcH17CrxYlN8WG/rUUd3FIdudrehpMB8MMcA2oPqanoqOQSbf3ZAPqaYDZ5RDEZD26VTed4IfMlOZH6D0qZ08yZQwxHFz9T/8AWrPBN7dc/cH8qzk2BJAot4jdzcuelJaoZXe7n6Dp/n2qK5drq6EEfQcD+pq1Mu9lsYuAOWPtWVwIlU30xlfiJKZcTtO4trcfJ047/wD1qddzhALW3HA4OP5VIoSwh3t80r1L7feaCs0dhFsT5pTTYFEMbXk/Lt0zVW1ha5mMkpyByTU0jPf3Hlx8Rp3qebqvkOwyGKS8mMsn3e/+Aqd2N1IIIOIl6kU2d84srbp0P+f506aRbOLyIvvHqajRJ3+f+RY24kyRY230OP8AP50+R0sYvKi5kPU02FVsrfzXH7xugogiCg3lyfcf5/lRr8/yQCwQCJftF397sD/nrVlnCjz7jgD7q/5700ttH2m54/ur6f8A16IoHmfz7n/gK+lXFW92P9ebB92QrFLesJZvlj7CtNEVFCoMAU+iumFNR16mLlcY7qilnOAKoX9x5cOxeGf+VRLI13dbf+WcZzUO37bek9Y1/kP8a46lVyVo9dDeMLO8h0A+x2/nMP3j8KKdMTa2whB/eS8sf51KjC6ujIf9XB0+tQQD7XdtO/3Y+n9K5+ijD0X6svzkPP8AoNrgf62T/P6UQj7FbeaR+8k6CoV/028z/wAs0/kKuArNO87/AOqh4H17mnHV3j6L9WU+z+ZET9gt8nmaSsuKN7iUIvU9TS3EzTytIfw+laKgWNtvP+tk/SuR2qS/ur+vxNdYrzY26lWBBaQde5qRV+xQiOPmaWobSMKDeTdB09zU8b7Fe+n6n7o9q6Y6++9O3kiHpp/TY7BgUW0PM0nU+nvUV1KIUFpByW6n6/404MbWE3EvzTS9KWwtjn7TLyW6f41TvJqnHS/4L/Nk6L3n/wAOyxZ2wgTc3326+3tVxmCKWbgCnVnXjNLIlon8fLfSu92pU7RRzK85akMTBme/l6DhRUVqpnuGupui8/5+lJfOGYW8X3U7D1p1x+4gW1X7z8tXkNq7vtH8WdiWnr+RLA3myyXkn3F6VmyyNK5kbqav3f7m2jtl6nk/5+tUYIjNKkfY9fpWFe7aprfr6suFtZl6L/RbRpz9+TpUdlEMm4l+6n86bfSGW4EEf8PA+tWpVx5NivflvpW6S5tNo7ebIe2vX8i1bguDO3WTp7DtVuiivchHlVjz27szv9df+0A/U1Tg/wBKvjIeinP5dK0ILdohIZGy0nUinWsdsoLW/wBCa8/2UpOPN3v/AJHZzpJ29CrCfNvpJccAYB/StMKozgdetKc44qpBKZ0dH+V14OK76VNxT1OaT5tS2SAMmmGRdm8cj2qjazMHMExye2ali/cSmA/cflf6it3GwuWxJBcpPnbxj1qslzILnypcKOn+FQyA2l0JB9xv8mpr6LconTt1+la2V/U1sr+oy7Z4Z0mDHB7VbZhhLheg6/Q/4VH/AMflp/tf1FQ2MuQYX/D/AApPb0F09BNQhziZfoaZYS7WaI/x8j61eRQQ1u/bp9KxmDW83upqo6rlKjquUluo/LmOfutyKr/L61tyRLdxowOO9Qf2cv8AepKeglU0P//X/e1x9ptsj7w/mOtKMXdrg/e/qKuBVBJA69aokfZrjd/yzl/Q1qnfY1TvsR2Ux5t37dP8KniPkSm3b7p5X/Cq15EY3FzHx6/WrLgXVuHThhyPrTeupT117ldgbOfeP9W9PvIipFzF1XrUsTpdQmOTqOv+NJbsVJtZuSvT3FF+or9RJ0F1bh069R/UUyzlEsRhfnH8q8K/aI+Pfhr9mH4Yaj8VPF2n3mqaTYTW8JhsRGZy9zKIhjzWjXAJ5+bpXhX7OP7fnwO/aMh1zUNInbwedDlgRodeuLS1kn+0BjuiCztlRtIJ7EijyK/un3kFEkbQSdRx+HY1kxs1tcfN2OD9K5AfGD4SytHJD410R2PAUalbZOe2PM613t7CJUE8fJH6iiMujJi+jC+h3oJk7dfpT0IurXafvDj8abZSiWIwvzj+VQR5tLny2+4/f+VPy7FeXYswN50Rjfh04Prx0NSECeMo3Dr+h9az9TurfSIZdYvZkt7W2R5J5ZWCRxxoMs7McAAAZJPAxXFSfGP4R8TR+ONCJHUf2na8j/v5UvuiH3R89/t6/FXx58G/2UvGvxC+HOqHRfE2ktpot7sRRTlBcahbwSYSZJIzujkYcqcZyMHFfLn/AASx/aL+Nf7ROgfETVPi94lbxHc6FdacloTbWtt5aTxzmQYtoogclR97PTivd/21vjx+zdpX7P2sT+P47D4kaHc3FlDPothqkSTz/v1kjbMMokAidVY4PbnivPP+CaPxE/Z0+IGh+O5f2ffhtN8OobK408ahHNeyXn2p3SbymBkd9uwBhxjOam9tUTe2qP03VoryLDDkdfY1Wjkksn8mXmM9DViaBt3nwcOO3rSq0d3GUcYI6juDWif3FX+4bPaxzjzIyAT37Go7e4eJvJufl9Ca/HbxV/wVdubTxV4us/g98HdY+IHhbwPJINU1mK5kghhijZ0NwyxWlwIoW2M0bSupKqSQMHH6Nfs5/HvwV+1B8J9M+KfgyKe0tr1pYJ7W5x59pcwnbJExUlT2ZSOCpBwDkCb9GF+jPa7u02nzofxAqWzut+IpDz2PrSwtNA3kSAuvZhTbixD/ALyH5X9Kd+jHfozSpjxpKu1xkVFCJTHtuAM9PrUZinjb904K+jVnYzsJNbsbfyYeAPWoWVoYUgT/AFknWtIZxz1parmC5j3jiGJbaP8AGnriyt97f616tG1iMwnOd3WqF7FcvIXK7lXpimn0LXYqwRNczbSevJNX5V+0TLbx8Rx9aSH/AEW2Mh/1knQfyociytto/wBZJ1pt3YXGXUm9haQ9Bx+NPndbOAQRn5j1NNtEWKNrqTt0qrGr3lx83fk/SpJsWrVRBCbmTr2/z70+ICFTeT8s3QVKwE82OkUPX0J/+tUSn7bcbv8AllH+tK5BIrGJDdSjMsnAH8hU8EJTMknMjdT/AEpsQ82Tz26Dhf8AH8auVLYBUMsixLub8B6mpqz2/e3yr2jGaSAjv5G2JAOr9aZdDYkVnH1NKn+kX5btH/T/AOvToCJrqSc/dj4FXsAlz/yyso++M/5/Wm3f7yWO1ToP8/yp1sfMllu26Dp/n6U2z+Z5bqTt/k0wG3zZaO1j7Y/+tVpkH7u1XoOW+g/xNU7JTNctO3bn8TVp5dkMlz/FJ936dv8AGswKN9N5s20fcXj/ABqxbqtpAbiT7z9BVO1h8+YKeg5NT3cjXFwII+g4/GgXmFnGZpTcSnhOc+9Wo282R7uThE4X/GmTDaq2MPU9TT5FDyR2cf3U5b6elVcLAH8tHvJfvN90e3amWMTSObqXknpUN2zXV0LdOg4/xrYRVRQi9BxRcY+ql1N5UBdep4FOnfBSIdZDj8O9VJj597HAPux8mpAZN/o1mIh9+Tr/AF/wpLQCG2kuD1PT/P1qO7EtxOVjQkJx7Vda3Z7VIM7Omf8AP1oJsVtPH+snft3/AFNZrMXYsepOa34LdI4TFncD1qKOW2jmEKR7T0ziqSb2Jdla7GRxOtjsjHzydfx/+tUltB9mRjIQCe9F5LNFhoz8v9ae4W7t8r17exq+XZsXMrtLdD4I4ooyYvmB5z1zSrL5sRki6+hqhaSmJ2ik4BP5GrmPJm/2Jf0P/wBem420M4z5kmJbT+ehR/vL1p0Xyg28nOBx7iqlwjQTCePoatnbcRh0OGHIPoaGuq2HFvZ7ogDtaP5b8xHofSr4IYZXkVXVluEMUgww6iqp86zbj5o6bXN6kqXJ6fkaLoHUo3QjFU7YFke2nHKcfUGrMU0cwyh/CpMDOe4rBq250Jp6ooWhID2kvJT9QarwsbS5MTfcf/INW7pGRhcx9U6j1FNuYluoBLHyRyPp6UBYfL+4lE/8DcN/Q1DeRMrC7i6r1p9rKtxCYpOSBg+4otpDG5tJeo+6fUUFCzIt5bB069R/hRauLm3MUnUcGmqPsc23/llIePY0TKbeb7Un3Dw4/rQBXtHNvM1tJ3P6/wD160B+6l2dn5H17/4/nVW/h3qJ4+qdfpU0UguoOuGH6Ed6BLsZl3EYJspwDyK0mAvbTI6nn8RT5IxdQFG4cfoaz7CUwym3k4z/ADoFYm0+XKvA/bsf1qa2PkStat06r9Kr3aGCZLqPpnn/AD71ZuY/PiWeL76cigaJFAUmB+h+79PT8KjiY28n2eQ/K33D/SnRSLdwhhww/Q0pCXURjcYYdR6GgY64txOuOjDoaht5y5NvOMOPXuKSC4aN/s9x98dD61PPbpMOeGHQjtQBReOSxk82LmI9RVsrBexZH59xSRSsx8i5GH/RhVOeCS0cz233O49P/rVmAqNLYvtk5iPerFzbJcp5kR+bsfWiC7hul8uQYY9j3qJg9gfMX5oT1HpR+QEFrdvA/lTZ2+/atsEEZqlPax3Kbx8jev8AjSWkdxCPLlwVHQ5pq60AukBhg8g1AtukSv5A2FqbLDLu327bT3B6Gpo/Nx+9Az7VW+4GfDCbNJJpeW6DFJuNrbmZ/wDWy1rVVuLaO4xvyCvTFZONvhKT7mdZRKqm7m6Dpn+dVJZJLmXcep4ArTvYJWRY4R8i9hUFlDtZppRtCetc8ou6gjRdx8w8iFbSLmSTrSSstlCIY/8AWP1NOhON9/L1P3R7VWtozdXBlk5A5NEn0ju/yKS7liELZwG4k+83QVXs4jcTmaXkJyc+tMupjcT4TkDgVeeMoiWUR+Z+WPt3qFZvTZfiO3caoF3MZ5OIo+nvT0b7S5nfiKLoPU+tRXDbnWxg6DrVgxh3W2T/AFcfLe57D+tWtXb+m/8AJCCJGuJPtEo+QfcX+taFFNJCgsxwB3rrjHlMW7gzBQWbgCqU1zi1aUcbuFpmoFmWOBeshqC9G5obWPt/+quWrVa5kv6bNoQ2uEZ+zWJk6PJ0oX/RLHd/y0l/z/KluFEtxFaJ9xev+fpRL/pN6sQ+5H1/z+lczVtI9NF69TXff1GS/wCi2IiH3pOtLJ/otkI/45etD/6VqATqkf8AT/69MuCbu9EQ6Dj/ABrOTtdx9ENdL+pLApgtdy/6yY4H49P8ajvWEESWkf1NXPMiNyQSALden1/+tWK7PPMT3c1NZ8keWPp/n97HBczuy1YQgsZ5PuR8/jTSXvrnjgfyFWLx1t4UtI/xoQraWnmD/WScD2//AFVHIl+7ey1ZV/tdXsSOBPOtrH/q4utPJWeYs3EMH5E1Fg2tsEX/AF01NvCIIEtY+p5Nbylypyl6v9EQleyX9d2MUNqF1ub/AFafy/8Ar1uAY4FVbODyIQD95uTU08qwRGRugrroQ5Iuc93qznm+Z8sQaRUDMeiDms23cqkt7J1PAoumaO3WH+OTk027DJHFbRgtgZOK56tV3b7fmzeEencisY/NuN7c7eT9aRD9qvg3bOfwFW7O3lSGQMNjNwM0+2tVt5CWcFiOlYU6EuWCt1uy5TV5Mzr2Tfcv7cflVjToyA82M4GBUk0lpbSEGLc55596s3Mkn2fzbc+/4VUKSVWVSTu10QnL3VFLcq21pKs3n3GB3/GrcccJmaZW3t9elQWk4u4jDLye/uKzwXsbnnoP1FNThTjGUVePfzG4yk2m9TajuFkleLBBX1qrFdSfant7jHoMf570+4A+S8h5x1x3Wob6ETRi4i5IHb0roqSmldPVa+qMoqOz6/mT8283P+qlP5H/AOvUNwklrL9pi5Q/eFSW0yXkBjl5Ydf8adFIUb7Ncc/3Se4qfdklZ6PZ9mGqevzHi6jdFkToTg+2ajm/0e5Wf+F+DSxWYhmdl5Rlxg1aliWWMxmvRoylb31qZPlT93YoXsZVluY+vepzi6gDpww5HsRTYGDRvBN1Xg/Sq0LG1uDC/wB0/wCQa6fLsV0t2Lny3kGD8rfyNR2jkg2svVP5UTZt5fPX7j8MKdPHuC3EH3hz9RU+RPkQQ5trkxN91un9Kbdo0Ewnj/i/nVmRVu4Qy9e319KVCLqAxyfeHB+tO/Uq/UezCRFnj5I5/DuKr3kQljWdO38qjs5GhkNtJx6fWrijY5iP3W5H9RU7Mn4WU7GcIDG5wOorQ+0Rf3qx7qAwycfdPSqtbWT1NOWLP//Q/eyG/VuJRsPr2q78kg7EGqslrDON8Z2k9xWe0VxanK5x6jpXRywlsBtFVK7O3Ss6LdaTmJ/9W/Q02PUHHEiZ9xVtbu3kGCcexqeWa3RadivcxvBILqEf7wqZwLiJZoThhyP8Ksgo44wRVSOKS3lxGN0T/pSuUmfMP7Wnw4+Hnx2+B/iD4R+OvFlp4QXVRBLFe3EsSm1uLaVZo5DHK8YZSUww3DKk4IPNfiZ4c/4JDDxnPJB4P+O/hrXHj5xZRfaDt9SIp2xX03+2L/wTH+MX7R/7R3iX4u+HfEug6VoWsR2CRRXL3T3im2tIoJC8ccBjGWjJGJDkeh4r8rv2lv2Jfjt+xqui+Ntd1C2utLu7nybTWNGnmU294FMiRyb0ikilKqzIRkEA4bIxWRkfd2lf8EVvHuma1Z3U3xO0xltpo5cf2fN8+xgcf63viv6C21zRbe5NnJqFujltvlmVQ4b0xnNfAX/BNX9ojxN+0f8As6Cfx5cNeeJvB96+kXV67b5buNIklguJO/mFJNjE5LMhY8mv5+/j4G/4eDeK1k5P/CfEH/wPFVoX7p/YNPE9tKJox8uaqXOsaFMfs51C3W4B2hTKgbf02kZzn2reAJBjk5Hr61/HP8eFCf8ABQrxSq9B8QG/9OAquYpyP6xvix4Xb4jfCHxt8PWvotMl8SaJqOli6mG6OA3ttJAJWGRkKWyRkdK/BG2/4It+L72Vks/i1o9wFxlorKVwM9M4l4r9fP2/bYH9j/4qzrwRo0mff51r+XP9mWL9prxjqOtfBX9m651CKXxqludWSwcW6m2tC4SS5uuDDCnnMHIZQ+7YdxIUp2Jdj7v1P/gkYmi6omiar8ePDFpqEhwLaWPy5/8Av004Y/lX6pfsH/sW67+yBovi+z1TxTa+JX8TzWU8L2sDwCMWySgg7mbO7zOMelfhn8c/+CY/7QvwF+F198VfEl9ouq6fpKpJf2+nXE8lxbxyOE8zEsESyKpI37TkdcEAkffH/BGf4+eNfEP/AAlnwI8S6hLqul6LaQ6ppInkeSS0i8wQTwxlycQ5aJljGApLED5jS2BaH7lya9pdowg1O7htJWHAlkWPP0yanvLzTbezOq3N1HbW6Ju89nVIwp6EseMV/Ov/AMFuwP8Ahafw1I76Nd/+lIr50+E/7Mn7a/7c3gfw9cXes/Zvh/4VtoNM0abXLiS208Q2aeQBaQQROZWjVdjTeXyRtMhIIBfXQV+x9g6V+xB+0N4Y1X4m+C/2RfjN4Pu/AvxIEttqVpNdrLeR2jeavlSCK1uthRJniMsTKzA5KqQu39Vf2Q/2dNO/ZJ+Bll8Or3WItRu4557/AFG+I8iBri4IB2BjkIqqqgscnGeM4H8snx0+Anxq/Yl+KmlafrOqpYaz5I1HStX0W5lRHQMULRSlYpVZSCrKQD9QQT/RnfWvjX9vH/gnrZafpV1Zaf4l8eaVYie4ui8doLuyvIjct+6R2AZoJCAFOCQOnNFpEn2ZN8Z/hLDfDSj410T7af8AlidTtQ//AHz5mf0r0P7VEsaSbgwcZG3nIPQj2r+VX44f8Eqfjf8ABb4Z6z8TW8Q6L4itPD1u13fW9m08c6W8fMrx+bEqyCNfmYEqcA4BPB+jf+CNPxr8X33jnxL8BdZ1Ka88PrpLaxp8MzlxZzW88UUscOT8iSifcVHGVyACTm0l9oD+hPz7m5O2H5B3/wD11w978V/hRoV2un6p4z0e2vXOFhm1C2SQn0CFwa/DL/gr/wDtM+PdK8daR+z14J1efRtBj0uPUdW+xyvBJeT3UksaW8xUgtDHEgbZ0Yvlgdq48C+Fv/BIj49/Ev4f6L4+l8S6Docev2cF9a2tw9zJKILiMSR+aYoSisVIJClsdznIFOXRLQD+nKz1611mBbnSLmK7gb7rwOJAfxUkVlax4y8I+GMv4r8SWOj4GSLy8ityB7+Ywr82v+Cd37FfxU/Y/wDEfj28+JGpaRqkHiK3sIrRtKnnlwbZ5i/mCaCHbxIMYz3rx/8Aa7/4JjfFz9pX9obxL8XtC8UaJo+kaxFYJBDdfaXuAbW0igbeqQlQC0ZIwx4x9Kbk0tFYD9jfD/xA8D+LI5JPCXiCw11YgC5sbqK5C56ZMTMBmuojmmkPEW0epNfxafFf4Y/Gj9hv46waFcawum+KdFSDULDU9Knby5YJSdsiEhH2ko0bxyKM4YEFTk/1Oap+0NqkX7HUv7R9laRDU28GjxBHAQXiF49iJxGQDnyxKcHnpnms4q+yE3Y+rb25sbSMTX8scCKeGlYIM/U1nST6dewNqEN7E9vHw0gdTGMdcsDgV/HT8HPhR8dP+CgHxtvtGuPE/wDaGvm0l1O+1LWriV44baORIyFCrIR80qrHEgCjp8qjj9uZv2atf/ZV/wCCbXxd+GPibWbbWr17PVb8T2YkSLZPHEoTEgByPLOfrUodz9Vm1LT9QItdLuYbnyxuIikWQ46dAc1fhU2ttv2/vX4A/lX80v8AwRUkSL9o7xk0hwP+EUn/APS+zr6o/wCCxf8Awu7w3oXhT4heEfGl1o/gS4kXRb3TbK/uLaSfUJhPcpLJFFiOSPyYiuWbIIHy85p62Kv0P2M8R+NPB/hS3+z6/rtjpZxljd3MUH5+Yw60eHfG3gjxTCsHhLxDp2sl+WNjdw3PHc/umb6V/J3+yh+wJ8TP2wPDGteN/CniTS9Is9K1D7DP/aLTvPJMYlmLARRuCMSDksDnPFR/tK/sUfHb9iJtA+IF9r1tPa3V55Fnq+h3E8E9reKjSKjb1ikjdkRmUoSMKeRUBc/r9keKCIyOwjjjGSTwAB6+1ef33xf+E+l3IstT8a6JaXDHAim1G2jcn/daQGvz+/Y2+L3jj9s39hzxd4c8SXcMnjOOz1XwnLezkhbiSaxAtrqfapIyJwJCASSjMBk4r8y/F3/BGn9oXw34R1HxFpvifQNbvtPge4+wW73Mck/lruMcUksKqXOMKH2gnqRQSf0zWWpW2qeXdadOlzayJvjliYPHID0IcZBH0qSNtiXFyepJx+HSv5cv+CSvxy8Y+C/2lNL+EaahNL4V8bw3sUtk7kwRXdvbSXUU8aE4WQ+SYyR94NznAx+t/wDwU+/aC8XfAH9nG3j+H962meIfGOoppaXcTFLi1t/KlmuJYXBysvyKgbqu8sMOAaAPurWPH/gTwbbyN4p8R6bo0p7Xl5DbnnpxIw+tX9E8V+F9e0vzvDusWeqLJzm0uI5xg+8ZPav5Qf2Z/wBgf42ftheHtS+KOm6/p+n6Z9vktHvNUluJru5u0VJJGAjjkJADjLOwJPQHkj9AP2Yv+CW/x1+Av7SXgj4n69r/AIf1bQNBuZpbgWk90LnZJbSxDEctsqHlh/H0qrgfu9P+4sUh7ydf5mkl/cWCJ3k6/jzSXiSz3KR7DsGBn69aku4ZJ7iOPafLHU/zqSrBEhjs1jH3pj/P/wCtUOoSDesC9FFaRQtcBiPlQcfU/wD1qz3sZ5pzK5ABP44oJHQ4trIyn7z9P6f402zRYYmu5Pwq3c2vnYy+1UqRoYZ0CA5VewNAFO1O1JLyXq3Slty0cEl03LSdKkae3jXyNpITtVoN+53QAdOBVuLW5CmnoijYQspeaQEE8DNatUre6807JOG7VTu45I23biVPTJ6VShrZmbqe7zIuskcMpuZXPPA9BT4vJYGaEAk55qOF1uYNr9eh/wAapwu1rcGKToev+NUobrqDqWafRmjBMJgcjDLwRVis66VoZBcx/wDAquxyLKgdOhrOS6ouMvsvcpMTaT7v+Wcn86W7gEq+dHyR6dxVySNZUKOODVKF2t5Ps0vQ/dNap31W5lKNvdezJIZFuoCj9eh/xqrC7Wsxjk6H/OammRreXz4/unqKlliS6jDoeex/pTTS9GS036oiu4Mjzk6jr/jUkEq3MJR+vf8AxqO1mKn7PLwR0z/KmTRPbSefD070W+y/kTf7a26ltfnUwTcn+Y9apKXspcNyhq78lzGGU4I6HuDRlZQYpR83p/UVCdtGauN7NP0EliEwEsRw46GmRXCyfupRsfpg9DUQEtk39+I/pU8kMV0gdTz2NOy67Epvdb9iGW0ZD5luce1NivSvyTjp3pFnlt28ucZFWilvdLuHPuOtU/7xCV3em7PsTpIkg3Ic0qqq8KMVlSWk0J3xnP0601L2VDh/mpezvrFlqtbSasSTxPbzi6hXIP3gKmuYRcxCaA/OvKmnJewt97K/WrKNGw/dkH6Vi4tbm6lF7MqQyJeQFJOvRh/WiCQ5a0n5YdM/xCkmgdJftNuPm/iX1FS3EPnqGX5HXlTUlixAwt5Tcqfun+lU3VrGfzU/1T9farUUnnKY5k2OOo/qKl4cGCXnI/MUAIcAiVeQRzjuPWql7beaFuIfvr6dxT4t1q/kvzE5+U+nsauAFenQ/pQBVglS7tyr9ejf41XtpHtpjaS9D901PJbvHL9ot+p+8vrUlzbrcx4PDDofSgCrMjWk32mPmNvvCrMg3YuIOTj/AL6HpRAZXQxXKHI4J7EVAubJ9jcwueD6GgCeSOG9h/ke4NV4bp4G+z3nB7N61ZdCG86Dqeo7N/8AXqSSKOdAJF/xFKwHlXx18aa18Ofg74w8e+G9NXWNX0DTLm8s7Ng7ie4iQmOPEfznc2BheT0FfzX/ALVdr/wUC1/4XW/7RP7RWtXfhbRLnUYLHTtBSeSwkjNzHLIHFjD/AKoKIiCbhvPORnI5r+qlVWNQo4Ar8mP+CyU6yfsn6ekfOPFGn5Pb/j2u6Yrn1D+wPJNqX7IHwu1PUpXu7qbS90ksrmR3bzpeSSSSa/NqX/gjN4o8USNq3xL+N899qtwSSF0yS8wT/wBNri8Vm/75Ffo5/wAE/ZsfsafCmKL5pDpP4D99L1r334kfF74YfBnTLXWPid4msfDlvfSmGGa/mEKyyBdxVCepwM4FFiWz+cf40/Bb9pf/AIJfeIvC3xA+H/xGm1nwvqd15IEQltraSeIeYbW+sGlliZZY92xgzH5WI8tgpr+jn4XfEe2+K3w18KfEfR7c20HinS7PUlhJDvF9qhWUxkjgmMnaT6ivwh/4Kc/tW/DP9o/QfBnwO+Bd8/jbU/7ZW/mksYJXTzRBJb29tDlAZpH89ifLyBgAkk4H7X/s2eAtR+D/AOz/APD/AOHOtAf2voei2cF4gO4JdeUDMmQSCFkJAx1AzQJvS57isQhHmXMmT6ZrI1u/jfTLuKSdbKKSJ0M0hACbxtB5IHU+tWFWe7kz1Pr2r4S/4KgW0Vv+wx8ScnMhOjY/8HFnWZKu9j4ssP8AgkF411KEXNp+0ffywHpImlSuDj0xqlSXP/BIDxfZRvNc/tJ38aRjLFtIlAA9z/avFfVP/BKL7TL+xd4Xii+RRqGq5P8A29yV79+21BBB+yP8Wgxy58OX+P8Av2e1VeRsYH7F37Ot/wDs0+BNc8KS+PJfiP8A2rqZvReyQG28j9zHF5IBuLrP3N2dw69O5+0SokTbIOvUV+On/BGC6eH9l7xTGgHPjG9OT/2D9Or9dQL6fncQPXoKhytpuBfuLUTRhFO0L0Hase51LTNOjaykvoI7ljyrSqj8+xOa/JL/AIK8fG34gfCT4XeD/BngXVrjRpPG93ei9u7R3in+zWEcWYFlQgqsrTjdjBYLj7pYHyH4Q/8ABHrwrfeHPCvjzxb8S7w61dxWepzQ2dnEbdJJAk/lLI0haQDOPM43ddo6VPKnq9C1Jn7ji5stLH2rVZ47VBwpmcJk+2cZ4q9HcJ9mOoIwfzwChByCp6Y9Rjmvxg/4LazRS/B74d+Wc416f/0lav0+/Zmhim/Zo+EgkGceEtCx/wCC+GoVO0fcY+a71PYbUeRC92/LN0/z71pQJ5SbTyTyT7mopUhDRbn2CPkDoDVsEEZFVThy6dhydzJ1u1vL7R76z0+X7PdTwSxwyZK7JGQhWyvIwecjmvwjb/gjz8S/GTxX/wAYPjtPqepzH94os7jUfx8+6u42P/fuv3yJxVCSN3vo3x8ijr781VRtL3SYpdT+Y747fAL9pD/gmXqHhz4o/DL4mT614curxbIsI5LaLz9jTLbXVi8s0UkUqRvhgx+6fuHaT+unxy+KLfFP/gn54q+Mejb9Ll8QeDhqSrDId1tLPEpeMSLg5RsrnjpXwP8A8FePjdD488QeFP2TvAKHWNdTU7e/1CG3O9xeSxtb2FmAOsjidpGXtui9ePuf40fDub4Rf8EzvEPw3uwou/D/AILjsrkx8o1xFEgmYdOGl3EfWspLmav6lrS9j8gP2R/2JvjJ+1j8Lrz4oaT8Xbnw5BaalPpxt5/tVw7GCKKUvuWdBgiUDGO1fTcf/BI747mB7j/hfToB/wBMbzn/AMma8O/Yw/4KE/Dj9k79mqfwHfaFfeJvFOo6/e3v2S3ZbeCK2kt7dI2knkDcs0bAKiNwCTjjP2x8JP8AgsR8G/HeuWPhT4ieGL3wGLxljF81yt/ZxyE4AmdY4ZEQk/f2ED+LAyQ6jqK7j2/EI2e5+tWixp4f8PLJqNwNmn2yrLM/AxCnzMSeg4yc1/Ob4i+K/wC1L/wUn+OGvfDz4I67N4V+HWj7nYrPLZ2wsRL5aXF80X7yaafqkHIGMADa8lful+1Tq9x4e/Za+KGraexjng8Law8bp/DI1nLtb8GINfgL+wZ+2j8H/wBkP4IeKpfEtld674u8Ta6gTTbJAj/YrS2j8uWWaTCKhkllVQNzZB+XHNY04Wjtql+LLk7s+j/+HJzC0jvtR+M0x1SQ7i66JkA/U324keuR9K/ZzRVsfhH8K47rXrt7uy8EaIv2q5CYeWPTrb95IFLHBKxk4LHr171+SGhf8FqPh9qmuxWfjP4banoWnGQK1xbXsV9Ikb/8tGhaKDoOSAxOOmelfof8avF+g/Fv9ij4h+MfhZqaatpOveDtZnsrqEMPOT7JMHXa4DK+QYyrAMrAggEVLhOVW8loti04qNluz8Ufhv4Z/ad/4KpfEnxX4k1jx5N4N8BaFPtWFfMktrRLkuYbWC1iaFJ5RGv72WRwcYJJyFrd+Mn/AATP+L37MHgfWPjX8D/ind6jP4Tge/vI7eCXSLxLaDmaaGWG4lEnlqDIytt+QHkkAH6n/wCCKN7pk/wM8faQjAX8XiISygEb/Jls4Vi/DMcmPxr9Lv2jr/R9D/Z8+J02pj/RU8MawZd2MFfsUoxz69PrXRNuLVtF1MY6rzPnf/gnZ+0n4g/ad+BMXibxxKk/ijwzdyaTqUygR/aXjjWWK58tAApeOQBsDBdWIAGAPuiFXubzzmB2dfy6V+Jv/BEGeRvAHxStSfkj1PTnA/2nhlB/9BFftut7LHcGK5AA6cfzrmrQhFrmel7/ADNYSbTsa9U7iFJCryNhY+cCquoQSFfNQkjuM/rTdPuP+Xd/w/wrSdZOfspolQtHnTLUclrczZX5nQd6ctyftBgkXb6H1rMnjazuRJH0PI/wq9cxi6gE0X315H+FZRqyd1b3lv5lOK07M0a/nB+LXxj/AGjP+CgP7T2ufAP4F+IZvC3gLw/LOsskcklvGbaykEM15dyQfvZfNlI8mHO3lMgHc4/oqW8L2crg4ljUn8h1r+e3/giRGl58QPixql3+8uv7O05S7ckiaaZpM/UqCa7lJVI80Tns4uzOqvf+CNXjnStLn8QeAfjc8nikIWHnafLZRyyjorXMV3NLGP8Aa2P64r0f/gm1+1v8XdQ+J3iH9kj9ou6udR8R6CLhdPu7vD3UcmnsUurS4l+9Nx88cjZOFfLEFMfs6ytp83mJzA/X2r+eLw+G07/gtddx6UfLS41K9Zgv8XnaDJI35sc/WsIVHZ8y95f1+JrKOqtsz9gv2vPjzH+zB8EfEHxUhtxeahAEtdMgb7kl9cnbEJOn7tDmRhkEqpA5Ir8Xfgr+x/8AtPf8FB/Ds3x0+NXxVutH0PWJZEsUlhe6NwsLlHMNmktvb28AcFV29SCdmOW+yv8Ags5qUrfsueGIY32ibxdZiRR3AsL4j8MjNfY37DcaaT+yb8Joo02QS+H7OU/78qeY5/FiSazjKFKPNHZv7i2pTdnuj8ZvjH+yR+05+wBoEfxu+CnxVu9W0XRZY1vY4opLQ28csgjQzWTy3FvPBvIVt3QkHZjkftj+x5+0HD+0l8CPDvxPktxZ39zvs9ShX/VxahbfLN5fXEb8SIMkhWAJyDVT9uXTbXUP2SfixI6hwnh69lx6mOPzFP4EA18Xf8EWbp7j9mXxXYTPuSLxZdbFPYNYWROPx5rSKn9t6rZ9yG19nY/Wy5t3tZRcQfd/l/8AWr8c/wBo7xH+39+0f8bvFPwG+Att/wAIX8P9AnhtbjxAu+yE/mQRySb747pW2lyPLs13Y+/kGvevg7+3frfxJ/bE8W/ssX3hO3srDw1cavAmqLdvJLKNMl8td0RjCjf3+biv0YltZbZ/PtOndax5XSblFaPddi78+jevc/nv/wCCO3iTxTc/Gj4kaVr+r3eqiy0iNALi4klUOt2FJUSE4zX6S/8ABQj9rLUv2W/gkureDcf8Jj4nuPsGkySxiSO2IXzJrl0f5W8tOFUgjzGXIKgivzR/4I3bG/aA+LIkxg6Z3/6/q6r/AILhvJDJ8HLONiIJBr0hXtuH2EA/gCfzr1laxyHJfCn/AIJufH79rLwbY/Gf9oH4uXmmSeK0XULW0ngl1O5e3mG6KSQSTwRQblwyIgYBCPu9BxPxi+EX7WH/AATG1LQ/iT4E+I0vivwVf3KWciyJLHbGXBkEF3YyyTRqJEVhHLHJvGGwYzjP9EHgCM6V4H8OWFuPLgt9Ns0jU9AqQqAB+FfCX/BV4wXv7F3iZ54v3ltqOlSRn0f7VGuf++XI/GrdNrVAfbXwU+KOifG74U+GfidokLw2fiWxiuxDJy8TOMSRkjglJAykjqRmvSIHa1mNtL9w/dNfBP8AwS4vGuf2H/h4LiTe0LavGueoQapdYH4V+gU8CTptPXsai/ctPoyCTNtL5o/1cn3h6H1qSRSGE8PPqB3FLCJGQxzryOM+oqCMvaP5L8xH7p9PrTGPuoROgli+8vI96dDILmH5vlcdfY+tSN+6O4fcPX296gmhZH+0wde49RRfoO+liwuHG2QAsOo/rS+Un/PMU0BJ0Dr+vWj7P71mZH//0f3jaOe0O5enqOn41PHfqeJRj3FLFfDOycbD6097WCYbo+PcdK6W+k0ApgtbgZXGfUVXfTmH+rfP1qCS0miOVGfcU+3kvHbah4XrmqSa1iwGm0uV6D8jVy3gnXmWQ/TNXhnHNQSzxxffPJ6Adayc3LQCxX5Zf8FgI4pP2P52cAtHr2msmex/ejI/AkV75+1B+3D8Jf2TNY8P6J8TNO1i7n8SQT3FvJptvBPHGLdlVhL5txCwOXGNoI68ivxA/b+/4KKeFv2pPA+mfC34Z6DqGmaJBfR6je3mqeVHcXEsKPHFEkUMkqrGPMLEl8kgcDBznYD64/4Ih3DjwR8U4BlsajphC9hmGbJ/QV+Xn7QOf+HhPizHX/hPm/8AS8V+0P8AwR9+GWt+A/2ctW8b67ZG0l8daqbmxDcPLYW0SwxykdQGl87b6jDDgivxo/bw8P8AiP4T/tt+ONTngaC4n1eLX7GSVfklS523KOvqok3IcHqpHUU2tLgf2Elm/wBWpy3c+lfx1/HsH/h4V4qAP/NQG5/7iAr9VdZ/4LX/AAxj8FLL4b8AaxL4tlg+eG7lto9PjuCva4jdpZEDf9MYyR6dvxHsPGviH4k/tJ6Z8QvFaJFrHibxNZ6jcLFGY4xJd3SS/u1YkhMN8uSeMcnrQ/ID+rr9vhj/AMMc/FiNedujSZJ/66JX4zf8ETt//C/PHITH/ItHP/gbb1+y37e/y/sc/FaKLoujSbj/ANtE/Wvxq/4Im/8AJfPHX/Ysn/0tt6GB+1f7dCI37IHxaLAEroF4Rn6V+In/AARR/wCTkPGP/YpXH/pfZ1+337c//JoHxc/7F+8/9Br8Ov8AgiyryftH+MEQ4z4Unz9Pt9nUrUDt/wDgt0wb4o/DTbz/AMSa8/8ASkV+pn/BOGJrj9i/4Xh/uLZXf/pdPX5Xf8Ft2U/FL4bRp0j0a7H/AJMCv1T/AOCdEjH9ij4WW8PVrO7z/wCB1xWsNHoB+XX/AAW6kjfx98LhGOF0zURn/ttFX6Zf8E2Lgj9h34YRJx+51PJ/7id3X5nf8FukSLx38LI16jTNRz/3+ir9Mv8Agmdbmb9ib4Zs/EYh1H8f+JndVUbXuJnsv7VFsZP2WvjDI33V8HeICPcjT5q/n3/4I8kj9q+/29/DOoD/AMj2tf0G/tbXW/8AZe+MEUXCjwfr/wCP/Evmr+fb/gjlIkX7WV/I4zjwzqGPr59rTk3dNjPsz/gqV+xF8V/iz4p0n45/CLS28Qy22mpp2qaZBt+1KLeR5IriFCQZtwlKMi5cbVIBydv5v6H+0x/wUQ/Z48NWnhkaj4m8M6DoUKW8UGsaMskVtAnyxxBr+2coijCqNwAGAMDFf0AftW/ty+Af2TfEXhfSviHoGqatbeJYLmeKXTBC7xC2aNSDHNLEDnzOu7tXx58UP+CxP7O+r/DjXdC8HeEfEGpapq1jcWsVvqVtaQ2mZ4zH/pDpdTEpzyFRsjjipktfMSZP/wAE6/8Agon43+PXj+b4OfGq2tJtantZbvS9TtIvs5na3G+WCeIEpu8vLq6hQApBGSDX7KTXU03yrwPQV/LL/wAEkPh1r/iz9q+x8ZWNrK2leDbC9uLu4A/dRveQSWkMbnpufzGKr1OwnoDX9UubazHHzyfr/wDWpwfV6sTP5hf+CzcTRftQ+GAwwT4OsT/5UNQr9qf2fv8AhAn/AGBfBdr8RmiXwrP4Ft01hpiRGLB7HFyXI5AEe7pz6c1+LX/BZ+V5v2o/DLsMD/hDrLH0/tDUK/Uyx8A658Rf+CWGl+DfCkUl1rep+ALP7JBFzJPJHBHKIUHcy7dg+tT1fMLpofgJ8IovihYftF6hF+wNea/qV3GtwthO9vBFdvp2V3/a43aS38ndt5l2qTsJVHwo/crXIP2ln/4Jy/Fyf9rHePHIstUwHFiD9i8uLyf+Qf8Aueu7/a9e1fix+wj+1jYfsg/FfVfFPifQ59Y0jWrA6deR221byDbKkokiWUqjEFCrIzLnOc8YP6Q/tH/8FWf2dfjD8CvHHwy8OeHvFcGr+JdLnsraW8tbFLeOWUYBkMd67BfUhCfaoTt1KseAf8EV3iT9o7xiZen/AAik+O//AC/2dfd3/BaGaKT9ljw0sY/5nGx7f9Q/UK+EP+CK8yQ/tHeMWcZ/4pSfp/1/2dfd3/BaG5Sb9lrw0qgj/isbE8/9g/UKpLS9ib62Oe/4InSxp8CPHaMcE+Jf/bOCu4/4LNKh/ZR0d8AkeK7DB9P9EvK4T/gijMifAjx2rgnPiT0z/wAucFdv/wAFlZ4pP2UNIVTz/wAJVp/b/p0vKm2l0Vc8/wD+CI//ACRz4if9h6H/ANJVr9qrhC8EiKcEg1+Kv/BEf/kjnxE/7D0P/pKtftc/+rP0qBn8dX/BNr/k9z4Xf9fd5/6QXFf0I/8ABRb9mbxP+098Dk8M+CDGfE3h2/j1TToZWWNbvEckMtt5jkKhZZNyk4G5QCQCSP56P+CcLGP9tb4XuP4by8/9ILiv6lP2m/jzoH7N/wAJb74u+IdNudXsNOntYJILQospF1KsQI8wheC2cEitI8vUzlzdD+YDwRff8FB/2SI7/QfBmleLfB1jcTmeeL+ypLmwkmACGVPNhmt2JVQC6Z3ADkgCvqj9m3/grR8fNN+I2ieGvjzcWfibw3ql3FZ3d0bOKzvbMSuI/OX7MsUbCMnLo0RJAIBBr7dtf+C0H7Lx09jP4b8WpMo4i+x2LZ9g/wBtx+Jx9K/DvxBfaj+2H+19LqPgvQJLKX4ha/GYbGEhpIoSVEksjDAyI1aaZ+ADuOcc1GiL1Z/Z5aXBnQ5+8KiiuHWZoLg89j0qNv8ARLkMP9W9SX8OV85eo6/Suiyv6mF3bzRo0yRBIhQ96qWdz5q+W/31/Wr1YNOLNU1JXM60lyDbydR/nFRgm0nx/wAs3/z+lLdo0UonTv8AzqyQl5Bxwf5Gt7rfozn1fu9UQ3cG4edH+PvUNnP5beW33T/OpbWZo2+zy8elR3Vts/exDjuPSqX8kiH/AM/I/MdeQlD56fj9fWp4JUuoyjj5u4/rTbWYTRmKTqB+YqjLG9tLlfqDQlf3XuNu3vrZjvns5+eQf1FXLqFbiMSR8kDj3FPBjvYcHg/yNVYJWtZPIm6djU3b16oLJaPZktpOJU8iXqPXuKjAeyl9YmqS5tznz4fvjk4qWGaO7jKOOe4pea2Ls/he62LQIYAjkGo5YVlTa34H0qmjPZv5cnMR6H0rRBBGRWTXK7o2TUlZlaIkgwy9R+oqnl7Kbb1jP+fzrSdA2OxHQ0ySITR7H61SkupEoPpuiOWKO6QSIeexpIZiT5M3Dj9aoRyPayFT+IrQZYruPcp+h7irkraPYzjLmd47kMkT2z+dDyvcVYVo7pMqcEfmDUSTtGwiuePRuxolt3jbzrbg9x60PzGtNY7diVZDnyphyeh7GoXhkhbzLfkd1qWOaK5Uo689waPnh4b5k9e4qdi91f8AEFkiul2kc+hqpJayw/PASf51Yltkl/exHa3XI71Et1JCfLuR+NaR/u/cZTSfx/eNjv2X5ZRn3FWf9GuPQn8jStHb3K7hz7jrVKSxdeYzuFHuvyYv3iXdEraeP4G/OqzWMw6AH6UqPdK3lrnPof8A69ayBwv7w5PtScpR6ijCE9lYoQQ3Ocu5UDtmtMcCmO6xjc5wKiE6+WZTwvbPesW3LU6YxUNLljOKieRY13N+HvVVG+Vruf5f7o9B/wDXpIzwbuf/AICPQU+UXPfYstMEjDyDBPbvSB2VQZPvN0UVWiBYm7n4A+6PQU93ESm4k+8eAPT2/wAaLdBc3Ukkn8kBT8zt0AoBZAA53u/bt/8AqqCMGNTczcyP0H17VMN0a+sr/kP/AKwptdATe45pCpEa/M5/IVKQGTa+D6+lJHGEGOpPU+tS1DNlfqMRFjG1BgelOyM471RuboofKi5c8VFMxt4REpzJJ1NFiHNajZ5WuZhBF0FflR/wWR8uL9k3TrdOv/CUaeT/AOA13X6sqBZQbj/rWr8o/wDgsXD5X7JWnNJ/rH8U6ef/ACWu6bIje93ufTP7AMqW37GPwq2f6x9Jz/5GlrsP2hP2Xfhp+1ToOm+GfieL1rPR7lryE2dx5DiV4zGcna2Rg9MV51+wXNFafsY/DS9uDsgttGeWRsZwiSyknA68CrOi/wDBQ/8AYy1yySXSfihp8IfqLyO5s3HrkXEUZz+npUBq3foflB+2T+wZafsY+F7X9o79mzxtrely6DeQQ3Uc04+024uz5SywXVusJ2biI3idTuDctj5W/Xz9iT4y6z+0V+zj4T+JvijaNauEntNReMBBJc2crQtIAOB5oUSEDABbAGK/Mj/gpF+3Z8EPiJ8ELz4JfCLXB4q1HxFc2jXs9vHIltbW1rMtzjzJFUSSPLFGAqZAGSSCAD+i/wCwB8J/Enwh/ZR8E+C/FFodP1mWO41G9hP3o3vp5Jo1kHUSLCyKy9mBHakxvVao+0nuAv7m0X8RXwH/AMFQLZo/2GfiTNK2Xzo3/p4s6+/i8NkuxPmf/PWvz3/4KfySzfsQfEd3+bB0f6D/AIm1nUFddTB/4JT3UifsV+F4o+P9P1Xn/t7kr3j9tWGV/wBkn4tykcDw5fnJ7/uzX5J/8E5/29/ht8CvhrpvwY+Oljc+HNLeW6vNI10W8strcRzzt5iyqil/lmDqJUDJwVfaVJP01+3V/wAFAf2ddZ/Z08W+APhx4rt/FGv+LbM6fBBZLIyRxzkCWWaUqEQLHnC53FsDGMkDWt2XYsf8EXJLeL9l7xTJLy3/AAmN7j1/5B+nV+uLXlzMdsC4+nNfmL/wSN8Bah4R/ZIj1jXLeS2HinW73VbcScb7cxwWqSAdcObYkeo5HBFfVeq/tf8AwQ0P48W37NN3qVxD45u5IIo7b7HMYS9xCLiP98F2cxkHkj0qWmxnyh/wVXtfgU/7Pls3xovLuHWlu3bw0NORZLx70JiQESEL9m2kefkjHy4+faD8V/syWv8AwVjh8BeE18JuIvAojtPsSaz/AGUbj+zuNuwXIN0I/K+5v/hxs4xXpP8AwWz8A+JtQ8OfDT4j2UMt3o2iS6jYXrIMx20l79naByByBL5LqSeMhRnJGfsP4Sf8FL/2Q/FngbR77W/F0HhPWBaxLeabe280Zt5lQB0SRYzFIgP3SrcjGQDkA5dAPmH/AILZTQSfB/4drEMY12ftj/l1av0+/ZgvLdf2avhMjHBHhLQR0/6cIa/Fb/gq9+0v8C/jl8MfBOjfCfxdZ+JLzTdYluLiK235jiNuyBjuUcZ4r9pv2Yb2Ifs1/CZGRuPCWhDp/wBOENDdluB76yxzJhsMppsERhTZnIHSvmD4E/th/An9ozXNa8O/CvVbm+vfD8aSXaz2c1sER3MYwZFAPIPSvqNJEkXchyK00v5gPr4H/bq/bBsf2TfhpJc2E0V34319JINEtHwQGxh7uVP+eUGQcfxthehJH1d8W/iZ4d+DHw18R/FPxWJW0rw1ZyXcyQrvlk2cLGg6bnchRnABOSQMmv5WfC3xZ+HX7U/7Vd18Zv2yvFsXh/wtastwmm+VdXKywRN/o2mQi2ifZCvWZjtL/N/y0kLCZx+12LT6H6H/APBMv9kbX9Q1P/hsz44JLqGu67LLd6DHe5eV3uCTLqk2/kvLk+RnsTL3jI/Yf4wfDix+Nvwk8TfC/U7yTT7bxPZSWUs8KgyRiTuofjP1r5Vtv+Ck37C8OnxWMXxJt7eOFAiRppephEVRhQALTAAHYV9E+F/j58LPEHwiu/jxoOt/bvAtrZX+oSahHbzj/R9MMouXELxrMdhhcY2ZOOM5FcspuNRN7M2STWm6PGf2Qv2JPhT+yjpuqN4dLeIPEGpz731a+hi+1xQBAqW8RUfIgYMxxyxPOQFx8V/8Fj/hd4RvPgvonxXTS7e38UaVrUFi97FGqSz2dzFMWilYDLgSKjJuJ2/Pj7xr7W0n/goJ+xrquNR0/wCKemRwyDJFyLi0kHr+7niRs+2K/Kz/AIKd/tm/Cn9oHwt4b+BvwJvZfFVxLq8V7eXdtBKkTyRxyQ29rCJFVpmkabJKjAKqASSQKj7R2vunr5kOx9u2XizVfFv/AASin1rUpXuJZfh3eWzySHc7mztpLbczdST5WST17184f8EXfg/4Jv8AwX40+Mur6Vb3+vw6sukWVxPGkj2kUNsk0nk7gTG0pnAcjkhQOmc/ox4J+AOpWv7DNl+zxfKlvrNx4Ml0e4AYFI7+8s2SbDdCFmkPPQ4zX4//APBMb9rX4e/swy+N/gd8fLqXwl9p1P7VDcXEUjRwXsKfZrq3uBGrtE37pMEjGQQSOM6wum9bpky6H7O/tofCDwX8X/2cvHuneKNJt7y907Rb++026kjUz2l5aQPNDJFKRuT50AbBG5CVPBNfnp/wRo8SHxF8CfHvw613/TtLsdX/ANRP88Qg1G2AkiAPG1jExK9MsT3Neu/tgf8ABRX9mzTfgT4y8MfDvxfb+LfFHibS7rTLK204SSLGb2IwmeWbaI0ESuWxu3EgADqVwv8AgkV8JNd8Efs06l4316zNnJ421V72zDcPJp9vEsMUhHUB5RKV9Vww4YUq7ajzR3Q6dm7M+Ydf/Yb/AG1v2P8A4pav42/Yt1Qax4b1dnItxPapNHbhyYre7tr9hFOYgxEcqEseTiMnBo/EnwL/AMFR/wBon4e69afHi7tvBfw+0vTrrUtQX/QYjcrYRGcRGGzZrhyxQELIVizyegFfr7rP7Zf7L/hbXdT8GeMPiRpGlazo8z213a3MpjeOROqnIxkexr4M/bS/4KM/ASy+Cvi34dfCLxNH4u8S+LdPn0tTZRyfZ7aG8QxTTSTsipkRM2xULNvxkAc1lzttNLRl8qV03qjzn/gia0tv4I+J11j5G1LT1+uIZcj9RX7n3cK3UIni+Ygce4r8vv8AglJ8E9c+Gn7L/wDwkfiK1az1HxzqMmrxRvw4sPKjhtsjt5mxpV9VcV+m1hcmN/Jk+4ensa5KkrTdOptI1ivdUo7oz7661T+xNQh0nH9ofZ5fshOMeftPlg7+PvY68etfiNJD/wAFtLciVo7Ec9R/wjn+NfuTfW3lN50f3D19jVq0uVuE+zz8tj8xSpys/ZVd1s2OS+3HbqfnZ+xyf+Cg97441oftefZv+EYGmt9hMP8AZW8ah50WM/YP3mPK8z73y/jiv0LtJjbSmCbgMfyNI6yafPvXmNquzwxXsQkjPPY/0NVeU3zLSa6dwSUdH8LM/V4Xggnu4P8Anm+R+Ffz+f8ABDz/AJHH4sf9eGlf+jbiv6DbO5IP2a44I4Gf5V/Mx+zx8RYv+Cb/AO2l458D/GC0msvDGrCSzNzBG0oW0abz7C9RBzJEY8qwUFlJIxuRlPTRcbOcOvQzqXuoyP6enVXUqwyDX86Ohqtv/wAFt3UHgancj8/D0lfqbr//AAUc/Y00Dw9J4hPxIs9RCxmRLWyimnu5COkaxBAVYngb9o9SBzX5Z/8ABPvSvE37T37eHjT9rG40o2fh7S5tQuQZORHPqMT2trbKeQ8i27MXI4GM8blB7GvtLc579GfTv/Bai2EX7N3hOVPuv4utuPf7BfV9yfsSiG7/AGRPhNF3Tw5p49x+6FePf8FNfgz4j+Mn7KOtad4XtDqGq+FbuDXoYRzJLHZpLHOEA6yCCVyB1bGBycV8f/8ABP8A/wCCgfwO8OfA7w/8Jvi1r6+FNe8Jo9pDNcxyfZLy18wvEyyoGCuisEZX29MjIJA45+5H3Y3XVG8feerP0a/bRaS1/ZM+LltLyjeGtR2n/tia+G/+CL1u8n7Nfi6eE/vF8W3H/pBZVzf/AAUC/wCChvwH8RfATxB8JPhJrqeKvEPi2NLOaW1jk+yWdtvUzO8rhQzOoKIqbuuWwAM/UX/BMn4QeJvgl+yto9v4tsjY3/iy8n16WA8SxR3ccUcAlB+65hiRip5GcHBBFS4RVK0np+Qczcrrc/Qu3uUuVME64boQe9LvktDiTLQ9j3H1r5i8I/ta/Av4jfGrWPgD4V1a4l8b6FJeR3MDWc0cSvYPsmxMV8s4PQg89q+moLog/Z7sbX6ZPQ0ruLSm9ej7+pVk9Y/cfzu/8EdYDP8AH/4s7Tyum/8At9XRf8Fv/MF58G1lzwniDGfrp9c7/wAEdZXg/aA+LLoMgabyP+32vqT/AILF/CTXPiD8EvDXxM8O2puv+EAvLhr5V5kjstQWJZJQO6pJFFu9Ad3QEj1lfl2OQ/V7wTdW83g7Qlfj/QLbr0/1S18Ef8FXbaJf2K/FksfH+m6T9P8Aj9irh/2Wf+Cjn7Nvij4QeGtJ+I3iyDwh4t0axt7K+t9QSSOGWS3jEfnQzANGVl27sFtyk4I6E/Hf/BSj9tz4W/Gr4f6d8A/gXfyeK7jUtSt7i+u7eCUQYiz5NtDvCtLK8pU/KpUAYBJPFu1vdYH6Ef8ABLi1lk/Yh8ASLggy6x/6dLqv0EW2uw2Fyvvmvnb9jj4T638Ef2a/AXwz8Qxrb6jpNiZLyJTny7q7lkupk3Dg7XlIJ6EjjivqOj2jWgEUUbRrhnLn3qWqwuFeTy4/mI6nsKidzcSmBPuD7x/pWXK29QLuQRntUKTCQkqPlHeqrN9ok8iLiNepFIzee/2aLiNOpq1HuBOHknJ8o7VHf1p3l3H/AD0/So/mY+VCdiR8Z9/Sl8qb/ntVAf/S/fF4oLkbu/qOtU2trm3O6JiR7f4VdaNJv3kTbW9R/WlhNxkrMBx3HeuhSaQEdrNNKP3icDvVzgc0tZvmNdzeWv8Aql6+9RbmdwLkkyRx+YTx296oQDcXvJ+g6UyZzdXAiX7o4/8Ar1LP+8kW0j6DrWijbQVz5j+PX7InwO/afuNN1f4waTcX9xoscsNnLb3k1sY45SC4xGwVslR1BrxjwL/wTA/Y18Hagmuy+C5Nblt23xrqt7cXMCkf3odyxSD2kVh7V+gk/wA7paRdB1pty25ltYu1Fr/10GVdNsrSzgjhtIEtbS0QRQwxIEjjjjGFVVGAAo4AAwK8P+OP7MPwM/aL0+2X4xeFINams8i0uQ8lteQK2TsSeBkk2EnJjLFSeSM19AlAStsv3Ry3+feoW/0u42D/AFaUt9wPg74f/wDBNL9jjwBfQ+IIvAo1m9t5PMhOq3c97GD2Bt3fyJB/vo1ei+L/ANhn9lvx98Rn+LXi7wOt54ummtbg3aX9/bqJLJI44SIILhIB5axIMbMHHOcmvrMkO/mN9yPge5qyikfM3U1DA43x54B8J/E3wbq3w+8cWP8AaXh/W4Tb3lt5ssPmxEgkeZC0ci8jqrA14z8FP2QP2dP2dNfvvE/wb8I/8I9qWp232O4m+3393vg8xZNu26nmUfOoOQAeOuK+m6rLMJJCF+6nU+9RuBxnxF8G+GPiP4P1X4f+M7P+0dD12BrW9tvMki82F+q+ZEySLn1VgfevD/gn+x/+zp+zlrt54z+EHhH+wNX1G0NjLN9vv7vfbvIkpTbdTyoMvGpyADxjOCa+kUBu7kk9O/0q2QLm45/1cX866GkkkxXPmz42fsl/s+/tC32na/8AGnwr/wAJDf6XC9vaP9uvrTy45G3kYtJ4QcnnLAmvWPhp8OfBvwd8C6Z4C8B6f/Zeg6QjxWdr5ss/lpJI0pHmTNJIcs5PzMa7Qf6ZdZP+rT/P61Hcu082yPkDgYp2voxXPnX4zfso/Aj9pLU9L1P4y+F/+EgudGjkitn+23lr5UcpDuMWs8IOSB97OO1ep/D74deCfg/4I0v4Y/DTTf7I8O6MJEtbXzZrjyxLK00g8yd3lbMjsfmY9cDjivQxFJbw7IhmRupptpatGTJIOewour8wrPY5nxV4T8P+LvCWs+DvFtp9u0rxBZXGnXtvvePzba7jMU0fmRlZF3IxG5WBHYg189fBb9i39mv4D+LpPHfwo8H/ANg6vJayWbT/ANoX9zmCVlZl2XVxLHyUU5xnjg9a+qWs5ppN8rj8KsywFoxFGdqipcl31HY+XP2hP2U/gZ+01NpU/wAWtCl1O50KOWKynhvLi2aJJyhkGIZFVslR95SRjjHNfOulf8Emf2NLW4N5f+HdRvIuvkzardBPziaNv/Hq/SmGyWNtznf6U6e3mmb74CelJuGyFruzy/4bfCv4a/B3w8ng/wCEvhqz8NaXkFks4wjysBjzJZDmSVscb3Zmx3r0mO1jiHmXByfT/PWrKw+QmIRlvU00RMg82XLyeg7fSjmWyC3c+YfjP+xp+zj+0V4ptfGvxg8If25q9lZx2EM/9oX9oVto5JJVj2WtxEnDyuclS3OM4AA9z8GeFfC3w48KaR4E8FWX2PR9DtorKytxJJL5UECbY08yUs7YAxlmJ9TXR7bm6b58xx+lXooY4RhB+NS7LcNz5N+JX7EP7L3xi1q48SfEP4daddapeZM9zbNNYzyv/fke0khLse7MST615sv/AAS4/YWH/NNSfrrOsf8AyZX6A0xnVSAep6CobuVax8xfBX9jn9nL9nfxJeeLvg34Q/4R/Vr+0NjPN/aF/db7dpI5Smy6uJlHzRqcgA8Yzgmu++NHwI+FX7Q3ha28FfGDQ/8AhINFs7xNQig+1XNrtuY45Ikk32ssTnCSuMFsc5xkDHr7yJGu5zgVnPfFjtgXcf8APahRb2E5Jbnk/wAE/wBnz4Qfs66DfeGPg3oH/CPaZqVz9suIftV1d759ix7911LMw+VAMAgcdM1c+MvwM+Fn7QfhSLwN8XdE/t7Q7e7jvo7f7Tc2uLiJZI1ffayRPwsjDG7HPI4FenrBdS/NLIUHoKk863g+XeXP1yaOXsLm7njvwS/Z1+Dv7Omjaj4f+Dfh/wD4R7T9VuBdXMX2q6u/MlVQgbN1NMw+UYwCB7V7cRkYqrvnk+6PLHqeT+VSl1X5c7j7daVirnx38Of2Av2SvhN410v4i/D7wH/ZPiHRmd7S6/tTU5/LaSNomPlz3UkbZViPmU9c9a90+K3wb+H3xw8C3vw2+J2mnWPD19JFJJbiea3O6Bg8ZEkDxuNrgHrg9wRXqaszdsfWnEgcnii72C3U/MOf/gkv+xul8lwugap9nByYhqk+z6E53f8Aj1fUnwf/AGS/2ff2ew998IfBtpo9/ICHvXMl3elD1UXNy0sqqe6qwU+lfTNFNSJcb3RSYLeW3HX+tMs5d6NBJ1Tjn0qaKIwyHZ/q27ehqrdRNFILmL8atWfumbuveK00T20uU6dQa1YJ1nTI6jqKjBjvYOf/ANRrM+e0m9x+orT4lZ7md+R3WzNuSNZEKN0NZCu9pNtbkd/ceta0UqTIHXpUdxAs646EdDWUXbRm0483vR3I7iJZ0Eide3vTLa43fuZevTn+VV4J3t38qbgfyqxdQbx5sX3vbvV2t7rML39+O/UhnhaBxNF0/lVsGO8h56/yNR2tys6+XJ97+dVpY3tX8yP7n+eDRvo9x6L3lsyPEtpLn/JFaBWK8iz3/kaFaK8i56/qKzz5tpL/AJwRVfF6k/B5xZagme3fyJ+nY0s9uyt9og4YckVMPJvIv85FQxStbP5E/Tsaz80XZWs9ujJYpo7tNjjnuKiUtaNsbmI9D6UXNuVPnw8FeTinwXKXC+W/X09aOl1sF3e0ty6CCMjkUtZ5V7Q7k+aLuPSrkcqSruQ5rNrqdClfR7kNzbideOHHQ1kJJLbvxwR1BroaqXNss4yOGFaQlbRmFSnf3o7gkkN5HtP4iolMlodr/NF2PpWZ88L85RxWpBdpN+7k4Y/kapxttsZxqc2+jJJII5/3sZ2v2YUxZ5IjsuRx2YdKZJDJbnzbbp3WnxXUUw2PwT2PQ1PTujW9n2ZY24G6LHPOOxpp8qceW459D1qIwyQHdByO6n+lPBiuV9x+BBqPMq/QpvZSId9uf6Gn2890W8tlzjrnirCi5RgrYkX16GrdU5dGTGnreOgUzcvPPTrVS4nfeLeH7x6n0qC5cRxi2i69/wDPvQo3KlUSuGTez4/5ZJSn/Sp/LH+qjok/0W3ES/6x+tD/AOiW4jH+ser9DD/F8/8AIVv9LuNg/wBVH1oc/a5xEv8Aq060jn7JbCMf6xqfEhghAX/Wy/5/SjzQ99H8/wDIlyJH9Iov5/8A1qrx5upzM/8Aq4+lLcfKqWcPU9amKDCWydByx9v/AK9TsVuxUPmN579Bwo/r+NWEXGWb7x60i4Y7uw6f41LWTZukFV7mXyYSw69BQ8uHEKfeP6Cs+9cyzCFOccfiaEiJystAsowWM79FqSHEsjXkvCp0p0qlUjs4up6n2qO5O5ks4ug61d7mduVf1uOhzcSm6l4VOlePfGb4K/DP9oXwzH4H+LGi/wBvaLHdR3kdv9ouLbE8SsqP5ltLE/AkbjdjnkcCvX7phEi2sX40+1gMSGZhlz0FA+XWxw3gz4deCfhf4AsPhh4L04WPh/TbdrW3tDLLNshcksnmSs8rfePVia+IdU/4JV/sXatM1+PCV3pStzstNUvAn4CWWTH0H4V+iaWsssvmXAwOpqxc28sxCggKOgrNlq+58ZfCj9gz9lP4ReILfxN4G8BW41i05ivL+e41CSJh0kjF1JJHHIOzRqpHrX2PNMlsvkQde5/z3q1HbmGEpGcMe9Vl08bsu+4d6AsyrBbPcNuPC9zXE/FX4aeAPjD4E1P4X/ETS/7Z8O6x5P2u18+a38w28yTx/vYHjlGJY1PysM4wcjIr0qaJ2Ty4SEFNhtFhG4/O1Q0+hSjbY+ZZ/wBjz9nPUvhVpPwX1jwPZ3Xg3QvNOn2c7zSy2puJWmlMV1I5ukLOxJIlBOcZxxXhfh//AIJc/sX6JrMesReCptS8iRZI4r7Ubue2BQ5A8rzQJR6rJuU9CCK/Q0RSStun+6Oijp+NQyyXUzeVEhjHr0pbGiKllY6RoFjbaZp1vFa2tnGkMEEKLHHFHGMIkcaAKqqBgAAACvA9T/ZT+BviH41W/wC0RqPhb/i4FtJDLHqf228BV7eEQRnyFnFucRADmLnqcnmvo6Gzih+Y/M/qauUcre4HN6v4W0PxDplzoviSzh1bT71DHPb3UaSwTIeqvG4IYH0Oa+OdY/4Jq/sRa7dteXvwwto5HJJFtf6jZx8+kdvdRoPwFfdDMqjLHApN427jwPemklogPgP/AIdc/sK/9Ez/APKzrP8A8m19u+GPDOi+DfDWkeD/AA1bfYtI0Kzt7Gzg3vJ5VtbRiKJN7lnbaigZYknqSTWhNqKL8sQ3n17VGBf3HJPlp+X/ANepdVbR1K5Twr4M/spfAP8AZ71rV/EHwh8L/wBg6hryLFeyfbby681EcyAbbqeVV+Yk/KBX0UAB0qiBBa/62Usfc/0oFzLNxbx8f3m6UvaLruO3Y5f4h/D7wj8VfBmq/Dzx7p/9p+H9bi8m8tfNlh82MMGx5kLJIvIByrA18b/8Ouf2Ff8Aomf/AJWdZ/8Ak2vvbd5K/vpNzH2/kKeru54Qgep4/Sr5oisfAH/Drf8AYZEm7/hW2U/u/wBsax/P7bX0n4e+AXwr8E/CR/gd4U0AWvgZra8sn0xp551e31BpXuUMszvMRIZpM/PkZwMACvcSQBk0isrDKnNROmpLlY1Jp3PzX1P/AIJTfsW6wWuLPwpe6W5OSlvqt5tB7jE0spAP1r174J/sNfstfBDV4vEPgfwPANftDmK/vppr64ibpui+0O6wuOm6NVPvX2ZVKW3bzhcQ8MOo9amUZKz37lJrVFO2c2k5tpOjHg18o/HP9iD9mr486xJ4t+IXg6GfWpcCXULSWWyuZMDAMrwMgl4wAZAxAAAOK+t762M8e9PvL+oqOzuFnT7PNy2Mc9xXHblfsW7dmbXv733nwR8PP+Ca37GPgnVrbVofAY1i/tHEkTareXN5FkdntpJPIk+kkRFfoBBbQWsEdpbRLFBCoSNFACqijAAA4AA4ArGurd7aTKfcPQ1rWd0J12t98dferw9Z39lV3JqQ0547H59/FT/gmx+y38TfG+sfEHxRol//AGvr9w91dywajPGryycu2zLKPoABW38Of+CcH7HPgPUYNf0rwJHqWo2pUxvqlzPfJG4OQfJmkMJOecmM+1feUsaTIY36GsFlmsJtw5H6EVNRyoyu9Yv8CopTVluS28z2Mn2eX/V/y+ntVi9tRIPPh5PcDv71NLHFfQh4+vY/0NU7S6aB/s8/A9+1c7Sj+6m7xez7F3b96O/UsWd0s6eRNyenPeqNzbNbvuX7ueDVu8tdpM8P1IH86ktblbhfJn+9/OlKPN+6qb9GUnb34bBbXEd3GYZfvfz96r4l0+XP3om/z+dQ3Vq9q/mR52dj/dq/bXSXSeVMBu9PWnGTk+SppNbMGrLmjqmOuLdLxBLEfm7GvFfix8Bvgz8ftKh8P/GfwpaeIo7U/uJZt8NxFnqIrmFo5owe4VwG75r2EiXTpNy/NC36VYuYI7uMSx/e7H19q1967nBWkt13I0tyy26M/OuD/glX+xbpuotqf/CF3V9CTn7LNqt/5SfTZMrkf7zGvvLwP4N8HeAfDdn4U8BaPa6FotgNsNnZwrBFH6naoGSepJySeSSa27a9KHyLntxk/wBammtnjfz7Pg917GtIVW/3kNV1XVEyhb3ZGlXxV8VP+CfH7JPxh1u78U+K/AkNtrd/zNd6bcT6ezuesjRQSLCzk8l2jLE9Sa+yre7Sf5fusOoNW69CMlNXizmacXZnwd8Nf+Cfv7Kfwc1+18S+GPAsNxrNkd0F3qNxcX5Rl6SJHPI0KuDyGEYYHoa+3bW+SceVPgOePY1dngSdNj/gfSudnhkgfa4+h7GvFq+1oS507o74ctRcuzPD/C/7KPwK+H/xd1T49eEPC/2TxrrL3cl5ffbb2TzDfNvnIhknaAbjz8sYx2xX0WRbX8fuPzFULTUCmI5+R6+lXJrXefPtW2v146GuiM1OLcNV1X+Rm48rtLTzPnX4L/sofAb9nrxJrHif4VeF/wCw9Q12Lyby4+23lz5qeZ5mClzPKi/NzlQPTPavoe6022uoZInRWjlBV0cbkYNwVIPY0W135jG3uRg+/ep2imi5t24/un+lejh5JwvB/ec9RNOzPgLx5/wTU/Y+8b6tca3f+Ahpd7dvvlbS7u5s4iT/AHIIpBAmfRYxXrHwZ/Ym/Zj+A2rJ4m+HHga2stcRcLfXUs9/cx+8TXUkvksehMQUkcV9XoWKgsMH0qOeZYYy5/Cuhvm0sZEpYAgHqapXk5X9zH99qZG5SM3UvLHoKZajcXu5e1XGKWrAV/8ARYhDH/rZOtDg28IgT/WSdaLf95I13L0HSlg/eSPdSdB0q/UAkP2WERR/6xutOVDBEIk/1sn6f/qqOH9/Mbh/urUwk2q10/fhR7VL00AjnnFsBDCeV61W+3T+tXLWIEGabq/rVvbD6Cj3V0A//9P99BCofzIztz1A6GrFFJkU73Ao3s3lx7F6v/KoW/0S1Cj/AFj02P8A0u6Ln7if5FMkJurrYOnT8K6EraEeZLbAW9uZ26npRB+5ha6k+8/SluP306WqcIvWkn/fzpbJ91etG+4hbb91E1zJyT0pLUbFe7l/i6Us486ZLaPhV61McSzrEv3IuT9e1TcCOR2ggy3+tl/z+lSQxmKIR/xP19qgX/Srvd/DHVouQjyjqeF/z9ab7FocoDNtX7kX8/8A61WaZGgjQKO1PrFjKl3L5UJx1bgVXdHhthCiku/XFXniSQhmGcdKlpqVhWKFtA8UJ7SN+lTLbosXldj196ld1jQu3QUxJRLF5kXPpn1ou3qFh0cUcQ2xjFSAAdKq21z52UfiReoq3Sd76jQx2VRlyAPenZGM9qayLIpVuQaowyNbzfZpOVP3TTSuK5bjnilJEZyRR5o83yjwcZHvWfdRtBKLiLuf1/8Ar1Ym/fQrcRfeX5h/Wq5YiuTSXCxyCNlPPQ9qdLMkQBfoaglUXVsGTr1H1pEIurXaevT8aLILlqOVJV3RnIoEsZO0MM1kWkpgm2PwDwfrT7+Da3nL0PX60+TWxPN7tzYoqnE7XFv8pw/TPuKhtLl2kMUx57VHLuXcuyK7LiNth+lV2H2dCyKZGPU9akluUiYLJkBuhqZGV13Kcg0aoNzJjinuW8yQ4Hqf6VYaa3tBtjGW7/8A1zV10EilTkZ9Kqx2kUJL4LkdKvmT3M+W2xAFurvljsjNTKLa2OxBuk/M03dcXB2oDEnc96RpYLRdkY3P/nrVeQtNyxiRvmmOxfQf1NV3vYoxtgXP6CqRae7fHX27CriW0MK+ZOQT+n/16LJbkczfwkKyXtx9zgeo4FWBaRr89w+768CkN1LMfLtl/E077PHGPMu33n36UN/IaSfmSpLH9yBCR7DA/OplMhGXAH05qp9qeQ+XbR5x3PSniF8briXj0HAqGu5on2LJdA2wsMntTyARg1SE9tF8kK7j6KKkD3LfdQIP9o5/lU2HzCC2WN/MhOz1HY0+eBZ02twex9KnGcc9aWlzMOVWsYKPLaS4b8R61tRyJKgdDkGmTwJOm1uvY1lqZrN8EfIfyNau0vUyV6foac8CTrhuvY1Vt5Xgb7PPx6GrsUqTJvQ8Uk0KTLtb8DWafRmjjf3olC7t9jefDx3OO3vU9vcJcJ5cn3u49aWJ3jYQTf8AAW9aq3Ns0TedDwBzx2q99GYvT3o/MZLHJaSeZH9z/PBq8rw3sWD+I7imwTpcp5cn3u49apzRSWr+ZGePX/Gq30e4vh1WwwpNZybx09exrSBivIv85BpsNzHcrtYc+nrUL28ls/nW/I7ihu++40rax1Q6GV7d/InPH8JplzaEHzofqR/hVkGK8i/zkGoUle1byp+V7NSvrdbg0mrPYS2vQ37ubr60+W2ZW821Ox/TsaWa1jnHmRkBj3HQ1VjlntD5cwyv+elPfWIndaS+8sxXozsnG1hV4EEZHIqqyW92u7r7jqKrLa3ELfupOP8APaoaTNE5LzRfkijlG2QZrNk09s5iOR71qJv2/OQT7U+pUmti5QUtyhbtcR/JOpI7HrRcWiy5ePh/0NX6KObW6DkTXKzJhuJ4f3cqkgfnV0pHOA6nB9Rwas0UOXVBGFtGxACBg81HNKIYzIe1SE4rLu2M0yW6fj9aIq7CcuVaCWw2o93Lz6Uy0QzTNcSdBz+NOvXACW0fQf5FOm/0e2WBfvydf61v+pzWt8vzFh/0m5NwfuJ0pIc3N0Zz91On9KWb9xbJAv3n6/1pZR9ntxAn3pP8mp9Crd/Uag+1XJkP3Eqwsiktct91eF/z71Ey+VElqn+sk6/1plz8zR2kXap3Hsr/ANXHWwJ3XcnJPT/P6VYwVxH/ABycsf8AP5CnKqhgg+7GP1pYAWBlPV+fw7VDZpGNtCxTHcIhc9AM0+mOiyLsfkGoNvQz7XcI5Llhln6UlpDIJDNMMHtn1NaSqFG1RgCnVVzNQ2uVoodjvK5yzfoKclvFG29R8x7miOeOYlV6r61CLhluDDMAM/dNSP3S5jFBIAyaWigsYrK43Kcj2qL7TD5nkk4f0qpLutJfMT/Vt1FOu4RNGJo+oH5igm5bklWLBboTjNE0ywrvYEj2qtA4uoDG/UcH+hpbdhNCYJeqcGlcdyz5q+V5v8OM0yK5hmO2M5IqvZsUZ7STqnT6VnSBrS447HI+lQ5W1C5uNLGrbWYA+hqQEHpWfeRi4gEqckc/hTNOmypi9ORT5tbDNSmsCQQpwayDcS29x5cjErnv6VpTTCBQzAke1JTTuVYhWFo8zTEyuOn/ANYVnv8AabyTbjaB27D61rxTRTDMZzipqhwUlo9ATsZgS2shukO56iM93dnbCNq/571Y/s+LzN7MWHof8abJLOW8i1j2Y7kVjJNaPReRaGi3tbUb5zub/Pap1aebkfuo/wBf/rVBsgtP3kx3ymqU11NcHb0B7CpclDT8P82WlcvNcW1vkRje3c//AF6r/bLqdtsQx9KWGxwPMuDtHpUrXiR/urVN1ZNzt77silborjVsWf57qT9f61MslpD8sA3v/s8n86jFtLJ+8vHwPSj7XDH+6tY959v8801aGtreurDV6blxWuG52BB7nJ/SpXkRBl2C/WqaxXcnM8nlj0Wk8yxgPGGf8zXQqjSu9PX/ACM+W5oAgjI5FU5rGKRvMT5H9RSCe5k/1UOB6vx+lWYhKB++IJ9qt8tTRoWsdRnlmSLy5wG9fesOeCWzlDqeOxrotyk7c802SNJUKOMg1Fagqi03RcKnK/IgtLpblfRx1FTSRpKhSQZBrEmtZ7STzYuQOh/xrUtbpLhcHh+4rKlWv+7qLX8ypwt78NigBLp82esT/wCfzqzdWyXMYmi5b+dX3RZFKOMg1nKsli/d4T/47USpKCcH8L/Aanzarf8AMitLsofIn6dAT29jSXloU/fQ9OpA7VPdWqzr50PLfzqvZXmwiGfp2J7e1czVv3VXbozRP7cPmie0uluF8if7/v3qpdWTwHzYeV/UVJeWWzM0PTqR6fSn2t/nEc/4N/jRLX91W36Mpae/T27EtrdJcp5Mv3/51EQ+nSZHMDf+O0+5sQf3tvw3XH+FPt7gTA29yMP0IPetrSuo1NJLZkabx26oW5tkukEsON3r61RtryS2PkzKdo/MVYKy2D70+eA9R6VZeO2vk3KefUdRUuLlLmhpPt3BNJWlqhs1tFdqJojhuzCq6Xk0DeVdj8f89ar7LmxfcvK/oa0I5ra9Ty3HPof6URlzPT3ZfgwastdUXI5UlXdGcilZVcbXGR71kvp8sZ327f0NaEK3Cj9+4b6Cu6nUlL3akf8AIwlFLWLKM2mKfmgOPY02Bb21ONu+P0H9K2aKj6rTUuaOjH7Z2tLUrmOKX53TkjHI5p0UZjBG4kds9qmortWisc7CsmQm6uhGPuJ/k1cupfLhLDqeBVOD/R7Yzn7z9K2iraifYbdOZpxBH0HH40+54EdpF+NNs0Ch7iToKfbcmS8l/CtHp8iBLn5RHaRfjRcny41tYup60Wo3NJdy9qW3+ZpLyXp2pbASmMAJap35Y+3/ANeo5j9ouBbr91OtOEhjge5f70nT+lNtkMUPmfxycD/P60vM0LRjSY4cfInA+tJ9ktv7tMkV2IghONoyT/Ko/s1z/fqfmB//1P35dgilm6CqNzIY4MH78tTSHzJ1hHRfmb+lUJm+0XSoPug4/wAa2iu4myVf9GtC/wDHJTbQCGJ7hvoKbePvmWJP4ePxNSXQ2rFaR1p+pAW/7uKS7fq3T/P1pbc+TC1zJ1fpRcLkxWkf40XH7yVLVOg6/wCfpU7gEJMEDXD/AHpOlJkwWW4/el/r/wDWqxPA8zqo4RastGjEFhnHSpci7FO2hZbf5eGf+VW/KXK+i9BUtZst+FJWMZPqaWsnoGxpUzcNu5efpVYMl5CQOP6GqcMr2cnky/d/zzUqNwuWYrxXl8tl2+lQX0Ug/eZLJ6elS3VsJR5sXX+dLa3AmXypfve/etVp7yJ8mMs7gMPJk/D/AAp2DaS5H+qk/Q1SuYGgfcv3T0NX7eZblDFJ17+9D7rYE+jG3cLK32mLqOtWbecTJuHBHUVHEWhfyJOQfun+lVJo3tJfPi+4e1Tvow21Neq1xAJ0x0I6GpIZVmXetS1lqmXuU4/38Ril+8OD/Q1DZMUZ7Z+o5q/tXdv79Ko3SiKaO4Hrg1ad9CGraiW7eTcNbt0PSnf8e11/sS/zqO+QjZcJ/D/kVNKBdWu5evUfWqvfUXkVL6Ha4kHRuv1q3A63UBjfqOD/AI0RMLu3Kt16H6+tZ0MjW8/zcY4NXurdUTezuTWzm3uDC/Q8f4U69jMUonTjP86kvoQ6idf4ev0qWF1urco/Xof8aV/tBb7ITKLq2Dr16j/CqthNtcwt0PT6060kMMpt5OM/zqK9iMMvmJ0bn8aaX2WDf2i5NcSW8q7hujf8xV0EEZHINU/lvbb3/kahspyp+zyfh/hWdtCuazNF13KVyRn0rM/s5vMxv+T9a1qKhSa2G4p7mY9zFbL5UAyaiit5Lg+bcH5a0WtoXbey81n3rzlthGE7Y71pF9EZSXVj5LtIV8q2A479qbFbPKfNum4/z+VOhhjt08+fr2H+e9NzPetgfJGKq/YXr9xI10q/ubRNx/SkW2d/3l03vinGWG1HlRDc3+etILeWb57lsDrip22DffUd9phj/d2y7z7U8C8l5ciIeg5NRNdW1uNkQ3fT/GoA13dfd4T8hRbqVzdPyLjLbxf659x/2jn9KYb+FOFBNJHYRrzId36VcWKOP7igVLaKSl00IYbkytjy2APftVlgGGCMinUVL8i0u5Qa1aJ/MtjtPcHpVxSxGWGDQHViQpzt60MyggE4J6UN3EklsDosi7XGQaYgdfkb5h2P+NTUgIPSpKsZc9oyN51v+Q7fSpre5SdfKk+9/Or9RGKInJQZ9cVfNfcy5LO8TLntGiPmRcr+op9ve/wTdPX/ABrWqnLZxSnP3T7VXNfRkOm07wElgO7z7c4f9DSxyx3KmKQbW7qaWGCSD5S+5PTFOlt0mw3Rh3FTc0s90iv5M9sc253r/dNXAPMT94uM9QeaeowAM5x60hZQCSenWk3cpRsMjhii/wBWmKfuUNtJ5PaqsNwziSVuEXoKgtjhZLuTv0p27kcy0sW2nHnLCoye/tUM07mYQQ9e5qKEmGB7l/vP0pLMbEkuZOadupHM3ZC3lwykRRkgjqaeryQ24LEvI/QHmqlshnnMknQcmrsJ+0TNMfurwv8AjVPTQUW2+YswxmOMKx3HuamoqvcOyJtT7znArPc6dkNMoCvMei8D/P1qlZrzJcyds/8A16L1girbL0A5p1x+4tVgPV+taJaHNKWt30I7UG4umlbtz/hUsf8ApN2ZOqx9P6f40i/6PZF/4pP60D/R7HP8Un9f/rUMSVkr+osX+kXRmb7sfT/P60sOJ7h7lvux8CklxbWoiH3n6/1/wqYwOtsIIzyep/nSuWl/mRwOHeW7foOB9KbZKZJGuG/CrkcCpCITyO9TABRgDAqXIpQ2bIRHlCj9W5OP8/hViqc92kB2EEmkt7pZwUfhvT1pWe5fMr2LmR0qjLeiKXy2UgetVJFkspt6cof84q86RXkQZevY+lO1ieZvRbiXaPLFuiJ+g7iqFpdeS2x/uH9Kltp2gfyJuB/KlvbXrNGPqP60eRm9feRPPEyuLmDqOo9RTpo1uoQ6deo/wqtZXW3EMnTsaskG3fev+qbqPQ+tQWrPUba3Jk/cy8SD171frPurcufOh++PSpLW5Eq7W+8P1oLTtoyzIiyIUfoap24aBzbv0PKmr9MZQ3XtyKCrGYB9lvAB9yT+tOuD9nulmHR+tWL2LzYSR95ORUUn+k2YcfeAz+I61LFYLsGNlu4/4OvuKS9jE8AlTnHP4UWUgntzC/bj8KSzcozWsnVelS9Shmnz4PkN35FQzIbS5Eifc6j+oqKeNre4+XjuK0pAt5a7k69R9ax3VuqAjvYxPCs8f8PP4Utm4uLYxP24/DtUVhN1t3/D+oqJgbK63D7h/lQ5fbNCGJms7n5uxwfpWtdSyxIJo+QOoqtqEIdBcJ26/SlsJRLEYJOdv8qiN03D7h+ZdgmE8YdfxFT1hRu1lclG+4ev09a3AQRkdDXRTnzKz3JasZM2nuz743zn+9Tv9HsF/vy/5/KtWq81vFOP3i/j3rJ0UryhuUpdGZCi4vn5OEH5CrTS29j8kQ3Sd6fdGaFAkC4jxyRVO1tRIPNl4jH61xtOMuWOsu5srNXew5I7m9bc5wn6fhU7T21kNkA3yd//AK5qOS4knPkWgwvt/nipFjt7Eb5TvkPT/wCtRHTWL9W/0G+z+4YsF3dHdO21fT/61P8ANsbP5Yxvf25P50wC6veSfLi/n/jT99lZcINz/maFp76+9/oG+j+5Dlkvbj7iiJPU9aeYY4xuupS/1OB+VUjd3dw2yAYHt/jUkemsx3XDc+g/xoU3P4E5euwWtu7E3260h4iX8hihNQ3thYmI9uasx2dvH91B+PNWuldMYVuskvRGblHsIDkZqhNYq58yE+XJ7dKvggjIphkQOEJ+Y9q3nCMlaZlFtP3SKAz7ds45Hcd6sEAjBprMqLuc4HvSqwYbh0NXFW924nrqVliaBv3XMZ6r6fSoLyxE37yL5X/nWhkE4B5FOrOVGMo8j2LU2ndGJa3bQt5FzwB0J7VJdWAf97B+X+FaTxRSffQH6inIixjagwKwWHbjyVHddO5p7Wz5o6HP295LbnY3K+h7VqSRQ3iCSM4YdD/jUs9rDOPnHPqOtVorGSB90Mv4EVzxpVYe5Jc0TRzjL3loxYrpkbyLzhux7GklsnjfzbQ7D6VcmhjnTZIP/rUlvD5CbN5f61v7Fv3Z6ro+qMudLWP3Dbd5pFPnx7D/ADpy2tur+YsY3VNuXO3PNUftLS3fkRfdT7x+lay5IpKerEru9tC48iIMuwX61DcXKwAZG4t0FUR/pd7n/lnFSxEXF09w3+ri6VjKu5aQ6uy/VlKmlrInurpoIh2d+3pUc1xLBbDzD+9k/SqsObu98xug5/AdKinZru62r64H0rjnXk05xe+i/wAzojTSaT9WXdO8590sjEjoMmr8jZKxDq3X6d6gidEm+zL92Ncn68U0SbYpLs9X4X6dq9XDRtG172/M46ru7le4P2i6EK9Bx/jRePukSBOi9velsgFElw/am2ama4Mr9ufxr0dvkcxJcfu4o7ROrdf8/Wi5GxI7SPqetEH7+6aY/cTp/SnQESTSXT9F6f5+lTsAlwMCOzi79aWcDdFaJ070WuZZJLlh9Kmt4HWRp5fvP29KNgK1zmadLdOg/wA/yrQ2fOD/AAqOKcsaISVGCetJNKsSb3zj2rJu+iNBUQJuI5LHJp/zelZZ1Fs8LxR/aLf3arkkK8T/1f3qEhjt5LlvvSdP6VBYgL5k7dFFF+wG2FeiinyfuLFI+8n/AOuujp6mfUitFM1z5jdufxqeD99ePKei9P5VJaQskLbvlZ6tQwpAu1KmUtxpFeCNzM88gxngfSrCQxoxcD5j1NTU0jII9azbuWIzBFLHt6VEsgni3RNgn9KhjkeF/JmOQfutTJImt38+H7n8S07CuV4rmWCUxz5I71ZurVZ182L7386fLHHdxB0bnsf6GqttO1u/kTcD+Va3vqtyfJlOKZoJNy9uorWljju4g6Hnsf6VFd2nmfvYh8/cetUra4MD8/cPWm3fVC20ZPa3BgbyZen8qmurck+fD98cnFPubcTr5kfX+dVrW68s+TLwOxPale/vIe2jLcEyXcZjk+93FZs0MlrIGU8djVy6tmVvPg4ZeSBUsM0d3G0cg57j/CpTtqg8mLFKl3Ftbg9/8RTkckmCbk9j2YVmywy2kgkTkdj/AENaKtHdw5HBH5g0mgT6FR45bOTzIuYzWlFKkyb0qvHOd32ef7/r2NQvbyW7+dbcjutD13Baao06jljEsZQ96ZDMk67l69xU9ZbF7lONC8BglHK8f4Gq1kzRyNA/+TWrWXeIYpFuU/GtE76ENW1G5+y3ZB+49LqEOCJl+hqS9QTQLKnbn8DT7ZxcwGJ+o4NVf7QrfZI7KUSRmB+dv8qrjNlc4/g/pVf57ab3U1qXMa3MAkTqORVPR+pG680RXsXAnj6jrj+dTLtvLbDdf61FYzB0MDdun0qAE2Nzg/6tv5f/AFqm3Qd+oWkhgmMT8A8fjRfQlJBOnQ9frUt9BuHnJ+NTQSJdwGN+SOD/AI0X+0K32WSWs/nR8/eHWrVc8pktLj3HX3FbyOsih16GokrbFwlfRjug+akBDDK8inVmWeY5ZYD/AA9KVi27OxPNa+dKHdztHaq81wxYW1uMdqurPG0hizhx2qTYu7dgZ9ad7bkON9igqxWSb3+ZzVRnuLt9o6enarBs5ZJiZTx61oxxpEuxBgU+a2pHK3psipDZRx/M/wA5/Sr9FZk95z5cHJ9f8KWsjTSKLU9zHCMHlvSqiG8uBnPlof8AP1ojt44h590efQ/55pj3c1w3lwDAP51aXYzb/mLJNvbnkl5PzNOxJIN9wfLX+6P6molSKzXc/wA0h/zxTiMDz7s9Oi9h/iakaJlLMMRDavr/AIComnhibbGN8h/z1qo8812/lw8L/nrU5MNiuB80hp2J5r7EmxyPMunwv90cD8fWnozOMRLsT1/wFV4kab/SLo/KOg7U7L3ZwvyxD8zSKTJ1kB+WH58dSen596V51iwhO9z2HWqrz5ItrQfjUiqtsNi/PM/+fypWHzE4dkXfMQM9AP8APNSKzFdzjbVYkREPL+8lPQD+lTJGxPmSct2HYVBSZPTWZUUsxwBTqzb1t8kduO5yapK4SdlcmuJsW+5OsnA/Gq1z/o9usC9T1qeQCS5jjHSMbqrv+/v1Xsn9KtGcv+AFwDFbx2y9W6/5+tOuRgRWifxdaP8AXX+e0f8AT/69Oi/e3jydo+B/KkK1/wAiK/bBWBOgFLdfureO3Hfr/n61FF/pF7v7Zz+A6VK/+kX23sn9P/r1oQ9bvuOkzbWqxj779f61egj8qJU9OtUn/fXyr2jrTrORrBahVJT5lw8h+5EMD696sSt5cTP6Cs+T9xZBf4pOv40kipMgizc3e89M5/KlnJuLrZ2ztqWzAihknP4U2xiYv5rDjHB96tmCV0l3JLkGWeO2XoOv+fpU8kby3CDH7uPn8amSBFcy9WPep6zubqO9yJoo2cSMMlelS0VRkZ7eQyMS8Tdf9n/61G5b0J450lZkXhl7Gs6aS5t5wxYsh/KrU8Pm4ngOJB0PrTo5Eu0Mcgww6j0qjJ3egMsV7Dkfge4NYrh7eXnhhVsCWxm9UP61fliju4gy9exovYhrm9RsMsd5EUk69x/WqKmWynKnlD+tQKZLeTPRhWuRFew56H+RpbDXveok0Ud3EGQ89j/SobW4Kn7PPwRwM/yqtHJJaSlH6dx/UVfmgS6j3xnnsagtO+q3Kl3a7AZYhx3HpU1ndeZ+6l69j60W9wQfIn+VhwCaiubMp+9gHHp6fSgVraxLY/cNtP8Aqj0Pp7fSobm2YN50HykckCnWtyJ08qTlsfnQHa1Ijk5iPQ+nsaC9GS210s4weGHardZ81qJCJ7c4fr7GpILnzD5co2SDt60DXZlyqUCNBK8R+43K/wCFXaKCjEP+iXueiN/I/wCFS36tFIlynXoas3sXmxbu6c0yIi7tCp6jj8R0rFrdAJcIt1biSPqOR/UVUsJ/Lk8tuj/zqSwmKuYH/D61Wu4fJlyv3X5FZye00Uia+haGUXEfAJ/Wrcire2wdfvDp9fSiF1u7cxv16H/GqdpK1vOYpOhOD9aHZPyZRZsJt6G3k6j+VUWVrO4yOg5HuKsXcTQSrcxdz+v/ANerUyLeWwdOvUf4Vm02uXqgI72IXEAnj7DP4VFp91/y7uf93/Ciwm5Ns/4f1FVbq3NvLuT7h5FZyla1SPzNEvss6Kk53e1VrW4E6ZP3h1q1XoxakroxatoRq6OSFOccGoLq3M6BVfbjt2qpJ+6v0c8B/wCvFXpLiOJ1STjd0PasOZSTjMuzVmijLIlinlQj5j1JpkVuqA3V4ffBrVZEfG4A45FZt5a3M0oKnKdvauepTa961+yNIyvoVbi9luD5cWQDxgdTU1vp2fnuPyH9av21rHbjjlu5q3RDDtvnq6scqltIDFRUXagwPamTTxwLukOBVa6vUg+ReX/lVGG2kuD9oumwvX/PoKupWs/Z01d/kTGF/elsO+1Xl0+23G1f896n8qCAeZdyeY3v/hUM18qDyrUYA7/4UsVssa/ab0/ga41K70fM+72R0NWXb8ywJJ7r/V/uovXufpSoyLmO0Tee7Hp+J70wGS7G9/3UA7d2/wDrVXmvePIsxgdMj+layqKK5pP/ADfouhmo30RakeC3+e4fzJP89B2oBubn5mPkx/qagWCK1Xz7vluw601Wn1B8fciFQ5vZrV9F+rHbqvv/AMi1G6A+VaJn1Y9P/r04yJE+0EyzHt/ngVA0hY/ZbPjHVqRpY7JfKj+aU9TWntLK99F93ohct9P6+ZaaXyRvuH5PRR/nmlSWV/3jgRx+/X/61VI4xD/pd2cyHoKlOSvn3Z2oOif4+pq1Ul1/r1f6EOK/r9CykplOVX936nv9BUysGGV5FU0Elx88g2x9l9frV6uqm21dmMkkFVhcxsruvKx96hv5dlsdv8fFVXHlWEcS9ZSP15rCrXcW0uiv/kawp3V2ELGK3lu3+9J0plt/o9pJcn7zcCnagQixWy9v/wBQpLwYEFmvtn+VefL3W7fZX4s6Vr8/yQR/6NYGT+OWh/8AR7AIPvy9adeAPPDar0FQ6gxecRL/AAjH4mpn7iduit9+5Ufeav11HwfuLGSXvJwP5UlkBDDJdN24FOvzsWK1TsP/AK1Ovh5cUVqlD9x/4V+LF8S9fyGwI5t2f+O4bGfan3zAFYF6KK0kjWONV/uVjRj7TdAt3Ofwr6DDw5Kaj2PNqy5ncsTfubVIe7cmnR/ubIv3eobrfPclEGccVpyW6SBVb7idq3b0VzMqRxulltQZeT+v/wBarSW6iAQt+NWAMDFLWTkXYaqKi7VGBUUk6RMFfjPftTZo5HAaI4ZenoaYrR3UZjcYI6j0oS6sY28WYpvjYgDqBTbW5WdfKl+9/OiKRrZ/ImPy/wALVDd2xVvPh+pA/nV6bMjzIrm0eNt0Sb1Pb0qt5Vx/zxrXtrpZlxJwwqzvj9armktAsj//1v3k+zS3ExlbhCf0rVKqSCRyOlI0iIQGIGemaiuROU/cHBq27itYkllSJN79KqwXscz7CNh7e9Jb3ay/uZhtfpz3qvc2ZT95AOPT0qklsyW+qNiisq1vgf3c/Xsa1ahqxSdyOSNZUKN0NVUkkgbypuQfut/jV6o5I0lUo4yDQn0GVJI3t382EZU/eX/CnSRx3cW9Dz2P+NCM9ufLmOY+zf0NJJE8Ledb/wDAl9fpV3Agtp3hf7NccehovbXOZoh9RVllhvYv85BqGGd4G8i549DRfqiPIq2l15J2P9w/pVu6tFnHmx/e/nUd3Z5zLCOe4qva3TQHY/Kfyp76xFtoyS1ujEfIm6L3Papri1YHz7fqOcD+lSzW8VyvmRkZPQ+tVIbiS2fypx8n8qW+qDyZaguknHlyj5/T1qJ4ZLV/Og5XuKfcWyzDzYT83X61HBeFT5Vx1Hf/ABo9AfmWWWK9hyPwPoarxXLwN5V126GrRhAbzoTgnqOxpXjjuU2uMEfmKm5VhkkIZvPgOH9exqSKbf8AI42OOo/wrPDT2TYbmM/5/CrwMF2u4dR+YoYky1THRZEKP0NQB3i+Wbkdm/x9KtVBZWhiMaGJuU7fQ9qzFJs7nB6f0rcqld2xmUMn3l/Wri+5El2Ir+HegmX+Hr9KisJsHymPB6VNZyFkNtKPnTsfSs24ie2mwOnUGrW3KyHp7yLNxGbeZZI+AeR/hVyZFu7cOnXqP8KBtvbX0P8AIiqNlOYZWhk4BP5GlcNvRlqymDoYJOq+vpVUhrK53D7p/UVJdxNBKt1F68/X/wCvVqQJeW+5evb6+lK/Udr6dRt1CJ4hNF8xA49xVaxuNreU3Afp9aLG48tvIk4yePr6Uy/t/Lbzl+4evsaf91kv+ZG5Wc6mK7SUdH4P1qS0uPPjw3316/41PLGJFK/kfQ1Gxo9VdGde5inSUd/5itCSZY4xKeVOP1qtqC7oN+OUNJakTWpjPVeP8Kf2SNm0X1dXXcpyKdWPYOVkaJuM9vcVo+agl8knDdR70mrFxldXKV5O7N9njH19/alREsk8yTlz0FaBRSwYjkd6ybqC4Mm4/OD0x2pp9CJK2pVdpbqUA8k9BWh+7sYtq/PK3+fyoASwi3HmRqZAowby5+oz/n8qq5CVvUkRPIzc3JzIentVEma8lAH4DsBSSyyXMvr2Aq8SljDtHMjUbC306CSSJZx+VFzIe9QW0BlJnnPyjnnvSW0DXLl3+73PrUs8huHFvB9z/P6Uh76scWa+l2JxEnX3plxMSRaWw46HFPmcQItrb/fPX1qSKJbVAAN8rdP8+lBVhY0Fqgjj+aVv85+lI8i23yr+8mk/z/kUSyC1QnO+Vup/z2p1rblP30vMh9e1LzH5Ikt4Cn7yU7pT1NW6Kg80Gbyh1Ayajc12IZHZ7pYh91BuNV4/3uoMeyf04qWDDXc0npx/n8qjsessx7//AK60Mt2iaA5muJT0Bx+VVrE8y3L/AOe5p8fyWDuer5/XimoBHp5I/i/xxQLsFkdkEtw3J/wotR5VrJMepz/n86JP3dgqf3/680sw2aeiD+PH680ErQZp4CrJM3RRj+ppbD/lrcN/nuaWMeXp7MP4v/1UqjyrAnu/9f8A61NjStYWwBbzJm6k4/rWpVG3XZBEvdzn+tXqhmsFZWKN0SzRQDpIefoKhu4pbiYRxjhR1PTmr7RqziQ9VHFPZlQbmOBRcTje9yKOFUiETcgVMSAMntUbFmjzCRk9D2qlHdSxN5dyPxqR3SFGoxGTZg7fWtAEEZFZ9xaLMPNixvP5Gq0Fy9u3lS/c/UVduxHM07SNqkIBGDSKyuNynINOqDYobWtG3LzEeo9KfLF5mJoThx0PrVyqRRrcl4xmM9V9PcVVyLWHI6XKGOQYYdR6VUXfYyYbmNqtyRLOBNC2HHQ/40kcqzgxSrhx1U/0qRNCXECXKB1PPY+tZcUslrL/ADFXf3lk/PzQn9KnngjukEkZ57H1oE1fVbiukN5FuU/Q+lZscsllLsccdx/UVGks1rL0x6g961v3F9F/nIoDf1GyxJdx+ZGfm7H+hqGC6MTeTc8Y6E1XxNp75+8p/I//AF6uukF9HuU4I79xQCGT2m4+bBw/XFSwTLcoYphhx1BqlHPNZv5Uwyn+elXzHFcgSocMOjDrQWioWlsH2n54j09qtMkF4gdTyOhHUVIDvHlTgZP5H6VmywTWjebAcr3/APr1LHsXUmaNhFc/g3Y1dqjDcw3S+W457g04CS36Zkj/AFH+NO4y5VSKDyJS0f3H6j0NWEZXXcpyDT6Vr6gYl9EYZhOnGefxq44F5a7k69R9asTwieIxn8PrWdamS0m8mbgP09M1k1Z67MCpazGCUE9Ohq9fwBlFwn4/SoNQt9j+cg4fr9asWMwljMEnOB+lYpb05F+Y+3kW7tzFJ95eD/Q1UtZHtLg28vQ/5zUZL2Vz6j+Yq7eRLPCLiLkgfmKV21fqi/Ir38BjkFzFxnr7GrqlL+2weD/I1HaSrcwGKXkgYP0qgheyuGDcjv7ipbUXzdGUlfTqhsUj2k/zduCK6FWDqGXkGs69gEsf2iLkgfmKh0+5wfIc8HpRTfs5cj2YSXMros38RaMSr1jqO/Hm2qTDtg/nWmQCMGqvkH7O0PUc4/pWtSlfmt1QoytbyGWkxe1DDkoMY+lSwXEU65jPPcd6zdNkw7RH+Ln8qiz9kv8A/Zz+hrGNdqMZdNmaOF20dBWffXRgQKn3n7+lWZZ0hI38A96eyxyrhgGHWuyd5Jxg9Tnjo7tGNbWy7ftNz93rz3qC6unuDtHEY6Cr9/BcS7SnKr/CKgtrdIU+03HygdBXjzpyT9jFWXVnbGS+Nj4II7WP7Tc9ew/z3ojVrpvtNycRJ0Hao0D6hPvk4jSo7y680+VFxGn60c0Yxv8AZ6eb7sdm35/kJdXbXDeXHxH2HrVqKNLGLzZeZT0FMtYkt4vtU/X+EVV/fXtx7n9BWV3F88tZPbyKsn7q2QqpNez5Y/U+gq5NIRiytR7E/wCf1onlW0QWtv8AePU0qhbGHe3+tfoKuMeW8b6/af6Et3s/uQPIllH5UXMh6mmwQLAv2m45c9B3z/jRBCEBvLr6gGpy4Ufa7nr/AAr6f/XrWKvactLbLsu7M2+iEYiL/Srv738K+lJBFJdMLi56fwrUUET3kv2mf7g6CtmumlD2nvPb8/Nkzly6LcKoX8rxxqsfDSHFTXE4iVQPvOcCqtz899BH6c/5/Ktq8/dcY76L7yKcdU2Q34zJBbL/AJ7VPKA97FEOkYzUDfvNTA7L/QVYhw99PJ/dAH+fyrjiuaT83b7jZ6Jen5lU/v8AUsdkP8v/AK9Pj/fak7do/wCnFNsPmmluD2H8+aSxJWKa5P8AnvWEHzcrfVt/cXLS6XRWH2/76/eXsucfyqCH/SNQ3dsk/l0qWx/d2083+eBTNMUeZIx7D+dKPvezT6tsp6cz7aD/APXal/sof5f/AF6X/X6n7R/0/wDr0mncvLO3b+vNJYHAnuW/z3qoe9yt9W39xMtL26Kxo3LMYCIxktwKhs7VoSXk6txirkY2xqvoBQsiMSqkEjrXvqTsec1qKqqv3RjNVbi7SA7cFmqKeS6gk8zG+P0FTf6Pex/T8xTt1YrksM6TJvX8R6VPWAwnspNw6evY1rW9xHcLleD3FDj1QJlmqk8DE+bCcSD9at0VCdhlRXjukMcgww6j0qON3t28qc5Q/db+hqWaAuRJGdsg6H/GkVlnBhlGHHUf1FXcCvcWRdt8GBnqKr/YLr1FWvMktfkkBeP+Fh1+hpPt0f8Adkq7kWR//9f97Z7SO4HmIcMe/Y1VjuJrVvLnBYf56VJ5VxaHdEfMj7irUcsF2m3r6g1oZjZIYLxd6tz6io0lltj5Vz8ydn/xqJrSWBvMtm/D/PWp4bqOb91MNr9CD0NACT2cc37yLhj+RqtFcy2jeVcKdvarfkyQndbHj+4en4U4Swz/ALqVcN/db+lK5ViyjrIu5DkGn1mG0lgbzLVv+AmpUvFLeXOvlv79KVuw79y4wDDaRkGokRoxtHKdvUVPRUjKkkDK/nQcP3HY0Ziu4yjjBHUdwat1XlhEhDKdrjoRVXFYqK8tm3lzfNF2b0qWe2iuV3xkAnuO9TIXZSkyc/mDVU28tsd9ryvdTTuMpI9xZvtYcenY1pg297H6/wAxQk0N0vlyDB7qapyWc0DeZbHPt3/+vTI2ExcWLZHzRH/P4VbaOC8Tcp59e4+tMhvUl/dzDY3TnoaWS0aNvMtjtPpS9RFVWuLJ9rjKH8q0Y5I7hd0Z5H5ioUuY5f3VwNjdwehpjWbxP5tqcH0ND8x+ha8xc+VMAC35Gqr2TI2+2bYfSp0YTxlZUKnuCP5U6GF4iR5hdewP+NLYq1xsUzufLmQhv0NSpGseQucenYVNRUjCiqxtoy/mc7vXNWaAInjV2DH7y9DUdzbi4j29x0NWaKLhYwbWVrefZJwDwan1G3589foasXloJhvT74/Wm2kvmxtBL95eOfSrv1MbfZYWsq3UDRS8kcH6VVt3a0uDBJ90/wCQajIexuc9v5ir15CJ4hLHyQM/UUx/oQX9vj/SE/H/ABqzbzLdwlJOuMH/ABplnOJ4zBJyQPzFUHV7K4DL07e4peQtveAiSynz1x+oreR1kUOhyDVSVY7yDcvXt9fSqVlcGJ/Ik4BP5Gh6jWjsa8iB0ZD3GKyLBzHOYm4zx+IrbrEvImhn89OhOfxoXYcu4XQNtdiZeh5/xqe/TdGk6/w/yNOvFFxbCVe3P4d6W0YXFqYn/h4/wov1JtuizBL5kCv1OOfrUkcqSrujORWVYuYpmt37/wAxUmPs99/sy/1/+vSsWpFqW0jmcOxOR196z795NwjxiMdPetOS4SJwsnAboamZVYbWGRQnYHG+xlWqrBE1zL+FVVWW8n579T6CtS7tnmUCNsY7VXOLG2wP9bJ/n9KdzNx6dBl3OsafZYPof8KkUCyt9zf616hsYgxNxL0X19fWpIf9KnNzJxHH0zTBX3HRJ9nQ3E3LnoPrTwxgQ3M/Mj9B6e1Rxk3dwZW/1UfSoDuvrnA4jT+X/wBegfoT2kLTP9pl59K1aaFCgKvAFOrNmkVYKzLQh55pasRkiWc9hgD8BVSw+W3lf/PAoDqh9sx+yyy9zk/pTIPlsZG/vZ/woU7dNJHf/HFJ00v6/wCNaE/5D5jssYx/ex/jRcDFnEg6nH8qS9+W1iUe38qkuh+9tlHTP+FBLW5HqBx5cS0uoHaqIKZd/NfRD6fzpb6GaadFjGQBQJrcdL8tgg9cf40+6jkMMUCDJ/wFT+QrwxxSfwY6ewq1U3L5SIIvyf7HT+VS1GkschIRg2PSs65e7hk8wHMf6fjUlt21LM90LdgChOe9Kyw3ceQfx9Kjhu4bkeXIME9j0NRtaSRN5tocf7JoI39CE/abE5Hzx/p/9arqSQXabT+XcU2G6SU+VKNj9MHvUc1iC3mW52sO1AJW2ACazOR+8i/UVM8cF4m5T+I61DHeOjeVdjYfWpmtwT51u2xj6dDQHkigPtNi/TfGfy/+tWpFPHOu5D9R3qFbjb+7uV2k9/4TTJLFSfMtz5bfpQCVtjQorPW6khOy7Tb/ALQ6VdVlcblOR7UFpkPlFG3x8Z6jsf8ACllhEoDfdcdD6VYooHYqRylj5FwAH/Q/Sq7Ry2bF4fniPVfSr0kSSrtcVHH50Z2SfMOzf40CsMIt72PPX+YrMkhuLR96nj1H9a0JbT5vNtj5cn6GiO7GfKuR5b+/Q0EtdwhuorpfLkABPY96gltZbZ/OtencU6ewDfPbnafTtTYb14W8m6ByO9AepPHNDeJ5cg+b0/wqm8E9k3mRHKf561cmtY5/3sR2P1BHemR3UkLeXdjHo3rSYepJBdRXI2tw/p/hUpcw/wCs5T+96fX/ABqvJZRS4lgO09RjpUkEkxPlXCHPr2NT6lIZNZxS/vIjsbrkdKSOaeEiO4QkdmHNSi2Mcm6JtqHqvarlFuoyHyVD+Yvyk9cd6moqtLbxzcvk47ZqttgLNRyRpKuxxkGlVdq7R+tPpgRNGrx+W/IPFYLLJaTj25B9RXR1XuLdJ02twex9KwqU+ZXW5aditcxreW4kj6ryP6iq2nz7G8huh6fWltZGtJvs03AbpUd/AYX86PgH9DXNJvSovmWl9kJo2s7kTRfcP+SKuXMS3UAmi5IGR/hSqVvrXn738jVSynML+RLwCfyNDsnZ7Mrz6ofYXPPkP0PSory2ML+ZH9w/oaW9tzG/nJ0P6GrlvKl3AY5Pvd/8az5eb91LdbDvb3kS2lwJ48n7w61brnQ0ljc4PQfqK31dXUMvINddCpzLllujOcbaowZM2t6WHQHP4GrOpRgqs6/Q/wBKl1GBnUTJ1Tr9KS1IurMxN1HH+FcXJrOl31R0c2imL/x92GP4l/mKbpku5DEeqcj6GoNNkKStA3Gf5imNmzvdw+4efwNJVLctX5MHHeBsJPG7mLOHHY024tluV2sSMdKo36lDHdJ2P/6qvSXCpCJsZU4/WuznUuaFTp+RhZq0olG6DWtsIogcH7zVTs7cTPvf/Vp1rfR0lXchyDUMtuGhMUX7vNYTw/NJTWqXQ1jVsuVmJdTNdS7U6dFFXyV0+DaOZXpsFt9kD3Fx/B0xVOJXvLnLd+T7CuD3ovmfxy/A6NHotkWLOIKGvJ+g6Z70+JPtDm7n4jFJMftU62kXEcfX8KfOfNkWzg4Qda0SSVlql+LIu3r/AEkOU/aHNxLxDH0FVRv1C454Rf0H+NSXUmSLSHovH1NadtAtvEEHXufetIwdWXI9lv5sly5FzdehKqqihVGAKfnFFUpcm6hTsMmvVlLlRyJXK0p8zUY0/uf/AK6evz6k5/uLUMfz6m59M/yxU9pzd3L+hxXmQ96XrL8kdr0XyIbP576V/r/On2zfurmb1JqHTjzNJ7U6DjTpT65rKm9Iy/xMqa1a9BtoNllM3rkfpS/6vTPdj/WkHy6WT6n+tLefLZQp9P5Uvhh/27+Y95/P8hR8mmZ/vf40af8ALbzv/ngU64RzZQxoCS23p9KltIGS3eOXjzM/lirhBurGy2X6EOS5X6le3ymnyEdXOPz4qza27C1MUnyljzV2ONYkEadBTTNEJPKLjf6V2QoKNuZ9LHPKo3ew9tpG09+Ky5bOSE+bbE8du9W7i3knbG7CjkfWoFuJrc+XdDI7MK9CL7HK13Fhvlb93P8AK3r2p0loUbzbQ7G9OxqSW3gul3DqejCqgNxZfe/eRfy/wp+gvUtxzx3AMMy4fupqlNZSQt5tsScdu9Xf9HvUyOo/MUgaeA4k/ep6jqPrRcRHb3yyfu5vkf8AQ1o1SeG2u13jr6jrUKi6tOMebH7dRSsaGnUMkSyYJ4YdCOopsVxFOPkPPp3qxU7ARoXxh+T6in59qWigD//Q/eWC/ZT5dyPx/wAasy2sc/72I7W7EVLJFDOMSDn9aqfZrm2O62bePQ0GYC6ntjsulyP7wqwVtrtexPt1FNS6hl/dzDYfRqjk09Sd8DmM0AOCXNv/AKs+bH6HrUiy21wPLcc+jdahE13b8Tr5i+oqXNreL2J/Wg0JBHLH/q23D0b/ABppaOX93KuD6N/Q1H5V1B/qX8xPRuv504XUT/u518s+jdKBXEFtJH/x7yYH91uRTxcsn+vjK+45FO8lk/1L4HoeRR5kif6yMn3Xn/69AyZHRxlCD9KfTQq53Y5qKWeOEfOefSqtfYTdtWT0VUieVz5r/InpUyvkbui+poasJSuJJBFJy65Pr3qUDAxUKSeYfkHy+v8AhSiVS+xOcdT2FFpDvEbNbQzffXn1HWiGFoRjzC496WWeOEfMefQUsTvINzLtHb1p2drk3V7CywRTDEgzTkRY12r0FPoqCwoqtPcpDweT6U0zNFFvl+8egrTlkRzrYklmEYAxlj0FNkn8mPdJ949AKrxfKpup+p6VDEjXcxlk+4P84rRRXUxc303ZYhaQg3E74HYdqkVm5mlOxOw/xpuVkPnPxFH09/eoFzeSbm4jTtRa+rFe1kizFLLM25RtjHr1NOFwHk8uIbsdT2FV2drh/Jh4jHU04sEP2a2Hzdz6UOI1Lz/ryLhdQwUnk9qa0SM4kI+Yd6rHZaDj95K/5mnqXiUvKxZm6KP6VHL2NVLox9xAtxHtPXsar2YmiHkyqcDoe1XNwUDzMAmpKyL63MK4ha0mEsf3e3t7VoEJe2/of5GrTKrqVYZBqGO2jhfdFlc9R2qrk8tjLt5ntZTFLwD19verV7aeYPNi69x61YurVbhcjhx0NMto54h5UnKjoQelSK3RiWVwZk2P95f1FW3RZFKOMg1n3FtJHJ9othz3Aq/E/mIGIKn0NBS7Mr2yGMPbvyByPcGqEBNpdmNujcf4Vt4Gc1l6jDkCde3BqkJrqhl+nlyrcJ/kip7pfPt1mj6p8w/rToiLu1w3XofqO9Q2EpGbd+o6f1qRfqSTgXVoJF6jn/GpLGfzodp+8nBpIQIZmg7N8y/1FUjmxu/+mbfy/wDrUBtqbdMZVcbWGR70+oZi4jJj+8OaDQjmtvMh8mM7BVa6SRIVt4EJB6kVcgmE0Qk/OpEdHGUII9qCbJmXdMIIVtY+p6/596u2kPkRBT948mpWijZg7KCR3qWquNLW4VV84m58kdFXJqx83GPxqsInF2Zf4CuKkGRqcR3Le7foKgteLCX/AIF/KrKxP5U645ctj8aSG2dLVoWxk5/WquKxBJ8unAeuP50k/wAthGPXH+NXGtw9ukDn7uOR7VJ5MZRY2GQnTPtRcLFS9Rn8pFGeasSRF545OyZqzRUjsQmCMyebjLVNRUMsQkxhipHQigYy4maBN6oX/pVOHUQTiYY9xVkTSRHbcDj++On4+lRzWUUw3xHYT6dDQQ79CRreGb97Edrf3lpwleP5Zx/wIdPx9Kxj9ptH7r/I1ow6ijfLMNh9e1AlISfT0k+eL5D6dqrx3M9s3lzAke/X8K1FQAbojgHt2pWCSDZIvX1qrj5eqIWS3vEz19+4qqWu7T7372OnNYtG3mWzYPoael4yHy7pdh9e1SL1JUnt7pdp79jUf2aWE7rV+P7rdKWSzt5xuj4z3HSogL63/wCmqfr/AI0B6k4uUP7q4Xyyex6GniBkGYG2+x5FRpc21wPLfg+jUhtZIzm1k2j+6eRQBL5uBtnXb79V/P8AxphtVB3wOYyfTofwpBdmM7blDH79RUgijb57dtmf7vT8ulBe40SzpxNHvHqvP6VNHNFL9xgfbvTN9wv3lDj1X/A/409QsqhmX/voc0DJqKY8iRLuc4FVFnlnbEQ2oOrGqSvqQ5JaF6o3jSUbZAGFJvy21OcdT6Uwygv5cY3Hv6CpsVeJIkaxrtTgUSRJKu2QZFNeZUIT7zHsKc8qRLukOKLBeJXjtfJOYpCAex5FWXRJBtcZFV4p2mb5E+T1P+FW6LAmnsQRwRwgiPPPvU9FRTTJCm96B7EtRySLEhdzgCq0U7yAzP8ALGOnvVdM3knmPxEnagjm7FxJiYzLIPLX9aqpJLdS5UlIl9Khlke7mEUf3B/nNWioP+ixcIPvH+n41mF7i73nf92dsS9T601rmSV/Ktv4erHpUMkhmcWtvwo60+RvIAtrYfvD1NTcq5YkuViIjH7yT0FTNKqIGlOzNUvksxk/PM1KE8v/AEm7OX7D0+lHMxlySKKYYcZoaNXj8t+QRjmqkbSyN9omPlxjoP8AGrCykqZJBsXtn+tUmn0Az4Ip7SfGC8R7inX9tn9+n4/41qKwdQy8g06svYpxcehrz63M20nW4jMEvJA/MVRZZLK4BXkdvcVqGzhD+YmUI54qaaFJ02P/APqrOVKco67oakkytNHHewB069v8DVOzuGik+zy8ZPfsalt7e6tn+XDoeozUt7aecPMj/wBYP1qGpv8AeJar8TRNfC3oaNZqxfZbnK/6uXj6GpLSWR08uUEMvqOtXGUMMGumyqJSRl8LaZh3yGC6Eyd+fxq1eILm2Eyfw8/h3qxew+dCQPvLyKpaZMCGgb6j+tcUoJTdN7S/M2TvFSXQltiLqzMTdRx/hRafvLeS2k6plarRH7FeGNvun+Xarkw8i4W4H3X+Vv8AGpg9FKW60foVJdF11RWsJDHK1rJ+H1FbVYmoRmKVbiPgn+YrUglE8QkHfrW+HfK3Sl0/Izqq9pomIBGDUH2dFVhEPLLdxVg9Ko2tw7s8Mv8ArI/1rpm43Sl1MknZtESwvaWzGMb5D3FQw/6JbGdv9ZJ0rUEsZcqCNw7d6V4o5RiRQa5nQW9N7aI09p/MZ1hBx9ofqen+NatNChQFXgCht207evauilTVOKijKcuZ3Kl1MYvLReshx+FDDN8vsn9aS6iklaEqPuNk1Jsb7X5uPl2Y/HNYyUnJ32ujVWS+8pWnOoTn6/zp1qebl/c/1qW2gdLmWVhw5OPzp8FsyJKrH/WE9Kwp05aadWayktfkUrDi1nb2/pTox/xLDjv/AI1egtY4YzGCWDdc1OiLGu1BgCrp4dqKT7NfeKVVXbXcz/s7yWKwjg+/1q3JbRyqqychKsUV1qjFaPyX3GDqMaFCgAdBTZHKIWVS5HYUSRrKmxulVP8ASLf7372P1/jH+NOcnHpoTFXKi6m4f95Hx6DqKuFbW9GRyfUcEUjQ214u9evqOv41ky209q27t/eFeVKVWCvP3onbFRl8OjNCZ7u2QYPmKD17/Q1NDdw3I8uQYJ7HoahsrySVjHKM7RnNTS2MM3zJ8p9ulenQnGVO8TiqxanqRvbSwHzLQ/VadFfIx2Tjy2/SmLJdWvEo8xPUVY/0a9XsT+orq9TH0GvaxOfMhOw+o6Ugmng4uUyP7y/1qH7JcQHdbSZ9j/nFSreFTsuUMZ9e1QIlCwzfvIjg+q9fxp26aP743j1HX8qja2hk/ewtsPqtN8y7g4lTzV9V6/lQaD2it7n5h94dxwRRi5i6HzV9+DSq9vc8qefyIpdtwn3WDj0bg/mKAAXUX/LTMZ9G4p32q3/vj86QTHo8bA+w3D86d5o/uP8A980Af//R/fCK7guPlPB9DU+HX7pyPQ/41gWv/HxXR9qpgVWMMnyTLg+jf0P+FJ9meL/USED+6eRUV3/roq0akCn50sfE8Z+q8j/Gjy7S4+ZcZ9RwasS/crMsKfUC3tuYvukSj0PB/OgzwSfJMNp9GFWj1FY97/x9D6U0BfFsqf6hzH7dR+RqwoYLhzk+vSl/iobpUgVLq5EQ2p98/pUEMAANxc/XmoLz/XtV+5/482/3a6WrLQ5G7z1FJ3DzZ/kUdAf60xS1x+8f5Yh29frT77/j2emRf8ehpdLlPewze9y2yL5Yh1NMmuREPJg4x3p1h/qXqhN/rGrRRXNYycnyc/U0be1x+8l5b0rQpF6Utc0pNvU64RSjoJnnFVUlLM8hP7teB71Z/irPi/49D/vU4ikRwKbi4MrdBz/hS83dz/0zSn2PRvotJYdZK6XucsdUrkdw7TzCKPoOKslR8trF06sfb/69VYP+Po/WrcP/AB9P/uLUS02HT1bv3K1w5llFrF0HH+fpT5zsCWcPU9aii/5CB+rU9v8AkJL9KEtkDerJJXFsgtoPvmlUfZIgq/PK/wDP/CoZ/wDj/jqxP/x8Q0dh9QUCD55Pnlb/ADxUqhl+ZuXb8h/9aop/9dDVnv8A8BrN7mi3K8kkVud8h3SH/P4CnxNM37yXCL6f41n6h/rD/uVpyf6l/wAaUujGviHpLHJnYQcU2US4zEeR2PQ1RsP461KjqaL3o6mdDds0vlTLsP8AWrkkqxld3QnGayX/AOP7/gVXb37if79bSiroxjJ8rLjMFGWoYhRknAqOf7lJcf6uuc6X1JEdG+6QfpQ6rIhRuh4qlY9DV7/GjqC2Ma1L2t0YpOA/H+FF4jQTiePjPP40t1/x/J9VqbU/urTM+hNN+9iSeL7yfMP6iknjW8tw8fXqP8Kdbf8AHoPo1Fj/AMesdI0ItPn3p5LdV6fStKsLTv8AXn/drdoFHYpQxm3lZB/q5OR7H0qqP9FvsdEl/r/9etKTqn+9Wbff8fUP1X/0KgTJ7ueaBg6YKHjB9antrgXEe7G0jqKqaj/q0/36XT+klAvtFtLmJ5DEDhx2NSsyoNznA96xk/5Cj1oX3+poKTLSsGG5TkGkVlbODnHBqO2/1K1HbdZf96gY2e7SBtrKf6VPHKkyboj/APWrM1SptM/1LfWgXUX7TLbvsuRkHowq+jpINyHIrN1LpHVmx/1NAlvYuUUUUFBVUwbTugOz27H8KtU3utAEG8MNkyYz68g/jVObTgfmhO32NW5/uJ9RVqgjfc5wNcWjd19j0NaMN/FJ8so2H9Kh1XqlZh60C8jpggAyh49OoqMuoG2dcD35H5/41JB/qxUV7/x7tQWxv2ZAd8DGMn06flR5lzF/rE8weq9fyqwnQU/vQMqbrW6+RsE+h4NAhliH7l8j+63P61mQf8f1bq0C3KwnAG2dDH9eR+dIIIG+eE7fdT/kUzUf9RRZf8etAy1GHUfO2704xTJ50gTc3XsKsVlan0WqW5EtIuwxIpbt/NlOEH+eKuA7/li+WMdT6/T/ABpbX/j2FJb/APHqv+7WsjnhsR+YZm8i2+VB1Yf0pGl2EW1qOe5pmm/dNJB/x+GoJ5nYkd1s12j5pG6k1DBA903mzHj+dJqH+sFXbP8A490prY0Ws1B7FkAKMDgClJA60j/dNNesjpIXkYzCFPqx9qo3DG4uRCnQcf41bX/j7f8A3KpW/wDx/H/eagxm9CW6bJS0i7U27cQRC2j/ABob/kIior7/AF5pMT3ZZiQ2sQ4zK/AFJcP9niESHLPyTVif/XW/1/pVG9/1if7tJlvTYmUCyt9x/wBY9C4tIjLLzK/+f/10aj9yOjUPuL/wKs3oaCQL5ateXHJPSnqu8/arrgD7q+lE/wDx4L+FSXX/AB7VICqTJ++lGFH3V/rSSbFHm3R47L/nqaef+Pdf92q2p9If96n0YEkctxcNmMeXGO56mrQnhL+WHBb0qK1/1ArMh/5CVKMnYuxtSKzLhTtPrWa17cW8my4QEeorVPSsTU/vVnWm1qmVDVams8oWLzQN468elOWRXj8xeQRmq6f8eX/AP6UWv/Hmv+7XQpO/yJsWVZXUMpyDTVmic7UYE+lRWn/HulZ1p/x81Lk9Cbbm3WBcI9pdCZB8pOR/UVv1k6n92L6tWGL/AIan1N6T1DUIxLClynO3+Rp9uwu7UxP1Xj/A0r/8g4f7oqLTP4/otYL+Mv7y1L/5dk0P7+3e2m+8nyn+hqlZytazmCXhWOPxq7bf8fNz9VrNuf8Aj9X/AK6VlUbShNblpfEjo6z5ojHOLuP6MPb1rQqCf/VP/u16dWKcVc5oPUz75TFIl0n4/wBKszyyG3E8B98e1Raj/wAev/fNOi/48F/651wS0nOxstVES0vTO3lyAA9sVZkuoopPLk49+1Yun/8AHyv41Pqf3qmnXm6HP1uOUFzm2SAM9qYkscn+rYNj0ob/AFdZml/x16XM72OVLRmnvTf5efm64qK4uFt13MpI9qh/5iH/AAGl1D/UVnUm1FtGkYpyVx1veRXHyjhvQ1DNJc2z+YR5kX6is+w/4+617z/j2euJVZyoKbeptypTsh8NxFMMoefTvVisLTP9cfpW7XoUJOUU2YTioy0CiiitjIqSW6s3mRny5PUf19aQPLH8s65H95en4irJ602b/VP9KwnFRbaNY67lR/s1sVuFHD/Lx09f6VYV4pxujbn261mXX/HhF/vf0an6X0NbwilHRGTk29TSLOv3hkeo/wAKhMVvcfMPvL3HBFWm6VRs/vyUASbLqL7rCUeh4P50faYj8k6GPPZhx+fSrX8VZup/cWnuLYsfZ0/1lu3lk+nT8qXzJ4v9am8eq/4U+H7i1M3SkMq4tbjngn8jT1ikQjbISPRuf1rNtP8AW1tjpVMSCiiipGf/2Q==	2026-06-12 17:11:11.237	2026-06-30 00:00:00	ชำระอัตโนมัติผ่าน SlipOK | ยอด ฿199 | Ref: Affb87d6c93314681	2026-06-12 15:28:43.49	2026-06-12 17:11:11.297	199	Affb87d6c93314681	t
\.


--
-- Data for Name: InvoiceItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InvoiceItem" (id, "invoiceId", type, description, quantity, "unitPrice", amount, "createdAt") FROM stdin;
cmqb304iq0002jo043tl3s4ok	cmqb304iq0001jo04qzie7ntz	PLATFORM_FEE	ค่าบริการระบบหลัก JadHor OS — แพ็กเกจ Starter (รายเดือน)	1	199	199	2026-06-12 15:28:43.49
\.


--
-- Data for Name: MaintenanceRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MaintenanceRequest" (id, "roomId", title, description, "imageUrl", status, "createdAt", "updatedAt", "isDeleted", "scheduledAt", "scheduledNote", "preferredAt", "aiCategory", "aiTechnician", "aiUrgency") FROM stdin;
\.


--
-- Data for Name: MeterSubmission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MeterSubmission" (id, "roomId", "tenantId", month, year, type, reading, "photoUrl", status, note, "approvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Notification" (id, "userId", title, message, type, read, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Parcel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Parcel" (id, "trackingNumber", "recipientName", "roomId", status, "receivedAt", "pickedUpAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, "billId", amount, "slipUrl", status, "verifiedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Property; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Property" (id, name, address, "imageUrl", "leaseTemplate", "ownerId", "createdAt", "updatedAt", "companyName", "promptPayName", "promptPayNo", "taxId", "defaultCommonFee", "defaultInternetFee", "defaultParkingFee", "electricRate", "waterRate", "signatureUrl", "isDeleted", "defaultAdvanceRent", "defaultCarFee", "defaultKeyDeposit", "defaultMotorcycleFee", "defaultSecurityDeposit", "enableTenantReport", "reportEndDay", "reportStartDay") FROM stdin;
cmpy7gswa0004r2agzlwm61bd	สบายดี อพาร์ตเม้นท์	123 ถ.สุขุมวิท กรุงเทพ	\N	{{START_DATE}}\n{{TENANT_NAME}}\n{{ROOM_NUMBER}}\n{{RENT_PRICE}}\n{{START_DATE}}	cmpy7gsse0001r2ag8ry4b9km	2026-06-03 15:12:39.754	2026-06-05 16:16:22.627	อรรถณพ	อรรถณพ ศรศรี	0640353806	1339600028457	100	150	100	7	18		f	\N	\N	\N	\N	\N	f	24	20
cmq224yze0001r2aopkyeezpq	อนา เพลส	บางปลา		\N	cmpy7gsse0001r2ag8ry4b9km	2026-06-06 07:54:34.392	2026-06-11 18:24:18.15		อรรถณพ ศรศรี	0640353806	1339600028457	\N	\N	\N	7	18		f	\N	\N	\N	\N	\N	f	24	20
\.


--
-- Data for Name: PropertyStaff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PropertyStaff" (id, "userId", "propertyId", "createdAt") FROM stdin;
\.


--
-- Data for Name: RegistrationCode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RegistrationCode" (id, code, months, "isUsed", "usedById", "createdAt", "updatedAt") FROM stdin;
cmq0shx770000jx04eofwlinu	8FBVIJZA	1	f	\N	2026-06-05 10:36:56.276	2026-06-05 10:36:56.276
\.


--
-- Data for Name: Room; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Room" (id, number, floor, "rentPrice", "inviteCode", "propertyId", status, "createdAt", "updatedAt", "imageBalcony", "imageBathroom", "imageFacility", "imageMain", "isDeleted", "electricMeterStart", "hasAircon", "hasFan", "hasFurniture", "waterMeterStart") FROM stdin;
cmq3d8ccw0001lb044p78s2ix	102	1	3500	YKWSBQ	cmpy7gswa0004r2agzlwm61bd	AVAILABLE	2026-06-07 05:52:53.648	2026-06-07 07:14:16.912	\N	\N	\N	\N	f	0	t	f	f	0
cmpy7gt040006r2agan42aflc	101	1	4500	01Q4Q4	cmpy7gswa0004r2agzlwm61bd	AVAILABLE	2026-06-03 15:12:39.893	2026-06-13 07:39:24.927	\N	\N	\N	\N	f	0	t	f	t	0
cmq5fsze70001l8042t0tmxgo	001	1	100	ZG1TUD	cmq224yze0001r2aopkyeezpq	AVAILABLE	2026-06-08 16:40:28.207	2026-06-14 14:52:01.268	\N	\N	\N	\N	f	0	t	f	f	0
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: SmsAddon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SmsAddon" (id, "ownerId", tier, quota, used, "resetMonth", "resetYear", "isActive", "createdAt", "updatedAt", "thaibulkApiKey", "thaibulkApiSecret", "thaibulkSenderId") FROM stdin;
cmq3zs77h0001l104g5nj2xip	cmpy7gsse0001r2ag8ry4b9km	SIZE_M	120	0	6	2026	f	2026-06-07 16:24:11.427	2026-06-12 05:16:35.592	5IzjYJ-_M6yt9IekUC732EWGAPpbTj	aGMyYzdYVTCBeMSfGcTEPazjR47bN_	Demo
\.


--
-- Data for Name: SystemSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SystemSettings" (id, "heroHeadline", "heroSubheadline", "heroImageUrl", "contactEmail", "contactPhone", "pricingMonthly", "pricingYearly", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Tenant" (id, "userId", "roomId", "leaseStart", "leaseEnd", "depositAmount", "idCardNumber", "createdAt", "updatedAt", "contractIpAddress", "contractPdfUrl", "contractSignedAt", "contractUserAgent", "signatureUrl", "isDeleted", "lineUserId", "phoneNumber", address, "emergencyContact", "emergencyPhone", "firstName", "lastName", "moveInDate", "profileCompleted", "eContractData", "eContractStatus", "eContractToken", "dataAnonymizedAt", "moveOutDate") FROM stdin;
cmqcexxn80001kw04vs72dces	cmpy7gsse0001r2ag8ry4b9km	\N	\N	\N	\N	\N	2026-06-13 13:50:42.836	2026-06-14 14:52:01.278	\N	\N	\N	\N	\N	t	U88f912f73a60cd69b861c67e89c4d56e	\N	\N	\N	\N	\N	\N	\N	f	\N	NONE	\N	\N	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, password, name, image, role, "createdAt", "updatedAt", "emailVerified", username, "pdpaAcceptedAt", "planExpiresAt", "planTier", "lineChannelAccessToken", "lineUserId", "lineBindingCode", "resetTokenExpiry", "resetTokenHash", "lineBindingCodeExpiresAt") FROM stdin;
cmpy7gsse0001r2ag8ry4b9km	atthanop.sornsri@gmail.com	$2b$10$IkR0rwZRHowcDVMbmCPRp.npZsrcz4oveUXDjozJWcq.AkhoNhWQq	เจ้าของระบบ	\N	OWNER	2026-06-03 15:12:39.614	2026-06-27 02:09:47.88	\N	\N	2026-06-26 15:02:02.467	\N	FREE_TRIAL	1UmTsBKuvO++e/a7ahg5/47TeV1XWjoad+LXJK8n6CdcWFd6+L6hUFJNA5dtga/byrL2RalfQPbGWN3DXDz8BNAuDFt9BARLBvq9KimmsgRKtCfcLckj+RHUWvFUxpxUNIpLP1bruDTUFSbD1IGCcwdB04t89/1O/w1cDnyilFU=	U88f912f73a60cd69b861c67e89c4d56e	\N	\N	\N	\N
cmpy7gsq10000r2aglem4hq2d	admin@apartment.com	$2b$10$oM3kzV.VgUkXJw2NB0vPuuoGpuBHKWVkFrZk4gxFfjCNErITX0ZbS	Platform Admin	\N	ADMIN	2026-06-03 15:12:39.526	2026-06-28 19:29:22.794	\N	\N	2026-06-28 19:29:22.793	\N	FREE_TRIAL	\N	\N	\N	\N	\N	\N
cmro2lkde0000l10412mw52xf	line-1784240286817-13rivq2@line.placeholder.jadhor.app	\N	听起来	https://profile.line-scdn.net/0hdNUNtCiCO2FoNy76pTNENlRyNQwfGT0pEAR9V01lZlBBUntnVwEnDk5iZQVAUCw-VVUnAU4zbQYX	TENANT	2026-07-16 22:18:06.819	2026-07-16 22:18:06.819	\N	\N	\N	\N	FREE_TRIAL	\N	\N	\N	\N	\N	\N
cmqd5ou0a0000i804nfcl5gxv	line-1781403567849-jnzoyjq@line.placeholder.jadhor.app	\N	MEGAMAX Bangna	https://profile.line-scdn.net/0h_iLJW0-JAEZxMxD8XuB_EU12DisGHQYOCQdGdQZnW3UPCkRFSlEYIwM0VndUVE5DGFIcJwZmXCMJ	TENANT	2026-06-14 02:19:27.85	2026-06-14 02:19:27.85	\N	\N	\N	\N	FREE_TRIAL	\N	\N	\N	\N	\N	\N
cmt5yqpaq0000l1045x2mwekg	line-1787498981521-2h05ak4@line.placeholder.jadhor.app	\N	Fern Fern	https://profile.line-scdn.net/0hMt9gci4gElsEHg3HfqptDHlbHDZzMBQTfH0ObSNMTmosLVRfOXhaOSNJGDguKgYEbH8KbSUbTm59MSJ4OC04YVV_E2hCKyVmZQsIamZWOndydSFZRQtfXV5MSh5NKAxfeCsoY1sdO2pTd1xXTA4CdH9fEQtQKz5KbiY	TENANT	2026-08-23 15:29:41.523	2026-08-23 15:29:41.523	\N	\N	\N	\N	FREE_TRIAL	\N	\N	\N	\N	\N	\N
cmt8fo3ze0000ih04cql1wsfa	line-1787648346409-5jktm0w@line.placeholder.jadhor.app	\N	!Muk🐰	https://profile.line-scdn.net/0hLJm78YszE2VQTg3JBQFsMi0LHQgnYBUtKHhcUXQdSwd1K1QxOS5cVncdSgV6LFxjPC5fUCBLHQApYSszGlEpc3cuJih9GzVNKF0FfQlSEyUhKRxJHnoFfAgTTCgHexM2NVwEXCwtFxMmCzZIan0lczA7PTUTLg1SAiE	TENANT	2026-08-25 08:59:06.41	2026-08-25 08:59:06.41	\N	\N	\N	\N	FREE_TRIAL	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: Vehicle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Vehicle" (id, "tenantId", "licensePlate", brand, color, type, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: VerificationToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VerificationToken" (identifier, token, expires) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-06-02 18:20:44
20211116045059	2026-06-02 18:20:44
20211116050929	2026-06-02 18:20:44
20211116051442	2026-06-02 18:20:44
20211116212300	2026-06-02 18:20:44
20211116213355	2026-06-02 18:20:44
20211116213934	2026-06-02 18:20:44
20211116214523	2026-06-02 18:20:44
20211122062447	2026-06-02 18:20:44
20211124070109	2026-06-02 18:20:44
20211202204204	2026-06-02 18:20:44
20211202204605	2026-06-02 18:20:44
20211210212804	2026-06-02 18:20:44
20211228014915	2026-06-02 18:20:44
20220107221237	2026-06-02 18:20:44
20220228202821	2026-06-02 18:20:44
20220312004840	2026-06-02 18:20:44
20220603231003	2026-06-02 18:20:44
20220603232444	2026-06-02 18:20:44
20220615214548	2026-06-02 18:20:44
20220712093339	2026-06-02 18:20:44
20220908172859	2026-06-02 18:20:44
20220916233421	2026-06-02 18:20:44
20230119133233	2026-06-02 18:20:44
20230128025114	2026-06-02 18:20:44
20230128025212	2026-06-02 18:20:44
20230227211149	2026-06-02 18:20:44
20230228184745	2026-06-02 18:20:44
20230308225145	2026-06-02 18:20:44
20230328144023	2026-06-02 18:20:44
20231018144023	2026-06-02 18:20:44
20231204144023	2026-06-02 18:20:44
20231204144024	2026-06-02 18:20:44
20231204144025	2026-06-02 18:20:44
20240108234812	2026-06-02 18:20:44
20240109165339	2026-06-02 18:20:44
20240227174441	2026-06-02 18:20:44
20240311171622	2026-06-02 18:20:44
20240321100241	2026-06-02 18:20:44
20240401105812	2026-06-02 18:20:44
20240418121054	2026-06-02 18:20:44
20240523004032	2026-06-02 18:20:44
20240618124746	2026-06-02 18:20:44
20240801235015	2026-06-02 18:20:44
20240805133720	2026-06-02 18:20:44
20240827160934	2026-06-02 18:20:44
20240919163303	2026-06-02 18:20:44
20240919163305	2026-06-02 18:20:44
20241019105805	2026-06-02 18:20:44
20241030150047	2026-06-02 18:20:44
20241108114728	2026-06-02 18:20:44
20241121104152	2026-06-02 18:20:44
20241130184212	2026-06-02 18:20:44
20241220035512	2026-06-02 18:20:44
20241220123912	2026-06-02 18:20:44
20241224161212	2026-06-02 18:20:44
20250107150512	2026-06-02 18:20:44
20250110162412	2026-06-02 18:20:44
20250123174212	2026-06-02 18:20:44
20250128220012	2026-06-02 18:20:44
20250506224012	2026-06-02 18:20:44
20250523164012	2026-06-02 18:20:44
20250714121412	2026-06-02 18:20:44
20250905041441	2026-06-02 18:20:44
20251103001201	2026-06-02 18:20:44
20251120212548	2026-06-02 18:20:44
20251120215549	2026-06-02 18:20:44
20260218120000	2026-06-02 18:20:44
20260326120000	2026-06-02 18:20:44
20260514120000	2026-06-03 14:51:28
20260527120000	2026-06-03 14:51:28
20260528120000	2026-06-03 14:51:28
20260603120000	2026-06-04 07:42:27
20260605120000	2026-07-05 14:26:32
20260606110000	2026-07-05 14:26:32
20260616120000	2026-07-05 14:26:32
20260624120000	2026-07-05 14:26:32
20260626120000	2026-07-05 14:26:32
20260706120000	2026-07-19 10:05:09
20260707120000	2026-07-19 10:05:09
20260709120000	2026-07-19 10:05:09
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type, versioning_status) FROM stdin;
documents	documents	\N	2026-06-05 05:23:28.954551+00	2026-06-05 05:23:28.954551+00	f	f	\N	\N	\N	STANDARD	DISABLED
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-06-02 16:02:51.939415
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-06-02 16:02:52.013807
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-06-02 16:02:52.017792
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-06-02 16:02:52.052893
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-06-02 16:02:52.065643
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-06-02 16:02:52.070008
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-06-02 16:02:52.074728
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-06-02 16:02:52.084274
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-06-02 16:02:52.090681
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-06-02 16:02:52.09901
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-06-02 16:02:52.105222
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-06-02 16:02:52.109681
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-06-02 16:02:52.11497
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-06-02 16:02:52.119852
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-06-02 16:02:52.125177
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-06-02 16:02:52.176802
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-06-02 16:02:52.183025
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-06-02 16:02:52.187283
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-06-02 16:02:52.192031
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-06-02 16:02:52.197611
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-06-02 16:02:52.201642
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-06-02 16:02:52.208393
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-06-02 16:02:52.224254
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-06-02 16:02:52.234728
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-06-02 16:02:52.239462
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-06-02 16:02:52.243377
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-06-02 16:02:52.248073
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-06-02 16:02:52.251876
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-06-02 16:02:52.255708
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-06-02 16:02:52.259182
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-06-02 16:02:52.26304
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-06-02 16:02:52.26655
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-06-02 16:02:52.270025
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-06-02 16:02:52.274562
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-06-02 16:02:52.278148
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-06-02 16:02:52.282004
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-06-02 16:02:52.285588
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-06-02 16:02:52.28902
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-06-02 16:02:52.29373
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-06-02 16:02:52.310155
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-06-02 16:02:52.314427
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-06-02 16:02:52.31958
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-06-02 16:02:52.323363
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-06-02 16:02:52.327041
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-06-02 16:02:52.330563
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-06-02 16:02:52.335058
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-06-02 16:02:52.347934
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-06-02 16:02:52.360808
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-06-02 16:02:52.366696
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-06-02 16:02:52.388865
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-06-02 16:02:52.395886
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-06-02 16:02:52.619154
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-06-02 16:02:52.621213
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-06-02 16:02:52.640112
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-06-02 16:02:52.64257
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-06-02 16:02:52.644015
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-06-02 16:02:52.654144
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-06-02 16:02:52.659659
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-06-02 16:02:52.664045
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-06-02 16:02:52.670113
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-06-02 16:02:52.674153
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-08-12 02:41:06.978152
62	object-versioning-core	0b855f00ff3be0bfca91efee02a9858912491a9a	2026-08-20 02:37:43.021385
63	fix-search-name-relative-to-prefix	c7485e417624f795ce8bb2da21927f48e088904d	2026-08-23 02:37:44.402676
64	fix-search-by-timestamp-sqli	0af424ecd388a39bb1645184b222185a12149675	2026-08-23 02:37:44.442373
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, archived_at, is_delete_marker, is_versioned) FROM stdin;
b783a4ac-1a00-4f22-96ed-bff2ba838bc2	documents	slips/cmq9txx050001l104pftimljb-1781205802334.jpeg	\N	2026-06-11 19:23:23.243298+00	2026-06-11 19:23:23.243298+00	2026-06-11 19:23:23.243298+00	{"eTag": "\\"5bdcb7452a0dfcc48391bdffdf78c78b\\"", "size": 350916, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-11T19:23:24.000Z", "contentLength": 350916, "httpStatusCode": 200}	8897820d-5b11-406b-8703-38920bf92782	\N	{}	\N	f	f
d0d09643-9a15-4312-8619-50445af27ee2	documents	backups/2026-08-03.json	\N	2026-08-03 02:41:06.330269+00	2026-08-03 02:41:06.330269+00	2026-08-03 02:41:06.330269+00	{"eTag": "\\"deabfd1454dabdba6b147de2b52b8c50\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-03T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	5e8e64e0-64a4-43cc-a910-70d90af5b3b7	\N	{}	\N	f	f
04cd3a61-a527-4eb8-beb2-8059c2de9aee	documents	slips/cmq9txx050001l104pftimljb-1781205816161.jpeg	\N	2026-06-11 19:23:37.637289+00	2026-06-11 19:23:37.637289+00	2026-06-11 19:23:37.637289+00	{"eTag": "\\"5bdcb7452a0dfcc48391bdffdf78c78b\\"", "size": 350916, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-11T19:23:38.000Z", "contentLength": 350916, "httpStatusCode": 200}	f21d3ad4-e501-4097-b4cb-0d8886211217	\N	{}	\N	f	f
646393db-43af-4e7e-8a23-ff05dd0990fa	documents	backups/2026-06-13.json	\N	2026-06-13 02:53:05.153883+00	2026-06-13 02:53:05.153883+00	2026-06-13 02:53:05.153883+00	{"eTag": "\\"9280f98811c4fb120cf18802c052db62\\"", "size": 5428, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-13T02:53:06.000Z", "contentLength": 5428, "httpStatusCode": 200}	050154a9-7fdd-41ab-b43d-a021f03ef734	\N	{}	\N	f	f
b1ec146b-a043-4ab8-bdf4-5ada516e5a20	documents	backups/2026-08-08.json	\N	2026-08-08 02:41:06.237647+00	2026-08-08 02:41:06.237647+00	2026-08-08 02:41:06.237647+00	{"eTag": "\\"8a4a0380f8502a975f171d08151748e2\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-08T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	186992a0-2f88-4793-a1a4-21b2dadfc336	\N	{}	\N	f	f
f62d4c6a-5943-499b-b5d5-6d2752cc2dcc	documents	backups/2026-06-15.json	\N	2026-06-15 02:03:28.206802+00	2026-06-15 02:03:28.206802+00	2026-06-15 02:03:28.206802+00	{"eTag": "\\"c07ab14dfbd51fcec2d63edd40c709a6\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-15T02:03:29.000Z", "contentLength": 4310, "httpStatusCode": 200}	7214178a-2dd3-4601-a675-32daf1621a59	\N	{}	\N	f	f
effd9d43-2614-425d-a225-d587f3e89e6d	documents	backups/2026-06-16.json	\N	2026-06-16 02:03:28.044945+00	2026-06-16 02:03:28.044945+00	2026-06-16 02:03:28.044945+00	{"eTag": "\\"5db4a5752f9796913db53397c1bb5b63\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-16T02:03:29.000Z", "contentLength": 4310, "httpStatusCode": 200}	b3e38f5b-8d14-4e53-9dbc-1cd0093bfc47	\N	{}	\N	f	f
d71ff1de-b79e-4900-a734-4d99c3047588	documents	backups/2026-08-13.json	\N	2026-08-13 02:41:06.224411+00	2026-08-13 02:41:06.224411+00	2026-08-13 02:41:06.224411+00	{"eTag": "\\"58e254aac8e9070d180a2accc43da8e8\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-13T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	4f40e5c6-bf9d-4bb2-b7ed-962ffe43ec44	\N	{}	\N	f	f
1567c782-6868-46ae-a5a2-28762545c54f	documents	backups/2026-06-17.json	\N	2026-06-17 02:03:28.275143+00	2026-06-17 02:03:28.275143+00	2026-06-17 02:03:28.275143+00	{"eTag": "\\"f9e3a169ec71ab4d759d7fd77522ceab\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-17T02:03:29.000Z", "contentLength": 4310, "httpStatusCode": 200}	52277a31-7a70-414b-9016-ed984b802d8c	\N	{}	\N	f	f
6dfe640a-f1e5-49b3-acd2-7122a1babafc	documents	backups/2026-06-18.json	\N	2026-06-18 02:03:14.94919+00	2026-06-18 02:03:14.94919+00	2026-06-18 02:03:14.94919+00	{"eTag": "\\"21aa9f13b713ade08d25e72248def4c4\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-18T02:03:15.000Z", "contentLength": 4310, "httpStatusCode": 200}	226cbacf-4506-4eaf-a5ea-69018f9cde3b	\N	{}	\N	f	f
c1e45303-2f64-4b31-ac04-25940e2136f7	documents	backups/2026-08-18.json	\N	2026-08-18 02:41:06.186596+00	2026-08-18 02:41:06.186596+00	2026-08-18 02:41:06.186596+00	{"eTag": "\\"42f507fd65c049beac8642171c8ef575\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-18T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	7fcefb5f-8733-4dd0-897a-e10074aa9238	\N	{}	\N	f	f
46316427-4d1c-40aa-baf7-360771709f4c	documents	backups/2026-06-19.json	\N	2026-06-19 02:03:12.308211+00	2026-06-19 02:03:12.308211+00	2026-06-19 02:03:12.308211+00	{"eTag": "\\"0bcd5de0447e38068cf270f760d54ea8\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-19T02:03:13.000Z", "contentLength": 4310, "httpStatusCode": 200}	6a4ff6c5-4123-40a1-a72f-452c30bba379	\N	{}	\N	f	f
b588e504-c2ba-4a3f-9786-868f020332f9	documents	backups/2026-06-20.json	\N	2026-06-20 02:03:12.287615+00	2026-06-20 02:03:12.287615+00	2026-06-20 02:03:12.287615+00	{"eTag": "\\"d2fc28f198d3a9d10d794f05630d1d76\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-20T02:03:13.000Z", "contentLength": 4310, "httpStatusCode": 200}	b26e2006-a770-4b0b-ad67-e8d84744fab8	\N	{}	\N	f	f
3bf3ed5c-65ab-4b29-9d53-79a441af7df7	documents	backups/2026-06-21.json	\N	2026-06-21 02:03:16.315771+00	2026-06-21 02:03:16.315771+00	2026-06-21 02:03:16.315771+00	{"eTag": "\\"f7611d417ce1384f26e3bb62382d2ac0\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-21T02:03:17.000Z", "contentLength": 4310, "httpStatusCode": 200}	d448bc23-7a8f-4798-8807-5cca4e4615ad	\N	{}	\N	f	f
c6b1181e-a637-434c-bc46-9ccc74a48604	documents	backups/2026-06-22.json	\N	2026-06-22 02:03:12.408782+00	2026-06-22 02:03:12.408782+00	2026-06-22 02:03:12.408782+00	{"eTag": "\\"5d1eafc9e9eadcf0385628fb577f372b\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-22T02:03:13.000Z", "contentLength": 4310, "httpStatusCode": 200}	208c68ca-06f7-4f3b-9e7f-cd3459202bd5	\N	{}	\N	f	f
fdd72d4c-c4a9-4044-a1a6-574f9ea46229	documents	backups/2026-06-23.json	\N	2026-06-23 02:03:12.193565+00	2026-06-23 02:03:12.193565+00	2026-06-23 02:03:12.193565+00	{"eTag": "\\"78895a4b9618e64a183e42cf7e2d7d8e\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-23T02:03:13.000Z", "contentLength": 4310, "httpStatusCode": 200}	38e5829d-b8f8-410a-b144-2ababc27cdf2	\N	{}	\N	f	f
5e96fbe4-e2d9-4eb2-b9f1-4925446c811c	documents	backups/2026-08-04.json	\N	2026-08-04 02:41:06.35763+00	2026-08-04 02:41:06.35763+00	2026-08-04 02:41:06.35763+00	{"eTag": "\\"95f14f675e957d08e15eb0bc591e0cfe\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-04T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	08eeedc7-178c-47a0-8200-4ffc36c16c2e	\N	{}	\N	f	f
74c91ca2-188d-4b40-a682-8a00d3eba503	documents	backups/2026-06-24.json	\N	2026-06-24 02:03:12.251914+00	2026-06-24 02:03:12.251914+00	2026-06-24 02:03:12.251914+00	{"eTag": "\\"f7762540a3737e15f3581fdeca861da3\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-24T02:03:13.000Z", "contentLength": 4310, "httpStatusCode": 200}	9b8092b5-1111-4fed-b6e0-e83480c50236	\N	{}	\N	f	f
d3cbe9b2-cee8-4acb-a003-656a20cb69cb	documents	backups/2026-06-25.json	\N	2026-06-25 02:03:12.585404+00	2026-06-25 02:03:12.585404+00	2026-06-25 02:03:12.585404+00	{"eTag": "\\"8e5b6f158e9ad4de474348551164045a\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-25T02:03:13.000Z", "contentLength": 4310, "httpStatusCode": 200}	5363952d-b27e-465c-8729-a833adc4779b	\N	{}	\N	f	f
aea1ae06-10bf-4ea2-aeec-ca427c194dba	documents	backups/2026-08-09.json	\N	2026-08-09 02:41:06.217199+00	2026-08-09 02:41:06.217199+00	2026-08-09 02:41:06.217199+00	{"eTag": "\\"fe2cbd817065957bcd7b95a1e809e2f1\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-09T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	72df3374-c0dd-47b3-a978-2026c17bef47	\N	{}	\N	f	f
8f0f61ce-f566-439d-8579-b1ef4559d4e7	documents	backups/2026-06-26.json	\N	2026-06-26 02:03:12.180263+00	2026-06-26 02:03:12.180263+00	2026-06-26 02:03:12.180263+00	{"eTag": "\\"bac601a1740d4d18f90cf9d860b97db2\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-26T02:03:13.000Z", "contentLength": 4310, "httpStatusCode": 200}	732c4dc1-0833-440d-bd59-fc0e724be579	\N	{}	\N	f	f
4a485231-ad15-4678-ab00-eaaab15c8c9a	documents	backups/2026-06-27.json	\N	2026-06-27 02:16:42.126789+00	2026-06-27 02:16:42.126789+00	2026-06-27 02:16:42.126789+00	{"eTag": "\\"ad47dbaaad318afd7495f05cc80312f1\\"", "size": 4310, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-27T02:16:43.000Z", "contentLength": 4310, "httpStatusCode": 200}	bcb7ec4c-d1df-4663-9ae1-c8d2e3dc8e9e	\N	{}	\N	f	f
4e606c75-a083-4526-98dc-9ac09b71a744	documents	backups/2026-08-14.json	\N	2026-08-14 02:41:06.20777+00	2026-08-14 02:41:06.20777+00	2026-08-14 02:41:06.20777+00	{"eTag": "\\"220271e5f649975aa21e730afdfa9692\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-14T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	ecb15f38-d7c1-491d-b7ae-54bb83a279df	\N	{}	\N	f	f
d932526e-893f-4c52-bafa-168206864b11	documents	backups/2026-06-29.json	\N	2026-06-29 02:23:11.410643+00	2026-06-29 02:23:11.410643+00	2026-06-29 02:23:11.410643+00	{"eTag": "\\"bd2119ca286980a1d2fcb5ba14bb8976\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-29T02:23:12.000Z", "contentLength": 4500, "httpStatusCode": 200}	bf758cfe-3677-40be-9969-ea2f4804964e	\N	{}	\N	f	f
e81c9f7b-a051-4683-bb6f-479957f72ae8	documents	backups/2026-06-30.json	\N	2026-06-30 02:23:11.276144+00	2026-06-30 02:23:11.276144+00	2026-06-30 02:23:11.276144+00	{"eTag": "\\"4bc042dd89ab8d702577e59c25cacea8\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-06-30T02:23:12.000Z", "contentLength": 4500, "httpStatusCode": 200}	4b178bc1-bb65-45b8-bd9c-913eb1fd5a0b	\N	{}	\N	f	f
a8da01ec-e211-49a5-83ae-647b6ddc1b45	documents	backups/2026-08-20.json	\N	2026-08-20 02:37:41.095716+00	2026-08-20 02:37:41.095716+00	2026-08-20 02:37:41.095716+00	{"eTag": "\\"d8657defca21fb2ff527afafe2bc4b46\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-20T02:37:42.000Z", "contentLength": 434209, "httpStatusCode": 200}	ac3f3dc6-d769-4d25-a237-70c0191e5b0a	\N	{}	\N	f	f
eea60bd2-9ee0-4400-8704-f80510da3f2b	documents	backups/2026-07-01.json	\N	2026-07-01 02:23:12.485266+00	2026-07-01 02:23:12.485266+00	2026-07-01 02:23:12.485266+00	{"eTag": "\\"6712a1084c1b4da6fca0677212f0de14\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-01T02:23:13.000Z", "contentLength": 4500, "httpStatusCode": 200}	1894cea8-78a5-4a59-8698-6215e6c71797	\N	{}	\N	f	f
8f065b2f-d5b7-4c93-929a-9eece298efef	documents	backups/2026-07-02.json	\N	2026-07-02 02:26:50.040511+00	2026-07-02 02:26:50.040511+00	2026-07-02 02:26:50.040511+00	{"eTag": "\\"a70205610af65d6ab997d4c51a7974bc\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-02T02:26:50.000Z", "contentLength": 4500, "httpStatusCode": 200}	b2c35083-2a57-46e1-b8f6-e6279af32feb	\N	{}	\N	f	f
b10d9025-ed4d-4db1-b3f9-29a2eb5b2b32	documents	backups/2026-07-03.json	\N	2026-07-03 02:26:50.354389+00	2026-07-03 02:26:50.354389+00	2026-07-03 02:26:50.354389+00	{"eTag": "\\"a832db66221738cd69bb3711382042c3\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-03T02:26:51.000Z", "contentLength": 4500, "httpStatusCode": 200}	170c5bd9-33f0-49b1-9371-915fb7ec583d	\N	{}	\N	f	f
254eb989-dd4d-4fca-a2ee-44798592b04e	documents	backups/2026-07-04.json	\N	2026-07-04 02:26:50.196259+00	2026-07-04 02:26:50.196259+00	2026-07-04 02:26:50.196259+00	{"eTag": "\\"613b4db4efc4cb8899a62a5fc049bc53\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-04T02:26:51.000Z", "contentLength": 4500, "httpStatusCode": 200}	1e491bc2-575d-4512-88cf-31e4d21ff812	\N	{}	\N	f	f
8f607d97-54c8-43f9-a913-d89d69e67de1	documents	backups/2026-07-05.json	\N	2026-07-05 02:26:50.175536+00	2026-07-05 02:26:50.175536+00	2026-07-05 02:26:50.175536+00	{"eTag": "\\"a6514c86c01164b9a60ac801ed48aa92\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-05T02:26:51.000Z", "contentLength": 4500, "httpStatusCode": 200}	c1a1e1b5-48d0-42db-a08d-fa3974709a46	\N	{}	\N	f	f
3aec20f1-99e7-4e0c-9f3e-f6f6a197c130	documents	backups/2026-07-06.json	\N	2026-07-06 02:26:50.090546+00	2026-07-06 02:26:50.090546+00	2026-07-06 02:26:50.090546+00	{"eTag": "\\"fa2ba69b3be25318a43490b34b2f589c\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-06T02:26:51.000Z", "contentLength": 4500, "httpStatusCode": 200}	276427ea-d9b1-4c24-bb9d-2cc7fb04a56c	\N	{}	\N	f	f
658ec4f3-3940-402f-a378-c2a074029b94	documents	backups/2026-08-05.json	\N	2026-08-05 02:41:06.288848+00	2026-08-05 02:41:06.288848+00	2026-08-05 02:41:06.288848+00	{"eTag": "\\"1d53a6b5083cbc896370d37e575408b0\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-05T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	7378b392-4d66-4af3-a62b-53c7298402f7	\N	{}	\N	f	f
b9992c57-599c-4e7f-a3d8-95b5adccb6a7	documents	backups/2026-07-07.json	\N	2026-07-07 02:26:50.503701+00	2026-07-07 02:26:50.503701+00	2026-07-07 02:26:50.503701+00	{"eTag": "\\"79b6e0464c2e7acb5ec08c880ec76afb\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-07T02:26:51.000Z", "contentLength": 4500, "httpStatusCode": 200}	6a26c1b2-b8a9-4312-a7e7-ad0275b24cc8	\N	{}	\N	f	f
0a5e063b-d730-4281-925f-d4108488aa42	documents	backups/2026-07-08.json	\N	2026-07-08 02:46:45.303864+00	2026-07-08 02:46:45.303864+00	2026-07-08 02:46:45.303864+00	{"eTag": "\\"c99a955ecc9d40b7e9ebcdf14bc81614\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-08T02:46:46.000Z", "contentLength": 4500, "httpStatusCode": 200}	cbf90ee5-52e8-40b2-b113-e30f26d08bb2	\N	{}	\N	f	f
99c1a2d4-1998-411f-a57e-4d87426f6f35	documents	backups/2026-08-10.json	\N	2026-08-10 02:41:06.275532+00	2026-08-10 02:41:06.275532+00	2026-08-10 02:41:06.275532+00	{"eTag": "\\"e86d536c4f78c3985942e48ae7bba075\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-10T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	dcb1177b-6122-4d89-beec-283a52b4880a	\N	{}	\N	f	f
01b78c32-4ee8-44a5-9130-c871600aa85c	documents	backups/2026-07-09.json	\N	2026-07-09 02:31:28.317473+00	2026-07-09 02:31:28.317473+00	2026-07-09 02:31:28.317473+00	{"eTag": "\\"210adcd2eed34ebc7c57747ffc88631c\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-09T02:31:29.000Z", "contentLength": 4500, "httpStatusCode": 200}	bf28301e-1658-4b13-825b-e19290668460	\N	{}	\N	f	f
02ae3a2d-b192-4833-92f5-978911cd0cad	documents	backups/2026-07-10.json	\N	2026-07-10 02:31:27.305089+00	2026-07-10 02:31:27.305089+00	2026-07-10 02:31:27.305089+00	{"eTag": "\\"b01d022cd82c160e6a146a261bbcdc01\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-10T02:31:28.000Z", "contentLength": 4500, "httpStatusCode": 200}	5e622647-7b05-4966-95bf-ea136fb64318	\N	{}	\N	f	f
9fc965c7-ee85-4996-a89a-6848f9939397	documents	backups/2026-08-15.json	\N	2026-08-15 02:41:06.236014+00	2026-08-15 02:41:06.236014+00	2026-08-15 02:41:06.236014+00	{"eTag": "\\"7d93c585f37c2ab77d823295fb2989f7\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-15T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	9f9f1a41-81a0-4ed1-9184-dd0c33a147aa	\N	{}	\N	f	f
ee7b6ac2-0f87-45ed-b766-808e5bc39951	documents	backups/2026-07-11.json	\N	2026-07-11 02:31:27.23419+00	2026-07-11 02:31:27.23419+00	2026-07-11 02:31:27.23419+00	{"eTag": "\\"eec78114400db1052aa577b9f1073636\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-11T02:31:28.000Z", "contentLength": 4500, "httpStatusCode": 200}	64f53698-041a-4fba-86ab-f3f3886f5d16	\N	{}	\N	f	f
ed8eb11a-c8ca-4d00-ab2d-7f6467df5ed0	documents	backups/2026-07-12.json	\N	2026-07-12 02:31:27.335119+00	2026-07-12 02:31:27.335119+00	2026-07-12 02:31:27.335119+00	{"eTag": "\\"60c4c4c47ff35c6ac5bbe77a7e0889b6\\"", "size": 4500, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-12T02:31:28.000Z", "contentLength": 4500, "httpStatusCode": 200}	b376b59a-d19d-4151-a4dc-4f0f8dd45a9a	\N	{}	\N	f	f
153403a8-0eba-4105-88d0-408eb13ecb76	documents	backups/2026-08-21.json	\N	2026-08-21 02:37:41.170772+00	2026-08-21 02:37:41.170772+00	2026-08-21 02:37:41.170772+00	{"eTag": "\\"dca564f53dada0463a3186212381ecc2\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-21T02:37:42.000Z", "contentLength": 434209, "httpStatusCode": 200}	3b814ef3-1924-43c6-9c93-b1922a4283b1	\N	{}	\N	f	f
aefe56aa-8f34-4f70-a73c-ef07f12eabf2	documents	backups/2026-07-13.json	\N	2026-07-13 02:31:27.166527+00	2026-07-13 02:31:27.166527+00	2026-07-13 02:31:27.166527+00	{"eTag": "\\"065ada85224f9c6d70052310d401cd42\\"", "size": 3980, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-13T02:31:28.000Z", "contentLength": 3980, "httpStatusCode": 200}	23675d0f-c86b-4c0a-bbfd-5a8fc30d8bd3	\N	{}	\N	f	f
09add102-0cb0-470d-b70b-7b1b68f7c018	documents	backups/2026-07-14.json	\N	2026-07-14 02:31:27.418496+00	2026-07-14 02:31:27.418496+00	2026-07-14 02:31:27.418496+00	{"eTag": "\\"9b8a6cdc8799bed0d545a29bc2cf4fb3\\"", "size": 3980, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-14T02:31:28.000Z", "contentLength": 3980, "httpStatusCode": 200}	36fd44ba-c1d0-4bfd-ba33-1c43558d55dd	\N	{}	\N	f	f
51f04426-5194-4c63-831f-d410a9a07584	documents	backups/2026-07-15.json	\N	2026-07-15 02:31:27.192784+00	2026-07-15 02:31:27.192784+00	2026-07-15 02:31:27.192784+00	{"eTag": "\\"14e7a5c16d74e19906988fa806d3a000\\"", "size": 3980, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-15T02:31:28.000Z", "contentLength": 3980, "httpStatusCode": 200}	cfa9aeb4-f1b9-458f-91db-c0843eaf2995	\N	{}	\N	f	f
526f0cf3-aeb5-4daf-b9a7-7eaf8f1b7ec2	documents	backups/2026-07-16.json	\N	2026-07-16 02:01:54.387641+00	2026-07-16 02:01:54.387641+00	2026-07-16 02:01:54.387641+00	{"eTag": "\\"7e6f6bffaadaa8d3bb89e3726390b35c\\"", "size": 3980, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-16T02:01:55.000Z", "contentLength": 3980, "httpStatusCode": 200}	2adb8dc6-81f3-489d-b29a-2196e5e19b88	\N	{}	\N	f	f
14739604-5ed6-444b-82da-6e433379e60f	documents	backups/2026-07-17.json	\N	2026-07-17 02:01:54.269114+00	2026-07-17 02:01:54.269114+00	2026-07-17 02:01:54.269114+00	{"eTag": "\\"fcebcf2f4be8d718f52df1a408e9be3a\\"", "size": 4283, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-17T02:01:55.000Z", "contentLength": 4283, "httpStatusCode": 200}	8e7aea8e-d088-41a2-a27e-89294640c313	\N	{}	\N	f	f
a2043fe3-7556-4ce8-b96b-72fe8fe5eb0d	documents	backups/2026-08-06.json	\N	2026-08-06 02:41:06.301329+00	2026-08-06 02:41:06.301329+00	2026-08-06 02:41:06.301329+00	{"eTag": "\\"718c86107fbc1c24f88807c6d5ceb0d0\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-06T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	1773f970-f403-4271-807e-e36f5448e5a8	\N	{}	\N	f	f
25d0d4e3-c281-4f9d-a24d-fc2ae7f18d35	documents	backups/2026-07-18.json	\N	2026-07-18 02:01:54.29886+00	2026-07-18 02:01:54.29886+00	2026-07-18 02:01:54.29886+00	{"eTag": "\\"2805a76e665333c6fc80085a7035e957\\"", "size": 4283, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-18T02:01:55.000Z", "contentLength": 4283, "httpStatusCode": 200}	2903c3c2-889b-4e59-a529-51573e339d09	\N	{}	\N	f	f
a231c401-fe3c-47d3-892a-69424a6f34f8	documents	backups/2026-07-19.json	\N	2026-07-19 02:01:54.319383+00	2026-07-19 02:01:54.319383+00	2026-07-19 02:01:54.319383+00	{"eTag": "\\"d6e0d1ef5f10ce4ef1828ebac85379a4\\"", "size": 4283, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-19T02:01:55.000Z", "contentLength": 4283, "httpStatusCode": 200}	5a8f611b-9fe6-4306-91f7-4c6517937be9	\N	{}	\N	f	f
84cdbf96-0a85-4585-ae0d-b312198310c1	documents	backups/2026-08-11.json	\N	2026-08-11 02:41:06.477568+00	2026-08-11 02:41:06.477568+00	2026-08-11 02:41:06.477568+00	{"eTag": "\\"56dfab6643aabf006be7db3163e6b4b9\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-11T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	cbbdb648-68da-4806-a792-43f87e03c712	\N	{}	\N	f	f
63de009b-0da0-4dcc-84f5-40d6118756a8	documents	backups/2026-07-20.json	\N	2026-07-20 02:41:06.41522+00	2026-07-20 02:41:06.41522+00	2026-07-20 02:41:06.41522+00	{"eTag": "\\"8703243cbd8ae9ad32f5a60404502fa7\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-20T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	47c14eea-8162-4503-b897-6f6ab60dc300	\N	{}	\N	f	f
a1a70ff5-a814-47b4-be54-400282bf6532	documents	backups/2026-07-21.json	\N	2026-07-21 02:41:06.270156+00	2026-07-21 02:41:06.270156+00	2026-07-21 02:41:06.270156+00	{"eTag": "\\"ea872c9ba50549c4e33d1bae9b9b2cf8\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-21T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	a6d9dde5-2959-4c0f-9cb7-619e703b2297	\N	{}	\N	f	f
68c1f6db-4212-477a-be98-66d14dca95bb	documents	backups/2026-08-16.json	\N	2026-08-16 02:41:06.186736+00	2026-08-16 02:41:06.186736+00	2026-08-16 02:41:06.186736+00	{"eTag": "\\"794b9f769a3fa8fc2560d3bf20ad5be4\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-16T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	c38300ad-85dd-4820-87c4-2bd47ba9c5f0	\N	{}	\N	f	f
4a75dd45-0ed6-4932-a753-7fa881d1e2c2	documents	backups/2026-07-22.json	\N	2026-07-22 02:41:06.845014+00	2026-07-22 02:41:06.845014+00	2026-07-22 02:41:06.845014+00	{"eTag": "\\"53b9a9cffa59d206f88f549bcc282f5c\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-22T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	6077d330-aa90-4308-af6a-5c70e90116c1	\N	{}	\N	f	f
f27a4a6f-3430-4275-91dc-15daa40f8b23	documents	backups/2026-07-23.json	\N	2026-07-23 02:41:06.429919+00	2026-07-23 02:41:06.429919+00	2026-07-23 02:41:06.429919+00	{"eTag": "\\"6245ee4404ab1c835de428e4dd175dfe\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-23T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	fb705bc3-12fb-4181-8fd0-8a7e442746d8	\N	{}	\N	f	f
f7336270-a8ba-4ee1-9246-5d3895d7d783	documents	backups/2026-08-22.json	\N	2026-08-22 02:37:41.847724+00	2026-08-22 02:37:41.847724+00	2026-08-22 02:37:41.847724+00	{"eTag": "\\"5fdb2ce0ef611b0e79b881207bba62db\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-22T02:37:42.000Z", "contentLength": 434209, "httpStatusCode": 200}	1feb2a5e-ec3d-409f-9304-9df529127938	\N	{}	\N	f	f
15d15170-6a5d-4d2d-9916-a43d496b26f5	documents	backups/2026-07-24.json	\N	2026-07-24 02:41:06.36141+00	2026-07-24 02:41:06.36141+00	2026-07-24 02:41:06.36141+00	{"eTag": "\\"b11f859e8c2287d1d70544d67f2076ae\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-24T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	abf5de96-fc8b-4741-a001-034134154f79	\N	{}	\N	f	f
896ef9a8-995c-4ada-b8cd-c220c83b7a05	documents	backups/2026-07-25.json	\N	2026-07-25 02:41:06.225261+00	2026-07-25 02:41:06.225261+00	2026-07-25 02:41:06.225261+00	{"eTag": "\\"c7cd5309f7429ade3065ea2d50b97f9b\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-25T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	4784c779-5bf4-4e07-af97-d66218d4601a	\N	{}	\N	f	f
37b235e6-4608-4c45-9444-8b07f805a417	documents	backups/2026-07-26.json	\N	2026-07-26 02:41:06.370042+00	2026-07-26 02:41:06.370042+00	2026-07-26 02:41:06.370042+00	{"eTag": "\\"426333d3cdcd59deccfb4de677eb6a56\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-26T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	160e709b-d6cf-414f-b605-f45c1a0f44e1	\N	{}	\N	f	f
90492673-9283-4ae9-b0dd-74a2cf796af1	documents	backups/2026-07-27.json	\N	2026-07-27 02:41:06.348324+00	2026-07-27 02:41:06.348324+00	2026-07-27 02:41:06.348324+00	{"eTag": "\\"f655ab4d6f66a47e0a4573ae495f6eac\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-27T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	997cd5c1-a900-471b-b12e-1ffc54a4f531	\N	{}	\N	f	f
0a491d20-27bf-4a71-a22d-0263e34ea023	documents	backups/2026-07-28.json	\N	2026-07-28 02:41:06.298459+00	2026-07-28 02:41:06.298459+00	2026-07-28 02:41:06.298459+00	{"eTag": "\\"039691ac1b10f38c5b28f1d2b909c14c\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-28T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	f3baf2d2-745d-41cc-9c2c-1a5865ac0ccd	\N	{}	\N	f	f
81cea971-29d9-4f75-9872-edbc27d7c5b3	documents	backups/2026-08-07.json	\N	2026-08-07 02:41:06.379169+00	2026-08-07 02:41:06.379169+00	2026-08-07 02:41:06.379169+00	{"eTag": "\\"e33d58a701ecd7179fc2128015a01609\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-07T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	33dc1b80-d9c4-448b-83dc-777aeb40cdc5	\N	{}	\N	f	f
281930dd-7e3b-4c31-bfe9-1dd1eb36f95c	documents	backups/2026-07-29.json	\N	2026-07-29 02:41:06.335397+00	2026-07-29 02:41:06.335397+00	2026-07-29 02:41:06.335397+00	{"eTag": "\\"791a344ff12b9be03182cb4bea505b21\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-29T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	067e1856-844a-48c8-aa94-43650099e21a	\N	{}	\N	f	f
741f8b9a-66c9-4435-ae84-0ad9cb08d1b2	documents	backups/2026-07-30.json	\N	2026-07-30 02:41:06.22961+00	2026-07-30 02:41:06.22961+00	2026-07-30 02:41:06.22961+00	{"eTag": "\\"a42919415a8385e03437df4e62643699\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-30T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	3d65174d-ad0e-4cdc-af15-b3f582f3936d	\N	{}	\N	f	f
908c4d1c-756e-42e2-9156-4024ae24a7dd	documents	backups/2026-08-12.json	\N	2026-08-12 02:41:06.281887+00	2026-08-12 02:41:06.281887+00	2026-08-12 02:41:06.281887+00	{"eTag": "\\"c3e40a54310bf2754067d6bdfe2b6e86\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-12T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	7aa80c93-3b91-4978-bb28-4cfc2ea7d6df	\N	{}	\N	f	f
eb3fff50-cde9-4f9c-9dac-3a8d7891568e	documents	backups/2026-07-31.json	\N	2026-07-31 02:41:06.329249+00	2026-07-31 02:41:06.329249+00	2026-07-31 02:41:06.329249+00	{"eTag": "\\"b32e53a0e8b77c0842e0039ddcac8e68\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-07-31T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	cb3a4708-20c4-483c-bb4a-0c55e7ea1b73	\N	{}	\N	f	f
67b85c1f-f010-48ef-84fa-5269aa31f67e	documents	backups/2026-08-01.json	\N	2026-08-01 02:41:06.124667+00	2026-08-01 02:41:06.124667+00	2026-08-01 02:41:06.124667+00	{"eTag": "\\"7e8fb785222cd4cedc4dd9fec2dc1d0b\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-01T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	a5e3e2a7-1bb3-4fd6-90bf-36e720329ba8	\N	{}	\N	f	f
960378bd-6cab-479c-ac12-8b5591b1ffd7	documents	backups/2026-08-17.json	\N	2026-08-17 02:41:06.618134+00	2026-08-17 02:41:06.618134+00	2026-08-17 02:41:06.618134+00	{"eTag": "\\"0fec87cc02609aacdc0a68ebc0d178e4\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-17T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	e9693ff9-b761-4832-b195-1325dc2c8b41	\N	{}	\N	f	f
0afb847b-6673-4f2c-abe5-37b0f15970a6	documents	backups/2026-08-02.json	\N	2026-08-02 02:41:06.595826+00	2026-08-02 02:41:06.595826+00	2026-08-02 02:41:06.595826+00	{"eTag": "\\"d04f100489f0995c4f6cbbd4aa8cdb2d\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-02T02:41:07.000Z", "contentLength": 434209, "httpStatusCode": 200}	540c7fd4-c8d1-4703-90dd-682d8a7afd6a	\N	{}	\N	f	f
3befa72a-5fdf-480b-9c34-267a2a4bae0e	documents	backups/2026-08-23.json	\N	2026-08-23 02:37:41.125179+00	2026-08-23 02:37:41.125179+00	2026-08-23 02:37:41.125179+00	{"eTag": "\\"425787fbf770b0911f7a52e865a5eaac\\"", "size": 434209, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-23T02:37:42.000Z", "contentLength": 434209, "httpStatusCode": 200}	8b216089-7b06-4358-b4c4-1fd8ffc91c5a	\N	{}	\N	f	f
01e9829b-0348-4746-b134-dfcf942d33b7	documents	backups/2026-08-24.json	\N	2026-08-24 02:37:41.642094+00	2026-08-24 02:37:41.642094+00	2026-08-24 02:37:41.642094+00	{"eTag": "\\"756d17eece36db7f73a77a6bf802136f\\"", "size": 434570, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-24T02:37:42.000Z", "contentLength": 434570, "httpStatusCode": 200}	331f158b-2a6d-46c0-b589-d69ba3ba3dd8	\N	{}	\N	f	f
9df9bc5f-3f3f-4d1e-b096-f14b23241d0f	documents	backups/2026-08-25.json	\N	2026-08-25 02:37:41.508549+00	2026-08-25 02:37:41.508549+00	2026-08-25 02:37:41.508549+00	{"eTag": "\\"d2e84c50a70a4c76095ac700992b4187\\"", "size": 434570, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-25T02:37:42.000Z", "contentLength": 434570, "httpStatusCode": 200}	a3d5acf6-2357-45c4-83d9-bc8883c6224b	\N	{}	\N	f	f
324726c4-330e-454e-9538-2c43f34e5392	documents	backups/2026-08-26.json	\N	2026-08-26 02:37:41.592907+00	2026-08-26 02:37:41.592907+00	2026-08-26 02:37:41.592907+00	{"eTag": "\\"d67cd26e7b695424ed15a37b919f751e\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-26T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	849009b1-0e92-44c0-9f10-fb5fdd45854c	\N	{}	\N	f	f
8fd996e6-7e8b-47e9-be2f-f82a9cc7f440	documents	backups/2026-08-27.json	\N	2026-08-27 02:37:41.472521+00	2026-08-27 02:37:41.472521+00	2026-08-27 02:37:41.472521+00	{"eTag": "\\"7b7248a67c0e624e60900b188f466f03\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-27T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	e7552009-c1c4-403a-82ed-e950d5f5e38b	\N	{}	\N	f	f
8ef43d19-a162-44f0-af6c-73e53562b42f	documents	backups/2026-08-28.json	\N	2026-08-28 02:37:41.128279+00	2026-08-28 02:37:41.128279+00	2026-08-28 02:37:41.128279+00	{"eTag": "\\"ccf77c4ca7c987d71d4215a4985a8651\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-28T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	33c7ff91-ef7c-45bf-8c4f-cfb4bde96e5c	\N	{}	\N	f	f
99618a5c-4240-4764-be39-c59cd0902d97	documents	backups/2026-08-29.json	\N	2026-08-29 02:37:41.06259+00	2026-08-29 02:37:41.06259+00	2026-08-29 02:37:41.06259+00	{"eTag": "\\"071d57693e0c360255047eaf52465783\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-29T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	36ebe6b9-845b-4d72-b88c-139c8bf2d003	\N	{}	\N	f	f
e4480044-3a75-44b0-ad82-2880122fef44	documents	backups/2026-08-30.json	\N	2026-08-30 02:37:41.460771+00	2026-08-30 02:37:41.460771+00	2026-08-30 02:37:41.460771+00	{"eTag": "\\"7f000528757d8c30ac639d05a37bd2df\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-30T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	600f066f-65e7-4dcc-a8fc-3440f8896164	\N	{}	\N	f	f
3a6c3f56-31ef-4a9b-b8e9-b0caff3cb928	documents	backups/2026-08-31.json	\N	2026-08-31 02:37:41.235298+00	2026-08-31 02:37:41.235298+00	2026-08-31 02:37:41.235298+00	{"eTag": "\\"349f54a5e68bd20ead73619798ca6eec\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-08-31T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	f75e471b-eb04-4497-833c-27233f807bb7	\N	{}	\N	f	f
a409af94-aec3-431f-9845-c50d0a6607e6	documents	backups/2026-09-01.json	\N	2026-09-01 02:37:41.071101+00	2026-09-01 02:37:41.071101+00	2026-09-01 02:37:41.071101+00	{"eTag": "\\"3363d522014f7e0a19320e45c5792633\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-09-01T02:37:41.000Z", "contentLength": 434930, "httpStatusCode": 200}	1144a3c0-59c0-4323-9dc4-4b00a3826e40	\N	{}	\N	f	f
dea49dca-48b8-4e67-9977-01b2301bdc65	documents	backups/2026-09-02.json	\N	2026-09-02 02:37:41.05386+00	2026-09-02 02:37:41.05386+00	2026-09-02 02:37:41.05386+00	{"eTag": "\\"1e7d36de1d6087ad103acd310cee64f9\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-09-02T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	75a68a03-0b01-4be7-85b1-6cedb3d83d54	\N	{}	\N	f	f
84fc5000-708d-4b66-bc2c-c915ef8527b0	documents	backups/2026-09-03.json	\N	2026-09-03 02:37:41.659801+00	2026-09-03 02:37:41.659801+00	2026-09-03 02:37:41.659801+00	{"eTag": "\\"a7672407e625e8bbdaf6c6215941e1ce\\"", "size": 434930, "mimetype": "application/json", "cacheControl": "max-age=3600", "lastModified": "2026-09-03T02:37:42.000Z", "contentLength": 434930, "httpStatusCode": 200}	6bf9b851-6082-41f9-bad8-1bc91786a4e5	\N	{}	\N	f	f
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Bill Bill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bill"
    ADD CONSTRAINT "Bill_pkey" PRIMARY KEY (id);


--
-- Name: Checkout Checkout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Checkout"
    ADD CONSTRAINT "Checkout_pkey" PRIMARY KEY (id);


--
-- Name: InvoiceItem InvoiceItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: MaintenanceRequest MaintenanceRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MaintenanceRequest"
    ADD CONSTRAINT "MaintenanceRequest_pkey" PRIMARY KEY (id);


--
-- Name: MeterSubmission MeterSubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MeterSubmission"
    ADD CONSTRAINT "MeterSubmission_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Parcel Parcel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Parcel"
    ADD CONSTRAINT "Parcel_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: PropertyStaff PropertyStaff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropertyStaff"
    ADD CONSTRAINT "PropertyStaff_pkey" PRIMARY KEY (id);


--
-- Name: Property Property_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Property"
    ADD CONSTRAINT "Property_pkey" PRIMARY KEY (id);


--
-- Name: RegistrationCode RegistrationCode_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RegistrationCode"
    ADD CONSTRAINT "RegistrationCode_pkey" PRIMARY KEY (id);


--
-- Name: Room Room_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Room"
    ADD CONSTRAINT "Room_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SmsAddon SmsAddon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SmsAddon"
    ADD CONSTRAINT "SmsAddon_pkey" PRIMARY KEY (id);


--
-- Name: SystemSettings SystemSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSettings"
    ADD CONSTRAINT "SystemSettings_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Vehicle Vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vehicle"
    ADD CONSTRAINT "Vehicle_pkey" PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: Bill_roomId_month_year_type_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Bill_roomId_month_year_type_key" ON public."Bill" USING btree ("roomId", month, year, type);


--
-- Name: Bill_slipTransRef_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Bill_slipTransRef_key" ON public."Bill" USING btree ("slipTransRef");


--
-- Name: Checkout_tenantId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Checkout_tenantId_key" ON public."Checkout" USING btree ("tenantId");


--
-- Name: Invoice_invoiceNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Invoice_invoiceNumber_key" ON public."Invoice" USING btree ("invoiceNumber");


--
-- Name: Invoice_ownerId_month_year_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Invoice_ownerId_month_year_key" ON public."Invoice" USING btree ("ownerId", month, year);


--
-- Name: MeterSubmission_roomId_month_year_type_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "MeterSubmission_roomId_month_year_type_key" ON public."MeterSubmission" USING btree ("roomId", month, year, type);


--
-- Name: PropertyStaff_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PropertyStaff_userId_idx" ON public."PropertyStaff" USING btree ("userId");


--
-- Name: PropertyStaff_userId_propertyId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PropertyStaff_userId_propertyId_key" ON public."PropertyStaff" USING btree ("userId", "propertyId");


--
-- Name: RegistrationCode_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RegistrationCode_code_key" ON public."RegistrationCode" USING btree (code);


--
-- Name: Room_inviteCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Room_inviteCode_key" ON public."Room" USING btree ("inviteCode");


--
-- Name: Room_propertyId_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Room_propertyId_number_key" ON public."Room" USING btree ("propertyId", number);


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: SmsAddon_ownerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SmsAddon_ownerId_key" ON public."SmsAddon" USING btree ("ownerId");


--
-- Name: Tenant_eContractToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Tenant_eContractToken_key" ON public."Tenant" USING btree ("eContractToken");


--
-- Name: Tenant_lineUserId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Tenant_lineUserId_key" ON public."Tenant" USING btree ("lineUserId");


--
-- Name: Tenant_phoneNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Tenant_phoneNumber_key" ON public."Tenant" USING btree ("phoneNumber");


--
-- Name: Tenant_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Tenant_userId_key" ON public."Tenant" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_resetTokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_resetTokenHash_key" ON public."User" USING btree ("resetTokenHash");


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: VerificationToken_identifier_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_identifier_token_key" ON public."VerificationToken" USING btree (identifier, token);


--
-- Name: VerificationToken_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VerificationToken_token_key" ON public."VerificationToken" USING btree (token);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Bill Bill_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bill"
    ADD CONSTRAINT "Bill_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."Room"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Bill Bill_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bill"
    ADD CONSTRAINT "Bill_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Checkout Checkout_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Checkout"
    ADD CONSTRAINT "Checkout_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InvoiceItem InvoiceItem_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MaintenanceRequest MaintenanceRequest_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MaintenanceRequest"
    ADD CONSTRAINT "MaintenanceRequest_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."Room"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MeterSubmission MeterSubmission_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MeterSubmission"
    ADD CONSTRAINT "MeterSubmission_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."Room"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MeterSubmission MeterSubmission_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MeterSubmission"
    ADD CONSTRAINT "MeterSubmission_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Parcel Parcel_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Parcel"
    ADD CONSTRAINT "Parcel_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."Room"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_billId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_billId_fkey" FOREIGN KEY ("billId") REFERENCES public."Bill"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PropertyStaff PropertyStaff_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropertyStaff"
    ADD CONSTRAINT "PropertyStaff_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public."Property"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PropertyStaff PropertyStaff_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropertyStaff"
    ADD CONSTRAINT "PropertyStaff_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Property Property_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Property"
    ADD CONSTRAINT "Property_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RegistrationCode RegistrationCode_usedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RegistrationCode"
    ADD CONSTRAINT "RegistrationCode_usedById_fkey" FOREIGN KEY ("usedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Room Room_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Room"
    ADD CONSTRAINT "Room_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public."Property"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SmsAddon SmsAddon_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SmsAddon"
    ADD CONSTRAINT "SmsAddon_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tenant Tenant_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."Room"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tenant Tenant_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Vehicle Vehicle_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vehicle"
    ADD CONSTRAINT "Vehicle_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict 05YQk86kfEfZ7TqpRaQc0WmDpLyycOhhfKT87cg26ye6chz7n4qeTy2fxrxh6fu

